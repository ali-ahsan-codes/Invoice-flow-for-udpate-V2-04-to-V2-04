@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Setup is incomplete. Run "Setup InvoiceFlow.bat" first.
    echo Your database and uploads will not be deleted.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" launch.py
if errorlevel 1 (
    echo.
    echo Startup failed. The message above explains the issue.
    echo Run "Diagnose InvoiceFlow.bat" or open INSTALLATION-GUIDE.html.
    pause
    exit /b 1
)


