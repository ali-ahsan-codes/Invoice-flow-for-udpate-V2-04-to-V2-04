-- NEW EMPTY DATABASE ONLY. Never drop/replace production tables.

-- Select the intended empty schema in MySQL Workbench first.

-- Runtime migrations complete additional batch/book indexes and constraints on startup.

CREATE TABLE IF NOT EXISTS backup_records (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	filename VARCHAR(255) NOT NULL, 
	size INTEGER NOT NULL, 
	created_at DATETIME, 
	PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS batches (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	name VARCHAR(80) NOT NULL, 
	numbering_mode VARCHAR(20) NOT NULL, 
	start_book INTEGER NOT NULL, 
	start_serial INTEGER NOT NULL, 
	archived BOOL NOT NULL,
	locked BOOL NOT NULL DEFAULT 0,
	hidden BOOL NOT NULL DEFAULT 0, 
	created_at DATETIME, 
	PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS detection_policy (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	manual_enabled BOOL NOT NULL, 
	automatic_enabled BOOL NOT NULL, 
	invoice_limit NUMERIC(13, 3), 
	user_daily_limit NUMERIC(13, 3), 
	batch_daily_limit NUMERIC(13, 3), 
	version INTEGER NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS live_revision (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	token VARCHAR(32) NOT NULL, 
	PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS system_settings (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	`key` VARCHAR(100) NOT NULL, 
	value TEXT NOT NULL, 
	updated_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (`key`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS users (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	username VARCHAR(80) NOT NULL, 
	email VARCHAR(120) NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	`role` VARCHAR(20) NOT NULL, 
	created_at DATETIME, 
	updated_at DATETIME, 
	last_login DATETIME, 
	preferred_start_serial INTEGER, 
	can_export BOOL, 
	api_key VARCHAR(64), 
	PRIMARY KEY (id), 
	UNIQUE (username), 
	UNIQUE (email)
,
 UNIQUE INDEX `ix_users_api_key` (`api_key`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_logs (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	user_id INTEGER NOT NULL, 
	action VARCHAR(50) NOT NULL, 
	details TEXT, 
	ip_address VARCHAR(45), 
	timestamp DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS books (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	batch_id INTEGER NOT NULL, 
	book_number INTEGER NOT NULL, 
	capacity INTEGER NOT NULL, 
	assigned_user_id INTEGER, 
	created_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_batch_book UNIQUE (batch_id, book_number), 
	FOREIGN KEY(batch_id) REFERENCES batches (id), 
	FOREIGN KEY(assigned_user_id) REFERENCES users (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS invoices (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	date DATE NOT NULL, 
	batch_id INTEGER NOT NULL, 
	serial_number VARCHAR(20) NOT NULL, 
	amounts_json TEXT NOT NULL, 
	total_amount NUMERIC(10, 3) NOT NULL, 
	created_by INTEGER NOT NULL, 
	updated_by INTEGER NOT NULL, 
	created_at DATETIME, 
	updated_at DATETIME, 
	media_required BOOL, 
	book_id INTEGER, 
	book_page INTEGER, 
	PRIMARY KEY (id), 
	serial_numeric BIGINT GENERATED ALWAYS AS (CAST(serial_number AS UNSIGNED)) STORED,
	CONSTRAINT uq_date_serial_numeric UNIQUE (date,serial_numeric),
	CONSTRAINT ck_positive_serial CHECK (serial_number <> '' AND serial_number NOT REGEXP '[^0-9]' AND serial_numeric BETWEEN 1 AND 2147483647),
	CONSTRAINT uq_batch_serial UNIQUE (batch_id, serial_number), 
	FOREIGN KEY(batch_id) REFERENCES batches (id), 
	FOREIGN KEY(created_by) REFERENCES users (id), 
	FOREIGN KEY(updated_by) REFERENCES users (id), 
	FOREIGN KEY(book_id) REFERENCES books (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS invoice_media (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	invoice_id INTEGER NOT NULL, 
	file_name VARCHAR(255) NOT NULL, 
	file_path VARCHAR(500) NOT NULL, 
	file_size INTEGER NOT NULL, 
	mime_type VARCHAR(100) NOT NULL, 
	uploaded_by INTEGER NOT NULL, 
	uploaded_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(invoice_id) REFERENCES invoices (id), 
	FOREIGN KEY(uploaded_by) REFERENCES users (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS review_cases (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	case_key VARCHAR(128) NOT NULL, 
	kind VARCHAR(20) NOT NULL, 
	batch_id INTEGER NOT NULL, 
	invoice_id INTEGER, 
	subject_user_id INTEGER, 
	invoice_date DATE NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	fingerprint VARCHAR(64) NOT NULL, 
	reasons_json TEXT NOT NULL, 
	snapshot_json TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	reviewed_by INTEGER, 
	reviewed_at DATETIME, 
	review_note TEXT, 
	resolution VARCHAR(120), 
	PRIMARY KEY (id), 
	UNIQUE (case_key), 
	FOREIGN KEY(batch_id) REFERENCES batches (id) ON DELETE CASCADE, 
	FOREIGN KEY(invoice_id) REFERENCES invoices (id) ON DELETE SET NULL, 
	FOREIGN KEY(subject_user_id) REFERENCES users (id) ON DELETE SET NULL, 
	FOREIGN KEY(reviewed_by) REFERENCES users (id) ON DELETE SET NULL
,
 INDEX `ix_review_invoice` (`invoice_id`),
 INDEX `ix_review_status_batch_date` (`status`,`batch_id`,`invoice_date`)
) ENGINE=InnoDB;

INSERT IGNORE INTO batches (id,name,numbering_mode,start_book,start_serial,archived,created_at) VALUES (1,'Batch 1','repeat',1,1,0,UTC_TIMESTAMP());

INSERT IGNORE INTO detection_policy (id,manual_enabled,automatic_enabled,version,updated_at) VALUES (1,1,1,1,UTC_TIMESTAMP());

INSERT IGNORE INTO live_revision (id,token) VALUES (1,REPLACE(UUID(),'-',''));

-- Create first admin with the prompted CLI; no passwords are placed in this script.

CREATE TABLE IF NOT EXISTS invoice_identity_reservations (
 date DATE NOT NULL,
 serial_numeric BIGINT NOT NULL,
 invoice_id INT NOT NULL,
 PRIMARY KEY (date,serial_numeric),
 KEY ix_invoice_identity_reservations_invoice_id (invoice_id),
 CONSTRAINT fk_identity_invoice FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Invoice notes/comments, their attachments, and invoice-to-invoice relations.
CREATE TABLE IF NOT EXISTS invoice_notes (
 id INTEGER NOT NULL AUTO_INCREMENT,
 invoice_id INTEGER NOT NULL,
 body TEXT,
 created_by INTEGER NOT NULL,
 created_at DATETIME,
 PRIMARY KEY (id),
 INDEX ix_invoice_notes_invoice_id (invoice_id),
 INDEX ix_invoice_notes_created_at (created_at),
 FOREIGN KEY(invoice_id) REFERENCES invoices (id) ON DELETE CASCADE,
 FOREIGN KEY(created_by) REFERENCES users (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS invoice_note_media (
 id INTEGER NOT NULL AUTO_INCREMENT,
 note_id INTEGER NOT NULL,
 file_name VARCHAR(255) NOT NULL,
 file_path VARCHAR(500) NOT NULL,
 file_size INTEGER NOT NULL,
 mime_type VARCHAR(100) NOT NULL,
 uploaded_by INTEGER NOT NULL,
 uploaded_at DATETIME,
 PRIMARY KEY (id),
 INDEX ix_invoice_note_media_note_id (note_id),
 FOREIGN KEY(note_id) REFERENCES invoice_notes (id) ON DELETE CASCADE,
 FOREIGN KEY(uploaded_by) REFERENCES users (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS invoice_links (
 id INTEGER NOT NULL AUTO_INCREMENT,
 invoice_id INTEGER NOT NULL,
 linked_invoice_id INTEGER NOT NULL,
 link_type VARCHAR(20) NOT NULL,
 amount_action VARCHAR(10) NOT NULL,
 merged_amount NUMERIC(10, 3),
 merged_line_index INTEGER,
 exclude_from_totals BOOLEAN NOT NULL DEFAULT FALSE,
 note TEXT,
 created_by INTEGER NOT NULL,
 created_at DATETIME,
 PRIMARY KEY (id),
 CONSTRAINT uq_invoice_link_pair UNIQUE (invoice_id, linked_invoice_id),
 CONSTRAINT ck_invoice_link_distinct CHECK (invoice_id <> linked_invoice_id),
 INDEX ix_invoice_links_invoice_id (invoice_id),
 INDEX ix_invoice_links_linked_invoice_id (linked_invoice_id),
 INDEX ix_invoice_links_created_at (created_at),
 FOREIGN KEY(invoice_id) REFERENCES invoices (id) ON DELETE CASCADE,
 FOREIGN KEY(linked_invoice_id) REFERENCES invoices (id) ON DELETE CASCADE,
 FOREIGN KEY(created_by) REFERENCES users (id)
) ENGINE=InnoDB;

-- IMPORTANT: run the offline Python schema upgrade to install and verify
-- invoices_reserve_ai and invoices_reserve_au BEFORE opening entry.


