-- =====================================================================
-- InvoiceFlow: MySQL upgrade for INVOICE NOTES, ATTACHMENTS & RELATIONS
-- =====================================================================
-- Use this on an EXISTING InvoiceFlow database (MySQL Workbench / any MySQL client).
-- It only ADDS three new tables. It does not ALTER or DELETE any existing table or row.
--
-- Before running:
--   1. Stop the InvoiceFlow server (no users writing) and take a full backup.
--   2. Select the InvoiceFlow schema first:  USE your_invoiceflow_database;
--   3. Run the whole file once. Re-running is safe (IF NOT EXISTS).
--
-- Afterwards, verify with the queries at the bottom of this file, then start the app.
-- The app refuses to start until these tables exist (startup gate).
-- The uploads folder also needs to be writable (notes attachments go to invoice_<id>/notes/).

-- Invoice notes/comments, their attachments, and invoice-to-invoice relations.
CREATE TABLE IF NOT EXISTS invoice_notes (
 id INTEGER NOT NULL AUTO_INCREMENT,
 invoice_id INTEGER NOT NULL,
 body TEXT,
 created_by INTEGER NOT NULL,
 created_at DATETIME,
 PRIMARY KEY (id),
 INDEX ix_invoice_notes_invoice_id (invoice_id),
 INDEX ix_invoice_notes_created_at (created_at),
 FOREIGN KEY(invoice_id) REFERENCES invoices (id) ON DELETE CASCADE,
 FOREIGN KEY(created_by) REFERENCES users (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS invoice_note_media (
 id INTEGER NOT NULL AUTO_INCREMENT,
 note_id INTEGER NOT NULL,
 file_name VARCHAR(255) NOT NULL,
 file_path VARCHAR(500) NOT NULL,
 file_size INTEGER NOT NULL,
 mime_type VARCHAR(100) NOT NULL,
 uploaded_by INTEGER NOT NULL,
 uploaded_at DATETIME,
 PRIMARY KEY (id),
 INDEX ix_invoice_note_media_note_id (note_id),
 FOREIGN KEY(note_id) REFERENCES invoice_notes (id) ON DELETE CASCADE,
 FOREIGN KEY(uploaded_by) REFERENCES users (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS invoice_links (
 id INTEGER NOT NULL AUTO_INCREMENT,
 invoice_id INTEGER NOT NULL,
 linked_invoice_id INTEGER NOT NULL,
 link_type VARCHAR(20) NOT NULL,
 amount_action VARCHAR(10) NOT NULL,
 merged_amount NUMERIC(10, 3),
 merged_line_index INTEGER,
 note TEXT,
 created_by INTEGER NOT NULL,
 created_at DATETIME,
 PRIMARY KEY (id),
 CONSTRAINT uq_invoice_link_pair UNIQUE (invoice_id, linked_invoice_id),
 CONSTRAINT ck_invoice_link_distinct CHECK (invoice_id <> linked_invoice_id),
 INDEX ix_invoice_links_invoice_id (invoice_id),
 INDEX ix_invoice_links_linked_invoice_id (linked_invoice_id),
 INDEX ix_invoice_links_created_at (created_at),
 FOREIGN KEY(invoice_id) REFERENCES invoices (id) ON DELETE CASCADE,
 FOREIGN KEY(linked_invoice_id) REFERENCES invoices (id) ON DELETE CASCADE,
 FOREIGN KEY(created_by) REFERENCES users (id)
) ENGINE=InnoDB;


-- ---------------------------------------------------------------------
-- Verification (should return 3 rows and 0 errors):
--   SELECT table_name FROM information_schema.tables
--    WHERE table_schema = DATABASE()
--      AND table_name IN ('invoice_notes','invoice_note_media','invoice_links');
-- ---------------------------------------------------------------------
