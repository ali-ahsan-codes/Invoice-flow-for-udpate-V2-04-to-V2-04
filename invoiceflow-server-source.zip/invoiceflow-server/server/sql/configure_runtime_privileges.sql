-- DBA ONLY, AFTER offline upgrade. CUSTOMIZE database/account/host BEFORE RUNNING.
-- Intended dedicated runtime account; do not revoke an unrelated shared account.
-- If this account already has blanket schema/global DDL or reservation DML,
-- inspect SHOW GRANTS and deliberately remove those broader grants first.
-- These additive GRANT statements do not revoke broader existing privileges.
GRANT SELECT ON invoiceflow_db.* TO 'invoiceflow_app'@'127.0.0.1';
GRANT EXECUTE ON PROCEDURE invoiceflow_db.invoiceflow_verify_identity_guards TO 'invoiceflow_app'@'127.0.0.1';
GRANT INSERT, UPDATE, DELETE ON invoiceflow_db.users TO 'invoiceflow_app'@'127.0.0.1';
GRANT INSERT, UPDATE, DELETE ON invoiceflow_db.batches TO 'invoiceflow_app'@'127.0.0.1';
GRANT INSERT, UPDATE, DELETE ON invoiceflow_db.books TO 'invoiceflow_app'@'127.0.0.1';
GRANT INSERT, UPDATE, DELETE ON invoiceflow_db.invoices TO 'invoiceflow_app'@'127.0.0.1';
GRANT INSERT, UPDATE, DELETE ON invoiceflow_db.invoice_media TO 'invoiceflow_app'@'127.0.0.1';
GRANT INSERT, UPDATE, DELETE ON invoiceflow_db.audit_logs TO 'invoiceflow_app'@'127.0.0.1';
GRANT INSERT, UPDATE, DELETE ON invoiceflow_db.backup_records TO 'invoiceflow_app'@'127.0.0.1';
GRANT INSERT, UPDATE, DELETE ON invoiceflow_db.system_settings TO 'invoiceflow_app'@'127.0.0.1';
GRANT INSERT, UPDATE, DELETE ON invoiceflow_db.live_revision TO 'invoiceflow_app'@'127.0.0.1';
GRANT INSERT, UPDATE, DELETE ON invoiceflow_db.detection_policy TO 'invoiceflow_app'@'127.0.0.1';
GRANT INSERT, UPDATE, DELETE ON invoiceflow_db.review_cases TO 'invoiceflow_app'@'127.0.0.1';
-- No runtime TRIGGER/DDL, no reservation INSERT/UPDATE/DELETE.
-- CLI backup/restore require separately configured maintenance privileges.


