-- =====================================================================
-- InvoiceFlow: MySQL upgrade for PER-USER PERMISSIONS
-- =====================================================================
-- Use this on an EXISTING InvoiceFlow database (MySQL Workbench / any MySQL client).
-- It only ADDS one new table (user_capabilities). It does not ALTER or DELETE any
-- existing table or row. Existing users keep today's access: with no row in this
-- table every function is allowed (data-entry users' export still follows the old
-- users.can_export flag).
--
-- Before running:
--   1. Stop the InvoiceFlow server (no users writing) and take a full backup.
--   2. Select the InvoiceFlow schema first:  USE your_invoiceflow_database;
--   3. Run the whole file once. Re-running is safe (IF NOT EXISTS).
--
-- Order: run upgrade_invoice_history.sql first if this database predates it.
-- The app refuses to start until this table exists (startup gate).

CREATE TABLE IF NOT EXISTS user_capabilities (
 id INTEGER NOT NULL AUTO_INCREMENT,
 user_id INTEGER NOT NULL,
 capability VARCHAR(40) NOT NULL,
 allowed BOOLEAN NOT NULL DEFAULT TRUE,
 updated_at DATETIME,
 updated_by INTEGER,
 PRIMARY KEY (id),
 CONSTRAINT uq_user_capability UNIQUE (user_id, capability),
 INDEX ix_user_capabilities_user_id (user_id),
 FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Verification (should return 1 row):
--   SELECT table_name FROM information_schema.tables
--    WHERE table_schema = DATABASE() AND table_name = 'user_capabilities';
-- ---------------------------------------------------------------------
