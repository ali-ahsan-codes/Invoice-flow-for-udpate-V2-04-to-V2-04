-- InvoiceFlow: additive amount-safety upgrade for existing batch release.

-- MySQL Workbench: select your existing schema, then File > Open SQL Script.

-- First: SELECT VERSION(); SELECT DATABASE(); Back up database AND uploads; stop writers.

-- Does not alter invoice values/IDs or require new columns on invoices.

-- MySQL 8.0+ / MariaDB; rerunnable CREATE TABLE IF NOT EXISTS.

-- Requires existing batches, invoices, users tables with compatible INT IDs.

-- STARTUP ALSO CREATES THESE TABLES. Do not mix schemas or run QA scripts here.



CREATE TABLE IF NOT EXISTS detection_policy (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	manual_enabled BOOL NOT NULL, 
	automatic_enabled BOOL NOT NULL, 
	invoice_limit NUMERIC(13, 3), 
	user_daily_limit NUMERIC(13, 3), 
	batch_daily_limit NUMERIC(13, 3), 
	version INTEGER NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS review_cases (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	case_key VARCHAR(128) NOT NULL, 
	kind VARCHAR(20) NOT NULL, 
	batch_id INTEGER NOT NULL, 
	invoice_id INTEGER, 
	subject_user_id INTEGER, 
	invoice_date DATE NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	fingerprint VARCHAR(64) NOT NULL, 
	reasons_json TEXT NOT NULL, 
	snapshot_json TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	reviewed_by INTEGER, 
	reviewed_at DATETIME, 
	review_note TEXT, 
	resolution VARCHAR(120), 
	PRIMARY KEY (id), 
	UNIQUE (case_key), 
	FOREIGN KEY(batch_id) REFERENCES batches (id) ON DELETE CASCADE, 
	FOREIGN KEY(invoice_id) REFERENCES invoices (id) ON DELETE SET NULL, 
	FOREIGN KEY(subject_user_id) REFERENCES users (id) ON DELETE SET NULL, 
	FOREIGN KEY(reviewed_by) REFERENCES users (id) ON DELETE SET NULL,
 INDEX ix_review_status_batch_date (status,batch_id,invoice_date),
 INDEX ix_review_invoice (invoice_id)
) ENGINE=InnoDB;

INSERT IGNORE INTO detection_policy (id,manual_enabled,automatic_enabled,invoice_limit,user_daily_limit,batch_daily_limit,version,updated_at) VALUES (1,1,1,NULL,NULL,NULL,1,UTC_TIMESTAMP());



-- After installing code, rescan through Amount safety / Recheck existing data,

-- or: python -m flask --app wsgi rescan-flags

-- Confirm the tables:

SHOW COLUMNS FROM detection_policy;

SHOW COLUMNS FROM review_cases;


