-- NEW INSTALL ONLY. DBA in Workbench; replace names/password/actual app host.
-- Existing installation: use preflight_batch_controls.sql, never create an
-- empty replacement by mistake. No database is dropped by this script.
SELECT VERSION();
CREATE DATABASE IF NOT EXISTS invoiceflow_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'invoiceflow_app'@'127.0.0.1' IDENTIFIED BY 'CHANGE_ME_STRONG_DB_PASSWORD';
GRANT SELECT ON invoiceflow_db.* TO 'invoiceflow_app'@'127.0.0.1';
USE invoiceflow_db;
SELECT DATABASE();
-- Next run python upgrade_database.py OFFLINE using a durable authorized DBA/
-- migration account, not this SELECT-only runtime account. MySQL binary logging
-- may require DBA authorization for trigger installation (error1419).
-- Keep the trigger/procedure definer account active with appropriate privileges.
-- Then inspect/customize configure_runtime_privileges.sql and apply its grants.
-- Set DATABASE_URL back to runtime credentials, diagnose, create first admin,
-- and launch. See INSTALLATION-GUIDE.html for full steps and backup tooling.
-- CREATE USER IF NOT EXISTS does NOT reset an existing account's password.


