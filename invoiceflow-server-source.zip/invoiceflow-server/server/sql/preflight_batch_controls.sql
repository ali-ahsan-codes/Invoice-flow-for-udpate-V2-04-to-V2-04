-- READ ONLY. Select YOUR existing database in Workbench. Back up first.
-- Stop ALL invoice writers, including external SQL/mobile clients, for upgrade.
SELECT DATABASE() AS selected_schema, VERSION() AS server_version;
-- Both result sets MUST be empty. Never delete/rewrite data automatically.
SELECT id, serial_number FROM invoices
WHERE serial_number = '' OR serial_number REGEXP '[^0-9]'
   OR CAST(serial_number AS UNSIGNED) NOT BETWEEN 1 AND 2147483647;
SELECT date, CAST(serial_number AS UNSIGNED) AS numeric_serial,
       COUNT(*) AS copies, GROUP_CONCAT(id ORDER BY id) AS invoice_ids
FROM invoices
GROUP BY date, CAST(serial_number AS UNSIGNED)
HAVING COUNT(*) > 1;
-- Run the canonical offline migration from your configured application folder:
-- python upgrade_database.py
-- Then run the following verification statements in Workbench:
-- SHOW COLUMNS FROM batches;
-- SHOW COLUMNS FROM invoices;
-- SHOW INDEX FROM invoices;
-- SHOW CREATE TABLE invoice_identity_reservations;
-- SHOW TRIGGERS WHERE `Table`='invoices';
-- SELECT COUNT(*) FROM invoices i LEFT JOIN invoice_identity_reservations r
-- ON r.invoice_id=i.id AND r.date=i.date AND r.serial_numeric=i.serial_numeric
-- WHERE r.invoice_id IS NULL; -- Must be 0.
-- Never edit, truncate, or omit the reservation table in backup/restore.

-- Startup repair also installs invoiceflow_verify_identity_guards().
-- Runtime needs EXECUTE on that procedure; normal startup does not do DDL.


