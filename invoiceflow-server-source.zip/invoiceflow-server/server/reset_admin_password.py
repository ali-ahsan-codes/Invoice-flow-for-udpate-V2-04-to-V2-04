import argparse
import getpass
import os
import sys

from app import create_app
from app.extensions import db
from app.models import User
from config import config


def main():
    parser = argparse.ArgumentParser(description="Reset an admin account password.")
    parser.add_argument(
        "--username",
        default="admin",
        help="Admin username to update (default: admin)",
    )
    args = parser.parse_args()

    password = getpass.getpass("New admin password: ")
    confirmation = getpass.getpass("Confirm new admin password: ")

    if not password:
        print("Error: Password cannot be empty.", file=sys.stderr)
        return 1
    if password != confirmation:
        print("Error: Passwords do not match.", file=sys.stderr)
        return 1

    config_name = os.environ.get("FLASK_CONFIG", "development")
    if config_name not in config:
        print(f"Error: Unknown configuration '{config_name}'.", file=sys.stderr)
        return 1

    app = create_app(config[config_name])
    with app.app_context():
        user = User.query.filter_by(username=args.username, role="admin").first()
        if user is None:
            print(f"Error: Admin user '{args.username}' was not found.", file=sys.stderr)
            return 1

        user.set_password(password)
        db.session.commit()

    print(f"Password reset successfully for admin user '{args.username}'.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


