# InvoiceFlow batch release — deployment and upgrade

## Important distinction
This package contains source, not your production database. The migration has been exercised on a synthetic 100-book legacy database. Your actual 100 completed books must be backed up, migrated and reconciled on your server. Do not import/re-enter those invoices. Do not run QA seeders against production.

## Supported deployment
Python 3.11+ (tested 3.13), MySQL/MariaDB (tested MySQL 8.4.7 and MariaDB), persistent upload and backup directories, and HTTPS. SQLite is not supported. Runtime assets/fonts are local. Linux production entrypoint is `wsgi:app`; Gunicorn is included. `run.py` / the Windows launcher are for local development, not a production service.

Use **one Gunicorn worker** with threads for this release. Live revisions are shared through the database, but restore status and the built-in backup scheduler are process-local. Multiple workers/hosts require external maintenance coordination and a single external backup scheduler; that topology has not been load-tested.

## Upgrade the completed 100-book installation
1. Stop all application workers, scheduled writers, mobile uploads and imports. Take a database dump **and a copy of uploads**, plus `.env`/old code. SQL backup alone does not contain attachment files. Keep an off-host copy. Test restoration in a disposable database first.
2. Restore a copy to staging. Preserve original invoice/book IDs, serial strings, dates, users, timestamps, media references and audit rows for before/after comparison. Record row counts and totals. Review nonnumeric/unpadded serials, missing book assignments and inconsistent capacities; the migration does not silently correct historical data.
3. Deploy the single `invoiceflow/` source directory. Preserve your private `.env`, upload and backup storage; install `requirements.txt` in a virtual environment. Do not copy demo/test data.
4. Set `DATABASE_URL` to the intended database, `SECRET_KEY` to a cryptographically random secret of at least 32 characters, and `SCHEDULER_ENABLED=False` during maintenance. `prepare_batches.py` reads `DATABASE_URL`, not `DEV_DATABASE_URL`.
5. While all writers remain stopped, run:
   ```sh
   python prepare_batches.py
   ```
   This initializes missing schema, gives existing books/invoices Batch ID 1, replaces global book/serial uniqueness with batch-scoped uniqueness, and installs a batch/book consistency FK. It preserves existing record IDs and does not rewrite historical assignments or timestamps. With exactly 100 Batch 1 books and only Batch 1 present, it creates empty Batch 2 books using the original capacities and assignments. It never fabricates missing legacy books or archives automatically. A mismatch stops the preparation and requires review (schema initialization may already have occurred).
6. Compare the migrated database against the backup: all original IDs, serial strings, dates, amounts, creators/updaters, timestamps, media references, history, 100 books, counts and totals. Open representative first/last books and attached files. Check gaps/cancelled pages as appropriate to your workflow. The UI's `entered` count need not equal printed capacity; verification is an administrator decision.
7. In **Batches**, verify Batch 2 printing. Select Batch 1 and review historical reports. Only then tick the verification checkbox and **Archive batch**. This blocks new entry/import in Batch 1; administrators can still correct its invoices/attachments. Select Batch 2 for entry. New logins select the newest open batch.
8. Test create/edit/delete, CSV exports/import previews, batch selector and camera attachments on the target devices. Log out/in after deployment and reload assets once. Resume writers only after acceptance. A database migration is not automatically rolled back by replacing code: rollback means restoring the pre-upgrade database, uploads and matching code together.

## Fresh installation
Create a MySQL/MariaDB database and a restricted account. Copy `.env.example` and replace placeholders. Then:
```sh
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
# Production environment loaded from .env by wsgi.py
python -m flask --app wsgi create-admin --username admin --email admin@example.com
```
Use Batches to configure actual printed ranges. The 100-book preparation helper is only for the existing installation, not an empty database. The create-admin command can reset an existing administrator: use deliberately.

## Production service
```sh
gunicorn --workers 1 --threads 4 --timeout 120 --bind 0.0.0.0:8000 wsgi:app
```
Run behind an HTTPS reverse proxy and a service manager; do not expose the backend/database publicly. Forward the original host/protocol correctly; preserve HTTPS CSRF Origin/Referer behavior. Set a consistent public URL for QR links. Production cookies require HTTPS. Set upload size/timeouts consistently in proxy and app. Restrict filesystem permissions, use least-privilege database credentials, monitor logs/disk space and test backup alerts.

Use `SCHEDULER_ENABLED=True` only in this single process if enabling the built-in scheduler; otherwise schedule backups externally. Backup commands require `mysqldump` and `mysql` on PATH for the preferred path. The SQLAlchemy fallback now includes every batch/book/revision but is not a replacement for a DBA-managed backup strategy. Backups include all batches; CSV exports use the selected batch. A backup request can include API keys and private business data: keep files private.

`MAINTENANCE_MODE=True` returns a 503 before request database access. Startup still checks schema. For schema replacement, stop workers rather than relying on request-only maintenance mode.

## Offline restore (recommended)
Web restore is **disabled by default** (`ALLOW_WEB_RESTORE=False`) to prevent destructive operations in a live threaded deployment. Confirmation screens remain available. Only enable it on a separately isolated, single-process maintenance instance after staging validation; async web upload/progress and failure recovery are not acceptance-tested for production.

1. Stop all app workers/schedulers and restrict incoming traffic. Make a new database + upload backup.
2. Restore a trusted dump using DBA tooling into an empty/replacement database. Never execute an untrusted SQL upload.
3. Restore matching uploads and environment. Start one offline schema-verification process, e.g. `SCHEDULER_ENABLED=False python -c 'import wsgi'`. A restored pre-batch dump needs the normal batch upgrade/verification workflow again; a post-batch dump must preserve its batch IDs.
4. Verify counts, totals, batch IDs, attachment files, users and audit history. Clear old login sessions or rotate the secret if appropriate. Restart only after validation.

CLI and fallback restore roundtrips were tested on disposable batch data. Actual production recovery, attachment-file restoration, asynchronous web restore, large dumps and interrupted-restore recovery remain operational acceptance tasks.

## QR/mobile compatibility
Each invoice payload includes `id`, `batch_id` and `batch_name`. QR v2 includes immutable invoice ID, batch ID and serial. Web links use `?batch_id=N`; list/next/previous/upload requests should preserve that value. When multiple batches exist, serial API endpoints require `batch_id` even if that user currently sees only one match. Old web serial-only QR codes return 409 when ambiguous, rather than choosing arbitrarily. Select a batch in the scanner; mark/sticker physical books with their batch identity. No native mobile app source was supplied; update that client to send batch identity before using repeated numbers.

## Limits that matter
CSV invoice imports are row-wise: successful rows remain committed when later rows fail. Review the detailed error report and retry rejected rows; do not assume whole-file rollback. Locked/archived batches reject normal-user imports/writes; administrators can still enter/import/correct. Hidden batches are inaccessible to normal users. Normal forms and API values normalize new numeric serials; historical serial strings are preserved. Eight recent batch work sessions are retained in the signed session cookie; very old tabs may need a new work session. Simultaneous edits to the same invoice use a version check; simultaneous drafts in one session are not collaborative editing. Hardware camera/HTTPS behavior and production-scale throughput need target-environment validation.

## Amount-safety upgrade
See INSTALLATION-GUIDE.html for the complete Workbench and new-PC setup. Additive `sql/upgrade_amount_safety.sql` creates detection_policy/review_cases with existing batch/user/invoice parents; no old invoice columns/data are rewritten. After code installation, run `python -m flask --app wsgi rescan-flags` or save Detection settings. Default manual amounts are blank; automatic heuristics are enabled. Checks use invoice date; user and combined totals are batch-scoped. A clear requires admin verification note; unchanged verified snapshots remain cleared. No native client changes are needed to store flags; review is admin-only in the browser.
Windows WSGI: `.venv\Scripts\waitress-serve.exe --listen=0.0.0.0:8000 --threads=4 wsgi:app`, behind HTTPS. Waitress is included; actual Windows host/service testing remains a local acceptance task.

## Stability patch upgrade (9 October 2026)
No schema change relative to the amount-safety release. Back up database and uploads, stop the application, replace code/templates/static files, retain `.env` and data directories, restart one threaded WSGI process. The bundled main/realtime/CSS URLs carry a release version so fresh pages load the fix. Existing tabs still run old JavaScript: finish or copy unsaved drafts before closing/reopening them once during deployment. Never ask an operator to reload a draft mid-entry.

Editor containers are not replaced by polling. Only read-only data regions update beside them. Dirty settings/verification notes are retained; a stale verification/version is rejected server-side. Initial HTML carries its revision. Quiet snapshot endpoints suppress session/auth cookies and action flash consumption, preventing stale background responses from overwriting foreground state. Drafts are held in the open page, **not a durable autosave**: browser crash, intentional navigation/reload or closing the tab can still lose unsaved input. Same-login multi-tab draft collaboration remains outside scope.

## Batch controls and historical identity reservations · 9 October 2026

**This release requires a database upgrade**, even if amount safety is already installed.

| Batch state | Normal users | Administrators |
|---|---|---|
| Open | Usual authorized entry and viewing | Full access |
| Locked or archived | Read-only; no invoice/book/media mutations | Can enter and correct records |
| Hidden | Not listed or accessible by direct link/API | Visible and editable |

Administrators have View, Lock/Unlock, Hide/Unhide and Archive/Unarchive controls. States are independent and reversible; unarchive does not silently unlock/unhide. Archiving requires verification. Permission changes sync without resetting typed fields: a remote lock disables saves; a hidden workspace preserves the local draft with an access notice.

**Identity rule:** the same invoice date + numeric serial is reserved globally across all batches and states. Leading zeros are ignored. Every date/serial combination used by an invoice remains owned by that invoice, even after corrections. Only deleting that invoice releases all its combinations. Administrators cannot override this rule. An invoice can return to its own historical combination. Different dates can use the same serial in different batches, provided neither combination is reserved; the existing within-batch physical-page uniqueness still applies. CSV rename/skip/overwrite cannot evade another invoice's reservation.

### Additive schema and enforcement
- `batches.locked` and `batches.hidden`: non-null Boolean flags, default false.
- `invoices.serial_numeric`: persisted generated BIGINT, unsigned numeric cast of the preserved serial string.
- `uq_date_serial_numeric`: global unique index on current date/numeric serial; positive ASCII numeric serial check (1 through 2147483647).
- `invoice_identity_reservations`: composite primary key `(date, serial_numeric)`, owning `invoice_id` FK with ON DELETE CASCADE and invoice lookup index. No ownership transfer on correction.
- `invoices_reserve_ai` and `invoices_reserve_au`: AFTER INSERT/UPDATE database triggers claim keys transactionally. Conflicting ownership raises `INVOICE_IDENTITY_RESERVED` and rolls back the statement. Unique-key locking protects simultaneous claims, including ordinary raw SQL writes. App services check reservations first for readable errors.
- The reservation table is internal: never manually update/truncate/delete it. A privileged DBA can disable database protections; direct destructive schema operations are not an application permission boundary.
- Current and historical keys are included in CLI and fallback backups. Restore child-table ordering and computed-column exclusion are handled. Replacing the database with an older backup necessarily restores that backup's historical state; do not restore partial invoice-only dumps.

### Offline upgrade procedure (existing installation)
1. Finish/save drafts. Stop the application, scheduler and **all other writers**, including direct SQL clients. Back up the full database, uploaded files, configuration and matching source. Rehearse on a staging copy of the exact target server version.
2. In Workbench select the intended schema and run `sql/preflight_batch_controls.sql`. Both invalid-serial and duplicate-date/numeric-serial result sets must be empty. Conflicts report original IDs; the migration never deletes, renumbers or rewrites them. Resolve legitimate corrections manually with the data owner before retrying. Do not run fresh-install SQL over existing data.
3. Replace source while retaining `.env` and uploads. Install `requirements.txt`. Set `DATABASE_URL` to the intended schema, then run `python upgrade_database.py` while offline. Normal development uses `DATABASE_URL` too; any existing `DEV_DATABASE_URL` explicitly overrides it only for development, so align/remove that override. Offline schema account needs authorized CREATE/ALTER/INDEX/REFERENCES/TRIGGER/CREATE ROUTINE/ALTER ROUTINE and metadata privileges (MySQL binary logging may require DBA authorization); use a least-privilege runtime account after controlled upgrades where appropriate. MySQL DDL is not rollback-safe: a failure may leave additive changes; keep offline, inspect the error and recover from the matching backup if needed.
4. Run the verification statements in the preflight SQL comments. Confirm both reservation triggers and zero missing current reservations; reconcile original invoice/book IDs, dates, serial strings, amounts, counts, timestamps, media and audit rows.
5. Verify admin and normal-user permissions, corrections, historical duplicate rejection, deletion/reuse and a complete backup/restore in staging. Restart the application and reopen pages once for the new assets. Preserve original 100 books; `prepare_batches.py` remains the separate guarded helper for preparing an empty repeated-number Batch 2.

**Historical boundary:** at upgrade, all existing invoices' current keys are reserved. Older date/serial values corrected before this feature was installed cannot be reliably reconstructed and are not claimed. From installation onward, every successfully committed key is retained until invoice deletion. Rolled-back writes do not reserve keys.

New installations also run `python upgrade_database.py` after database/config setup and before entry. The fresh SQL schema alone is not sufficient: the Python migration installs/verifies the triggers. Your exact MySQL/Workbench installation must be validated in staging; this release was exercised on MySQL 8.4.7 and MariaDB on Linux, not physical Windows/Workbench.

## Startup repair release
Read `INSTALLATION-GUIDE.html` for the authoritative setup/recovery steps. New tools: `Setup InvoiceFlow.bat`, `Diagnose InvoiceFlow.bat`, `launch.py`, `diagnose.py`, `configure.py`. Normal startup never migrates. Run `upgrade_database.py` offline with authorized migration privileges before diagnosis/launch. Verification uses a parameterless SQL SECURITY DEFINER procedure (`invoiceflow_verify_identity_guards`); runtime requires EXECUTE, not TRIGGER privileges. Runtime should have SELECT only on reservation rows. PyMySQL[rsa] supports MySQL caching-SHA2 authentication. Existing admin credentials are not reapplied from legacy config during startup.


