"""Initialize a random secret only if blank/placeholder. Never overwrites DB settings."""
from pathlib import Path
import argparse
import secrets
import re

ROOT = Path(__file__).resolve().parent

def initialize_secret(path):
    data = path.read_text(encoding='utf-8-sig')
    pattern = re.compile(r'^SECRET_KEY=(.*)$', re.M)
    match = pattern.search(data)
    if match and match.group(1).strip() and 'CHANGE_ME' not in match.group(1).upper():
        return False
    replacement = 'SECRET_KEY='+secrets.token_hex(32)
    data = pattern.sub(replacement,data) if match else data+'\n'+replacement+'\n'
    path.write_text(data,encoding='utf-8'); return True

if __name__ == '__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--initialize-secret',action='store_true');args=parser.parse_args()
    if args.initialize_secret:
        path=ROOT/'.env'
        if not path.exists(): path.write_text((ROOT/'.env.example').read_text(),encoding='utf-8')
        print('Random secret initialized.' if initialize_secret(path) else 'Existing secret preserved.')


