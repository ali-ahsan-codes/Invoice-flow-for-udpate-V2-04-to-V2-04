# Deploy checklist — Notes, attachments, invoice links, mobile API and user permissions

This release adds **four new MySQL tables** and changes **no existing table, column or row**.
Read `DEPLOYMENT.md` and `INSTALLATION-GUIDE.html` for general installation. This page covers only
what changed and what you must do.

## 1. What changed

| Area | Change |
|---|---|
| Database | New tables: `invoice_notes`, `invoice_note_media`, `invoice_links` (has `exclude_from_totals`), `user_capabilities` (per-user permissions). No existing table is altered. |
| Permissions | Admin decides, per data-entry user, which functions they may use (see section 1a). Default for everyone: allowed, so nothing changes until an admin switches something off. |
| Web app | Notes (text + attachments) on each invoice; links to other invoices (same or other batch) as Related / Duplicate / Adjusted; optional amount merge; for a merge you choose whether the other invoice is **excluded from totals** (default: exclude) or both stay in totals; history on the invoice page. |
| Reports | Money totals (dashboard, analytics, summary, daily/monthly totals, book totals, exports) leave out an invoice whose amount was merged into another invoice with *exclude* chosen. Page usage is unchanged. The book *average* is per counted invoice. |
| Mobile API (`/api/v1`) | New, all with `X-API-Key` and `batch_id`: `GET /invoices/<serial>/history`, `POST /invoices/<serial>/notes`, `DELETE /invoices/<serial>/notes/<id>`, `GET /invoices/<serial>/notes/attachments/<media_id>`, `POST /invoices/<serial>/links`, `DELETE /invoices/<serial>/links/<id>`. `GET /me` now also returns `capabilities`. Existing endpoints are unchanged. |
| Upload types | `ALLOWED_EXTENSIONS` covers ordinary documents and images (PDF, Word, Excel, CSV, PowerPoint, text, images incl. WEBP/HEIC, zip/7z/rar). Executables, scripts, HTML and SVG are refused. Type is decided by the file extension. |
| Fixes | Sample CSV download (`/import-export/sample-csv`) no longer fails with a NameError. CSV export no longer crashes for users without export permission. Dead code removed (unused imports and functions). |
| Android | *Notes & links* screen for the focused invoice. Actions follow the admin's switches; a clerk whose mobile access is off cannot connect. Install the new APK. |
| Files | Note attachments are stored under `UPLOAD_FOLDER/invoice_<id>/notes/`. |

### 1a. Permissions (Admin → Users → key icon)

Each data-entry user has these switches (admins always have everything):

| Key | Function |
|---|---|
| `mobile.access` | Use the mobile scanner app (API key connections) |
| `invoice.create` | Create invoices |
| `invoice.edit` | Edit invoices (own invoices only, as before) |
| `invoice.delete` | Delete invoices (own invoices only, as before) |
| `media.upload` | Upload photos and documents (web, scanner page, mobile) |
| `media.delete` | Delete uploaded files |
| `notes.create` | Add notes and note attachments |
| `notes.delete` | Delete notes |
| `links.create` | Link invoices (merge or relation), mark duplicate/adjustment |
| `links.delete` | Remove links |
| `data.export` | Download CSV exports (also follows the old *Allow Export* checkbox) |
| `data.import` | Import invoices, books, legacy files and download the sample CSV |

Buttons are hidden when a switch is off, and the server refuses the action anyway (403 with a clear message).
Viewing invoices, notes and links is not switched off. Analytics, users, backups and settings stay admin-only.
Buttons: **Save permissions**, **Allow all**, **Turn off all**, **Reset to defaults** (removes every custom setting).

## 2. Before you start (mandatory)

1. Announce downtime and stop all users from writing (close the app).
2. Take a **full MySQL backup** of the InvoiceFlow schema (Workbench: *Server → Data Export*).
3. Back up the uploads folder (`UPLOAD_FOLDER`, default `uploads/`).
4. Keep the current source folder until the new one is verified.

## 3. Create the new tables — choose ONE option

The four tables are: `invoice_notes`, `invoice_note_media`, `invoice_links`, `user_capabilities`.

### Option A — MySQL Workbench (manual)

1. Open `sql/upgrade_invoice_history.sql` in Workbench, select the schema (`USE your_invoiceflow_database;`), run the whole script.
   It creates the first three tables. Re-running is safe.
2. Open `sql/upgrade_user_permissions.sql`, select the same schema, run the whole script. It creates `user_capabilities`.
3. Verify (must return **4 rows**):
   ```sql
   SELECT table_name FROM information_schema.tables
    WHERE table_schema = DATABASE()
      AND table_name IN ('invoice_notes','invoice_note_media','invoice_links','user_capabilities');
   ```
4. Check the report-exclusion column (must return **1 row**):
   ```sql
   SELECT column_name FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'invoice_links'
      AND column_name = 'exclude_from_totals';
   ```
   If you ran an **earlier copy** of `upgrade_invoice_history.sql` from before this column existed and the query
   returns 0 rows, run once: `ALTER TABLE invoice_links ADD COLUMN exclude_from_totals BOOLEAN NOT NULL DEFAULT FALSE;`
   The app also refuses to start with `Database schema behind: invoice_links` if the column is missing.
5. Check the permissions table constraints (`SHOW CREATE TABLE user_capabilities\G`): `uq_user_capability`
   (user_id, capability) and a cascade foreign key to `users`.

### Option B — Python upgrade (automatic)

Run `python upgrade_database.py` offline with `DATABASE_URL` pointing at the target schema and the migration
account. It creates every missing table (including `user_capabilities`) and the column, then verifies them.
Use Option A **or** Option B, not both. Both produce the same tables.

## 4. Why the app refuses to start until step 3 is done

On startup the app runs a read-only check. If a table or the column is missing it stops with:

```
Database schema not ready: missing ['user_capabilities', ...]. Back up, stop all writers and run python upgrade_database.py ...
```

This is intentional. The app never creates tables at normal startup.

## 5. Permissions (database accounts)

- **Migration account** (Option B, or Workbench as admin): CREATE, REFERENCES, INDEX on the schema.
- **Runtime account** (the one in `DATABASE_URL`): needs `SELECT, INSERT, UPDATE, DELETE` on the four new tables
  (skip if it already has schema-wide DML grants):
  ```sql
  GRANT SELECT, INSERT, UPDATE, DELETE ON your_invoiceflow_database.invoice_notes TO 'invoiceflow_runtime'@'%';
  GRANT SELECT, INSERT, UPDATE, DELETE ON your_invoiceflow_database.invoice_note_media TO 'invoiceflow_runtime'@'%';
  GRANT SELECT, INSERT, UPDATE, DELETE ON your_invoiceflow_database.invoice_links TO 'invoiceflow_runtime'@'%';
  GRANT SELECT, INSERT, UPDATE, DELETE ON your_invoiceflow_database.user_capabilities TO 'invoiceflow_runtime'@'%';
  FLUSH PRIVILEGES;
  ```

## 5a. Is this done automatically or by hand?

- **Option A (Workbench / SQL files):** manual. You run the scripts; nothing runs at app start.
- **Option B (`upgrade_database.py`):** automatic. It creates the missing tables and column with the migration account.
- **App start:** never creates or alters anything. It checks the tables and the column and stops if they are missing.
- **Existing users after the upgrade:** no action needed. They keep their current access until an admin changes it.

## 6. Start and verify

```bash
# Validate configuration without binding a port
python launch.py --check

# Production, Linux (same command as DEPLOYMENT.md; put HTTPS in front)
gunicorn --workers 1 --threads 4 --timeout 120 --bind 0.0.0.0:8000 wsgi:app

# Production, Windows
.venv\Scripts\waitress-serve.exe --listen=0.0.0.0:8000 --threads=4 wsgi:app
```

Smoke test:

1. Sign in as admin → **Users** → key icon on a data-entry user → turn **Link invoices** off → Save.
2. Sign in as that user → open an invoice → the link form is hidden. Turn it back on as admin.
3. Open an invoice → add a note with a PDF → it appears; download the attachment.
4. Link two invoices (relation only, no amount) → both show the link.
5. Merge with *exclude* → dashboard total counts the amount once.
6. Mobile: with `mobile.access` on, the app connects; with it off, the app shows *Your admin has not allowed you to use the mobile app.*

## 7. Rollback

- Code: restore the previous source folder and restart.
- Data: the new tables are additive. Rolling back the code is safe; the tables can stay. Drop them only
  from a restored backup, never by hand on a live system.

## 8. Known limits (read before go-live)

- **Merged amounts:** the merge adds the source total to the receiving invoice. The source keeps its own
  amount. If you chose *exclude from totals*, the source is left out of money totals, so the amount is
  counted once. If you chose *keep both*, it is counted twice, by your choice.
- **Book page usage** still counts an excluded invoice as a used page (it physically occupies the page).
  The book *average* is per counted invoice, so an excluded invoice does not lower it.
- **Permissions default to allowed.** Existing and new data-entry users get every function until an admin
  switches it off. Set your switches before you hand out accounts if you want a restricted default.
- **Permissions are per user, not per batch.** Data-entry users still only change invoices they created.
- **Android build:** the new Android code was written and statically checked but could not be compiled in
  the sandbox (no Java/Android SDK). Build it in Android Studio and run its unit tests before release.
- Links to invoices in **hidden batches** are only possible for administrators.
- An invoice with links cannot be deleted until its links are removed.
- Tested on SQLite in development and on the MySQL DDL generated from the models. Run the staging test in
  section 9 against your real MySQL 8.x or MariaDB before production.

## 9. Staging test (recommended)

1. Restore the production backup into a staging schema.
2. Run section 3 and section 6 against staging.
3. Run the smoke test in section 6 and one cross-batch link.
