# Deploy checklist — Invoice notes, attachments & invoice relations

This release adds **three new MySQL tables** and no changes to existing tables or data.
Read `DEPLOYMENT.md` and `INSTALLATION-GUIDE.html` for general installation. This page covers
only what changed and what you must do.

## 1. What changed

| Area | Change |
|---|---|
| Database | New tables: `invoice_notes`, `invoice_note_media`, `invoice_links`. Existing tables are not altered. |
| Web app | Notes (text + attachments) on each invoice; links to other invoices (same or other batch) as Related / Duplicate / Adjusted; optional amount merge; history on the invoice page. |
| API | New JSON endpoint `GET /invoices/<id>/history`. Existing `/api/v1/*` endpoints are unchanged, so the Android app needs no change to keep working. |
| Files | Note attachments are stored under `UPLOAD_FOLDER/invoice_<id>/notes/`. |

## 2. Before you start (mandatory)

1. Announce downtime and stop all users from writing (close the app).
2. Take a **full MySQL backup** of the InvoiceFlow schema (Workbench: *Server → Data Export*).
3. Back up the uploads folder (`UPLOAD_FOLDER`, default `uploads/`).
4. Keep the current source folder until the new one is verified.

## 3. Create the new tables — choose ONE option

### Option A — MySQL Workbench (manual, recommended if you prefer SQL)

1. Open `sql/upgrade_invoice_history.sql` in Workbench.
2. Select the InvoiceFlow schema: `USE your_invoiceflow_database;` (or pick it in the schema list first).
3. Run the whole script (lightning bolt icon / Ctrl+Shift+Enter).
4. Run the verification query at the bottom of the file. It must return **3 rows**:
   ```sql
   SELECT table_name FROM information_schema.tables
    WHERE table_schema = DATABASE()
      AND table_name IN ('invoice_notes','invoice_note_media','invoice_links');
   ```
5. Check the constraints exist:
   ```sql
   SHOW CREATE TABLE invoice_links\G
   ```
   You should see `uq_invoice_link_pair`, `ck_invoice_link_distinct` and two `ON DELETE CASCADE` foreign keys.

Running the script again is safe (`CREATE TABLE IF NOT EXISTS`).

### Option B — Python upgrade (automatic)

```bash
# Linux / macOS
cd /path/to/invoiceflow/server
source .venv/bin/activate
DATABASE_URL='mysql+pymysql://migration_user:PASSWORD@127.0.0.1:3306/invoiceflow' python upgrade_database.py

# Windows
.venv\Scripts\python.exe upgrade_database.py      (with DATABASE_URL set in .env)
```

`upgrade_database.py` calls `db.create_all()`, which creates the three missing tables and
leaves existing tables untouched. It then verifies the triggers and identity reservations
that were already in place. It needs the migration account (CREATE privilege), not the runtime account.

Use Option A **or** Option B, not both. Both produce identical tables.

## 4. Why the app refuses to start until step 3 is done

On startup the app runs a read-only check. If the three tables are missing it stops with:

```
Database schema not ready: missing ['invoice_links', ...]. Back up, stop all writers and run python upgrade_database.py ...
```

This is intentional. The app never creates tables at normal startup. If you see this message,
run Option A or B and start again.

## 5. Permissions

- **Migration account** (Option B or Workbench as admin): CREATE, REFERENCES, INDEX on the schema.
- **Runtime account** (the one in `DATABASE_URL` for the server): needs `SELECT, INSERT, UPDATE, DELETE`
  on the three new tables, in addition to its existing grants. If you use a least-privilege account:
  ```sql
  GRANT SELECT, INSERT, UPDATE, DELETE ON your_invoiceflow_database.invoice_notes TO 'invoiceflow_runtime'@'%';
  GRANT SELECT, INSERT, UPDATE, DELETE ON your_invoiceflow_database.invoice_note_media TO 'invoiceflow_runtime'@'%';
  GRANT SELECT, INSERT, UPDATE, DELETE ON your_invoiceflow_database.invoice_links TO 'invoiceflow_runtime'@'%';
  FLUSH PRIVILEGES;
  ```
  (Replace the names with yours. Skip this if the runtime account already has schema-wide DML grants.)

## 6. Start and verify

```bash
# Validate configuration without binding a port
python launch.py --check
python diagnose.py

# Development / local
python launch.py --no-browser

# Production (Linux)
gunicorn --workers 1 --threads 4 --timeout 120 --bind 0.0.0.0:8000 wsgi:app
```

Smoke test in the browser:

1. Log in as a data-entry user; open any invoice.
2. **Notes:** add a text note, then a note with a PDF/PNG. Download the attachment.
3. **Links:** link the invoice to another invoice (same batch first). Try *Duplicate* with *Merge*:
   the amount line should be added and the total updated. Then remove the link: the amount should go back.
4. Try to delete a linked invoice: it must be refused until it is unlinked.
5. Open the Android app and load one invoice and upload one photo: it must work as before.

## 7. Rollback

Rollback is only needed if the new code must be removed. Dropping the new tables deletes all notes,
attachments records and links, so take a backup first.

1. Stop the server and deploy the previous source folder.
2. Only if you must remove the feature data:
   ```sql
   DROP TABLE invoice_note_media;
   DROP TABLE invoice_notes;
   DROP TABLE invoice_links;
   ```
   Also delete `uploads/invoice_*/notes/` if you want the files removed.
3. Invoices, amounts, media and audit logs are not affected by the rollback itself.
   Note: merged amount lines stay on the receiving invoice (they are normal amount lines); review
   them manually if you removed links before rolling back.

## 8. Known limits (read before go-live)

- **Merged amounts are counted twice in totals** unless you exclude the source invoice in reports.
  The merge adds the source total to the receiving invoice; the source keeps its own amount.
- Links to invoices in **hidden batches** are only possible for administrators.
- An invoice with links cannot be deleted until its links are removed.
- Tested on SQLite in development and on the MySQL DDL generated from the models. Run the
  staging test below against your real MySQL 8.x or MariaDB before production.

## 9. Staging test (recommended)

1. Restore the production backup into a staging schema.
2. Run section 3 and section 6 against staging.
3. Run the smoke test in section 6 and one cross-batch link.
