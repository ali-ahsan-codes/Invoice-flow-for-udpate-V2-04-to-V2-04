"""Offline, additive schema upgrade. Stop ALL writers and back up DB+uploads first.
Uses DATABASE_URL (not DEV_DATABASE_URL). Never removes legacy conflicts.
"""
import os
from dotenv import load_dotenv
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '.env'), encoding='utf-8-sig')
if not os.environ.get('DATABASE_URL'):
    raise SystemExit('Set DATABASE_URL to the intended schema; no default database is used.')
os.environ['SCHEDULER_ENABLED'] = 'False'
from app import create_app
from app.extensions import db
from sqlalchemy import text
try:
    app = create_app(upgrade_schema=True)
except Exception as exc:
    from app.startup import explain_error
    raise SystemExit('OFFLINE UPGRADE FAILED: '+explain_error(exc)+'\nKeep writers stopped; database DDL may have partly completed. Restore matching backups or consult your DBA.') from None
with app.app_context():
    from app.utils.db_utils import verify_schema
    verify_schema()
    missing = db.session.execute(text('SELECT COUNT(*) FROM invoices i LEFT JOIN invoice_identity_reservations r ON r.invoice_id=i.id AND r.date=i.date AND r.serial_numeric=i.serial_numeric WHERE r.invoice_id IS NULL')).scalar()
    if missing: raise SystemExit('Identity verification failed. Keep application offline.')
    print('Batch controls and current/historical identity reservations verified.')
    print('Existing invoice IDs, dates, serial strings, amounts and uploads were not rewritten.')
    print('History tracking begins with the current keys at upgrade; unavailable older keys cannot be reconstructed.')


