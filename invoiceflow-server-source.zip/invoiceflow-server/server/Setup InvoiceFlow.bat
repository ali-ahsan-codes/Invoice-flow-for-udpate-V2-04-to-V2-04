@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 goto USE_PYTHON
py -3 -c "import sys; assert sys.version_info >= (3,11)" >nul 2>&1
if errorlevel 1 goto PYTHON_ERROR
if not exist ".venv\Scripts\python.exe" py -3 -m venv .venv
if errorlevel 1 goto FAIL
goto INSTALL
:USE_PYTHON
where python >nul 2>&1
if errorlevel 1 goto PYTHON_ERROR
python -c "import sys; assert sys.version_info >= (3,11)" >nul 2>&1
if errorlevel 1 goto PYTHON_ERROR
if not exist ".venv\Scripts\python.exe" python -m venv .venv
if errorlevel 1 goto FAIL
:INSTALL
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto FAIL
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto FAIL
if not exist ".env" copy /y ".env.example" ".env" >nul
".venv\Scripts\python.exe" configure.py --initialize-secret
if errorlevel 1 goto FAIL
echo.
echo Dependencies installed. Existing .env values and data are preserved.
echo Edit .env and set DATABASE_URL to your MySQL database.
echo BACK UP your DB and uploads. Stop all writers before upgrading.
goto SUCCESS
:PYTHON_ERROR
echo Install Python 3.11 or newer from python.org and include it in PATH.
echo Tested on Python 3.13. Do not rename an old virtual environment.
goto FAIL
:SUCCESS
echo Database upgrade: .venv\Scripts\python.exe upgrade_database.py
echo Then run Diagnose InvoiceFlow.bat, and Invoicing app.bat.
pause
exit /b 0
:FAIL
echo Setup failed. Read the error above. No database or uploads were deleted.
pause
exit /b 1


