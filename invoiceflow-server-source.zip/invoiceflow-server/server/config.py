# config.py

import os
from dotenv import load_dotenv

load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '.env'), encoding='utf-8-sig')


def _mb(n):
    return n * 1024 * 1024


class Config:
    """Base configuration."""
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    DEBUG = False
    TESTING = False

    # Database
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DATABASE_URL',
        os.environ.get('DEV_DATABASE_URL', '')
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'isolation_level': 'READ COMMITTED',
        'pool_size': 10,
        'pool_recycle': 3600,
        'pool_pre_ping': True,
    }

    ALLOW_WEB_RESTORE = os.environ.get('ALLOW_WEB_RESTORE', 'False').lower() == 'true'
    MAINTENANCE_MODE = os.environ.get('MAINTENANCE_MODE', 'False').lower() == 'true'

    SCHEDULER_ENABLED = os.environ.get('SCHEDULER_ENABLED', 'True').lower() == 'true'

    # Backup settings
    BACKUP_INTERVAL_MINUTES = int(os.environ.get('BACKUP_INTERVAL_MINUTES', 2))
    BACKUP_RETENTION_COUNT = int(os.environ.get('BACKUP_RETENTION_COUNT', 20))
    BACKUP_DIR = os.environ.get('BACKUP_DIR', 'backups')

    # Upload settings
    UPLOAD_FOLDER = os.environ.get('UPLOAD_FOLDER', 'uploads')

    # Global request size limit — also governs the SQL backup upload endpoint.
    # Raise via env (in MB) if you regularly restore backups larger than 256 MB.
    BACKUP_UPLOAD_MAX_MB = int(os.environ.get('BACKUP_UPLOAD_MAX_MB', 256))
    MAX_CONTENT_LENGTH = _mb(BACKUP_UPLOAD_MAX_MB)

    ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx'}

    # Media requirement
    MEDIA_REQUIRED = os.environ.get('MEDIA_REQUIRED', 'False').lower() == 'true'

    # Session
    SESSION_COOKIE_SECURE = os.environ.get('SESSION_COOKIE_SECURE', 'False').lower() == 'true'
    REMEMBER_COOKIE_DURATION = 60 * 60 * 24 * 7  # 7 days

    # Pagination
    INVOICES_PER_PAGE = 50


class DevelopmentConfig(Config):
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DEV_DATABASE_URL',
        Config.SQLALCHEMY_DATABASE_URI
    )
    SESSION_COOKIE_SECURE = False


class ProductionConfig(Config):
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', '')
    REMEMBER_COOKIE_SECURE = True
    SESSION_COOKIE_SAMESITE = "Lax"
    DEBUG = False
    SESSION_COOKIE_SECURE = True


class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'TEST_DATABASE_URL',
        Config.SQLALCHEMY_DATABASE_URI
    )
    WTF_CSRF_ENABLED = False
    SESSION_COOKIE_SECURE = False


# Map configuration name to class
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig,
}


