"""Isolated sample workspace. Never use these credentials in production."""
import os
os.environ['DATABASE_URL'] = 'mysql+pymysql://invoiceflow:preview-only-password@127.0.0.1/invoiceflow_preview'
from config import Config
class PreviewConfig(Config):
    SCHEDULER_ENABLED = False
    TEMPLATES_AUTO_RELOAD = True
    SECRET_KEY = 'isolated-preview-not-for-production'
    SESSION_COOKIE_SECURE = False
from app import create_app
from app.extensions import db
from app.models import User, Book, Invoice, AuditLog
from datetime import date, timedelta
from decimal import Decimal
app = create_app(PreviewConfig, upgrade_schema=True)
with app.app_context():
    if not User.query.filter_by(username='admin').first():
        admin=User(username='admin',email='admin@example.com',role='admin');admin.set_password('Preview@2026');db.session.add(admin)
        clerk=User(username='sarah',email='sarah@example.com',role='data_entry');clerk.set_password('Preview@2026');db.session.add(clerk);db.session.flush()
        for n in range(1,5):db.session.add(Book(book_number=n,capacity=50,assigned_user_id=clerk.id))
        db.session.flush();books=Book.query.order_by(Book.book_number).all()
        for i in range(86):
            bn=i//50;page=i%50+1;amounts=[round(14.5+(i*7.125)%156,3),round(5.25+(i*2.25)%48,3)]
            inv=Invoice(date=date.today()-timedelta(days=i//4),serial_number=str(i+1).zfill(4),total_amount=Decimal(str(sum(amounts))),created_by=clerk.id if i%3 else admin.id,updated_by=admin.id,book_id=books[bn].id,book_page=page);inv.set_amounts(amounts);db.session.add(inv)
        for action in ['create_invoice','update_profile','create_book','import_data']:
            db.session.add(AuditLog(user_id=admin.id,action=action,details={'workspace':'Sample data'},ip_address='127.0.0.1'))
        db.session.commit()
if __name__=='__main__':app.run(host='0.0.0.0',port=5000,debug=False)


