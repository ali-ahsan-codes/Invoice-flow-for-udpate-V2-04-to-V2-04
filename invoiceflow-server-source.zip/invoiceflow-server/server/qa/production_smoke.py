"""Run with disposable DATABASE_URL and a running Gunicorn on 5001."""
import os,re,json,sys,requests,subprocess
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
r=subprocess.run([sys.executable,'-c','import wsgi'],cwd=Path(__file__).resolve().parents[1],capture_output=True,env={k:v for k,v in os.environ.items() if k not in ['SECRET_KEY','DATABASE_URL']});assert r.returncode!=0
r=requests.get('http://127.0.0.1:5001/auth/login');assert r.status_code==200 and 'Secure' in r.headers.get('Set-Cookie','')
from wsgi import app
c=app.test_client();r=c.get('/auth/login',base_url='https://example.test');token=re.search(r'name="csrf_token"[^>]*value="([^"]+)"',r.data.decode()).group(1)
r=c.post('/auth/login',base_url='https://example.test',headers={'Referer':'https://example.test/auth/login'},data={'username':'admin','password':'Testing123','csrf_token':token});assert r.status_code==302
assert c.get('/batches/',base_url='https://example.test').status_code==200
results=[{'test':'Production rejects missing secret/database','passed':True},{'test':'Gunicorn one-worker/four-thread WSGI login page and Secure cookie','passed':True},{'test':'Production HTTPS CSRF login and authenticated batch page','passed':True}]
print(json.dumps(results,indent=2));Path('/home/user/qa-work/production-results.json').write_text(json.dumps(results,indent=2))


