"""Destructive isolated MariaDB permission/global-identity tests. Never production."""
import os, sys, json
from pathlib import Path
from datetime import date
from sqlalchemy import create_engine,text,inspect
from sqlalchemy.exc import IntegrityError
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
URL=os.environ.get('QA_DATABASE_URL', 'mysql+pymysql://invoiceflow:preview-only-password@127.0.0.1/invoiceflow_batch_test')
os.environ['DATABASE_URL']=URL
from config import Config
class T(Config):
 SQLALCHEMY_DATABASE_URI=URL;SCHEDULER_ENABLED=False;WTF_CSRF_ENABLED=False;TESTING=True
 SECRET_KEY='test-only'
e=create_engine(URL)
with e.begin() as c:
 c.execute(text('SET FOREIGN_KEY_CHECKS=0'))
 c.execute(text('DROP PROCEDURE IF EXISTS invoiceflow_verify_identity_guards'))
 for (name,) in c.execute(text('SHOW TABLES')): c.execute(text(f'DROP TABLE `{name}`'))
 c.execute(text('SET FOREIGN_KEY_CHECKS=1'))
from app import create_app
from app.extensions import db
from app.models import Batch, Book, User, InvoiceMedia, AuditLog
from app.services.invoice_service import create_invoice,update_invoice,delete_invoice
from app.utils.db_utils import migrate_batches
from app.services.import_service import import_invoices_from_csv
from flask import g
app=create_app(T, upgrade_schema=True);out=[]
def check(n,ok):
 out.append({'test':n,'passed':bool(ok)});print('PASS' if ok else 'FAIL',n,flush=True);assert ok,n
def client(name):
 g.pop('_login_user',None)
 c=app.test_client();c.post('/auth/login',data={'username':name,'password':'Testing123'});return c
with app.app_context():
 a=User(username='admin',email='a@example.com',role='admin');u=User(username='clerk',email='u@example.com',role='data_entry')
 for x in (a,u): x.set_password('Testing123');x.regenerate_api_key();db.session.add(x)
 db.session.add(Batch(id=2,name='Batch 2',numbering_mode='repeat',start_book=1,start_serial=1));db.session.flush()
 for bid in (1,2):db.session.add(Book(batch_id=bid,book_number=1,capacity=50))
 db.session.commit();aid=a.id;uid=u.id;ak=a.api_key;uk=u.api_key
 inv,err=create_invoice({'batch_id':1,'date':date(2026,10,1),'serial_number':'0001','amounts':[9]},uid);iid=inv.id
 media=InvoiceMedia(invoice_id=iid,file_name='test.png',file_path='test.png',file_size=10,mime_type='image/png',uploaded_by=uid);db.session.add(media);db.session.commit();mid=media.id
 def req(c,method,path,**kwargs):
  g.pop('_login_user',None)
  if path.startswith('/batches/') or method=='post': kwargs.setdefault('headers',{})['X-Requested-With']='XMLHttpRequest'
  r=getattr(c,method)(path,**kwargs)
  return r
 admin=client('admin');g.pop('_login_user',None);clerk=client('clerk');g.pop('_login_user',None)
 for action,column,val in [('lock','locked',True),('unlock','locked',False),('hide','hidden',True),('unhide','hidden',False),('archive','archived',True),('unarchive','archived',False)]:
  r=req(admin,'post',f'/batches/1/{action}',data={'verified':'yes'})
  db.session.expire_all();check(f'Admin {action} persists + audit',r.status_code==302 and getattr(db.session.get(Batch,1),column)==val and AuditLog.query.filter_by(action=action+'_batch').count()==1)
  check(f'Normal user denied {action}',req(clerk,'post',f'/batches/1/{action}',data={'verified':'yes'}).status_code in (403,404))
 check('Admin View opens batch listing',req(admin,'get','/batches/1/view').status_code==302)
 check('Normal user denied View management endpoint',req(clerk,'get','/batches/1/view').status_code==403)
 check('Archive still requires verified records',req(admin,'post','/batches/1/archive').status_code==400)
 for state in ('lock','archive'):
  req(admin,'post',f'/batches/1/{state}',data={'verified':'yes'})
  check(state+' normal user can read',req(clerk,'get',f'/invoices/{iid}?batch_id=1').status_code==200)
  for path in [f'/invoices/{iid}/edit',f'/invoices/{iid}/delete','/invoices/create','/invoices/start-session','/invoices/update-session',f'/media/upload/{iid}',f'/media/scan-upload/{iid}',f'/media/delete/{mid}',f'/media/{iid}/cleanup']:
   check(state+' blocks '+path,req(clerk,'post',path+'?batch_id=1').status_code==403)
  check(state+' API read allowed',req(app.test_client(),'get','/api/v1/invoices/0001?batch_id=1',headers={'X-API-Key':uk}).status_code==200)
  check(state+' API upload denied',req(app.test_client(),'post','/api/v1/invoices/0001/media?batch_id=1',headers={'X-API-Key':uk}).status_code==403)
  check(state+' admin edit available',req(admin,'get',f'/invoices/{iid}/edit?batch_id=1').status_code==200)
  check(state+' admin API upload reaches file validation',req(app.test_client(),'post','/api/v1/invoices/0001/media?batch_id=1',headers={'X-API-Key':ak}).status_code==400)
  _,err=update_invoice(iid,{'date':date(2026,10,1),'serial_number':'0001','amounts':[12]},uid);check(state+' direct service edit denied',bool(err));db.session.rollback()
  ok,err=delete_invoice(iid,uid);check(state+' direct service delete denied',not ok and bool(err));db.session.rollback()
  inv,err=update_invoice(iid,{'date':date(2026,10,1),'serial_number':'0001','amounts':[10]},aid);check(state+' direct admin correction succeeds',inv is not None and not err)
  req(admin,'post',f'/batches/1/{"unlock" if state=="lock" else "unarchive"}')
 req(admin,'post','/batches/1/hide')
 for path in ['/invoices/?batch_id=1',f'/invoices/{iid}',f'/media/view/{mid}',f'/media/download/{mid}',f'/media/thumb/{mid}','/media/m/0001?batch_id=1']:
  check('Hidden direct link denied '+path,req(clerk,'get',path).status_code==404)
 check('Hidden API read denied',req(app.test_client(),'get','/api/v1/invoices/0001?batch_id=1',headers={'X-API-Key':uk}).status_code==404)
 check('Hidden select denied',req(clerk,'post','/batches/select',data={'batch_id':1}).status_code==404)
 r=req(clerk,'get','/dashboard?batch_id=2');check('Hidden omitted from selector',b'value="1"' not in r.data and b'value="2"' in r.data)
 check('Admin hidden invoice accessible',req(admin,'get',f'/invoices/{iid}?batch_id=1').status_code==200)
 with clerk.session_transaction() as s:s['batch_id']=1
 check('Stale selected hidden GET uses visible workspace',req(clerk,'get','/dashboard').status_code==200)
 check('Hidden snapshot refuses instead of morphing draft',req(clerk,'get',f'/invoices/{iid}/edit?batch_id=1',headers={'X-Live-Sync':'1'}).status_code==404)
 for serial in ('1','0001','00000001'):
  inv,err=create_invoice({'batch_id':2,'date':date(2026,10,1),'serial_number':serial,'amounts':[5]},aid)
  check('Global hidden duplicate blocked '+serial,inv is None and bool(err));db.session.rollback()
 inv,err=create_invoice({'batch_id':2,'date':date(2026,10,2),'serial_number':'1','amounts':[5]},aid);check('Different date same serial in another batch allowed',inv is not None and not err);other=inv.id
 _,err=update_invoice(other,{'date':date(2026,10,1),'serial_number':'1','amounts':[5]},aid);check('Edit cannot create global collision',bool(err));db.session.rollback()
 with app.test_request_context('/?batch_id=2'):
  g.batch_id=2
  csv='Date,Serial Number,Amounts\n2026-10-01,0001,5\n'
  result=import_invoices_from_csv([['2026-10-01','0001','5']],['Date','Serial Number','Amounts'],{'date':'Date','serial_number':'Serial Number','amounts':'Amounts'},duplicate_handling='rename',user_id=aid)
  check('CSV rename cannot bypass original duplicate',result['errors']==1 and result['imported']==0)
 # raw SQL bypass proves generated numeric identity independent of service padding
 with e.begin() as c:
  try:
   c.execute(text('INSERT INTO invoices (batch_id,date,serial_number,amounts_json,total_amount,created_by,updated_by) VALUES (2,:day,"00000001","[5]",5,:uid,:uid)'),{'day':'2026-10-01','uid':aid});blocked=False
  except IntegrityError:blocked=True
 check('DB rejects raw unnormalized numeric collision',blocked)
 ok,err=delete_invoice(iid,aid);check('Admin deletion frees global combination',ok and not err)
 # remove different-day same-batch physical page first
 delete_invoice(other,aid)
 inv,err=create_invoice({'batch_id':2,'date':date(2026,10,1),'serial_number':'1','amounts':[5]},aid);check('Deleted original permits reuse',inv is not None and not err)
 # migration conflict preflight non-destructive
 db.session.remove()
 with e.begin() as c:
  c.execute(text('DROP TRIGGER IF EXISTS invoices_reserve_ai'))
  c.execute(text('DROP TRIGGER IF EXISTS invoices_reserve_au'))
  c.execute(text('ALTER TABLE invoices DROP INDEX uq_date_serial_numeric'))
  c.execute(text('INSERT INTO invoices (batch_id,date,serial_number,amounts_json,total_amount,created_by,updated_by) VALUES (1,"2026-10-01","00000001","[5]",5,:uid,:uid)'),{'uid':aid})
 with e.connect() as c:before=[tuple(r) for r in c.execute(text('SELECT * FROM invoices'))]
 try:migrate_batches();blocked=False
 except RuntimeError as exc:blocked='duplicate' in str(exc) and 'invoice IDs' in str(exc)
 with e.connect() as c:after=[tuple(r) for r in c.execute(text('SELECT * FROM invoices'))]
 check('Migration reports conflicts and preserves every invoice column',blocked and before==after)
 with e.begin() as c:c.execute(text('DELETE FROM invoices WHERE batch_id=1'))
 migrate_batches();migrate_batches()
 check('Migration idempotently restores global index',any(i['name']=='uq_date_serial_numeric' for i in inspect(e).get_indexes('invoices')))
Path('/home/user/qa-work/batch-controls-results.json').write_text(json.dumps(out,indent=2))


