"""Run after batch_controls_test on disposable invoiceflow_batch_test."""
import os,sys,json
from pathlib import Path
from datetime import date
from threading import Barrier
from concurrent.futures import ThreadPoolExecutor
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
os.environ['DATABASE_URL']=os.environ.get('QA_DATABASE_URL', 'mysql+pymysql://invoiceflow:preview-only-password@127.0.0.1/invoiceflow_batch_test')
from config import Config
class T(Config):
 SCHEDULER_ENABLED=False;BACKUP_DIR='/home/user/qa-work/identity-backups'
from app import create_app
from app.extensions import db
from app.models import Invoice,InvoiceIdentityReservation,Batch
from app.services.invoice_service import create_invoice,update_invoice,delete_invoice
from app.services.backup_service import create_backup,create_backup_sqlalchemy,_execute_sql_file
app=create_app(T, upgrade_schema=True);out=[]
def check(n,ok):out.append({'test':n,'passed':bool(ok)});print('PASS' if ok else 'FAIL',n,flush=True);assert ok,n
with app.app_context():
 inv,err=create_invoice({'batch_id':2,'date':date(2026,10,3),'serial_number':'2','amounts':[5]},1);iid=inv.id
 inv,err=update_invoice(iid,{'date':date(2026,10,4),'serial_number':'3','amounts':[5]},1)
 check('Correction reserves old and new date/serial',inv is not None and InvoiceIdentityReservation.query.filter_by(invoice_id=iid).count()==2)
 _,err=create_invoice({'batch_id':1,'date':date(2026,10,3),'serial_number':'0002','amounts':[5]},1);check('Historical key blocked after date and serial correction',bool(err));db.session.rollback()
 inv,err=update_invoice(iid,{'date':date(2026,10,3),'serial_number':'0002','amounts':[5]},1);check('Invoice can return to its own reserved key',inv is not None and not err)
 inv,err=update_invoice(iid,{'date':date(2026,10,4),'serial_number':'0003','amounts':[5]},1)
 try:
  db.session.execute(text('INSERT INTO invoices (batch_id,date,serial_number,amounts_json,total_amount,created_by,updated_by) VALUES (1,"2026-10-03","0000002","[5]",5,1,1)'));db.session.commit();blocked=False
 except DBAPIError as exc:db.session.rollback();blocked='INVOICE_IDENTITY_RESERVED' in str(exc)
 check('Raw SQL cannot claim historical padded key',blocked)
 inv,err=create_invoice({'batch_id':1,'date':date(2026,10,5),'serial_number':'4','amounts':[5]},1);other=inv.id
 try:
  db.session.execute(text('UPDATE invoices SET date="2026-10-03",serial_number="0002" WHERE id=:id'),{'id':other});db.session.commit();blocked=False
 except DBAPIError as exc:db.session.rollback();blocked='INVOICE_IDENTITY_RESERVED' in str(exc)
 check('Raw SQL UPDATE collision rolls back entire update',blocked and db.session.get(Invoice,other).serial_number=='0004')
 before=[tuple(r) for r in db.session.execute(text('SELECT * FROM invoice_identity_reservations ORDER BY date,serial_numeric'))]
 for mode in ('mysql','fallback'):
  if mode=='mysql':backup=create_backup(manual=True);assert backup['success'],backup;path=backup['filepath']
  else:_,path=create_backup_sqlalchemy(app.config['BACKUP_DIR'])
  db.session.remove();ok,err=_execute_sql_file(path);assert ok,err
  after=[tuple(r) for r in db.session.execute(text('SELECT * FROM invoice_identity_reservations ORDER BY date,serial_numeric'))]
  check(mode+' backup restores every current and historical reservation',before==after)
  _,err=create_invoice({'batch_id':1,'date':date(2026,10,3),'serial_number':'2','amounts':[5]},1);check(mode+' restored historical key still blocked',bool(err));db.session.rollback()
 delete_invoice(iid,1)
 check('Deletion releases ALL historical keys',InvoiceIdentityReservation.query.filter_by(invoice_id=iid).count()==0)
 inv,err=create_invoice({'batch_id':1,'date':date(2026,10,3),'serial_number':'2','amounts':[5]},1);check('Historical key reusable only after deletion',inv is not None and not err)
 # simultaneous service creates across batches, not just same-batch index
 db.session.remove()
b=Barrier(2)
def writer(bid):
 with app.app_context():
  b.wait();inv,err=create_invoice({'batch_id':bid,'date':date(2026,10,6),'serial_number':'6','amounts':[5]},1)
  return inv is not None,err
with ThreadPoolExecutor(2) as ex:results=list(ex.map(writer,[1,2]))
check('Concurrent cross-batch claims save exactly one invoice',sum(x[0] for x in results)==1)
with app.app_context():
 check('Concurrent failure leaves one reservation and one invoice',Invoice.query.filter_by(date=date(2026,10,6),serial_numeric=6).count()==1 and InvoiceIdentityReservation.query.filter_by(date=date(2026,10,6),serial_numeric=6).count()==1)
with app.app_context():
 # A transaction that abandons an otherwise successful insert owns no key.
 db.session.execute(text('INSERT INTO invoices (batch_id,date,serial_number,amounts_json,total_amount,created_by,updated_by) VALUES (1,"2026-10-07","0007","[5]",5,1,1)'))
 db.session.rollback()
 check('Rolled-back insert leaves no historical reservation',InvoiceIdentityReservation.query.filter_by(date=date(2026,10,7),serial_numeric=7).count()==0)
 from app.utils.db_utils import migrate_batches
 db.session.remove()
 with db.engine.begin() as c:
  c.execute(text('DROP TRIGGER invoices_reserve_au'))
  c.execute(text('CREATE TRIGGER invoices_reserve_au AFTER UPDATE ON invoices FOR EACH ROW SET @identity_guard_bypassed=1'))
 try:migrate_batches();blocked=False
 except RuntimeError as exc:blocked='Unexpected reservation trigger definition' in str(exc)
 check('Migration refuses a same-name but incorrect reservation trigger',blocked)
 with db.engine.begin() as c:c.execute(text('DROP TRIGGER invoices_reserve_au'))
 migrate_batches();migrate_batches()
 check('Missing trigger recreated and repeated upgrade preserves ownership',InvoiceIdentityReservation.query.filter_by(date=date(2026,10,6),serial_numeric=6).count()==1)
Path('/home/user/qa-work/identity-history-results.json').write_text(json.dumps(out,indent=2))


