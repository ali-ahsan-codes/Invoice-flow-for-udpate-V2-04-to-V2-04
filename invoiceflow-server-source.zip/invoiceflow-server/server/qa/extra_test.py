import sys, json, io
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from support.demo_app import app
from app.extensions import db
from app.models import User, AuditLog, Book, Invoice
from app.routes.auth import safe_next_path
from flask import render_template
with app.app_context():
 admin=User.query.filter_by(username='admin').first();clerk=User.query.filter_by(username='sarah').first()
 # Clear only synthetic invoices left by interrupted runs.
 for inv in Invoice.query.filter(Invoice.book_id==3).all():db.session.delete(inv)
 db.session.commit()
 app.config['TESTING']=True;app.config['WTF_CSRF_ENABLED']=False
 c=app.test_client();c.post('/auth/login',data={'username':'admin','password':'Preview@2026'})
 # Attach references to a disposable user to reproduce the foreign-key bug.
 u=User(username='refdelete',email='refdelete@example.com',role='data_entry');u.set_password('Testing123');db.session.add(u);db.session.flush();uid=u.id
 db.session.add(AuditLog(user_id=uid,action='login'));book=Book.query.filter_by(book_number=4).first();book.assigned_user_id=uid;db.session.commit()
 r=c.post(f'/admin/users/{uid}/delete',headers={'X-Requested-With':'XMLHttpRequest'});assert r.status_code==200 and r.json['success'];assert db.session.get(User,uid) is None;assert db.session.get(Book,book.id).assigned_user_id is None
 print('PASS user deletion with audit logs and book assignment')
 for target in ['https://evil.test','//evil.test','/\\evil.test','/\n/evil.test','javascript:alert(1)']:
  assert safe_next_path(target) is None
 assert safe_next_path('/invoices/?book=2')=='/invoices/?book=2'
 print('PASS redirect target validation cases')
 # Stored backups get info without performing destructive restore.
 # Render only the confirmation screen with sample metadata (not a real backup).
 with app.test_request_context('/backup/restore'):
  from flask_login import login_user
  login_user(admin)
  html=render_template('admin/restore_confirm.html',backup={'filename':'sample-workspace.sql','created_at_formatted':'08 Oct 2026, 12:00','size_formatted':'24 KB','is_valid':True})
  (Path(__file__).parent/'fixtures'/'restore-fixture.html').write_text(html)
  (Path(__file__).parent/'fixtures'/'maintenance-fixture.html').write_text(render_template('maintenance.html'))
 r=c.post('/import-export/import?batch_id=1',data={'preview':'true','csv_file':(io.BytesIO(b'date,serial_number,amounts,total\n2026-10-08,0101,12.5|2.0,14.5\n'),'sample.csv')},content_type='multipart/form-data')
 assert r.status_code==200 and b'CSV Import Preview' in r.data;(Path(__file__).parent/'fixtures'/'import-preview-fixture.html').write_bytes(r.data)
 print('PASS CSV preview without importing')
 c.get('/auth/logout');c.post('/auth/login',data={'username':'sarah','password':'Preview@2026'})
 for path in ['/admin/users','/admin/settings','/backup/','/admin/analytics/']:
  assert c.get(path).status_code in (302,403)
 assert c.get('/invoices/1').status_code in (302,403)
 assert c.get('/invoices/2').status_code==200
 print('PASS data-entry access boundaries')


