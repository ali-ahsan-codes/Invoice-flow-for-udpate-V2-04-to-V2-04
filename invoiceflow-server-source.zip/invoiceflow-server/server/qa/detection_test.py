"""Destructive regression ONLY on invoiceflow_detection_test; not production."""
import os,sys,json
from pathlib import Path
from datetime import date,timedelta
from decimal import Decimal
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
URL=os.environ.get('QA_DATABASE_URL', 'mysql+pymysql://invoiceflow:preview-only-password@127.0.0.1/invoiceflow_detection_test')
os.environ['DATABASE_URL']=URL
from sqlalchemy import create_engine,text,select
engine=create_engine(URL)
with engine.begin() as c:
 c.execute(text('SET FOREIGN_KEY_CHECKS=0'))
 for (name,) in c.execute(text('SHOW TABLES')):c.execute(text(f'DROP TABLE `{name}`'))
 c.execute(text('SET FOREIGN_KEY_CHECKS=1'))
from config import Config
class TestConfig(Config):
 TESTING=True;SCHEDULER_ENABLED=False;WTF_CSRF_ENABLED=False
 SECRET_KEY='disposable-detection-tests-only'
 SQLALCHEMY_DATABASE_URI=URL
from app import create_app
from app.extensions import db
from app.models import User,Book,Batch,Invoice,AuditLog
from app.detection import DetectionPolicy,ReviewCase,policy_lock
from app.services.invoice_service import create_invoice,update_invoice,delete_invoice
from app.realtime import revision
app=create_app(TestConfig, upgrade_schema=True);out=[]
def check(n,ok):
 out.append({'test':n,'passed':bool(ok)});print('PASS' if ok else 'FAIL',n,flush=True);assert ok,n

def client(user='admin'):
 c=app.test_client();c.post('/auth/login',data={'username':user,'password':'Testing123'});return c

def configure(c,manual=True,auto=False,invoice='',user='',batch=''):
 with app.app_context():version=db.session.get(DetectionPolicy,1).version
 fields={'version':version,'invoice_limit':str(invoice),'user_daily_limit':str(user),'batch_daily_limit':str(batch)}
 if manual:fields['manual_enabled']='on'
 if auto:fields['automatic_enabled']='on'
 return c.post('/admin/review/settings',data=fields)

def make(serial,amount,day=None,uid=2,bid=1,amounts=None):
 with app.app_context():
  inv,error=create_invoice({'serial_number':serial,'date':day or date.today(),'amounts':amounts or [amount],'batch_id':bid},uid)
  assert inv is not None,error;return inv.id

def edit(iid,amount,day=None):
 with app.app_context():
  inv=db.session.get(Invoice,iid)
  inv,error=update_invoice(iid,{'serial_number':inv.serial_number,'date':day or inv.date,'amounts':[amount]},1)
  assert inv is not None,error

def case_for(iid):
 with app.app_context():
  c=ReviewCase.query.filter_by(case_key=f'invoice:{iid}').first()
  return (c.id,c.fingerprint,c.status) if c else None

def clear(c,cid,fp):return c.post(f'/admin/review/{cid}',data={'fingerprint':fp,'note':'Checked original paper and confirmed amount.'})

with app.app_context():
 for username,role in [('admin','admin'),('sarah','data_entry')]:
  u=User(username=username,email=username+'@example.com',role=role);u.set_password('Testing123');db.session.add(u)
 db.session.add(Book(batch_id=1,book_number=1,capacity=1000));db.session.add(Batch(id=2,name='Batch 2',start_book=1,start_serial=1,numbering_mode='repeat'))
 db.session.add(Book(batch_id=2,book_number=1,capacity=1000));db.session.commit()
admin=client();clerk=client('sarah')
check('Defaults enable checks with no assumed manual limits',admin.get('/admin/review/settings').status_code==200)
check('Manual settings save',configure(admin,invoice=200,user=400,batch=500).status_code==302)
a=make('0001',200);check('Exactly invoice limit is not flagged',case_for(a) is None)
b=make('0002',201)
check('Strictly above invoice limit is flagged in same commit',case_for(b)[2]=='open')
with app.app_context():
 check('Per-user total over 400 flags separately',ReviewCase.query.filter_by(kind='user_day',status='open',subject_user_id=2).count()==1)
 check('Combined total below 500 does not flag',ReviewCase.query.filter_by(kind='batch_day',status='open').count()==0)
c=make('0003',100,uid=1)
with app.app_context():check('Combined threshold uses all users but same batch/date',ReviewCase.query.filter_by(kind='batch_day',status='open').count()==1)
x=make('0001',300,bid=2,day=date.today()-timedelta(days=2))
with app.app_context():check('Repeated serial in Batch 2 has separate case identity/daily total',ReviewCase.query.filter_by(kind='invoice',batch_id=2,status='open').count()==1 and ReviewCase.query.filter_by(kind='user_day',batch_id=2,status='open').count()==0)
check('Admin sees invoice flag on detail',b'needs administrator review' in admin.get(f'/invoices/{b}?batch_id=1').data)
check('Clerk cannot view reviews/settings or clear cases',clerk.get('/admin/review/',headers={'X-Requested-With':'XMLHttpRequest'}).status_code==403 and clerk.post('/admin/review/1',data={'note':'checked'},headers={'X-Requested-With':'XMLHttpRequest'}).status_code==403 and clerk.get('/admin/review/settings',headers={'X-Requested-With':'XMLHttpRequest'}).status_code==403)
cid,fp,_=case_for(b)
check('Review requires verification note',admin.post(f'/admin/review/{cid}',data={'fingerprint':fp,'note':''}).status_code==400)
check('Admin unflag persists audit and leaves invoice unchanged',clear(admin,cid,fp).status_code==302 and case_for(b)[2]=='cleared')
with app.app_context():check('Review audit records reason/note/snapshot',AuditLog.query.filter_by(action='clear_review_case').count()==1 and db.session.get(Invoice,b).total_amount==Decimal('201.000'))
admin.post('/admin/review/rescan');check('Unchanged verified case stays unflagged on rescan',case_for(b)[2]=='cleared')
edit(b,250);check('Changed reviewed amount reopens case',case_for(b)[2]=='open')
check('Stale admin review cannot unflag newer amount',clear(admin,cid,fp).status_code==409 and case_for(b)[2]=='open')
edit(b,30);check('Correction below enabled limit resolves instead of deleting history',case_for(b)[2]=='resolved')
with app.app_context():check('Correcting source recomputes old day aggregate',ReviewCase.query.filter_by(kind='user_day',batch_id=1,status='open').count()==0)
edit(a,450);old_day=date.today();new_day=old_day-timedelta(days=1)
edit(a,450,day=new_day)
with app.app_context():
 check('Moving date resolves former daily flag and evaluates new date',ReviewCase.query.filter_by(kind='batch_day',batch_id=1,invoice_date=old_day,status='open').count()==0 and ReviewCase.query.filter_by(kind='user_day',batch_id=1,invoice_date=new_day,status='open').count()==1 and ReviewCase.query.filter_by(invoice_id=a,invoice_date=new_day,status='open').count()==1)
 success,error=delete_invoice(a,1);assert success,error
 check('Delete source resolves flags while retaining case snapshot',ReviewCase.query.filter_by(case_key=f'invoice:{a}').first().status=='resolved' and ReviewCase.query.filter_by(case_key=f'invoice:{a}').first().invoice_id is None)
# invalid/atomic settings updates and optimistic version
with app.app_context():p=db.session.get(DetectionPolicy,1);v=p.version;limit=p.invoice_limit
for value in ['-1','0','nan','Infinity','200.0001','99999999999999']:
 r=configure(admin,invoice=value);check('Reject invalid threshold '+value,r.status_code==400)
with app.app_context():check('Invalid settings preserve previous policy',db.session.get(DetectionPolicy,1).invoice_limit==limit)
check('Stale settings version refused',admin.post('/admin/review/settings',data={'version':v-1,'invoice_limit':'200'}).status_code==409)
check('Disable both options resolves pending and preserves history',configure(admin,manual=False,auto=False).status_code==302)
with app.app_context():check('Both disabled leave zero open cases',ReviewCase.query.filter_by(status='open').count()==0)
# clean historical baseline, checks disabled while seed committed
for n in range(10,50):make(str(n),30,day=old_day-timedelta(days=20+(n-10)//2))
# all earlier daily totals exactly 60, at least 20 invoice and 14 day samples
check('Automatic-only settings work with no manual limit',configure(admin,manual=False,auto=True).status_code==302)
typical=make('0050',30)
typo=make('0051',300)
with app.app_context():
 check('30 to 300 typo detected below any manual threshold',ReviewCase.query.filter_by(case_key=f'invoice:{typo}',status='open').first().reasons[0]['source']=='automatic')
check('Ordinary invoice with same baseline is not flagged',case_for(typical) is None)
low=make('0052',1)
check('Extreme low positive decimal/zero typo is detected',case_for(low)[2]=='open')
zero=make('0053',0);check('Zero cancelled invoice is not an automatic anomaly',case_for(zero) is None)
# Cross-batch history for a repeated new book learns from the user's previous invoices
cross=make('0002',300,bid=2,day=date.today()-timedelta(days=2));check('New batch uses available historical baseline without merging day totals',case_for(cross)[2]=='open')
# Configuration modes independent
configure(admin,manual=True,auto=False,invoice=1000)
check('Manual-only mode does not flag below manual limit',case_for(typo)[2]=='resolved')
configure(admin,manual=True,auto=True,invoice=1000)
check('Automatic check still flags below configured manual limit',case_for(typo)[2]=='open')
with app.app_context():
 check('Automatic daily total detects substantial change with 14-day history',ReviewCase.query.filter_by(kind='user_day',batch_id=1,invoice_date=old_day,status='open').count()==1)
# rollback should leave neither invoice/case nor version
with app.app_context():
 before=revision();before_cases=ReviewCase.query.count()
 inv=Invoice(batch_id=1,serial_number='0099',date=old_day,created_by=2,updated_by=2,total_amount=999);inv.set_amounts([999]);db.session.add(inv);db.session.flush();db.session.rollback()
 check('Rollback leaves no partial flags or revision',ReviewCase.query.count()==before_cases and Invoice.query.filter_by(serial_number='0099').first() is None and revision()==before)
# import path hooks same detection pipeline
from app.services.import_service import import_invoices_from_csv
with app.test_request_context('/?batch_id=1'):
 from flask import g
 g.batch_id=1;g.current_batch=db.session.get(Batch,1)
 r=import_invoices_from_csv([['1',old_day.isoformat(),'0098','900']],['Batch ID','Date','Serial','Amounts'],{'date':'Date','serial_number':'Serial','amounts':'Amounts'},user_id=2)
 check('CSV imported invoices automatically use detector',r['imported']==1 and ReviewCase.query.join(Invoice,ReviewCase.invoice_id==Invoice.id).filter(Invoice.serial_number=='0098',ReviewCase.status=='open').count()==1)
# both daily reviews and per-invoice review may need separate verification
with app.app_context():daily=ReviewCase.query.filter_by(kind='user_day',batch_id=1,invoice_date=old_day).first();daily_id=daily.id;daily_fp=daily.fingerprint
clear(admin,daily_id,daily_fp)
make('0097',30)
with app.app_context():check('Changed daily membership reopens verified daily total',db.session.get(ReviewCase,daily_id).status=='open')
# input is escaped in notes; review does not change invoice date/user/media
cid,fp,_=case_for(typo);clear(admin,cid,fp)
check('History status filters and pagination render',admin.get('/admin/review/?status=cleared').status_code==200 and admin.get('/admin/review/?status=all&page=2').status_code==200)
# ORM autoflush/default batch identity and partial per-invoice amounts.
configure(admin,manual=True,auto=False,invoice=200)
with app.app_context():
 inv=Invoice(date=old_day,serial_number='0300',created_by=2,updated_by=2,total_amount=300);inv.set_amounts([150,150]);db.session.add(inv);db.session.flush();iid=inv.id;db.session.commit()
 check('Autoflushed ORM invoice with default batch also flags summed amount rows',ReviewCase.query.filter_by(invoice_id=iid,status='open').count()==1)
 snapshot=db.session.get(Invoice,iid).updated_at
 c=ReviewCase.query.filter_by(invoice_id=iid).first();cid=c.id;fp=c.fingerprint
clear(admin,cid,fp)
with app.app_context():check('Verification leaves invoice timestamp unchanged',db.session.get(Invoice,iid).updated_at==snapshot)
# Admin notification count does not expose review metadata to clerks.
check('Admin live notification includes only aggregate count and revision',set(admin.get('/live/version').json)=={'revision','review_open_count'})
check('Clerk live notifications reveal no review count or cases',set(clerk.get('/live/version').json)=={'revision'})
Path('/home/user/qa-work/detection-results.json').write_text(json.dumps(out,indent=2))


