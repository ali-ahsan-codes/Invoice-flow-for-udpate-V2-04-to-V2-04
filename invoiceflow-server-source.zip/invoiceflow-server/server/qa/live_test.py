from playwright.sync_api import sync_playwright
from pathlib import Path
from PIL import Image
import io, json, sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from support.demo_app import app
from app.extensions import db
from app.models import Invoice,InvoiceMedia,Book
from app.realtime import revision
BASE='http://127.0.0.1:5000';results=[]
def check(name,condition):
 results.append({'test':name,'passed':bool(condition)});print('PASS' if condition else 'FAIL',name,flush=True);assert condition,name
def login(ctx,user='admin'):
 page=ctx.new_page();page.goto(BASE+'/auth/login');page.fill('#username',user);page.fill('#password','Preview@2026');page.click('[type=submit]');page.wait_for_url('**/dashboard*' if user=='admin' else '**/invoices/start-session*');return page
def amount(value):
 with app.app_context():
  inv=db.session.get(Invoice,1);inv.set_amounts([value]);inv.total_amount=value;db.session.commit()
def waitlive(page):page.wait_for_function("document.querySelector('#live-status')?.textContent === 'Live'")
with app.app_context():
 inv=db.session.get(Invoice,1);saved={'amounts':inv.get_amounts(),'total':inv.total_amount,'updated':inv.updated_at};old_book=db.session.get(Book,2).capacity
try:
 with sync_playwright() as p:
  b=p.chromium.launch();ctx=b.new_context(viewport={'width':1440,'height':1000},reduced_motion='reduce');ctx2=b.new_context(viewport={'width':390,'height':844},reduced_motion='reduce');errors=[]
  ctx.on('page',lambda pg:pg.on('pageerror',lambda e:errors.append(str(e))));ctx2.on('page',lambda pg:pg.on('pageerror',lambda e:errors.append(str(e))))
  view=login(ctx);upload=login(ctx2);view.goto(BASE+'/invoices/1');upload.goto(BASE+'/media/upload/1');waitlive(view);waitlive(upload)
  view.evaluate('window.__boot = performance.timeOrigin');view.evaluate('window.scrollTo(0,200)');scroll=view.evaluate('scrollY')
  draft=ctx.new_page();draft.goto(BASE+'/invoices/1/edit');waitlive(draft);draft.locator('.amount-field-input').first.fill('777.125');draft.locator('.btn-add-amount').click();draft.locator('.amount-field-input').last.fill('2.000');draft.locator('.amount-field-input').last.focus();draft.evaluate('window.__form = document.getElementById("invoice-form")');draft.evaluate('window.__focused = document.activeElement')
  summary=ctx.new_page();summary.goto(BASE+'/invoices/summary');waitlive(summary);before=summary.locator('#stat-revenue').inner_text()
  analytics=ctx.new_page();analytics.goto(BASE+'/admin/analytics/');waitlive(analytics);an_before=analytics.locator('#s-revenue').inner_text()
  grid=ctx.new_page();grid.goto(BASE+'/invoices/grid');waitlive(grid);grid_before=grid.locator('#grid-content').inner_text()
  amount(1234.567)
  view.wait_for_function("document.body.innerText.includes('1234.567')",timeout=12000)
  check('Invoice edits arrive in another session without document reload',view.evaluate('window.__boot === performance.timeOrigin'))
  check('Background sync preserves scroll',abs(view.evaluate('scrollY')-scroll)<2)
  draft.wait_for_function("document.body.innerText.includes('changed elsewhere')",timeout=10000)
  check('Draft amount rows, focus and handler DOM preserved',draft.locator('.amount-field-input').first.input_value()=='777.125' and draft.evaluate('window.__form === document.getElementById("invoice-form") && window.__focused === document.activeElement'))
  summary.wait_for_function('(old)=>document.querySelector("#stat-revenue").textContent!==old',arg=before,timeout=12000)
  analytics.wait_for_function('(old)=>document.querySelector("#s-revenue").textContent!==old',arg=an_before,timeout=12000)
  grid.wait_for_function('(old)=>document.querySelector("#grid-content").innerText!==old',arg=grid_before,timeout=12000)
  check('Summary, analytics and grid auto-refresh native datasets',True)
  # Real upload from independent browser session; filename and thumbnail must appear on both pages.
  bio=io.BytesIO();Image.new('RGB',(140,100),'#8454cf').save(bio,format='PNG')
  upload.evaluate('window.__boot = performance.timeOrigin');upload.set_input_files('#files',{'name':'realtime-qa.png','mimeType':'image/png','buffer':bio.getvalue()});upload.click('#upload-submit-btn')
  upload.wait_for_selector('img.attachment-thumb',timeout=12000);view.wait_for_selector('img[src*="/media/thumb/"]',timeout=12000)
  check('Upload renders attachment immediately without navigating',upload.evaluate('window.__boot === performance.timeOrigin') and 'realtime-qa.png' in upload.locator('main').inner_text())
  view.locator('img[src*="/media/thumb/"]').first.wait_for()
  view.wait_for_function('()=>[...document.images].filter(i=>i.src.includes("/media/thumb/")).every(i=>i.complete && i.naturalWidth>0)')
  check('New image appears in another session and fully loads',view.locator('img[src*="/media/thumb/"]').first.evaluate('(img)=>img.complete && img.naturalWidth>0'))
  media_id=int(upload.locator('img.attachment-thumb').first.get_attribute('src').split('?')[0].rsplit('/',1)[-1])
  # File selection must survive an unrelated external change.
  upload.set_input_files('#files',{'name':'unsaved.png','mimeType':'image/png','buffer':bio.getvalue()});amount(1234.568);upload.wait_for_timeout(2300)
  check('Background updates preserve selected upload files',upload.locator('#files').evaluate('(e)=>e.files[0].name')=='unsaved.png')
  upload.locator('[title=Delete]').first.click();upload.locator('#delete-media-form [type=submit]').click();view.wait_for_function("()=>![...document.images].some(img=>img.src.includes('/media/thumb/'))",timeout=12000)
  check('Attachment delete updates connected invoice without reload',view.evaluate('window.__boot === performance.timeOrigin'))
  # Book tabs stay open and paginate in place.
  book=ctx2.new_page();book.goto(BASE+'/admin/books/2');waitlive(book);book.evaluate('window.__boot = performance.timeOrigin');book.click('[data-bs-target="#book-missing"]')
  with app.app_context():
   obj=db.session.get(Book,2);obj.capacity=51;db.session.commit()
  book.wait_for_function('()=>document.querySelector("#book-missing").innerText.includes("51")',timeout=12000)
  check('Book detail sync retains active tab and compact mobile viewport',book.locator('#book-missing').is_visible() and not book.evaluate('document.documentElement.scrollWidth>innerWidth'))
  book.click('[data-bs-target="#book-invoices"]');book.click('[data-live-page]');book.wait_for_function('()=>location.search.includes("page=2") && document.querySelector(".book-pagination").innerText.includes("Page 2")',timeout=10000)
  check('Book pagination replaces cards without document navigation',book.locator('.invoice-mini-card').count()==12 and book.evaluate('window.__boot===performance.timeOrigin'))
  book.screenshot(path='/home/user/qa-work/screenshots/65-live-book-mobile.png',full_page=True)
  # Auth boundaries: no content in version response, no thumbnails leaking to clerk.
  clerk=login(b.new_context(),'sarah');unauth=b.new_context();resp=unauth.request.get(BASE+'/live/version');check('Live endpoint rejects unauthenticated access',resp.status==401)
  denied=clerk.request.get(BASE+'/media/thumb/'+str(media_id));check('Deleted attachment URL is unavailable',denied.status==404)
  payload=ctx.request.get(BASE+'/live/version').json();check('Notification endpoint contains only revision and admin-only aggregate case count',set(payload)=={'revision','review_open_count'} and isinstance(payload['review_open_count'],int))
  # Rollbacks do not announce data that never committed.
  with app.app_context():
   token=revision();obj=db.session.get(Book,2);obj.capacity=99;db.session.flush();db.session.rollback();check('Rollback never publishes a change',revision()==token)
   obj=db.session.get(Book,2);obj.capacity=old_book;db.session.commit()
  # Persisted source change prevents stale browser draft save.
  with draft.expect_response(lambda res:'/edit' in res.url and res.request.method=='POST') as response:draft.locator('#invoice-form [type=submit]').click()
  check('Concurrent edit refuses stale draft overwrite',not response.value.json().get('success'))
  with app.app_context():check('Newer persisted invoice remains intact',float(db.session.get(Invoice,1).total_amount)==1234.568)
  check('No JavaScript errors in concurrent desktop/mobile sessions',not errors)
  view.screenshot(path='/home/user/qa-work/screenshots/64-live-invoice-desktop.png',full_page=True)
  b.close()
finally:
 with app.app_context():
  inv=db.session.get(Invoice,1);inv.set_amounts(saved['amounts']);inv.total_amount=saved['total'];inv.updated_at=saved['updated'];db.session.get(Book,2).capacity=old_book
  for media in InvoiceMedia.query.filter_by(file_name='realtime-qa.png').all():
   path=Path('/home/user/invoiceflow/uploads')/media.file_path
   if path.exists():path.unlink()
   db.session.delete(media)
  db.session.commit()
 Path('/home/user/qa-work/live-test-results.json').write_text(json.dumps(results,indent=2))


