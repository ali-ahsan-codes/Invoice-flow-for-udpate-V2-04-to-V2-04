from pathlib import Path
from playwright.sync_api import sync_playwright
import json
results=[]
def check(name,condition):
 results.append({'test':name,'passed':bool(condition)});print('PASS',name,flush=True);assert condition,name
with sync_playwright() as p:
 b=p.chromium.launch();pg=b.new_page(viewport={'width':1440,'height':1000});errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));pg.goto('http://127.0.0.1:5000/auth/login');pg.fill('#username','admin');pg.fill('#password','Preview@2026');pg.click('[type=submit]');pg.wait_for_url('**/dashboard*')
 pg.goto('http://127.0.0.1:5000/admin/settings');old=pg.locator('#backup_interval').input_value();pg.fill('#backup_interval','59');pg.locator('button[type=reset]').click();pg.wait_for_timeout(700);check('Settings Reset discards unsaved inputs',pg.locator('#backup_interval').input_value()==old)
 for mid in ['factoryResetModal','clearAuditModal']:
  pg.evaluate('(id)=>bootstrap.Modal.getOrCreateInstance(document.getElementById(id)).show()',mid);pg.wait_for_timeout(350);check(mid+' is portaled and clickable',pg.locator('#'+mid).evaluate('(el)=>el.parentElement===document.body'))
  pg.locator('#'+mid+' [data-bs-dismiss=modal]').last.click();pg.wait_for_timeout(400);check(mid+' cancels without backdrop residue',pg.locator('.modal-backdrop').count()==0)
 pg.goto('http://127.0.0.1:5000/backup/');pg.wait_for_timeout(350)
 with pg.expect_response(lambda r:r.request.method=='POST' and r.url.split('?')[0].endswith('/backup/create')) as res:pg.locator('#btn-create-backup').click()
 data=res.value.json();name=data['filename'];check('Backup create actual browser action succeeds',data['success']);pg.wait_for_function('(name)=>document.body.innerText.includes(name)',arg=name);pg.wait_for_timeout(600)
 pg.evaluate('(name)=>confirmRestore(name)',name);pg.wait_for_timeout(350);check('Backup restore confirmation dialog is clickable',pg.locator('#restoreModal').is_visible());pg.locator('#restoreModal [data-bs-dismiss=modal]').last.click();pg.wait_for_timeout(350)
 for i in range(2):
  pg.evaluate('(name)=>confirmDelete(name)',name);pg.wait_for_timeout(350);check('Backup delete dialog clickability '+str(i),pg.locator('#delete-form [type=submit]').evaluate('(btn)=>{const r=btn.getBoundingClientRect();return document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)===btn}'));pg.locator('#deleteModal [data-bs-dismiss=modal]').last.click();pg.wait_for_timeout(350)
 pg.evaluate('(name)=>confirmDelete(name)',name);pg.wait_for_timeout(350);pg.locator('#delete-form [type=submit]').click();pg.wait_for_load_state();pg.wait_for_timeout(500);check('Backup delete actual browser operation leaves usable page',pg.locator('.modal-backdrop').count()==0)
 pg.locator('#btn-upload-restore').click();pg.wait_for_timeout(350);check('Upload restore dialog opens without stacking issue',pg.locator('#uploadRestoreModal').is_visible());pg.locator('#upload-cancel-btn').click();pg.wait_for_timeout(350)
 check('No JS exceptions in settings/backup actions',not errors);b.close()
Path('ui-actions-results.json').write_text(json.dumps(results,indent=2))


