"""Real MySQL8 test: full DBA upgrade, minimal runtime privileges, no DDL."""
import sys,os,json,subprocess
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from sqlalchemy import create_engine,text
from sqlalchemy.exc import DBAPIError
ROOT=Path(__file__).resolve().parents[1];out=[]
DB='invoiceflow_mysql_test';admin='mysql+pymysql://root@localhost/'+DB+'?unix_socket=/home/user/.cache/mysql.sock';runtime='mysql+pymysql://runtime:preview-only-password@127.0.0.1:3307/'+DB
def check(n,ok):out.append({'test':n,'passed':bool(ok)});print('PASS' if ok else 'FAIL',n,flush=True);assert ok,n
e=create_engine(admin)
with e.begin() as c:
 c.execute(text('REVOKE ALL PRIVILEGES, GRANT OPTION FROM runtime@127.0.0.1'))
 c.execute(text(f'GRANT SELECT ON {DB}.* TO runtime@127.0.0.1'))
 for (t,) in c.execute(text('SHOW TABLES')).all():
  if t!='invoice_identity_reservations':c.execute(text(f'GRANT INSERT,UPDATE,DELETE ON {DB}.{t} TO runtime@127.0.0.1'))
 c.execute(text(f'GRANT EXECUTE ON PROCEDURE {DB}.invoiceflow_verify_identity_guards TO runtime@127.0.0.1'))
 # ensure db credential/execution path distinct from schemas in other suites
os.environ.update(DATABASE_URL=runtime,SECRET_KEY='mysql-staging-runtime-not-production-123456',SCHEDULER_ENABLED='False')
from app.startup import create_configured_app
from app.extensions import db
from app.models import Invoice,Book,Batch,User,InvoiceIdentityReservation
from app.services.invoice_service import create_invoice,update_invoice,delete_invoice
from datetime import date
app=create_configured_app()
with app.app_context():
 check('MySQL 8.4 startup verifies guards with DML/EXECUTE-only runtime account',True)
 try:db.session.execute(text('DROP TRIGGER invoices_reserve_ai'));db.session.commit();blocked=False
 except DBAPIError:db.session.rollback();blocked=True
 check('Runtime cannot disable database reservation trigger',blocked)
 try:db.session.execute(text('DELETE FROM invoice_identity_reservations'));db.session.commit();blocked=False
 except DBAPIError:db.session.rollback();blocked=True
 check('Runtime cannot delete or release identity reservations directly',blocked)
 uid=User.query.filter_by(role='admin').first().id
 bid=Batch(name='MySQL Runtime QA',start_book=1,start_serial=1);db.session.add(bid);db.session.flush();bid=bid.id
 db.session.add(Book(batch_id=bid,book_number=1,capacity=50));db.session.commit()
 inv,err=create_invoice({'batch_id':bid,'date':date(2026,9,1),'serial_number':'1','amounts':[6]},uid);check('Runtime inserts invoice and definer trigger reserves key',inv is not None and not err);iid=inv.id
 inv,err=update_invoice(iid,{'date':date(2026,9,2),'serial_number':'2','amounts':[7]},uid)
 check('Runtime corrections retain both previous and current keys',not err and InvoiceIdentityReservation.query.filter_by(invoice_id=iid).count()==2)
 inv,err=create_invoice({'batch_id':bid,'date':date(2026,9,1),'serial_number':'0001','amounts':[8]},uid);check('Historical duplicate denied under minimal runtime privileges',inv is None and bool(err));db.session.rollback()
 delete_invoice(iid,uid);check('Authorized invoice deletion cascades reservations without direct reservation DELETE privilege',InvoiceIdentityReservation.query.filter_by(invoice_id=iid).count()==0)
 db.session.execute(text('DELETE FROM books WHERE batch_id=:bid'),{'bid':bid});db.session.execute(text('DELETE FROM batches WHERE id=:bid'),{'bid':bid});db.session.commit()
# A runtime backup works even with CLI installed but routine dump privileges denied.
with app.app_context():
 from app.services.backup_service import create_backup,create_backup_sqlalchemy
 from unittest.mock import patch
 import subprocess as sp
 fake=sp.CompletedProcess(['mysqldump'],1,stderr='Permission denied')
 with patch('app.services.backup_service.is_mysqldump_available',return_value=True),patch('app.services.backup_service.subprocess.run',return_value=fake):
  result=create_backup(manual=True)
 check('Restricted CLI dump falls back to a complete usable row backup',result.get('success') and result.get('method')=='sqlalchemy' and 'invoice_identity_reservations' in Path(result['filepath']).read_text() and 'SQLAlchemy fallback dump' in Path(result['filepath']).read_text())
 db.session.remove()
# repeated offline upgrade must not lose EXECUTE grant on routine
r=subprocess.run([sys.executable,'upgrade_database.py'],cwd=ROOT,env={**os.environ,'DATABASE_URL':admin},capture_output=True,text=True);assert r.returncode==0,r.stderr
r=subprocess.run([sys.executable,'launch.py','--check'],cwd=ROOT,env=os.environ,capture_output=True,text=True)
check('Idempotent DBA upgrade preserves runtime EXECUTE grant',r.returncode==0)
# startup cannot mask unrelated extra triggers
with e.begin() as c:c.execute(text('CREATE TRIGGER invoices_extra_qa AFTER INSERT ON invoices FOR EACH ROW SET @unsafe_extra=1'))
try:
 r=subprocess.run([sys.executable,'launch.py','--check'],cwd=ROOT,env=os.environ,capture_output=True,text=True)
 check('Runtime refuses unexpected extra invoice triggers',r.returncode!=0)
finally:
 with e.begin() as c:c.execute(text('DROP TRIGGER invoices_extra_qa'))
with e.begin() as c:c.execute(text(f'REVOKE EXECUTE ON PROCEDURE {DB}.invoiceflow_verify_identity_guards FROM runtime@127.0.0.1'))
try:
 r=subprocess.run([sys.executable,'launch.py','--check'],cwd=ROOT,env=os.environ,capture_output=True,text=True)
 check('Missing runtime EXECUTE yields actionable grant instruction, not generic traceback',r.returncode!=0 and 'grant runtime EXECUTE' in r.stderr)
finally:
 with e.begin() as c:c.execute(text(f'GRANT EXECUTE ON PROCEDURE {DB}.invoiceflow_verify_identity_guards TO runtime@127.0.0.1'))
Path('/home/user/qa-work/mysql-runtime-results.json').write_text(json.dumps(out,indent=2))


