"""Scenario tests for invoice notes/attachments, relations and merged amounts.

Runs through the real Flask routes (test client). Runs on a temporary SQLite database via
sqlite_harness.py (no MySQL needed). Run: python qa/invoice_history_test.py
"""
import io
import json
import os
import sys
from datetime import date
from decimal import Decimal

sys.path.insert(0, os.path.dirname(__file__))
import sqlite_harness as h  # noqa: E402

app = h.make_app()
app.config['TESTING'] = True

from app.extensions import db  # noqa: E402
from app.models import User, Invoice, InvoiceNote, InvoiceNoteMedia, InvoiceLink, AuditLog  # noqa: E402

PASSED = []


def check(label, cond, extra=''):
    if not cond:
        raise AssertionError(f'FAIL: {label} {extra}')
    PASSED.append(label)
    print('PASS', label)


def setup_data():
    with app.app_context():
        admin = User(username='admin', email='admin@x.test', role='admin')
        admin.set_password('Admin@12345')
        sarah = User(username='sarah', email='sarah@x.test', role='data_entry')
        sarah.set_password('Sarah@12345')
        omar = User(username='omar', email='omar@x.test', role='data_entry')
        omar.set_password('Omar@12345')
        db.session.add_all([admin, sarah, omar])
        db.session.flush()

        def inv(serial, owner, amounts):
            i = Invoice(batch_id=1, date=date(2026, 10, 1), serial_number=serial,
                        total_amount=Decimal(str(round(sum(amounts), 3))),
                        created_by=owner.id, updated_by=owner.id)
            i.set_amounts(amounts)
            db.session.add(i)
            db.session.flush()
            return i.id

        ids = {
            'i1': inv('0001', sarah, [10.0, 5.5]),
            'i2': inv('0002', sarah, [20.0]),
            'i3': inv('0003', omar, [7.0]),
            'i4': inv('0004', sarah, [3.0]),
        }
        db.session.commit()
        return ids


def login(client, username, password):
    r = client.post('/auth/login', data={'username': username, 'password': password})
    assert r.status_code in (200, 302), r.status_code


def load(inv_id):
    with app.app_context():
        db.session.expire_all()
        i = db.session.get(Invoice, inv_id)
        return i.get_amounts(), float(i.total_amount)


def upload_dir():
    return app.config['UPLOAD_FOLDER']


def main():
    ids = setup_data()
    i1, i2, i3, i4 = ids['i1'], ids['i2'], ids['i3'], ids['i4']

    sarah_c = app.test_client()
    omar_c = app.test_client()
    admin_c = app.test_client()
    login(sarah_c, 'sarah', 'Sarah@12345')
    login(omar_c, 'omar', 'Omar@12345')
    login(admin_c, 'admin', 'Admin@12345')

    # ---------------- Notes ----------------
    r = sarah_c.post(f'/invoices/{i1}/notes?batch_id=1', data={'body': 'Customer asked to re-issue this.'})
    check('note text-only saved (redirect)', r.status_code == 302, str(r.status_code))
    with app.app_context():
        notes = InvoiceNote.query.filter_by(invoice_id=i1).all()
        check('note row created', len(notes) == 1 and notes[0].body == 'Customer asked to re-issue this.')
        n1 = notes[0].id

    r = sarah_c.post(f'/invoices/{i1}/notes?batch_id=1',
                     data={'body': 'Scan of the printed copy',
                           'files': [(io.BytesIO(b'%PDF-1.4 fake pdf bytes'), 'scan.pdf', 'application/pdf'),
                                     (io.BytesIO(b'\x89PNG fake'), 'photo.png', 'image/png')]},
                     content_type='multipart/form-data')
    check('note with two attachments saved', r.status_code == 302, str(r.status_code))
    with app.app_context():
        note2 = InvoiceNote.query.filter(InvoiceNote.invoice_id == i1, InvoiceNote.body == 'Scan of the printed copy').one()
        atts = InvoiceNoteMedia.query.filter_by(note_id=note2.id).all()
        check('two attachment rows linked to note', len(atts) == 2)
        pdf = [a for a in atts if a.file_name == 'scan.pdf'][0]
        pdf_id = pdf.id
        check('attachment stored on disk under invoice notes folder',
              os.path.isfile(os.path.join(upload_dir(), pdf.file_path)) and 'notes' in pdf.file_path)

    r = sarah_c.get(f'/invoices/{i1}/notes/attachments/{pdf_id}')
    check('attachment downloads for owner', r.status_code == 200 and r.data.startswith(b'%PDF'))

    r = omar_c.get(f'/invoices/{i1}/notes/attachments/{pdf_id}')
    check('attachment hidden from other clerk', r.status_code == 404, str(r.status_code))

    r = sarah_c.post(f'/invoices/{i1}/notes?batch_id=1',
                     data={'body': 'bad', 'files': [(io.BytesIO(b'MZ'), 'virus.exe', 'application/octet-stream')]},
                     content_type='multipart/form-data')
    with app.app_context():
        check('disallowed file type rejected, nothing saved',
              InvoiceNote.query.filter_by(invoice_id=i1).count() == 2)

    r = sarah_c.post(f'/invoices/{i1}/notes?batch_id=1', data={'body': '   '},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    check('empty note rejected (AJAX 400)', r.status_code == 400 and r.get_json()['success'] is False)

    r = sarah_c.post(f'/invoices/{i1}/notes?batch_id=1', data={'body': 'x' * 2001},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    check('note over 2000 chars rejected', r.status_code == 400)

    r = omar_c.post(f'/invoices/{i1}/notes?batch_id=1', data={'body': 'sneaky'},
                    headers={'X-Requested-With': 'XMLHttpRequest'})
    check('other clerk cannot add note to invoice they do not own', r.status_code in (403, 404), str(r.status_code))

    r = sarah_c.get(f'/invoices/{i1}')
    check('invoice view shows note text', b'Customer asked to re-issue this.' in r.data)
    check('invoice view shows attachment link', b'scan.pdf' in r.data)

    # ---------------- Relations / merge ----------------
    r = sarah_c.post(f'/invoices/{i1}/links?batch_id=1',
                     data={'linked_serial': '2', 'link_type': 'duplicate', 'amount_action': 'merge',
                           'link_note': 'Customer re-issued; amount carried over'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    check('duplicate + merge link created', r.status_code == 200 and r.get_json()['success'], r.get_data(as_text=True))
    amounts, total = load(i1)
    check('merge appended linked total as a new amount line', amounts == [10.0, 5.5, 20.0], str(amounts))
    check('receiver total recalculated', abs(total - 35.5) < 1e-9, str(total))
    a2, t2 = load(i2)
    check('linked (past) invoice left unchanged', a2 == [20.0] and abs(t2 - 20.0) < 1e-9)

    r = sarah_c.post(f'/invoices/{i1}/links?batch_id=1', data={'linked_serial': '2', 'link_type': 'related'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    check('duplicate link pair refused', r.status_code == 400 and 'already linked' in r.get_json()['error'])

    r = omar_c.post(f'/invoices/{i3}/links?batch_id=1', data={'linked_serial': '1', 'link_type': 'related'},
                    headers={'X-Requested-With': 'XMLHttpRequest'})
    check('clerk cannot link to an invoice they cannot access', r.status_code == 400 and 'available to you' in r.get_json()['error'])

    r = sarah_c.post(f'/invoices/{i1}/links?batch_id=1', data={'linked_serial': '1', 'link_type': 'related'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    check('self link refused', r.status_code == 400)

    r = sarah_c.post(f'/invoices/{i1}/links?batch_id=1', data={'linked_serial': '4', 'link_type': 'related', 'amount_action': 'merge'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    check('merge refused for plain related relation', r.status_code == 400)

    r = sarah_c.post(f'/invoices/{i1}/links?batch_id=1', data={'linked_serial': '9999', 'link_type': 'related'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    check('unknown serial refused', r.status_code == 400)

    # Deleting a linked invoice must be refused so merged amounts cannot be orphaned.
    r = sarah_c.post(f'/invoices/{i2}/delete?batch_id=1', headers={'X-Requested-With': 'XMLHttpRequest'})
    check('linked invoice cannot be deleted', r.status_code == 400 and 'linked' in r.get_json()['error'], r.get_data(as_text=True))
    with app.app_context():
        check('linked invoice still exists', db.session.get(Invoice, i2) is not None)

    # History from the OTHER side shows the relation and the notes from the linked invoice.
    r = sarah_c.get(f'/invoices/{i2}/history')
    hist = r.get_json()
    check('history JSON returns relations for linked side',
          r.status_code == 200 and len(hist['relations']) == 1 and hist['relations'][0]['relation'] == 'Has duplicate')
    check('history JSON on linked side includes notes of linked invoice',
          any(n['invoice_id'] == i1 and n['is_own'] is False for n in hist['notes']))
    check('history JSON exposes attachments of linked invoice',
          any(a['file_name'] == 'scan.pdf' for n in hist['notes'] for a in n['attachments']))

    r = sarah_c.get(f'/invoices/{i2}')
    check('linked invoice view shows relation section', b'Has duplicate' in r.data and b'invoice-history' in r.data)
    r = sarah_c.get(f'/invoices/{i1}')
    check('receiver page renders merged badge', b'Merged +20.000 into this invoice' in r.data)
    r2 = sarah_c.get(f'/invoices/{i2}')
    check('linked page renders merged-into-other badge', b'Amount merged into #0001' in r2.data)

    r = sarah_c.get(f'/invoices/{i1}/history')
    hist1 = r.get_json()
    check('receiver history shows merged badge data',
          hist1['relations'][0]['merged'] is True and hist1['relations'][0]['merged_amount'] == 20.0
          and hist1['relations'][0]['receiver_side'] is True)

    # Search results expose relation/note counts.
    r = sarah_c.post('/invoices/search?batch_id=1', data={'search_type': 'serial', 'query': '0002'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    res = r.get_json()['results']
    check('search result shows linked_count and note_count',
          res and res[0]['linked_count'] == 1 and res[0]['note_count'] == 0, str(res[:1]))
    r = sarah_c.post('/invoices/search?batch_id=1', data={'search_type': 'serial', 'query': '0001'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    res = r.get_json()['results']
    check('search result for receiver shows note_count', res and res[0]['note_count'] == 2, str(res[:1]))

    # Unlink from the LINKED side reverses the merged line on the receiver.
    link_id = hist['relations'][0]['id']
    r = sarah_c.post(f'/invoices/{i2}/links/{link_id}/delete?batch_id=1', headers={'X-Requested-With': 'XMLHttpRequest'})
    check('unlink from linked side succeeds', r.status_code == 200 and r.get_json()['success'], r.get_data(as_text=True))
    amounts, total = load(i1)
    check('unlink reversed the merged amount line', amounts == [10.0, 5.5] and abs(total - 15.5) < 1e-9, str(amounts))
    with app.app_context():
        check('link row removed', InvoiceLink.query.count() == 0)

    # ---------------- Multiple merges keep line indexes correct ----------------
    r = sarah_c.post(f'/invoices/{i1}/links?batch_id=1',
                     data={'linked_serial': '2', 'link_type': 'adjustment', 'amount_action': 'merge'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    check('adjustment merge #1 (idx 2)', r.status_code == 200)
    r = sarah_c.post(f'/invoices/{i1}/links?batch_id=1',
                     data={'linked_serial': '4', 'link_type': 'adjustment', 'amount_action': 'merge'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    check('adjustment merge #2 (idx 3)', r.status_code == 200)
    amounts, total = load(i1)
    check('two merges appended in order', amounts == [10.0, 5.5, 20.0, 3.0], str(amounts))

    link_for_i2 = None
    with app.app_context():
        link_for_i2 = InvoiceLink.query.filter_by(linked_invoice_id=i2).one().id
        link_for_i4 = InvoiceLink.query.filter_by(linked_invoice_id=i4).one().id
    r = sarah_c.post(f'/invoices/{i1}/links/{link_for_i2}/delete?batch_id=1', headers={'X-Requested-With': 'XMLHttpRequest'})
    check('unlink first merge succeeds', r.status_code == 200, r.get_data(as_text=True))
    amounts, total = load(i1)
    check('later merge line shifted correctly after unlink', amounts == [10.0, 5.5, 3.0], str(amounts))
    r = sarah_c.post(f'/invoices/{i1}/links/{link_for_i4}/delete?batch_id=1', headers={'X-Requested-With': 'XMLHttpRequest'})
    check('second unlink succeeds after index shift', r.status_code == 200, r.get_data(as_text=True))
    amounts, total = load(i1)
    check('amounts back to original after both unlinks', amounts == [10.0, 5.5] and abs(total - 15.5) < 1e-9, str(amounts))

    # Tampered merged line: refuse to unlink silently.
    r = sarah_c.post(f'/invoices/{i1}/links?batch_id=1',
                     data={'linked_serial': '2', 'link_type': 'duplicate', 'amount_action': 'merge'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    with app.app_context():
        lid = InvoiceLink.query.filter_by(linked_invoice_id=i2).one().id
        inv = db.session.get(Invoice, i1)
        inv.set_amounts([10.0, 5.5, 99.0])
        inv.total_amount = Decimal('114.5')
        db.session.commit()
    r = sarah_c.post(f'/invoices/{i1}/links/{lid}/delete?batch_id=1', headers={'X-Requested-With': 'XMLHttpRequest'})
    check('unlink refused when merged line was edited', r.status_code == 400 and 'changed after linking' in r.get_json()['error'])
    with app.app_context():
        check('refused unlink keeps link row', db.session.get(InvoiceLink, lid) is not None)
        inv = db.session.get(Invoice, i1)
        inv.set_amounts([10.0, 5.5, 20.0])
        inv.total_amount = Decimal('35.5')
        db.session.commit()
    r = sarah_c.post(f'/invoices/{i1}/links/{lid}/delete?batch_id=1', headers={'X-Requested-With': 'XMLHttpRequest'})
    check('cleanup unlink after restoring amounts', r.status_code == 200)
    amounts, total = load(i1)
    check('amounts restored after cleanup', amounts == [10.0, 5.5], str(amounts))

    # Link only (no merge) for duplicate: amounts untouched.
    r = sarah_c.post(f'/invoices/{i1}/links?batch_id=1',
                     data={'linked_serial': '4', 'link_type': 'duplicate', 'amount_action': 'none'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    amounts, total = load(i1)
    check('link-only duplicate leaves amounts unchanged', r.status_code == 200 and amounts == [10.0, 5.5])
    with app.app_context():
        lid4 = InvoiceLink.query.filter_by(linked_invoice_id=i4).one().id
    sarah_c.post(f'/invoices/{i1}/links/{lid4}/delete?batch_id=1', headers={'X-Requested-With': 'XMLHttpRequest'})

    # ---------------- Hidden links from other clerks ----------------
    r = admin_c.post(f'/invoices/{i3}/links?batch_id=1',
                     data={'linked_serial': '1', 'link_type': 'related'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    check('admin can link any invoice in batch', r.status_code == 200 and r.get_json()['success'], r.get_data(as_text=True))
    r = sarah_c.get(f'/invoices/{i1}/history')
    check('clerk sees hidden link count instead of other clerk invoice',
          r.get_json()['hidden_link_count'] == 1 and all(x['other']['id'] != i3 for x in r.get_json()['relations']))
    r = admin_c.get(f'/invoices/{i1}/history')
    check('admin sees the link to other clerk invoice', any(x['other']['id'] == i3 for x in r.get_json()['relations']))

    # ---------------- Note deletion & permissions ----------------
    with app.app_context():
        note_id = InvoiceNote.query.filter(InvoiceNote.invoice_id == i1,
                                           InvoiceNote.body == 'Scan of the printed copy').one().id
    r = omar_c.post(f'/invoices/{i1}/notes/{note_id}/delete?batch_id=1', headers={'X-Requested-With': 'XMLHttpRequest'})
    check('other clerk cannot delete note', r.status_code in (403, 404), str(r.status_code))
    r = admin_c.post(f'/invoices/{i1}/notes/{note_id}/delete?batch_id=1', headers={'X-Requested-With': 'XMLHttpRequest'})
    check('admin can delete a note', r.status_code == 200 and r.get_json()['success'], r.get_data(as_text=True))
    with app.app_context():
        check('deleted note removed', db.session.get(InvoiceNote, note_id) is None)

    with app.app_context():
        check('attachment rows removed with note', db.session.get(InvoiceNoteMedia, pdf_id) is None)
    # Files of that note were removed from disk; the text-only note's attachments folder stays empty.
    leftover = []
    for root, _dirs, files in os.walk(upload_dir()):
        leftover += files
    check('attachment files removed from disk when note deleted', leftover == [], str(leftover))

    # ---------------- Batch lock stops writes ----------------
    with app.app_context():
        from app.models import Batch
        b = db.session.get(Batch, 1)
        b.locked = True
        db.session.commit()
    r = sarah_c.post(f'/invoices/{i1}/notes?batch_id=1', data={'body': 'after lock'})
    check('locked batch blocks clerk note creation', r.status_code == 403, str(r.status_code))
    with app.app_context():
        from app.models import Batch
        db.session.get(Batch, 1).locked = False
        db.session.commit()

    # ---------------- Delete invoice without links cleans up notes ----------------
    r = sarah_c.post(f'/invoices/{i1}/notes?batch_id=1',
                     data={'body': 'to be deleted', 'files': [(io.BytesIO(b'%PDF-1.4 x'), 'gone.pdf', 'application/pdf')]},
                     content_type='multipart/form-data')
    check('extra note saved before deleting invoice', r.status_code == 302)
    # i1 still has a link to i3 (admin link). Remove it first to test deletion path.
    with app.app_context():
        lid3 = InvoiceLink.query.filter_by(invoice_id=i3).one().id
    admin_c.post(f'/invoices/{i3}/links/{lid3}/delete?batch_id=1', headers={'X-Requested-With': 'XMLHttpRequest'})
    r = sarah_c.post(f'/invoices/{i4}/delete?batch_id=1', headers={'X-Requested-With': 'XMLHttpRequest'})
    check('unlinked invoice delete works', r.status_code == 200 and r.get_json()['success'], r.get_data(as_text=True))
    with app.app_context():
        check('invoice i4 deleted', db.session.get(Invoice, i4) is None)
        check('audit row for link actions written', AuditLog.query.filter_by(action='link_invoice').count() >= 2)
        check('audit row for unlink written', AuditLog.query.filter_by(action='unlink_invoice').count() >= 1)
        check('audit row for note add written', AuditLog.query.filter_by(action='add_invoice_note').count() >= 3)

    print(f'\nALL {len(PASSED)} CHECKS PASSED')


if __name__ == '__main__':
    main()
