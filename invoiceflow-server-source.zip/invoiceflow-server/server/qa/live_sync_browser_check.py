"""Browser check for background live sync (realtime.js) against the SQLite demo server.

Run while the demo server is up (python qa/screenshots/demo_server.py, port 5055) and after
`rm -rf /tmp/ifh_*` so the database is fresh:

    python qa/live_sync_browser_check.py

Environment overrides:
    IFH_BASE         default http://127.0.0.1:5055
    IFH_DB           path to the demo SQLite file (default: newest /tmp/ifh_*/test.db)
    CHROMIUM_PATH    optional Chromium executable (default: Playwright's bundled browser)

Checks
  1. Another "worker" changes invoices and bumps live_revision; each open page must update
     without a reload (dashboard, summary, invoice list, invoice view, analytics).
  2. Draft safety: a typed note draft and a focused field survive a background refresh,
     and an invoice-editor amount draft is kept without reloading the editor.

The grid page is not asserted here: it shows a serial/date presence matrix, so an amount
change is not visible on it. Its refresh request is exercised by the same loop.
"""
import glob
import os
import subprocess
import sys
import time

from playwright.sync_api import sync_playwright

BASE = os.environ.get('IFH_BASE', 'http://127.0.0.1:5055')
PAGES = ['/dashboard', '/invoices/summary', '/invoices/?batch_id=1', '/invoices/1', '/admin/analytics/']
ADMIN = ('admin', 'Admin@12345')
results = []


def demo_db():
    if os.environ.get('IFH_DB'):
        return os.environ['IFH_DB']
    found = sorted(glob.glob('/tmp/ifh_*/test.db'), key=os.path.getmtime)
    if not found:
        sys.exit('No demo database found. Start qa/screenshots/demo_server.py first.')
    return found[-1]


DB = demo_db()


def external_write():
    """Mimic a commit from another worker: change one invoice per batch and bump the revision.

    The write runs in a clean environment so a LD_LIBRARY_PATH for Chromium cannot shadow
    the system sqlite3 module.
    """
    env = {k: v for k, v in os.environ.items() if k != 'LD_LIBRARY_PATH'}
    code = ("import sqlite3,sys,uuid;c=sqlite3.connect(sys.argv[1]);"
            "c.execute('UPDATE invoices SET total_amount = total_amount + 1 "
            "WHERE id IN (SELECT MIN(id) FROM invoices GROUP BY batch_id)');"
            "c.execute('UPDATE live_revision SET token = ? WHERE id = 1',(uuid.uuid4().hex,));"
            "c.commit();c.close()")
    subprocess.run([sys.executable, '-c', code, DB], check=True, env=env)


def check(name, ok):
    results.append((name, bool(ok)))
    print('PASS' if ok else 'FAIL', name, flush=True)


def login(ctx):
    page = ctx.new_page()
    page.goto(BASE + '/auth/login')
    page.fill('#username', ADMIN[0])
    page.fill('#password', ADMIN[1])
    page.click('[type=submit]')
    page.wait_for_load_state('networkidle')
    return page


def wait_live(page):
    page.wait_for_function("document.querySelector('#live-status')?.textContent === 'Live'", timeout=20000)


# Invoice view: probe the invoice's own total. The page also shows other invoices in its
# link list, which can change through a live region and would hide a stale main total.
PROBES = {'/invoices/1': "document.querySelector('main .display-6')?.innerText || ''"}


def probe(page, path):
    return page.evaluate(PROBES.get(path, "document.querySelector('main')?.innerText || ''"))


with sync_playwright() as pw:
    launch = {'args': ['--no-sandbox']}
    if os.environ.get('CHROMIUM_PATH'):
        launch['executable_path'] = os.environ['CHROMIUM_PATH']
    browser = pw.chromium.launch(**launch)
    ctx = browser.new_context(viewport={'width': 1366, 'height': 900})
    page_errors = []
    login(ctx)

    # 1) Background content updates
    for path in PAGES:
        page = ctx.new_page()
        page.on('pageerror', lambda e: page_errors.append(str(e)[:200]))
        page.goto(BASE + path)
        page.wait_for_load_state('networkidle')
        try:
            wait_live(page)
        except Exception:
            check(f'{path}: live status reached', False)
            page.close()
            continue
        before = probe(page, path)
        external_write()
        started = time.time()
        updated = False
        while time.time() - started < 12:
            if probe(page, path) != before:
                updated = True
                break
            page.wait_for_timeout(300)
        check(f'{path}: updates without reload ({time.time() - started:.1f}s)', updated)
        page.close()

    # 2) Draft safety
    page = ctx.new_page()
    page.goto(BASE + '/invoices/1')
    wait_live(page)
    page.fill('#note-form textarea[name=body]', 'DRAFT-NOTE-KEEP')
    page.focus('#note-form textarea[name=body]')
    external_write()
    page.wait_for_timeout(5000)
    check('note draft kept after background refresh',
          page.input_value('#note-form textarea[name=body]') == 'DRAFT-NOTE-KEEP')
    check('focused field keeps focus', page.evaluate("document.activeElement?.name") == 'body')
    page.close()

    page = ctx.new_page()
    page.goto(BASE + '/invoices/1/edit')
    wait_live(page)
    page.locator('.amount-field-input').first.fill('555.125')
    page.evaluate("window.__marker = 'alive'")
    external_write()
    page.wait_for_timeout(5000)
    check('editor amount draft kept', page.locator('.amount-field-input').first.input_value() == '555.125')
    check('editor was not reloaded', page.evaluate("window.__marker") == 'alive')
    page.close()
    check('no page errors', not page_errors)
    browser.close()

failed = [name for name, ok in results if not ok]
print(f'\n{len(results) - len(failed)}/{len(results)} checks passed')
sys.exit(1 if failed else 0)
