"""Tests for: note-attachment QR, live link lookup, background note/link forms, mobile note upload.

Runs through the real Flask app on a temporary SQLite database (sqlite_harness.py).
Run: python qa/note_qr_and_lookup_test.py
"""
import io
import json
import os
import sys
from datetime import date
from decimal import Decimal

sys.path.insert(0, os.path.dirname(__file__))
import sqlite_harness as h  # noqa: E402

app = h.make_app()
app.config['TESTING'] = True

from app.extensions import db  # noqa: E402
from app.models import User, Invoice, UserCapability  # noqa: E402
from app.routes.media import _build_invoice_qr_payload  # noqa: E402

PASSED = []
XHR = {'X-Requested-With': 'XMLHttpRequest'}
SARAH_KEY = 'sarah-key-123'
H = {'X-API-Key': SARAH_KEY}


def check(label, cond, extra=''):
    if not cond:
        raise AssertionError(f'FAIL: {label} {extra}')
    PASSED.append(label)
    print('PASS', label)


def setup_data():
    with app.app_context():
        sarah = User(username='sarah', email='sarah@x.test', role='data_entry', api_key=SARAH_KEY)
        sarah.set_password('Sarah@12345')
        omar = User(username='omar', email='omar@x.test', role='data_entry', api_key='omar-key-456')
        omar.set_password('Omar@12345')
        db.session.add_all([sarah, omar])
        db.session.flush()

        def mk(serial, owner, amount):
            i = Invoice(batch_id=1, date=date(2026, 10, 15), serial_number=serial,
                        total_amount=Decimal(str(amount)), created_by=owner.id, updated_by=owner.id)
            i.set_amounts([float(amount)])
            db.session.add(i)
            db.session.flush()
            return i.id

        ids = {'mine': mk('0001', sarah, 10.0), 'mine2': mk('0002', sarah, 20.0),
               'other': mk('0003', omar, 5.0), 'sarah_id': sarah.id}
        db.session.commit()
        return ids


def login(client, username, password):
    r = client.post('/auth/login', data={'username': username, 'password': password})
    assert r.status_code in (200, 302), r.status_code


def main():
    ids = setup_data()
    sarah_c = app.test_client()
    login(sarah_c, 'sarah', 'Sarah@12345')
    anon = app.test_client()

    # ---------------- note-attachment QR ----------------
    with app.test_request_context('/'):
        inv = db.session.get(Invoice, ids['mine'])
        payload = json.loads(_build_invoice_qr_payload(inv, 'app', 'focus', 'note'))
        check('QR payload carries target=note', payload.get('target') == 'note', str(payload))
        check('QR payload keeps focus scan', payload.get('scan') == 'focus')
        plain = json.loads(_build_invoice_qr_payload(inv, 'app', 'focus'))
        check('default QR payload target is invoice', plain.get('target') == 'invoice')
        bogus = json.loads(_build_invoice_qr_payload(inv, 'app', 'focus', 'zzz'))
        check('unknown target falls back to invoice', bogus.get('target') == 'invoice')

    r = sarah_c.get('/media/qr/0001.svg?batch_id=1&mode=app&scan=focus&target=note')
    check('QR svg for own invoice renders', r.status_code == 200, str(r.status_code))
    check('QR svg is not cached publicly', 'no-store' in (r.headers.get('Cache-Control') or ''))
    r = anon.get('/media/qr/0001.svg?batch_id=1&mode=app&scan=focus&target=note')
    check('QR svg needs login', r.status_code in (302, 401, 403), str(r.status_code))
    r = sarah_c.get('/media/qr/0003.svg?batch_id=1&mode=app&scan=focus&target=note')
    check('QR svg hidden for another user\'s invoice', r.status_code == 404, str(r.status_code))
    r = sarah_c.get('/media/qr/0001.png?batch_id=1&mode=app&scan=focus&target=note')
    check('QR png for own invoice renders', r.status_code == 200, str(r.status_code))

    # ---------------- live link lookup ----------------
    base = f"/invoices/link-lookup?batch_id=1&current={ids['mine']}"
    r = sarah_c.get(base + '&serial=0002', headers=XHR)
    body = r.get_json()
    check('lookup finds a linkable invoice', r.status_code == 200 and body.get('found') is True, str(body))
    inv_json = body.get('invoice', {})
    check('lookup returns serial, date, total, amounts',
          inv_json.get('serial_number') == '0002' and inv_json.get('date') == '2026-10-15'
          and float(inv_json.get('total_amount')) == 20.0 and inv_json.get('amounts') == [20.0],
          str(inv_json))
    check('lookup returns batch name', bool(inv_json.get('batch_name')))

    body = sarah_c.get(base + '&serial=0003', headers=XHR).get_json()
    check('lookup hides an invoice the user cannot access',
          body.get('found') is False and '0003' in body.get('message', ''), str(body))
    body = sarah_c.get(base + '&serial=0001', headers=XHR).get_json()
    check('lookup refuses the invoice itself', body.get('found') is False and 'this invoice' in body.get('message', '').lower(), str(body))
    body = sarah_c.get(base + '&serial=9999', headers=XHR).get_json()
    check('lookup reports a missing serial', body.get('found') is False, str(body))
    body = sarah_c.get(base + '&serial=', headers=XHR).get_json()
    check('empty serial gives an empty, not-found reply', body == {'found': False, 'message': ''}, str(body))
    r = sarah_c.get('/invoices/link-lookup?batch_id=abc&serial=0002', headers=XHR)
    check('bad batch id is rejected', r.status_code == 400, str(r.status_code))
    r = anon.get('/invoices/link-lookup?batch_id=1&serial=0002', headers=XHR)
    check('lookup needs login', r.status_code in (302, 401, 403), str(r.status_code))

    # ---------------- background note save (web, AJAX) ----------------
    url = f"/invoices/{ids['mine']}/notes?batch_id=1"
    r = sarah_c.post(url, data={'body': 'Customer confirmed by phone'}, headers=XHR)
    check('AJAX note with text saves', r.status_code == 200 and r.get_json().get('success') is True,
          f'{r.status_code} {r.get_data(as_text=True)[:200]}')
    r = sarah_c.post(url, data={'body': '', 'files': (io.BytesIO(b'%PDF-1.4 test'), 'scan.pdf')},
                     content_type='multipart/form-data', headers=XHR)
    check('AJAX note with a file and no text saves', r.status_code == 200 and r.get_json().get('success') is True,
          f'{r.status_code} {r.get_data(as_text=True)[:200]}')
    r = sarah_c.post(url, data={'body': '', 'files': (io.BytesIO(b'MZ'), 'tool.exe')},
                     content_type='multipart/form-data', headers=XHR)
    check('AJAX note refuses a blocked file type', r.status_code == 400 and r.get_json().get('success') is not True,
          f'{r.status_code}')
    r = sarah_c.post(url, data={'body': ''}, headers=XHR)
    check('AJAX empty note is refused', r.status_code == 400, str(r.status_code))

    # ---------------- mobile API: note with attachment ----------------
    r = sarah_c.post('/api/v1/invoices/0001/notes?batch_id=1', headers=H,
                     data={'body': '', 'file': (io.BytesIO(b'%PDF-1.4 phone scan'), 'phone.pdf')},
                     content_type='multipart/form-data')
    check('mobile API: attachment-only note from phone is saved', r.status_code == 201, f'{r.status_code} {r.get_data(as_text=True)[:200]}')
    if r.status_code == 201:
        notes = r.get_json()['history']['notes']
        check('mobile API: the new note carries the attachment',
              any(n.get('attachments') and n['attachments'][0]['file_name'] == 'phone.pdf' for n in notes))

    # ---------------- permissions still enforced ----------------
    with app.app_context():
        db.session.add(UserCapability(user_id=ids['sarah_id'], capability='notes.create', allowed=False))
        db.session.commit()
    r = sarah_c.post(url, data={'body': 'blocked'}, headers=XHR)
    check('AJAX note blocked when notes.create is off', r.status_code == 403, str(r.status_code))
    r = sarah_c.get(base + '&serial=0002', headers=XHR)
    check('lookup still works without notes.create', r.status_code == 200 and r.get_json().get('found') is True)
    with app.app_context():
        UserCapability.query.filter_by(user_id=ids['sarah_id']).delete()
        db.session.commit()

    # ---------------- rendered invoice page ----------------
    r = sarah_c.get(f"/invoices/{ids['mine']}?batch_id=1")
    page = r.get_data(as_text=True)
    check('invoice page renders', r.status_code == 200, str(r.status_code))
    check('page has the note QR modal', 'id="noteQrModal"' in page)
    check('note QR image asks for target=note', 'target=note' in page and 'scan=focus' in page)
    check('page has the live link preview box', 'id="link-preview"' in page and 'id="link-submit"' in page)
    check('link and note forms submit in the background',
          'data-history-form id="link-form"' in page and 'data-history-form id="note-form"' in page)
    check('note file input no longer restricts types', 'accept=".pdf,.png' not in page)

    print(f'\nALL {len(PASSED)} NOTE-QR / LOOKUP CHECKS PASSED')


if __name__ == '__main__':
    main()
