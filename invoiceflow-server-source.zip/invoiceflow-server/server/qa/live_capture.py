import sys,io
from pathlib import Path
from PIL import Image
from playwright.sync_api import sync_playwright
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from support.demo_app import app
from app.extensions import db
from app.models import InvoiceMedia
with sync_playwright() as p:
 b=p.chromium.launch();ctx=b.new_context(viewport={'width':1440,'height':1000},reduced_motion='reduce');pg=ctx.new_page();pg.goto('http://127.0.0.1:5000/auth/login');pg.fill('#username','admin');pg.fill('#password','Preview@2026');pg.click('[type=submit]');pg.wait_for_url('**/dashboard*');pg.goto('http://127.0.0.1:5000/media/upload/1')
 bio=io.BytesIO();img=Image.new('RGB',(320,420),'#f4eafa');from PIL import ImageDraw;draw=ImageDraw.Draw(img);draw.rounded_rectangle((25,25,295,395),15,fill='white');draw.text((45,55),'INVOICEFLOW',fill='#633d94');draw.text((45,95),'Sample invoice attachment',fill='#63556b');draw.text((45,145),'Invoice #0001',fill='#633d94');img.save(bio,format='PNG')
 pg.set_input_files('#files',{'name':'sample-attachment.png','mimeType':'image/png','buffer':bio.getvalue()});pg.click('#upload-submit-btn');pg.wait_for_selector('.attachment-thumb');pg.wait_for_timeout(500);pg.screenshot(path='/home/user/qa-work/screenshots/66-live-upload.png',full_page=True)
 pg.goto('http://127.0.0.1:5000/invoices/1');pg.wait_for_timeout(500);pg.screenshot(path='/home/user/qa-work/screenshots/64-live-invoice-desktop.png',full_page=True)
 pg.set_viewport_size({'width':390,'height':844});pg.goto('http://127.0.0.1:5000/media/m/0001');pg.wait_for_timeout(500);pg.screenshot(path='/home/user/qa-work/screenshots/67-live-camera.png',full_page=True)
 pg.set_viewport_size({'width':1440,'height':1000});pg.goto('http://127.0.0.1:5000/admin/books/2');pg.click('[data-bs-target="#book-insights"]');pg.wait_for_timeout(500);pg.screenshot(path='/home/user/qa-work/screenshots/68-book-insights.png',full_page=True);b.close()
with app.app_context():
 for m in InvoiceMedia.query.filter_by(file_name='sample-attachment.png').all():
  path=Path('/home/user/invoiceflow/uploads')/m.file_path
  if path.exists():path.unlink()
  db.session.delete(m)
 db.session.commit()


