from playwright.sync_api import sync_playwright
from pathlib import Path
import sys,json,io
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from support.demo_app import app
from app.extensions import db
from app.models import Invoice,InvoiceMedia,User,AuditLog,SystemSetting,Book
from app.realtime import revision
BASE='http://127.0.0.1:5000';results=[]
def check(n,c):results.append({'test':n,'passed':bool(c)});print('PASS' if c else 'FAIL',n,flush=True);assert c,n
def login(ctx,user='admin'):
 pg=ctx.new_page();pg.goto(BASE+'/auth/login');pg.fill('#username',user);pg.fill('#password','Preview@2026');pg.click('[type=submit]');pg.wait_for_url('**/dashboard*' if user=='admin' else '**/invoices/start-session*');return pg
def wait(pg):pg.wait_for_function("document.getElementById('live-status').textContent==='Live'")
with app.app_context():orig_date=db.session.get(Invoice,1).date
try:
 with sync_playwright() as p:
  b=p.chromium.launch();ctx=b.new_context();pg=login(ctx);pg.goto(BASE+'/admin/users');wait(pg);pg.fill('#user-search','livetest')
  with app.app_context():
   u=User(username='livetest',email='livetest@example.test',role='data_entry');u.set_password('Preview@2026');db.session.add(u);db.session.commit();uid=u.id
  pg.wait_for_function("()=>document.querySelector('#user-table-body').innerText.includes('livetest')",timeout=12000)
  check('New user is filtered correctly in a live table',pg.locator('#user-search').input_value()=='livetest' and pg.locator('#user-table-body tr:visible').count()==1)
  calendar=ctx.new_page();calendar.goto(BASE+'/invoices/calendar');wait(calendar);calendar.locator('.calendar-day').filter(has=calendar.locator('.day-number')).count()
  # Select a date range on the existing calendar before another user changes an invoice date.
  calendar.locator('[data-date]').nth(1).click();calendar.locator('[data-date]').nth(4).click();selected=calendar.evaluate("[...document.querySelectorAll('[data-date].selected')].map(e=>e.dataset.date)")
  with app.app_context():
   from datetime import timedelta
   inv=db.session.get(Invoice,1);inv.date=orig_date-timedelta(days=1);db.session.commit()
  calendar.wait_for_timeout(2300)
  check('Calendar range selection survives live data updates',calendar.evaluate("[...document.querySelectorAll('[data-date].selected')].map(e=>e.dataset.date)")==selected)
  # Change commits performed by an isolated second Flask app are visible to server worker.
  token=ctx.request.get(BASE+'/live/version').json()['revision']
  with app.app_context():
   db.session.add(AuditLog(user_id=1,action='live_qa',details={'isolated_app':True},ip_address='127.0.0.1'));db.session.commit()
  check('Version invalidation is shared across app instances',ctx.request.get(BASE+'/live/version').json()['revision']!=token)
  # Non-owner must not receive attachments despite seeing global invalidation.
  bio=io.BytesIO();Image.new('RGB',(80,80),'#8154cc').save(bio,format='PNG');up=ctx.new_page();up.goto(BASE+'/media/upload/1');wait(up);up.set_input_files('#files',{'name':'live-extra.png','mimeType':'image/png','buffer':bio.getvalue()});up.click('#upload-submit-btn');up.wait_for_selector('.attachment-thumb');mid=up.locator('.attachment-thumb').first.get_attribute('src').split('/')[-1]
  clerkctx=b.new_context();clerk=login(clerkctx,'sarah');wait(clerk)
  check('Non-owner is denied a live image thumbnail',clerk.request.get(BASE+'/media/thumb/'+mid).status==403)
  check('Non-owner cannot fetch another user invoice snapshot',clerk.request.get(BASE+'/invoices/1',headers={'X-Live-Sync':'1'}).status in [403,404])
  # Existing file choice remains attached during reconnect; no document refresh.
  pg.goto(BASE+'/invoices/1');wait(pg);pg.evaluate('window.__boot=performance.timeOrigin');ctx.set_offline(True);pg.wait_for_function("document.getElementById('live-status').textContent.includes('Offline')")
  with app.app_context():
   inv=db.session.get(Invoice,1);inv.date=orig_date;db.session.commit()
  ctx.set_offline(False);wait(pg)
  check('Offline client catches up on reconnect without reload',pg.evaluate('window.__boot===performance.timeOrigin'))
  # No dirty state: new system setting updates all controls.
  s1=ctx.new_page();s2=ctx.new_page();s1.goto(BASE+'/admin/settings');s2.goto(BASE+'/admin/settings');wait(s1);wait(s2);initial=s1.locator('#media_required').is_checked();s1.locator('#media_required').set_checked(not initial);s1.locator('#settings-form [type=submit]').click();s2.wait_for_function('(v)=>document.querySelector("#media_required").checked===v',arg=not initial,timeout=12000)
  check('Settings auto-sync across sessions',True)
  s1.locator('#media_required').set_checked(initial);s1.locator('#settings-form [type=submit]').click()
  check('All tests completed',True);b.close()
finally:
 with app.app_context():
  db.session.get(Invoice,1).date=orig_date
  for m in InvoiceMedia.query.filter_by(file_name='live-extra.png').all():
   fp=Path('/home/user/invoiceflow/uploads')/m.file_path
   if fp.exists():fp.unlink()
   db.session.delete(m)
  u=User.query.filter_by(username='livetest').first()
  if u:
   AuditLog.query.filter_by(user_id=u.id).delete();db.session.delete(u)
  AuditLog.query.filter_by(action='live_qa').delete();db.session.commit()
 Path('/home/user/qa-work/live-extra-results.json').write_text(json.dumps(results,indent=2))


