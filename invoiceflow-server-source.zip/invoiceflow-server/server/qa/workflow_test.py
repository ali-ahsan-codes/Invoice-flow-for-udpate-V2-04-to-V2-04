from playwright.sync_api import sync_playwright
from pathlib import Path
import json
BASE='http://127.0.0.1:5000';results=[]
def check(name,condition):
 results.append({'test':name,'passed':bool(condition)});assert condition,name;print('PASS',name)
with sync_playwright() as p:
 b=p.chromium.launch();ctx=b.new_context(viewport={'width':1440,'height':1000},reduced_motion='reduce');page=ctx.new_page()
 page.goto(BASE+'/auth/login');page.fill('#username','admin');page.fill('#password','wrong');page.click('[type=submit]');page.wait_for_timeout(500);check('Invalid login message visible',page.locator('.alert-danger').is_visible());page.screenshot(path='/home/user/qa-work/screenshots/29-login-error.png',full_page=True)
 page.fill('#password','Preview@2026');page.locator('.password-toggle').click();check('Accessible password visibility toggle',page.locator('#password').get_attribute('type')=='text');page.locator('.password-toggle').click();page.check('#remember');page.click('[type=submit]');page.wait_for_url('**/dashboard*')
 check('Login remembers user',any(c['name']=='remember_token' for c in ctx.cookies()))
 page.goto(BASE+'/auth/login');check('Visiting login retains authenticated session',page.url.split('?')[0].endswith('/dashboard'))
 page.goto(BASE+'/auth/profile');page.fill('#email','sarah@example.com');page.click('input[type=submit]');page.wait_for_timeout(500);check('Duplicate email validated',page.get_by_text('Email already registered.').count()>0)
 page.goto(BASE+'/invoices/start-session?book=3');page.locator('#start-session-form [type=submit]').click();page.wait_for_url('**/invoices/create*');page.screenshot(path='/home/user/qa-work/screenshots/30-invoice-create.png',full_page=True)
 page.locator('.amount-field-input').fill('12.500');page.locator('.btn-add-amount').click();page.locator('.amount-field-input').nth(1).fill('7.250');page.locator('.btn-add-amount').click();page.locator('.amount-field-input').nth(2).fill('2.000');page.locator('.btn-remove-amount').nth(1).click();page.locator('.btn-add-amount').click();page.locator('.amount-field-input').nth(2).fill('3.500')
 check('Remove/re-add rows have unique contiguous names',page.locator('.amount-field-input').evaluate_all('(els)=>els.map(e=>e.name)')==['amounts-0','amounts-1','amounts-2'])
 check('Total calculated accurately','18.000' in page.locator('.total-display').inner_text())
 for i in range(18):page.locator('.btn-add-amount').click()
 check('Amount row cap enforced',page.locator('.amount-field-input').count()==20)
 while page.locator('.amount-field-input').count()>3:page.locator('.btn-remove-amount').last.click()
 serial=page.locator('[name=serial_number]').input_value()
 with page.expect_response(lambda r:r.url.split('?')[0].endswith('/invoices/create') and r.request.method=='POST') as response:page.locator('#invoice-form [type=submit]').click()
 data=response.value.json();check('Invoice create successful',data.get('success'))
 page.wait_for_timeout(400);check('Serial advanced after save',page.locator('[name=serial_number]').input_value()!=serial)
 # find created record via grid/list link
 page.goto(BASE+'/invoices/?search='+serial)
 link=page.locator('a').filter(has_text=serial).first
 href=link.get_attribute('href').split('?')[0];page.goto(BASE+href);check('Saved amount persisted','18.000' in page.locator('body').inner_text())
 page.goto(BASE+href+'/edit');page.locator('.amount-field-input').first.fill('20.000')
 with page.expect_response(lambda r:r.url.split('?')[0].endswith('/edit') and r.request.method=='POST') as response:page.locator('#invoice-form [type=submit]').click()
 check('Invoice edit successful',response.value.status==200);page.wait_for_url(BASE+href+'*');check('Edited total persisted','25.500' in page.locator('body').inner_text())
 token=page.locator('meta[name=csrf-token]').get_attribute('content')
 r=ctx.request.post(BASE+href+'/delete?batch_id=1',headers={'X-CSRFToken':token,'X-Requested-With':'XMLHttpRequest'});check('Invoice delete successful',r.ok and r.json().get('success'))
 page.goto(BASE+'/dashboard');check('Toast renders untrusted messages as text',page.evaluate("() => { showToast('<img src=x onerror=alert(1)>'); return document.querySelector('.toast-message').textContent.includes('<img') && !document.querySelector('.toast img'); }") )
 page.goto(BASE+'/auth/logout');check('Logout clears remember cookie',not any(c['name']=='remember_token' for c in ctx.cookies()));check('Logged-out dashboard protected',ctx.request.get(BASE+'/dashboard',max_redirects=0).status==302)
 page.goto(BASE+'/auth/login?next=https://evil.example');page.fill('#username','admin');page.fill('#password','Preview@2026');page.click('[type=submit]');page.wait_for_url('**/dashboard*');check('External redirect blocked',page.url.startswith(BASE))
 # date regression in an American timezone
 west=b.new_context(timezone_id='America/Los_Angeles');w=west.new_page();w.goto(BASE+'/auth/login');check('Date-only strings do not shift day',w.evaluate("formatDate('2026-10-08')")=='2026-10-08');west.close()
 # user deletion with references
 page.goto(BASE+'/auth/register');page.fill('#username','testdelete');page.fill('#email','testdelete@example.com');page.fill('#password','Testing123');page.fill('#confirm_password','Testing123');page.click('input[type=submit]');page.wait_for_url('**/admin/users*')
 check('User registration works',page.get_by_text('testdelete',exact=True).count()>0)
 # capture ID from actual rendered endpoint
 row=page.locator('tr').filter(has_text='testdelete');edit=row.locator('a[href*="/edit"]').get_attribute('href');uid=edit.split('?')[0].split('/')[-2]
 token=page.locator('meta[name=csrf-token]').get_attribute('content');r=ctx.request.post(BASE+f'/admin/users/{uid}/delete',headers={'X-CSRFToken':token,'X-Requested-With':'XMLHttpRequest'});check('User deletion works',r.ok and r.json().get('success'))
 b.close()
Path('workflow-results.json').write_text(json.dumps(results,indent=2))


