"""Run after detection_test.py. Uses only disposable invoiceflow_detection_test."""
import os,sys,json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
from datetime import date,timedelta
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
os.environ['DATABASE_URL']=os.environ.get('QA_DATABASE_URL', 'mysql+pymysql://invoiceflow:preview-only-password@127.0.0.1/invoiceflow_detection_test')
from config import Config
class C(Config):
 TESTING=True;WTF_CSRF_ENABLED=False;SCHEDULER_ENABLED=False
from app import create_app
from app.extensions import db
from app.models import Invoice
from app.detection import DetectionPolicy,ReviewCase
from app.services.invoice_service import create_invoice
app=create_app(C, upgrade_schema=True)
day=date.today()+timedelta(days=5)
with app.app_context():
 p=db.session.get(DetectionPolicy,1);p.automatic_enabled=False;p.manual_enabled=True;p.invoice_limit=500;p.user_daily_limit=400;p.batch_daily_limit=400;db.session.flush();db.session.info['detect_all']=True;db.session.commit()
barrier=Barrier(2)
def write(serial):
 with app.app_context():
  barrier.wait()
  inv,error=create_invoice({'batch_id':1,'serial_number':serial,'date':day,'amounts':[250]},2)
  return bool(inv),error
with ThreadPoolExecutor(max_workers=2) as e:results=list(e.map(write,['0200','0201']))
assert all(r[0] for r in results),results
with app.app_context():
 daily=ReviewCase.query.filter_by(kind='user_day',batch_id=1,invoice_date=day,status='open').all()
 assert len(daily)==1 and daily[0].snapshot['amount']=='500.000'
 combined=ReviewCase.query.filter_by(kind='batch_day',batch_id=1,invoice_date=day,status='open').all();assert len(combined)==1
print('PASS concurrent service saves produce one final per-user daily flag and correct combined total')
barrier=Barrier(2)
with ThreadPoolExecutor(max_workers=2) as e:results=list(e.map(write,['0202','0202']))
assert sum(r[0] for r in results)==1,results
with app.app_context():assert Invoice.query.filter_by(batch_id=1,serial_number='0202').count()==1
print('PASS concurrent duplicate serial writers save only one invoice without partial duplicate cases')
Path('/home/user/qa-work/detection-concurrency-results.json').write_text(json.dumps([{'test':'Concurrent invoice saves compute correct final user/batch daily totals with no duplicate cases','passed':True},{'test':'Concurrent repeated serial writers accept exactly one invoice','passed':True}],indent=2))


