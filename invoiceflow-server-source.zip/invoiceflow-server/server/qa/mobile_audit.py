from playwright.sync_api import sync_playwright
from pathlib import Path
import json
BASE='http://127.0.0.1:5000';out=[]
# reuse route definitions without running desktop suite
s=Path(__file__).with_name('audit_screens.py').read_text();ns={};exec(s[s.index('routes='):s.index('\nwith sync_playwright')],ns)
with sync_playwright() as p:
 b=p.chromium.launch();ctx=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,reduced_motion='reduce');page=ctx.new_page()
 page.goto(BASE+'/auth/login');page.screenshot(path='/home/user/qa-work/screenshots/mobile-01-login.png',full_page=True);page.fill('#username','admin');page.fill('#password','Preview@2026');page.click('[type=submit]');page.wait_for_url('**/dashboard*')
 for i,(name,path) in enumerate(ns['routes'],2):
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)));r=page.goto(BASE+path);page.wait_for_timeout(300)
  overflow=page.evaluate('document.documentElement.scrollWidth > innerWidth');page.screenshot(path=f'/home/user/qa-work/screenshots/mobile-{i:02d}-{name}.png',full_page=True)
  out.append({'screen':name,'status':r.status,'overflow':overflow,'js_errors':list(errors)});print(name,r.status,'OVERFLOW' if overflow else 'OK')
 page.goto(BASE+'/dashboard');page.click('#sidebarToggle');assert page.locator('#appSidebar').evaluate("e=>e.classList.contains('show')");page.screenshot(path='/home/user/qa-work/screenshots/mobile-28-navigation.png');page.keyboard.press('Escape');assert not page.locator('#appSidebar').evaluate("e=>e.classList.contains('show')")
 page.goto(BASE+'/invoices/start-session?book=3');page.locator('#start-session-form [type=submit]').click();page.wait_for_url('**/invoices/create*');page.screenshot(path='/home/user/qa-work/screenshots/mobile-29-invoice-create.png',full_page=True)
 # browser snapshots of otherwise state-dependent screens via route interception
 for i,(name,file) in enumerate([('restore-confirm','restore-fixture.html'),('maintenance','maintenance-fixture.html'),('import-preview','import-preview-fixture.html')],31):
  url=BASE+'/__qa-'+name;page.route(url+'*',lambda route,request,f=file:route.fulfill(status=200,content_type='text/html',body=(Path(__file__).parent/'fixtures'/f).read_text()));page.goto(url);page.wait_for_timeout(300);page.screenshot(path=f'/home/user/qa-work/screenshots/mobile-{i}-{name}.png',full_page=True)
  page.set_viewport_size({'width':1440,'height':1000});page.reload();page.wait_for_timeout(300);page.screenshot(path=f'/home/user/qa-work/screenshots/{i}-{name}.png',full_page=True);page.set_viewport_size({'width':390,'height':844})
 b.close()
Path('mobile-audit.json').write_text(json.dumps(out,indent=2))


