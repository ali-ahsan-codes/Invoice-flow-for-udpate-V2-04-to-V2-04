"""Destructive regression on invoiceflow_batch_test ONLY; never production."""
import os,sys,json,io
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
os.environ['DATABASE_URL']=os.environ.get('QA_DATABASE_URL', 'mysql+pymysql://invoiceflow:preview-only-password@127.0.0.1/invoiceflow_batch_test')
from config import Config
class TestConfig(Config):
    SCHEDULER_ENABLED=False
    WTF_CSRF_ENABLED=False
    TESTING=True
    SECRET_KEY='disposable-batch-test'
from sqlalchemy import create_engine,text
engine=create_engine(os.environ['DATABASE_URL'])
# Start with real legacy schema: create model tables then remove batch columns/FKs/indexes.
with engine.begin() as con:
    con.execute(text('SET FOREIGN_KEY_CHECKS=0'))
    con.execute(text('DROP PROCEDURE IF EXISTS invoiceflow_verify_identity_guards'))
    for (name,) in con.execute(text('SHOW TABLES')).all():con.execute(text(f'DROP TABLE `{name}`'))
    con.execute(text('SET FOREIGN_KEY_CHECKS=1'))
from app import create_app
from app.extensions import db
from app.models import Batch,Book,Invoice,User,InvoiceMedia,AuditLog
from app.services.invoice_service import create_invoice,get_book_serial_range,get_book_usage
from app.utils.db_utils import migrate_batches
from datetime import date
app=create_app(TestConfig, upgrade_schema=True);results=[]
def check(name,ok):
    results.append({'test':name,'passed':bool(ok)});print('PASS' if ok else 'FAIL',name,flush=True);assert ok,name
with app.app_context():
    a=User(username='admin',email='admin@example.com',role='admin');a.set_password('Testing123');u=User(username='clerk',email='clerk@example.com',role='data_entry');u.set_password('Testing123');db.session.add_all([a,u]);db.session.flush()
    for n in range(1,101):db.session.add(Book(book_number=n,capacity=50,batch_id=1))
    db.session.flush();book=Book.query.filter_by(book_number=1).first()
    old=Invoice(batch_id=1,date=date(2025,1,2),serial_number='0001',total_amount=5,created_by=u.id,updated_by=u.id,book_id=book.id,book_page=1);old.set_amounts([5]);db.session.add(old);db.session.flush()
    m=InvoiceMedia(invoice_id=old.id,file_name='original.png',file_path='invoice_1/original.png',file_size=12,mime_type='image/png',uploaded_by=u.id);db.session.add(m);db.session.add(AuditLog(user_id=u.id,action='original_history',details={'invoice_id':old.id}));db.session.commit()
    oid=old.id;mid=m.id;timestamp=old.updated_at; aid=a.id;uid=u.id; db.session.remove()
    # Recreate old single-batch indexes with columns absent and existing data intact.
    with engine.begin() as con:
        con.execute(text('ALTER TABLE invoices DROP FOREIGN KEY fk_invoice_batch_book, DROP INDEX fk_invoice_batch_book'))
        con.execute(text('ALTER TABLE books DROP INDEX uq_batch_book_id'))
        for table,col,index in [('books','book_number','uq_batch_book'),('invoices','serial_number','uq_batch_serial')]:
            from sqlalchemy import inspect
            for fk in inspect(engine).get_foreign_keys(table):
                if fk['constrained_columns']==['batch_id']:con.execute(text(f"ALTER TABLE {table} DROP FOREIGN KEY `{fk['name']}`"))
            con.execute(text(f'ALTER TABLE {table} DROP INDEX {index}, DROP COLUMN batch_id, ADD UNIQUE INDEX {col} ({col})'))
    migrate_batches();migrate_batches();db.session.expire_all()
    old=db.session.get(Invoice,oid)
    check('Legacy migration is idempotent and preserves IDs/date/users/timestamp/media/history',old.batch_id==1 and old.date==date(2025,1,2) and old.updated_at==timestamp and old.created_by==uid and db.session.get(InvoiceMedia,mid).invoice_id==oid and AuditLog.query.filter_by(action='original_history').count()==1)
    check('All 100 legacy books belong to Batch 1',Book.query.filter_by(batch_id=1).count()==100)
    admin=app.test_client();admin.post('/auth/login',data={'username':'admin','password':'Testing123'})
    res=admin.post('/batches/',data={'mode':'repeat','count':'100','capacity':'50','name':'Batch 2'})
    check('Repeat lifecycle creates distinct 100-book Batch 2',res.status_code==302 and Book.query.filter_by(batch_id=2).count()==100)
    b2=Book.query.filter_by(batch_id=2,book_number=1).first();check('Repeat serial range resets to 0001',get_book_serial_range(b2)==(1,50))
    with app.test_request_context('/?batch_id=2'):
        from flask import g
        g.batch_id=2;g.current_batch=db.session.get(Batch,2)
        inv,error=create_invoice({'date':date.today(),'serial_number':'0001','amounts':[7]},uid);iid=inv.id
        check('Same serial allowed in another batch',inv is not None and not error and inv.book_id==b2.id and inv.book_page==1)
        _,error=create_invoice({'date':date.today(),'serial_number':'0001','amounts':[7]},uid);check('Duplicate serial blocked within batch',bool(error))
        _,error=create_invoice({'date':date.today(),'serial_number':'1','amounts':[7]},uid);check('Alternate padding cannot bypass same-batch duplicate validation',bool(error))
        _,error=create_invoice({'date':date.today(),'serial_number':'5001','amounts':[7]},uid);check('Out-of-print range cannot auto-create overflow books',bool(error) and Book.query.count()==100)
        check('Book usage/next serial ignores same printed serial in Batch 1',get_book_usage(b2)['next_serial']=='0002' and get_book_usage(b2)['used']==1)
    db.session.expire_all();a=db.session.get(User,aid);a.regenerate_api_key();db.session.commit();headers={'X-API-Key':a.api_key}
    # Flask login cache belongs to the app context in this isolated harness.
    check('Serial-only API returns 409 when ambiguous',admin.get('/api/v1/invoices/0001',headers=headers).status_code==409)
    res=admin.get('/api/v1/invoices/0001?batch_id=2',headers=headers);check('Explicit API batch returns correct invoice and identity',res.status_code==200 and res.json['id']==iid and res.json['batch_id']==2)
    check('Serial-only API upload cannot attach to arbitrary duplicate',admin.post('/api/v1/invoices/0001/media',headers=headers,data={'file':(io.BytesIO(b'bad'),'bad.png')}).status_code==409)
    check('API rejects invalid batch selector',admin.get('/api/v1/invoices?batch_id=bad',headers=headers).status_code==400)
    check('API list scopes batch',all(i['batch_id']==2 for i in admin.get('/api/v1/invoices?batch_id=2',headers=headers).json['invoices']))
    check('Legacy serial-only web QR refuses ambiguity',admin.get('/media/qr/0001.svg').status_code==409 and admin.get('/media/m/0001').status_code==409)
    check('Explicit batch QR succeeds',admin.get('/media/qr/0001.svg?batch_id=2').status_code==200)
    with app.test_request_context('/?batch_id=2'):
        from app.routes.media import _build_invoice_qr_payload
        payload=json.loads(_build_invoice_qr_payload(db.session.get(Invoice,iid),'app',scan='focus'))
        check('Focus QR v2 contains invoice, batch, base URL and focus hint',payload['batch_id']==2 and payload['invoice_id']==iid and payload['version']==2 and payload['scan']=='focus' and payload['base_url']=='http://localhost')
    check('ID-based view resolves historical Batch 1 even with selected Batch 2',b'Batch ID 1' in admin.get(f'/invoices/{oid}').data)
    check('Explicit conflicting batch on ID link is rejected',admin.get(f'/invoices/{oid}?batch_id=2').status_code==409)
    csv=admin.get('/invoices/export?batch_id=2').data.decode();check('CSV export carries selected batch identity','Batch ID' in csv and f'{iid},2,' in csv and ('\n'+f'{oid},1,') not in csv)
    # Import must be validated before create commits.
    from app.services.import_service import import_invoices_from_csv
    cmap={'date':'Date','serial_number':'Serial Number','amounts':'Amounts'}
    with app.test_request_context('/?batch_id=2'):
        from flask import g
        g.batch_id=2;g.current_batch=db.session.get(Batch,2)
        header=['Batch ID','Date','Serial Number','Amounts','Book','Page']
        result=import_invoices_from_csv([['1','2026-10-08','0002','3','1','2']],header,cmap,user_id=a.id,col_book='Book',col_page='Page')
        check('Import refuses mixed/wrong batch row',result['errors']==1 and Invoice.query.filter_by(serial_number='0002').first() is None)
        result=import_invoices_from_csv([['2','2026-10-08','0002','3','1','3']],header,cmap,user_id=a.id,col_book='Book',col_page='Page')
        check('Bad imported page rejected before invoice commit',result['errors']==1 and Invoice.query.filter_by(serial_number='0002').first() is None)
        result=import_invoices_from_csv([['2','2026-10-08','0002','3','1','2']],header,cmap,user_id=a.id,col_book='Book',col_page='Page')
        check('Valid CSV import scopes batch/book/page',result['imported']==1 and Invoice.query.filter_by(serial_number='0002').first().batch_id==2)
        result=import_invoices_from_csv([['2','2026-10-08','0002','nan','1','2']],header,cmap,user_id=a.id,duplicate_handling='overwrite',col_book='Book',col_page='Page')
        check('Import overwrite rejects nonfinite amount',result['errors']==1)
    check('API next stays inside originating batch',admin.get('/api/v1/invoices/0001/next?batch_id=2',headers=headers).json['batch_id']==2)
    res=admin.post('/batches/',data={'mode':'continue','count':'2','capacity':'50','name':'Batch 3'})
    b3=Book.query.filter_by(batch_id=3).order_by(Book.book_number).first()
    check('Continue starts after configured book 100 and serial 5000, not entered max',res.status_code==302 and b3.book_number==101 and get_book_serial_range(b3)==(5001,5050))
    check('Archive requires administrator verification',admin.post('/batches/1/archive').status_code==400)
    check('Verified Batch 1 archive works',admin.post('/batches/1/archive',data={'verified':'yes'}).status_code==302 and db.session.get(Batch,1).archived)
    check('Admin may enter/correct archived batch',admin.post('/invoices/start-session?batch_id=1',data={'book_number':1}).status_code in (200,302))
    clerk=app.test_client();clerk.post('/auth/login',data={'username':'clerk','password':'Testing123'})
    check('Clerk cannot edit own archived invoice',clerk.post(f'/invoices/{oid}/edit?batch_id=1',data={}).status_code==403)
    from flask import g
    g.pop('_login_user',None)
    res=admin.post(f'/invoices/{oid}/edit?batch_id=1',data={'date':'2025-01-02','serial_number':'0001','amounts-0':'9','invoice_id':oid},headers={'X-Requested-With':'XMLHttpRequest'})
    check('Admin can correct archived invoice without moving identity',res.status_code==200 and res.json['success'] and db.session.get(Invoice,oid).batch_id==1)
    check('Attachment and original history retained after archive/correction',db.session.get(InvoiceMedia,mid).invoice_id==oid and AuditLog.query.filter_by(action='original_history').count()==1)
    check('Work sessions retain batch identity',admin.post('/invoices/start-session?batch_id=2',data={'book':'1','serial':'0003','date':'2026-10-08'}).status_code in (200,302))
    check('Untagged writes cannot be silently assigned to another batch',admin.post('/media/upload/'+str(iid)).status_code==400)
    check('Settings do not rewrite historical book capacities',admin.post('/admin/settings',json={'pages_per_book':75,'number_of_books':20}).status_code==200 and db.session.get(Book,b2.id).capacity==50)
    # Database constraint prevents wrong-book assignment even outside request guards.
    from sqlalchemy.exc import IntegrityError
    try:
        db.session.execute(text('UPDATE invoices SET book_id=:book WHERE id=:id'),{'book':b2.id,'id':oid});db.session.commit();blocked=False
    except IntegrityError:
        db.session.rollback();blocked=True
    check('Database rejects cross-batch book assignments',blocked)
    admin.post('/batches/',data={'mode':'continue','count':'1','capacity':'50','name':'Boundary','start_serial':'9999','start_book':'103'})
    boundary=Batch.query.filter_by(name='Boundary').first()
    with app.test_request_context('/?batch_id='+str(boundary.id)):
        g.batch_id=boundary.id;g.current_batch=boundary
        for serial in ['9999','10000']:create_invoice({'date':date.today(),'serial_number':serial,'amounts':[1]},aid)
    res=admin.get('/api/v1/invoices/9999/next?batch_id='+str(boundary.id),headers=headers)
    check('Continued numbering navigates numerically from 9999 to 10000',res.json['serial_number']=='10000')
    res=admin.get('/import-export/export?type=daily&from_date=2026-01-01&to_date=2026-12-31&batch_id=2')
    check('Administrator daily report covers every batch and is named as such',res.status_code==200 and 'all_batches_' in res.headers.get('Content-Disposition',''))
    res=admin.post('/admin/users/'+str(uid)+'/delete?batch_id=2',headers={'X-Requested-With':'XMLHttpRequest'})
    check('Deleting a user safely handles references in every batch',res.status_code==200 and res.json['success'] and db.session.get(Invoice,oid).created_by==aid and db.session.get(Invoice,iid).created_by==aid)
    check('Destructive web restore is disabled by default',admin.post('/backup/restore',data={'filename':'example.sql','confirm':'yes'}).status_code==403 and admin.post('/backup/upload-restore').status_code==403)
    # Maintenance gate must precede any request DB work.
    from sqlalchemy import event
    queries=[]
    def counted(*args):queries.append(1)
    event.listen(db.engine,'before_cursor_execute',counted)
    app.config['MAINTENANCE_MODE']=True
    res=admin.get('/invoices/?batch_id=2')
    app.config['MAINTENANCE_MODE']=False
    event.remove(db.engine,'before_cursor_execute',counted)
    check('Maintenance request returns 503 without any database query',res.status_code==503 and not queries)
Path('/home/user/qa-work/batch-results.json').write_text(json.dumps(results,indent=2))


