"""Disposable startup regression: no production configuration/data touched."""
import os,sys,json,subprocess,tempfile,socket
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
ROOT=Path(__file__).resolve().parents[1];OUT=Path('/home/user/qa-work');out=[]
URL='mysql+pymysql://invoiceflow:preview-only-password@127.0.0.1/invoiceflow_preview'
def check(name,ok):out.append({'test':name,'passed':bool(ok)});print('PASS' if ok else 'FAIL',name,flush=True);assert ok,name
clean={k:v for k,v in os.environ.items() if k not in ['DATABASE_URL','DEV_DATABASE_URL','FLASK_CONFIG','SECRET_KEY','AUTO_SCHEMA_UPGRADE']}
clean['SCHEDULER_ENABLED']='False'
def run(args,overrides=None,cwd=ROOT):
 return subprocess.run([sys.executable,*args],cwd=cwd,env={**clean,**(overrides or {})},capture_output=True,text=True,timeout=30)
r=run(['launch.py','--check']);check('Missing configuration produces visible instruction, not guessed root login',r.returncode==1 and 'No database configured' in r.stderr and 'root' not in r.stderr)
r=run(['launch.py','--check'],{'DATABASE_URL':URL});check('DATABASE_URL alone starts the shipped configured app',r.returncode==0 and 'PASS' in r.stdout)
r=run(['launch.py','--check'],{'DEV_DATABASE_URL':URL});check('Legacy development-only DEV_DATABASE_URL still works',r.returncode==0)
r=run(['launch.py','--check'],{'DATABASE_URL':URL,'DEV_DATABASE_URL':URL.replace('preview-only-password','WRONG_PASSWORD')});check('Explicit DEV_DATABASE_URL remains the documented dev override',r.returncode==1 and 'login rejected' in r.stderr)
r=run(['launch.py','--check'],{'DATABASE_URL':URL,'FLASK_CONFIG':'nonsense'});check('Invalid FLASK_CONFIG yields readable error',r.returncode==1 and 'Unknown FLASK_CONFIG' in r.stderr)
r=run(['launch.py','--check'],{'DATABASE_URL':URL.replace('preview-only-password','DO_NOT_LOG_MY_PASSWORD')});check('Wrong password report does not expose credentials or traceback',r.returncode==1 and 'DO_NOT_LOG_MY_PASSWORD' not in r.stderr and 'Traceback' not in r.stderr)
r=run(['launch.py','--check'],{'DATABASE_URL':URL.replace('@127.0.0.1/','@127.0.0.1:39999/')});check('Stopped/unreachable database yields actionable service/port error',r.returncode==1 and 'Cannot connect' in r.stderr)
r=run(['launch.py','--check'],{'DATABASE_URL':'sqlite:///test.sqlite'});check('Unsupported SQLite fails before schema changes',r.returncode==1 and 'SQLite' in r.stderr)
r=run(['launch.py','--check'],{'DATABASE_URL':URL,'SECRET_KEY':'CHANGE_ME'});check('Placeholder secret rejected',r.returncode==1 and 'SECRET_KEY' in r.stderr)
r=run(['launch.py','--check'],{'DATABASE_URL':URL,'FLASK_CONFIG':'production'});check('Production rejects development fallback secret',r.returncode==1 and 'Production requires' in r.stderr)
from configure import initialize_secret
with tempfile.TemporaryDirectory() as t:
 p=Path(t)/'.env';p.write_text('DATABASE_URL=do-not-alter\nSECRET_KEY=CHANGE_ME\n')
 initialize_secret(p);a=p.read_text();initialize_secret(p);check('Setup initializes random secret once and preserves configured database',p.read_text()==a and 'do-not-alter' in a and 'CHANGE_ME' not in a)
 # app paths anchored and dotenv loading independent of launch cwd; also UTF-8 BOM supported
 r=run([str(ROOT/'launch.py'),'--check'],{'DATABASE_URL':URL},cwd=t);check('Launcher starts from unrelated shortcut/service directory',r.returncode==0)
# temporary root .env for exact dotenv preference and BOM test; none exists in QA source
assert not (ROOT/'.env').exists()
try:
 (ROOT/'.env').write_text('FLASK_CONFIG=development\nDATABASE_URL='+URL+'\nSECRET_KEY=test-unique-secret-for-bom\nSCHEDULER_ENABLED=False\n',encoding='utf-8-sig')
 r=run(['launch.py','--check']);check('BOM-prefixed Windows .env loads before config selection',r.returncode==0)
finally:(ROOT/'.env').unlink(missing_ok=True)
# port collision must not open an unrelated app, do not spawn second server
with socket.socket() as occupied:
 occupied.bind(('0.0.0.0',0));occupied.listen()
 r=run(['launch.py','--no-browser'],{'DATABASE_URL':URL,'FLASK_PORT':str(occupied.getsockname()[1])});check('Occupied port gives visible failure rather than opening unrelated app',r.returncode==1 and 'Port is already in use' in r.stderr)
from sqlalchemy import create_engine,text
engine=create_engine(URL)
with engine.connect() as c:
 before=[tuple(x) for x in c.execute(text('SELECT id,date,serial_number,created_at,updated_at,total_amount FROM invoices ORDER BY id'))]
 guards=[tuple(x) for x in c.execute(text("SELECT TRIGGER_NAME,ACTION_STATEMENT FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE()"))]
for _ in range(3):assert run(['launch.py','--check'],{'DATABASE_URL':URL}).returncode==0
with engine.connect() as c:
 after=[tuple(x) for x in c.execute(text('SELECT id,date,serial_number,created_at,updated_at,total_amount FROM invoices ORDER BY id'))]
 after_guards=[tuple(x) for x in c.execute(text("SELECT TRIGGER_NAME,ACTION_STATEMENT FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE()"))]
check('Repeated ordinary startup preserves every invoice timestamp/identity/amount and trigger',before==after and guards==after_guards)
# tamper/missing guard prevents opening entry, never silently heals online
with engine.begin() as c:c.execute(text('DROP TRIGGER invoices_reserve_au'))
r=run(['launch.py','--check'],{'DATABASE_URL':URL});check('Missing identity trigger refuses startup without auto-upgrading',r.returncode==1 and 'trigger' in r.stderr.lower())
r=run(['upgrade_database.py'],{'DATABASE_URL':URL});assert r.returncode==0,r.stderr
r=run(['diagnose.py'],{'DATABASE_URL':URL});check('Diagnosis verifies schema/login and writes credential-safe HTML report',r.returncode==0 and (ROOT/'logs/diagnostic-report.html').exists())
OUT.joinpath('startup-results.json').write_text(json.dumps(out,indent=2))
# Failed logs must also be credential-safe.
check('Launcher error logs contain no supplied bad passwords','DO_NOT_LOG_MY_PASSWORD' not in (ROOT/'logs/startup.log').read_text())
OUT.joinpath('startup-results.json').write_text(json.dumps(out,indent=2))


