"""Real browser rejection of a corrected historical identity; synthetic cleanup."""
import sys,os,json
from pathlib import Path
from datetime import date
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
os.environ.update(DATABASE_URL='mysql+pymysql://invoiceflow:preview-only-password@127.0.0.1/invoiceflow_preview',SCHEDULER_ENABLED='False')
from app import create_app
from app.extensions import db
from app.models import Batch,Book,Invoice,User,InvoiceIdentityReservation
from app.services.invoice_service import create_invoice, delete_invoice
from playwright.sync_api import sync_playwright
app=create_app();out=[];BASE='http://127.0.0.1:5000';root=Path('/home/user/qa-work/screenshots')
def check(n,ok):out.append({'test':n,'passed':bool(ok)});print('PASS' if ok else 'FAIL',n,flush=True);assert ok,n
with app.app_context():
 uid=User.query.filter_by(username='admin').first().id
 source=Batch(name='History QA original',start_book=1,start_serial=1);target=Batch(name='History QA new',start_book=1,start_serial=1)
 db.session.add_all([source,target]);db.session.flush();sid=source.id;tid=target.id
 db.session.add_all([Book(batch_id=sid,book_number=1,capacity=50),Book(batch_id=tid,book_number=1,capacity=50)]);db.session.commit()
 inv,err=create_invoice({'batch_id':sid,'date':date(2026,7,1),'serial_number':'1','amounts':[9]},uid);assert not err;original=inv.id
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch();ctx=browser.new_context(viewport={'width':1440,'height':1000});p=ctx.new_page();errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
  p.goto(BASE+'/auth/login');p.fill('#username','admin');p.fill('#password','Preview@2026');p.click('[type=submit]');p.wait_for_url('**/dashboard*')
  p.goto(BASE+f'/invoices/{original}/edit?batch_id={sid}');p.fill('[name=date]','2026-07-02');p.fill('[name=serial_number]','0002')
  with p.expect_response(lambda r:r.request.method=='POST' and '/edit' in r.url) as res:p.locator('#invoice-form [type=submit]').click()
  check('Admin corrects date and serial through real edit form',res.value.status==200)
  p.wait_for_url(f'**/invoices/{original}*');p.screenshot(path=str(root/'history-01-corrected-invoice.png'),full_page=True)
  with app.app_context():check('UI correction retained old key owner',InvoiceIdentityReservation.query.filter_by(invoice_id=original).count()==2)
  p.goto(BASE+f'/invoices/start-session?batch_id={tid}&book=1');p.locator('#start-session-form [type=submit]').click();p.wait_for_url('**/invoices/create*');p.fill('[name=date]','2026-07-01');p.fill('.amount-field-input','21.250')
  p.evaluate('window.amountRef=document.querySelector(".amount-field-input")')
  with p.expect_response(lambda r:r.request.method=='POST' and '/invoices/create' in r.url) as res:p.locator('#invoice-form [type=submit]').click()
  data=res.value.json();check('Browser rejects corrected historical identity in another batch',not data.get('success') and 'reserved' in str(data).lower())
  check('Historical duplicate preserves date serial and amount DOM',p.locator('[name=date]').input_value()=='2026-07-01' and p.locator('[name=serial_number]').input_value()=='0001' and p.locator('.amount-field-input').input_value()=='21.250' and p.evaluate('amountRef===document.querySelector(".amount-field-input")'))
  p.screenshot(path=str(root/'history-02-reserved-error-desktop.png'),full_page=True);p.set_viewport_size({'width':390,'height':844});p.wait_for_timeout(400);p.screenshot(path=str(root/'history-03-reserved-error-mobile.png'),full_page=True)
  check('Historical duplicate mobile screen has no overflow',not p.evaluate('document.documentElement.scrollWidth>innerWidth'))
  with app.app_context():delete_invoice(original,uid)
  with p.expect_response(lambda r:r.request.method=='POST' and '/invoices/create' in r.url) as res:p.locator('#invoice-form [type=submit]').click()
  check('Deleting original permits same historical key in browser',res.value.json().get('success'))
  p.wait_for_timeout(450);p.screenshot(path=str(root/'history-04-reused-after-deletion.png'),full_page=True);check('No JS exceptions in historical correction/reuse flow',not errors);browser.close()
finally:
 with app.app_context():
  for bid in [sid,tid]:
   for inv in Invoice.query.filter_by(batch_id=bid):delete_invoice(inv.id,uid)
   for book in Book.query.filter_by(batch_id=bid):db.session.delete(book)
   db.session.flush();db.session.delete(db.session.get(Batch,bid));db.session.commit()
Path('/home/user/qa-work/history-browser-results.json').write_text(json.dumps(out,indent=2))


