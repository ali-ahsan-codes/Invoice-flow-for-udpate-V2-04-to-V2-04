"""Actual browser lifecycle, readonly, duplicate drafts and live controls."""
import sys,json
from pathlib import Path
from datetime import date
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from support.demo_app import app
from app.extensions import db
from app.models import Batch,Book,Invoice
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:5000';ROOT=Path('/home/user/qa-work/screenshots');out=[]
def check(n,ok):out.append({'test':n,'passed':bool(ok)});print('PASS' if ok else 'FAIL',n,flush=True);assert ok,n
def login(ctx,user):
 p=ctx.new_page();p.goto(BASE+'/auth/login');p.fill('#username',user);p.fill('#password','Preview@2026');p.click('[type=submit]');p.wait_for_url('**/dashboard*' if user=='admin' else '**/invoices/start-session*');return p
with app.app_context():
 b=Batch(name='Controls QA',start_book=1,start_serial=1,numbering_mode='repeat');db.session.add(b);db.session.flush();bid=b.id;db.session.add(Book(batch_id=bid,book_number=1,capacity=50));db.session.commit()
 original_date=db.session.get(Invoice,1).date.isoformat()
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch();ac=browser.new_context(viewport={'width':1440,'height':1000});uc=browser.new_context(viewport={'width':1440,'height':1000});a=login(ac,'admin');u=login(uc,'sarah');errors=[]
  for p in (a,u):p.on('pageerror',lambda e:errors.append(str(e)))
  a.goto(BASE+f'/batches/?batch_id={bid}');observer=ac.new_page();observer.goto(BASE+f'/batches/?batch_id={bid}');observer.fill('[name=name]','keep this draft');observer.evaluate('window.formRef=document.querySelector("[name=name]")')
  u.goto(BASE+f'/invoices/start-session?batch_id={bid}&book=1');u.locator('#start-session-form [type=submit]').click();u.wait_for_url('**/invoices/create*');u.fill('[name=date]',original_date);u.fill('.amount-field-input','33.125');u.evaluate('window.inputRef=document.querySelector(".amount-field-input");window.boot=performance.timeOrigin')
  check('Batch label next to serial and book','Batch #' in u.locator('label[for=serial_number]').inner_text() and str(bid) in u.locator('label[for=serial_number]').inner_text())
  with u.expect_response(lambda r:'/invoices/create' in r.url and r.request.method=='POST') as response:u.locator('#invoice-form [type=submit]').click()
  check('Cross-batch duplicate blocked in actual browser',not response.value.json()['success'])
  check('Failed duplicate retains exact date serial amount controls',u.locator('.amount-field-input').input_value()=='33.125' and u.evaluate('window.inputRef===document.querySelector(".amount-field-input")') and u.locator('[name=serial_number]').input_value()=='0001')
  u.screenshot(path=str(ROOT/'controls-01-global-duplicate-draft.png'),full_page=True)
  a.locator(f'form[action$="/{bid}/lock"] button').click();observer.wait_for_selector(f'form[action$="/{bid}/unlock"]');u.wait_for_function('document.querySelector("#invoice-form [type=submit]").disabled')
  check('Remote lock disables normal entry while keeping draft',u.locator('.amount-field-input').input_value()=='33.125' and u.evaluate('window.inputRef===document.querySelector(".amount-field-input")&&window.boot===performance.timeOrigin'))
  check('Remote lifecycle button updates without resetting admin draft',observer.locator('[name=name]').input_value()=='keep this draft' and observer.evaluate('window.formRef===document.querySelector("[name=name]")'))
  u.screenshot(path=str(ROOT/'controls-02-locked-user.png'),full_page=True)
  a.locator(f'form[action$="/{bid}/hide"] button').click();u.wait_for_selector('#live-removed',timeout=15000)
  check('Hide stops snapshots and retains unsaved inputs with notice',u.locator('.amount-field-input').input_value()=='33.125' and 'no longer accessible' in u.locator('#live-removed').inner_text())
  check('Hidden batch direct URL blocked',uc.request.get(BASE+f'/invoices/?batch_id={bid}').status==404)
  a.screenshot(path=str(ROOT/'controls-03-hidden-locked-admin.png'),full_page=True)
  a.locator(f'a[href*="/{bid}/view"]').click();a.wait_for_url('**/invoices/*');check('Admin View opens hidden locked batch',f'Batch ID {bid}' in a.locator('main').inner_text())
  a.goto(BASE+f'/batches/?batch_id={bid}');a.locator(f'form[action$="/{bid}/unhide"] button').click();a.locator(f'form[action$="/{bid}/unlock"] button').click()
  form=a.locator(f'form[action$="/{bid}/archive"]');form.locator('[name=verified]').check();form.locator('button').click();observer.wait_for_selector(f'form[action$="/{bid}/unarchive"]')
  check('Archive state live updates reversible button',observer.locator('[name=name]').input_value()=='keep this draft')
  a.screenshot(path=str(ROOT/'controls-04-archived-admin.png'),full_page=True)
  a.locator(f'form[action$="/{bid}/unarchive"] button').click();observer.wait_for_selector(f'form[action$="/{bid}/archive"] [name=verified]')
  check('Unarchive restores confirmation and entry availability',observer.locator(f'form[action$="/{bid}/archive"] [name=verified]').is_visible())
  u.goto(BASE+f'/invoices/start-session?batch_id={bid}&book=1');check('Unhidden unlocked batch selectable again',u.locator(f'#batch-selector option[value="{bid}"]').count()==1)
  a.set_viewport_size({'width':390,'height':844});a.wait_for_timeout(600);a.screenshot(path=str(ROOT/'controls-05-mobile-management.png'),full_page=True);check('Mobile lifecycle buttons no horizontal overflow',not a.evaluate('document.documentElement.scrollWidth>innerWidth'))
  check('Purple scrollbar theme applied',a.evaluate('getComputedStyle(document.documentElement).scrollbarColor').startswith('rgb(153, 115, 220)'))
  check('No JS exceptions in batch controls',not errors);browser.close()
finally:
 with app.app_context():
  for inv in Invoice.query.filter_by(batch_id=bid):db.session.delete(inv)
  db.session.flush()
  for book in Book.query.filter_by(batch_id=bid):db.session.delete(book)
  db.session.flush();db.session.delete(db.session.get(Batch,bid));db.session.commit()
Path('/home/user/qa-work/batch-controls-browser-results.json').write_text(json.dumps(out,indent=2))


