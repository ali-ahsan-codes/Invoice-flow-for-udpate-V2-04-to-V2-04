"""Tests for (1) the optional 'exclude from totals' choice on merges, (2) the mobile API for
notes/links/history, and (3) the upload file-type rules.

Runs through the real Flask app on a temporary SQLite database (sqlite_harness.py).
Run: python qa/exclusion_and_mobile_api_test.py
"""
import io
import os
import sys
from datetime import date
from decimal import Decimal

sys.path.insert(0, os.path.dirname(__file__))
import sqlite_harness as h  # noqa: E402

app = h.make_app()
app.config['TESTING'] = True

from sqlalchemy import func  # noqa: E402
from app.extensions import db  # noqa: E402
from app.models import User, Invoice, Batch, InvoiceLink, InvoiceNote, InvoiceNoteMedia, totals_amount_expr  # noqa: E402
from app.services.invoice_service import get_work_days_summary

PASSED = []
TODAY = date(2026, 10, 15)
PERIOD = (date(2026, 10, 1), date(2026, 10, 31))


def check(label, cond, extra=''):
    if not cond:
        raise AssertionError(f'FAIL: {label} {extra}')
    PASSED.append(label)
    print('PASS', label)


def setup_data():
    with app.app_context():
        sarah = User(username='sarah', email='sarah@x.test', role='data_entry')
        sarah.set_password('Sarah@12345')
        sarah.api_key = 'sarah-key-123'
        omar = User(username='omar', email='omar@x.test', role='data_entry')
        omar.set_password('Omar@12345')
        omar.api_key = 'omar-key-456'
        admin = User(username='admin', email='admin@x.test', role='admin')
        admin.set_password('Admin@12345')
        admin.api_key = 'admin-key-789'
        db.session.add_all([sarah, omar, admin])
        db.session.flush()
        hidden = Batch(id=3, name='Hidden Batch', numbering_mode='repeat', start_book=1,
                       start_serial=201, archived=False, hidden=True)
        b2 = Batch(id=2, name='Batch 2', numbering_mode='repeat', start_book=1,
                   start_serial=101, archived=False)
        db.session.add_all([b2, hidden])
        db.session.flush()

        def mk(batch_id, serial, owner, amounts, day=15):
            i = Invoice(batch_id=batch_id, date=date(2026, 10, day), serial_number=serial,
                        total_amount=Decimal(str(round(sum(amounts), 3))),
                        created_by=owner.id, updated_by=owner.id)
            i.set_amounts(amounts)
            db.session.add(i)
            db.session.flush()
            return i.id

        ids = {
            'old': mk(1, '0001', sarah, [100.0]),          # past invoice being merged in
            'new': mk(1, '0002', sarah, [40.0]),           # current invoice receiving the merge
            'other': mk(1, '0003', sarah, [10.0]),         # unrelated invoice
            'omar': mk(1, '0004', omar, [5.0]),            # other clerk's invoice
            'b2': mk(2, '0001', sarah, [50.0], day=16),    # same serial in batch 2 (different date: unique per date)
            'hidden': mk(3, '0009', sarah, [7.0]),         # in the hidden batch
        }
        db.session.commit()
        return ids


def login(client, username, password):
    r = client.post('/auth/login', data={'username': username, 'password': password})
    assert r.status_code in (200, 302), r.status_code


def period_total():
    with app.app_context():
        db.session.expire_all()
        s = get_work_days_summary(*PERIOD, user_id=None)
        return round(float(s['total_amount']), 3), s['invoice_count']


def main():
    ids = setup_data()
    sarah_c = app.test_client()
    omar_c = app.test_client()
    admin_c = app.test_client()
    login(sarah_c, 'sarah', 'Sarah@12345')
    login(omar_c, 'omar', 'Omar@12345')
    login(admin_c, 'admin', 'Admin@12345')

    base_total = 100 + 40 + 10 + 5 + 50 + 7  # everything visible to admin, hidden batch included
    check('baseline: admin period total counts every invoice',
          period_total() == (round(base_total, 3), 6), str(period_total()))

    # ---------------- Exclude-from-totals choice ----------------
    r = sarah_c.post(f"/invoices/{ids['new']}/links?batch_id=1",
                     data={'linked_serial': '1', 'link_type': 'duplicate', 'amount_action': 'merge',
                           'exclude_from_totals': '1'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    check('merge with exclude chosen is accepted', r.status_code == 200 and r.get_json()['success'],
          r.get_data(as_text=True))
    with app.app_context():
        link = InvoiceLink.query.filter_by(invoice_id=ids['new'], linked_invoice_id=ids['old']).one()
        check('link stores exclude_from_totals=True', link.exclude_from_totals is True)
        link_id = link.id
    check('excluded merge: amount counted once in period totals (5 counted invoices)',
          period_total() == (round(base_total, 3), 5), str(period_total()))
    with app.app_context():
        db.session.expire_all()
        check('receiver now carries merged amount line',
              db.session.get(Invoice, ids['new']).get_amounts() == [40.0, 100.0])
        check('raw invoice rows untouched (source still exists with own total)',
              float(db.session.get(Invoice, ids['old']).total_amount) == 100.0)
    with app.app_context():
        db.session.expire_all()
        helper_sum = float(db.session.query(func.sum(totals_amount_expr())).scalar() or 0)
        # Receiver is now 40 + 100 = 140 and the excluded source (100) drops out: 140+10+5+50+7 = 212.
        check('excluded merge: totals_amount_expr SUM equals baseline (no double count)',
              abs(helper_sum - base_total) < 0.001, str(helper_sum))

    # Dashboard quick stats also respect the exclusion.
    r = admin_c.get('/quick-stats')
    check('dashboard quick-stats endpoint responds', r.status_code == 200)

    # Invoice view explains the choice
    r = sarah_c.get(f"/invoices/{ids['new']}")
    check('view shows "Excluded from totals" badge', b'Excluded from totals' in r.data)
    check('link form offers the include/exclude choice',
          b'name="exclude_from_totals"' in r.data and b'keep both invoices in totals' in r.data)

    # Unlink restores the source in totals and removes the merged line
    r = sarah_c.post(f"/invoices/{ids['new']}/links/{link_id}/delete?batch_id=1",
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    check('unlink works for excluded merge', r.status_code == 200 and r.get_json()['success'])
    check('after unlink: totals back to baseline', period_total() == (round(base_total, 3), 6))

    # Include choice: both invoices count, merged amount is counted twice by design
    r = sarah_c.post(f"/invoices/{ids['new']}/links?batch_id=1",
                     data={'linked_serial': '1', 'link_type': 'adjustment', 'amount_action': 'merge',
                           'exclude_from_totals': '0'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    check('merge with include chosen is accepted', r.status_code == 200 and r.get_json()['success'])
    with app.app_context():
        link2 = InvoiceLink.query.filter_by(invoice_id=ids['new'], linked_invoice_id=ids['old']).one()
        check('link stores exclude_from_totals=False', link2.exclude_from_totals is False)
        link2_id = link2.id
    check('include merge: both invoices counted (total +100)',
          period_total() == (round(base_total + 100, 3), 6), str(period_total()))
    r = sarah_c.get(f"/invoices/{ids['new']}")
    check('view shows "Counted in totals" for include choice', b'Counted in totals (both)' in r.data)

    # Relation-only link never changes totals
    sarah_c.post(f"/invoices/{ids['new']}/links/{link2_id}/delete?batch_id=1",
                 headers={'X-Requested-With': 'XMLHttpRequest'})
    r = sarah_c.post(f"/invoices/{ids['other']}/links?batch_id=1",
                     data={'linked_serial': '2', 'link_type': 'related', 'exclude_from_totals': '1'},
                     headers={'X-Requested-With': 'XMLHttpRequest'})
    check('relation-only link accepted', r.status_code == 200 and r.get_json()['success'])
    check('relation-only link leaves totals unchanged', period_total() == (round(base_total, 3), 6))
    with app.app_context():
        rel = InvoiceLink.query.filter_by(invoice_id=ids['other']).one()
        check('exclude flag ignored when there is no merge', rel.exclude_from_totals is False)

    # ---------------- Mobile API ----------------
    api = app.test_client()
    H = {'X-API-Key': 'sarah-key-123'}

    r = api.get('/api/v1/invoices/0002?batch_id=1')
    check('API: no key -> 401', api.get('/api/v1/invoices/0002?batch_id=1').status_code == 401)
    r = api.get('/api/v1/invoices/0002?batch_id=1', headers=H)
    check('API: invoice lookup with key', r.status_code == 200 and r.get_json()['serial_number'] == '0002')

    r = api.get('/api/v1/invoices/0002/history?batch_id=1', headers=H)
    check('API: history returns relations and notes', r.status_code == 200 and 'history' in r.get_json())

    r = api.post('/api/v1/invoices/0002/notes?batch_id=1', headers=H,
                 data={'body': 'Customer called about this bill',
                       'files': [(io.BytesIO(b'%PDF-1.4 scan'), 'scan.pdf', 'application/pdf'),
                                 (io.BytesIO(b'PK\x03\x04 xlsx'), 'ledger.xlsx',
                                  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')]},
                 content_type='multipart/form-data')
    check('API: note with two documents created (201)', r.status_code == 201, r.get_data(as_text=True))
    hist = r.get_json()['history']
    own_notes = [n for n in hist['notes'] if n['body'] == 'Customer called about this bill']
    check('API: returned history contains the new note', len(own_notes) == 1)
    atts = own_notes[0]['attachments']
    check('API: both attachments listed', len(atts) == 2)
    pdf_id = [a for a in atts if a['file_name'] == 'scan.pdf'][0]['id']
    note_id = own_notes[0]['id']

    r = api.get(f'/api/v1/invoices/0002/notes/attachments/{pdf_id}', headers=H)
    check('API: attachment download', r.status_code == 200 and r.data.startswith(b'%PDF'))
    r = api.get(f'/api/v1/invoices/0002/notes/attachments/{pdf_id}',
                headers={'X-API-Key': 'omar-key-456'})
    check('API: other clerk cannot download attachment', r.status_code == 404)

    r = api.post('/api/v1/invoices/0002/notes?batch_id=1', headers=H,
                 data={'body': '', 'files': [(io.BytesIO(b'MZ'), 'setup.exe', 'application/octet-stream')]},
                 content_type='multipart/form-data')
    check('API: executable rejected', r.status_code == 400, r.get_data(as_text=True))

    r = api.post('/api/v1/invoices/0002/notes?batch_id=1', headers={'X-API-Key': 'omar-key-456'},
                 json={'body': 'sneaky'})
    check('API: other clerk cannot note on invoice they do not own', r.status_code == 404)

    r = api.post('/api/v1/invoices/0002/notes?batch_id=1', headers=H, json={'body': 'Plain JSON note'})
    check('API: JSON body note accepted', r.status_code == 201)

    r = api.post('/api/v1/invoices/0002/notes?batch_id=1', headers=H, json={'body': '  '})
    check('API: empty note rejected', r.status_code == 400)

    r = api.delete(f'/api/v1/invoices/0002/notes/{note_id}?batch_id=1', headers=H)
    check('API: author deletes note', r.status_code == 200 and r.get_json()['success'])
    with app.app_context():
        check('API: note and attachment rows removed', db.session.get(InvoiceNote, note_id) is None
              and db.session.get(InvoiceNoteMedia, pdf_id) is None)

    # Links via API with the exclude choice
    r = api.post('/api/v1/invoices/0002/links?batch_id=1', headers=H,
                 json={'linked_serial': '0001', 'link_type': 'duplicate', 'amount_action': 'merge',
                       'exclude_from_totals': True, 'link_note': 'from app'})
    check('API: link with merge + exclude (JSON)', r.status_code == 201, r.get_data(as_text=True))
    api_link_id = r.get_json()['link_id']
    check('API: totals still counted once after API exclude merge',
          period_total() == (round(base_total, 3), 5), str(period_total()))
    r = api.post('/api/v1/invoices/0002/links?batch_id=1', headers=H,
                 data={'linked_serial': '0001', 'link_type': 'related'})
    check('API: duplicate pair refused', r.status_code == 400 and 'already linked' in r.get_json()['error'])
    r = api.post('/api/v1/invoices/0002/links?batch_id=1', headers=H,
                 data={'linked_serial': '0001', 'link_type': 'related', 'linked_batch_id': '2'})
    check('API: cross-batch link to same serial is a different invoice', r.status_code == 201,
          r.get_data(as_text=True))
    cross_id = r.get_json()['link_id']
    r = api.post('/api/v1/invoices/0002/links?batch_id=1', headers=H,
                 data={'linked_serial': '0009', 'link_type': 'related', 'linked_batch_id': '3'})
    check('API: clerk cannot link into hidden batch', r.status_code == 400)
    r = api.delete(f'/api/v1/invoices/0002/links/{cross_id}?batch_id=1', headers=H)
    check('API: unlink', r.status_code == 200 and r.get_json()['success'])
    r = api.delete(f'/api/v1/invoices/0002/links/{api_link_id}?batch_id=1', headers=H)
    check('API: unlink merged link restores totals', r.status_code == 200 and period_total() == (round(base_total, 3), 6))

    r = api.get('/api/v1/invoices/0009/history?batch_id=3', headers=H)
    check('API: hidden batch invoice invisible to clerk', r.status_code == 404)
    r = api.get('/api/v1/invoices/0009/history?batch_id=3', headers={'X-API-Key': 'admin-key-789'})
    check('API: admin sees hidden batch invoice', r.status_code == 200)

    # ---------------- File types ----------------
    r = sarah_c.post(f"/invoices/{ids['new']}/notes?batch_id=1", data={
        'body': '',
        'files': [(io.BytesIO(b'<svg onload=alert(1)>'), 'pic.svg', 'image/svg+xml')]},
        content_type='multipart/form-data', headers={'X-Requested-With': 'XMLHttpRequest'})
    check('SVG refused even with image MIME', r.status_code == 400)
    r = api.post('/api/v1/invoices/0002/media?batch_id=1', headers=H,
                 data={'file': (io.BytesIO(b'<html>x</html>'), 'page.html', 'image/png')})
    check('HTML named .html refused even with image MIME (media upload)', r.status_code == 400,
          r.get_data(as_text=True))
    r = api.post('/api/v1/invoices/0002/media?batch_id=1', headers=H,
                 data={'file': (io.BytesIO(b'a,b\n1,2'), 'sheet.csv', 'text/csv')})
    check('CSV document accepted by media upload', r.status_code == 201, r.get_data(as_text=True))
    r = api.post('/api/v1/invoices/0002/media?batch_id=1', headers=H,
                 data={'file': (io.BytesIO(b'RIFF'), 'scan.webp', 'image/webp')})
    check('WEBP image accepted', r.status_code == 201)

    r = admin_c.get('/import-export/sample-csv')
    check('sample CSV download no longer crashes (NameError fixed)',
          r.status_code == 200 and b'Serial Number' in r.data, str(r.status_code))

    print(f'\nALL {len(PASSED)} CHECKS PASSED')


if __name__ == '__main__':
    main()
