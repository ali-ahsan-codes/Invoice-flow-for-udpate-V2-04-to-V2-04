"""Real browser regression: dialog stacking, cancel/delete/failure and live sync.
Uses disposable records in qa.support.demo_app's database only.
Run from /home/user/qa-work; screenshots/ must exist.
"""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from support.demo_app import app
from app.extensions import db
from app.models import Invoice,User,AuditLog
from datetime import date
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:5000';results=[]
def check(name,condition):
 results.append({'test':name,'passed':bool(condition)});print('PASS' if condition else 'FAIL',name,flush=True);assert condition,name
def make_invoice(serial):
 with app.app_context():
  inv=Invoice(date=date.today(),serial_number=str(900000+sum((i+1)*ord(c) for i,c in enumerate(serial))),created_by=1,updated_by=1,total_amount=3.5);inv.set_amounts([3.5]);db.session.add(inv);db.session.commit();return inv.id
ids=[]
try:
 with sync_playwright() as p:
  b=p.chromium.launch()
  for mobile in [False,True]:
   ctx=b.new_context(viewport={'width':390 if mobile else 1440,'height':844 if mobile else 1000},reduced_motion='no-preference');pg=ctx.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));kind='mobile' if mobile else 'desktop'
   pg.goto(BASE+'/auth/login');pg.fill('#username','admin');pg.fill('#password','Preview@2026');pg.click('[type=submit]');pg.wait_for_url('**/dashboard*')
   for iteration in range(3):
    iid=make_invoice('modal-'+kind+'-'+str(iteration));ids.append(iid);pg.goto(BASE+'/invoices/');pg.wait_for_timeout(600)
    # Query filter not required: newest date puts our record on first page.
    pg.evaluate('(id)=>deleteInvoice(id,"modal-test")',iid);pg.wait_for_timeout(350)
    check(kind+' dialog submit is the top clickable element '+str(iteration),pg.locator('#delete-form [type=submit]').evaluate('(btn)=>{const r=btn.getBoundingClientRect();return document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)===btn}'))
    # External write while modal is open must not clone/remove it.
    with app.app_context():db.session.add(AuditLog(user_id=1,action='modal_qa',details='test'));db.session.commit()
    pg.wait_for_timeout(1700)
    check(kind+' live update preserves a single active modal '+str(iteration),pg.locator('#deleteModal').count()==1 and pg.locator('.modal-backdrop').count()==1)
    if iteration==0:
     pg.screenshot(path='/home/user/qa-work/screenshots/delete-confirm-'+kind+'.png',full_page=True)
     pg.locator('#deleteModal [data-bs-dismiss=modal]').last.click();pg.wait_for_timeout(450)
     check(kind+' Cancel clears backdrop and body lock',pg.locator('.modal-backdrop').count()==0 and pg.evaluate('!document.body.classList.contains("modal-open")'))
     pg.evaluate('(id)=>deleteInvoice(id,"modal-test")',iid);pg.wait_for_timeout(350)
    if iteration==1:
     # Inject a genuine error response into this request, check re-enable and cancel.
     pg.route('**/invoices/*'+str(iid)+'/delete*',lambda route:route.fulfill(status=500,content_type='application/json',body='{"success":false,"error":"Simulated deletion failure"}'))
     pg.locator('#delete-form [type=submit]').click();pg.wait_for_timeout(300)
     check(kind+' Failed delete leaves usable modal and enabled retry',pg.locator('#deleteModal').is_visible() and pg.locator('#delete-form [type=submit]').is_enabled())
     pg.unroute('**/invoices/*'+str(iid)+'/delete*')
    boot=pg.evaluate('performance.timeOrigin')
    pg.locator('#delete-form [type=submit]').click();pg.wait_for_function('()=>!document.querySelector(".modal.show,.modal-backdrop")');pg.wait_for_timeout(450)
    with app.app_context():check(kind+' Delete actually removes invoice '+str(iteration),db.session.get(Invoice,iid) is None)
    check(kind+' No overlay or page reload after list deletion '+str(iteration),pg.evaluate('!document.body.classList.contains("modal-open") && performance.timeOrigin=== '+str(boot)))
    # Clicking a live-inserted/delete-morphed row action remains usable.
    check(kind+' No duplicate modal IDs after refresh '+str(iteration),pg.locator('#deleteModal').count()==1)
   iid=make_invoice('modal-detail-'+kind);ids.append(iid);pg.goto(BASE+'/invoices/'+str(iid));pg.wait_for_timeout(450);pg.evaluate('(id)=>deleteInvoice(id,"detail-test")',iid);pg.wait_for_timeout(350);pg.locator('#delete-form [type=submit]').click();pg.wait_for_function("location.pathname === '/invoices/'")
   check(kind+' Detail deletion returns to usable invoice list',pg.locator('.modal-backdrop').count()==0 and not pg.evaluate('document.body.classList.contains("modal-open")'))
   pg.goto(BASE+'/invoices/start-session?book=3');pg.locator('#start-session-form [type=submit]').click();pg.wait_for_url('**/invoices/create*');pg.wait_for_timeout(350)
   check(kind+' Invoice amount control has clear 60px entry height',pg.locator('.amount-field-input').first.evaluate('(el)=>el.getBoundingClientRect().height>=58 && parseFloat(getComputedStyle(el).fontSize)>=20'))
   check(kind+' Data-entry layout has no horizontal overflow',not pg.evaluate('document.documentElement.scrollWidth>innerWidth'))
   pg.screenshot(path='/home/user/qa-work/screenshots/invoice-create-'+kind+'.png',full_page=True)
   check(kind+' No JavaScript exceptions during real dialog interactions',not errors);ctx.close()
  # User delete uses the same portal/AJAX path.
  ctx=b.new_context();pg=ctx.new_page();pg.goto(BASE+'/auth/login');pg.fill('#username','admin');pg.fill('#password','Preview@2026');pg.click('[type=submit]');pg.wait_for_url('**/dashboard*')
  with app.app_context():
   u=User(username='modal-user',email='modaluser@example.test',role='data_entry');u.set_password('Preview@2026');db.session.add(u);db.session.commit();uid=u.id
  pg.goto(BASE+'/admin/users');pg.wait_for_timeout(500);pg.evaluate('(id)=>confirmDelete(id,"modal-user")',uid);pg.wait_for_timeout(350);pg.locator('#delete-form [type=submit]').click();pg.wait_for_function('()=>!document.querySelector(".modal.show,.modal-backdrop")');pg.wait_for_timeout(700)
  with app.app_context():check('User deletion modal succeeds and re-enables table',db.session.get(User,uid) is None)
  b.close()
finally:
 with app.app_context():
  for iid in ids:
   inv=db.session.get(Invoice,iid)
   if inv:db.session.delete(inv)
  AuditLog.query.filter_by(action='modal_qa').delete();db.session.commit()
 Path('modal-results.json').write_text(json.dumps(results,indent=2))


