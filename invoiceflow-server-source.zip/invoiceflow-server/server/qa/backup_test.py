from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from support.demo_app import app
from app.services.backup_service import parse_db_connection_string
app.config['TESTING']=True;app.config['WTF_CSRF_ENABLED']=False
with app.app_context():
 x=parse_db_connection_string('mysql+pymysql://invoice:p%40ss%3Aword@localhost:3307/ledger?charset=utf8mb4');assert x['password']=='p@ss:word' and x['database']=='ledger' and x['port']=='3307'
 print('PASS database URL credentials/options parsing')
 c=app.test_client();c.post('/auth/login',data={'username':'admin','password':'Preview@2026'})
 r=c.post('/backup/create',headers={'X-Requested-With':'XMLHttpRequest'});assert r.status_code==200 and r.json['success'],r.json;name=r.json['filename']
 r=c.get('/backup/download/'+name);assert r.status_code==200 and len(r.data)>1000
 r=c.post('/backup/restore',data={'filename':name});assert r.status_code==200 and b'Confirm Database Restore' in r.data
 r=c.post('/backup/delete/'+name);assert r.status_code in (200,302)
 print('PASS create/download/confirmation/delete backup; no restore performed')


