"""Real browser stability regression; only disposable preview DB."""
import sys,json,io
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from support.demo_app import app
from app.extensions import db
from app.models import Invoice,AuditLog
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:5000';ROOT=Path('/home/user/qa-work/screenshots');out=[]
def check(n,c):out.append({'test':n,'passed':bool(c)});print('PASS' if c else 'FAIL',n,flush=True);assert c,n
with sync_playwright() as p:
 b=p.chromium.launch();ctx=b.new_context(viewport={'width':1440,'height':1000});pg=ctx.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));pg.goto(BASE+'/auth/login?batch_id=1')
 check('Anonymous login has no batch strip or workspace sync',pg.locator('.batch-context-strip,#batch-selector,#live-status').count()==0 and 'window.invoiceflowBatch' not in pg.content() and not pg.locator('script[src*=realtime]').count())
 pg.fill('#username','admin');pg.fill('#password','draft-login-not-submitted');pg.wait_for_timeout(6000)
 check('Idle login keeps credentials and does not poll workspace',pg.locator('#password').input_value()=='draft-login-not-submitted')
 pg.screenshot(path=str(ROOT/'stable-01-login-no-batch.png'),full_page=True)
 pg.fill('#password','Preview@2026');pg.click('[type=submit]');pg.wait_for_url('**/dashboard*')
 pg.goto(BASE+'/invoices/start-session?book=3&batch_id=1');pg.locator('#start-session-form [type=submit]').click();pg.wait_for_url('**/invoices/create*');pg.wait_for_timeout(300)
 pg.locator('.amount-field-input').first.fill('30.125');pg.locator('.btn-add-amount').click();pg.locator('.amount-field-input').last.fill('40.250');pg.fill('[name=serial_number]','0105')
 pg.evaluate('window.__form=document.getElementById("invoice-form");window.__amount=document.querySelector(".amount-field-input");window.__origin=performance.timeOrigin;window.__main=document.querySelector("main");window.__flashes=document.querySelector(".app-flash").innerText;window.__removed=0;new MutationObserver(ms=>{for(const m of ms)for(const n of m.removedNodes)if(n===window.__form||n.contains?.(window.__form))window.__removed++;}).observe(document.querySelector("main"),{subtree:true,childList:true});')
 for i in range(5):
  with app.app_context():db.session.add(AuditLog(user_id=1,action='stability_qa',details={'sync':i}));db.session.commit()
  pg.evaluate('window.dispatchEvent(new Event("online"))');pg.wait_for_timeout(1700)
 check('Repeated background sync keeps exact form, main and input DOM identities',pg.evaluate('window.__form===document.getElementById("invoice-form") && window.__amount===document.querySelector(".amount-field-input") && window.__main===document.querySelector("main") && window.__removed===0'))
 check('Multi-amount and manually typed serial survive sync and debounce',pg.locator('.amount-field-input').evaluate_all('(els)=>els.map(e=>e.value)')==['30.125','40.250'] and pg.locator('[name=serial_number]').input_value()=='0105')
 check('Background sync does not reload or inject toasts/flash banners',pg.evaluate('performance.timeOrigin===window.__origin') and pg.locator('.toast').count()==0 and pg.locator('.app-flash .alert').count()==0)
 check('Batch context is not automatically dismissed after five seconds',pg.locator('.batch-context-strip').count()==1)
 pg.evaluate('window.scrollTo(0,0)');pg.wait_for_timeout(150)
 pg.screenshot(path=str(ROOT/'stable-02-draft-kept-desktop.png'),full_page=True)
 pg.set_viewport_size({'width':390,'height':844});pg.evaluate('InvoiceLive.refresh()');pg.wait_for_timeout(500);check('Mobile draft survives explicit data sync',pg.locator('.amount-field-input').evaluate_all('(els)=>els.map(e=>e.value)')==['30.125','40.250'] and not pg.evaluate('document.documentElement.scrollWidth>innerWidth'));pg.evaluate('window.scrollTo(0,0)');pg.wait_for_timeout(150);pg.screenshot(path=str(ROOT/'stable-03-draft-kept-mobile.png'),full_page=True)
 # Slow an intentional date-to-serial lookup then type a newer serial.
 pg.locator('.amount-field-input').first.fill('');pg.locator('.amount-field-input').last.fill('')
 pg.route('**/invoices/next-serial*',lambda r:r.fulfill(status=200,content_type='application/json',body='{"serial":"0101","page":1}'))
 pg.evaluate('window.invoiceFormHandler.syncDateToSerial();document.querySelector("[name=serial_number]").value="0110"')
 pg.wait_for_timeout(600);check('Late next-serial response cannot overwrite a newer manual serial',pg.locator('[name=serial_number]').input_value()=='0110');pg.unroute('**/invoices/next-serial*')
 pg.locator('.amount-field-input').first.fill('10');pg.locator('.amount-field-input').last.fill('20')
 # Delay save response using promise-bound route through async browser? fetch route remains synchronous
 pg.route('**/invoices/create*',lambda r:r.fulfill(status=200,content_type='application/json',body='{"success":false,"error":"Simulated retryable error"}') if r.request.method=='POST' else r.continue_())
 pg.locator('#invoice-form [type=submit]').click();pg.wait_for_timeout(500)
 check('Failed save retains values and restores controls',pg.locator('.amount-field-input').evaluate_all('(els)=>els.map(e=>e.value)')==['10','20'] and not pg.locator('.amount-field-input').first.evaluate('(e)=>e.readOnly') and pg.locator('#invoice-form [type=submit]').is_enabled())
 pg.unroute('**/invoices/create*')
 # save confirmation is deliberate; no background reset
 with pg.expect_response(lambda r:r.request.method=='POST' and '/invoices/create' in r.url) as response:pg.locator('#invoice-form [type=submit]').click()
 check('Explicit successful save works after repeated background updates',response.value.json()['success'])
 pg.wait_for_timeout(800);check('Amounts clear only after confirmed save',pg.locator('.amount-field-input').count()==1 and pg.locator('.amount-field-input').first.input_value()=='')
 # profile / arbitrary POST forms are similarly preserved
 pg.goto(BASE+'/auth/profile');pg.fill('#email','sarah@example.com');pg.locator('input[type=submit]').click();pg.wait_for_timeout(400);pg.evaluate('InvoiceLive.refresh()');pg.wait_for_timeout(800);check('Profile validation remains visible across sync',pg.get_by_text('Email already registered.').count()==1)
 pg.goto(BASE+'/batches/');pg.wait_for_timeout(5500);check('QR advice is collapsible help, not a transient error banner',pg.locator('details').get_by_text('Batch & QR help').count()==1 and not pg.locator('details').evaluate('(e)=>e.open'))
 pg.screenshot(path=str(ROOT/'stable-04-quiet-batch-help.png'),full_page=True)
 check('No JavaScript exceptions during stability scenarios',not errors)
 b.close()
with app.app_context():
 for inv in Invoice.query.filter(Invoice.book_id==3).all():db.session.delete(inv)
 AuditLog.query.filter_by(action='stability_qa').delete();db.session.commit()
Path('/home/user/qa-work/stability-results.json').write_text(json.dumps(out,indent=2))


