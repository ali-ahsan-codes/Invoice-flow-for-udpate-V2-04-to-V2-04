// Browser checks for the link lookup, background forms and note QR (run against qa/screenshots/demo_server.py).
// Run:  LD_LIBRARY_PATH=<dir with al2023 libs> node verify_ui.mjs <output dir>
// Needs: npm i @sparticuz/chromium playwright-core
import chromium from '@sparticuz/chromium';
import { chromium as pw } from 'playwright-core';
import { mkdirSync } from 'node:fs';

const BASE = process.env.DEMO_BASE || 'http://127.0.0.1:5055';
const OUT = process.argv[2] || './ui-check-out';
mkdirSync(OUT, { recursive: true });

const results = [];
function check(label, ok, extra = '') {
  results.push({ label, ok });
  console.log(ok ? 'PASS' : 'FAIL', label, ok ? '' : extra);
}

const browser = await pw.launch({ executablePath: await chromium.executablePath(), args: chromium.args, headless: true });
const context = await browser.newContext({ viewport: { width: 1366, height: 900 }, deviceScaleFactor: 1 });
const page = await context.newPage();
const pageErrors = [];
page.on('pageerror', e => pageErrors.push(String(e)));

await page.goto(`${BASE}/auth/login`, { waitUntil: 'domcontentloaded' });
await page.fill('input[name=username]', 'sarah');
await page.fill('input[name=password]', 'Sarah@12345');
await Promise.all([page.waitForLoadState('domcontentloaded'), page.click('button[type=submit], input[type=submit]')]);

await page.goto(`${BASE}/invoices/1?batch_id=1`, { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(800);

// ---- link lookup preview
await page.evaluate(() => { window.__noReload = 'still-here'; });
await page.fill('#link-serial', '0003');
await page.waitForFunction(() => document.getElementById('link-preview')?.textContent.includes('#0003'), null, { timeout: 5000 })
  .catch(() => {});
const previewText = await page.locator('#link-preview').innerText().catch(() => '');
check('lookup shows the other invoice (serial and date)', previewText.includes('#0003') && previewText.includes('2026-10-15'), previewText);
check('lookup shows the total', /Total\s+\d+\.\d{3}/.test(previewText), previewText);
check('submit enabled once the invoice is found', await page.locator('#link-submit').isEnabled());
await page.locator('#link-form').screenshot({ path: `${OUT}/13-link-lookup-preview.png` });

await page.fill('#link-serial', '9999');
await page.waitForFunction(() => document.getElementById('link-preview')?.textContent.includes('No invoice'), null, { timeout: 5000 })
  .catch(() => {});
check('missing serial says so', (await page.locator('#link-preview').innerText()).includes('No invoice 9999'));
check('submit disabled for a missing serial', !(await page.locator('#link-submit').isEnabled()));

// ---- link without a page reload; history list updates in place
await page.fill('#link-serial', '0003');
await page.waitForFunction(() => document.getElementById('link-preview')?.textContent.includes('#0003'), null, { timeout: 5000 })
  .catch(() => {});
await page.click('#link-submit');
await page.waitForFunction(() => document.getElementById('link-serial')?.value === '', null, { timeout: 8000 }).catch(() => {});
const noReload = await page.evaluate(() => window.__noReload);
check('linking does not reload the page', noReload === 'still-here', String(noReload));
check('form clears after a successful link', (await page.locator('#link-serial').inputValue()) === '');
// The list refreshes in the background after the form clears; wait for it (no reload).
await page.waitForFunction(() => document.getElementById('invoice-history')?.innerText.includes('0003'), null, { timeout: 8000 })
  .catch(() => {});
const historyText = await page.locator('#invoice-history').innerText();
check('history shows the new link without a page reload', historyText.includes('0003') && noReload === 'still-here', historyText.slice(0, 300));

// ---- typed text survives a background refresh
await page.fill('#note-form textarea[name=body]', 'draft note 123 — keep me');
await page.evaluate(() => window.InvoiceLive && window.InvoiceLive.refresh());
await page.waitForTimeout(1200);
const draft = await page.locator('#note-form textarea[name=body]').inputValue();
check('typed note text is not wiped by a background refresh', draft === 'draft note 123 — keep me', draft);

// ---- note saved in the background; the notes list updates without a reload
await page.fill('#note-form textarea[name=body]', 'Phone check note');
await page.click('#note-form button[type=submit]');
await page.waitForFunction(() => document.getElementById('live-notes')?.innerText.includes('Phone check note'), null, { timeout: 8000 })
  .catch(() => {});
check('note list updates in the background',
  (await page.locator('#live-notes').innerText()).includes('Phone check note') && (await page.evaluate(() => window.__noReload)) === 'still-here');
check('note form clears after saving', (await page.locator('#note-form textarea[name=body]').inputValue()) === '');

// ---- note QR modal
await page.getByRole('button', { name: /Note QR/ }).click();
await page.waitForTimeout(700);
const src = await page.locator('#noteQrModal img').getAttribute('src');
check('note QR points at target=note focus QR', !!src && src.includes('target=note') && src.includes('scan=focus'), String(src));
const qrOk = await page.evaluate(async (s) => (await fetch(s, { credentials: 'same-origin' })).ok, src);
check('note QR image loads for the signed-in user', qrOk);
await page.locator('#noteQrModal .modal-content').screenshot({ path: `${OUT}/14-note-qr-modal.png` });

check('no uncaught page errors', pageErrors.length === 0, pageErrors.join(' | '));

await browser.close();
const failed = results.filter(r => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} UI checks passed`);
process.exit(failed.length ? 1 : 0);
