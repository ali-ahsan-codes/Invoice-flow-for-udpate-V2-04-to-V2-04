import chromium from '@sparticuz/chromium';
import { chromium as pw } from 'playwright-core';

const BASE = 'http://127.0.0.1:5055';
const OUT = '/home/user/work/shots/out';
const { mkdirSync } = await import('node:fs');
mkdirSync(OUT, { recursive: true });

const browser = await pw.launch({
  executablePath: await chromium.executablePath(),
  args: chromium.args,
  headless: true,
});

async function login(page) {
  await page.goto(`${BASE}/auth/login`, { waitUntil: 'domcontentloaded' });
  await page.fill('input[name=username]', 'sarah');
  await page.fill('input[name=password]', 'Sarah@12345');
  await Promise.all([
    page.waitForLoadState('domcontentloaded'),
    page.click('button[type=submit], input[type=submit]'),
  ]);
}

const desktop = await browser.newContext({ viewport: { width: 1366, height: 900 }, deviceScaleFactor: 1 });
const page = await desktop.newPage();

await page.goto(`${BASE}/auth/login`, { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(800);
await page.screenshot({ path: `${OUT}/01-login.png`, fullPage: false });

await login(page);
await page.goto(`${BASE}/invoices/1?batch_id=1`, { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(1200);
await page.screenshot({ path: `${OUT}/02-invoice-0001-top.png`, fullPage: false });

const section = page.locator('#invoice-history');
await section.scrollIntoViewIfNeeded();
await page.waitForTimeout(400);
await section.screenshot({ path: `${OUT}/03-relations-notes-section.png` });

await page.goto(`${BASE}/invoices/3?batch_id=1`, { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(800);
await page.locator('#invoice-history').screenshot({ path: `${OUT}/04-invoice-0003-related-link.png` });

// Linked invoice in another batch, opened from the relation list
await page.goto(`${BASE}/invoices/4?batch_id=2`, { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(800);
await page.locator('#invoice-history').screenshot({ path: `${OUT}/05-other-batch-invoice-0102.png` });

// Mobile
const mobile = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
const mp = await mobile.newPage();
await login(mp);
await mp.goto(`${BASE}/invoices/1?batch_id=1`, { waitUntil: 'domcontentloaded' });
await mp.waitForTimeout(1200);
await mp.locator('#invoice-history').screenshot({ path: `${OUT}/06-mobile-history.png` });

await browser.close();
console.log('screenshots done');
