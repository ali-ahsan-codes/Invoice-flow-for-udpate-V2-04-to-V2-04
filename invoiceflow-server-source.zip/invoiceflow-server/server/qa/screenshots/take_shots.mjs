// Screenshot script for the InvoiceFlow demo (qa/screenshots/demo_server.py on port 5055).
// Run:  LD_LIBRARY_PATH=<dir with al2023 libs> node take_shots.mjs <output dir>
// Needs: npm i @sparticuz/chromium playwright-core   (run from any folder that has node_modules)
import chromium from '@sparticuz/chromium';
import { chromium as pw } from 'playwright-core';
import { mkdirSync } from 'node:fs';

const BASE = process.env.DEMO_BASE || 'http://127.0.0.1:5055';
const OUT = process.argv[2] || './screenshots-out';
mkdirSync(OUT, { recursive: true });

const ACCOUNTS = {
  admin: 'Admin@12345',
  sarah: 'Sarah@12345',
  omar: 'Omar@12345',
};

const browser = await pw.launch({
  executablePath: await chromium.executablePath(),
  args: chromium.args,
  headless: true,
});

async function signedInPage(username, viewport, extra = {}) {
  const context = await browser.newContext({ viewport, deviceScaleFactor: 1, ...extra });
  const page = await context.newPage();
  await page.goto(`${BASE}/auth/login`, { waitUntil: 'domcontentloaded' });
  await page.fill('input[name=username]', username);
  await page.fill('input[name=password]', ACCOUNTS[username]);
  await Promise.all([
    page.waitForLoadState('domcontentloaded'),
    page.click('button[type=submit], input[type=submit]'),
  ]);
  return { context, page };
}

async function settle(page, ms = 900) {
  await page.waitForLoadState('domcontentloaded');
  await page.waitForTimeout(ms);
}

const desktop = { width: 1366, height: 900 };

// 01 login (no session)
{
  const context = await browser.newContext({ viewport: desktop });
  const page = await context.newPage();
  await page.goto(`${BASE}/auth/login`, { waitUntil: 'domcontentloaded' });
  await settle(page, 800);
  await page.screenshot({ path: `${OUT}/01-login.png` });
}

// Sarah: data entry, a few switches off
{
  const { context, page } = await signedInPage('sarah', desktop);
  await page.goto(`${BASE}/invoices/1?batch_id=1`, { waitUntil: 'domcontentloaded' });
  await settle(page);
  await page.screenshot({ path: `${OUT}/02-invoice-0001-top.png` });

  await page.locator('#invoice-history').scrollIntoViewIfNeeded();
  await page.waitForTimeout(300);
  await page.locator('#invoice-history').screenshot({ path: `${OUT}/03-notes-and-links-0001.png` });

  await page.goto(`${BASE}/invoices/3?batch_id=1`, { waitUntil: 'domcontentloaded' });
  await settle(page, 700);
  await page.locator('#invoice-history').screenshot({ path: `${OUT}/04-related-link-0003.png` });

  await page.goto(`${BASE}/invoices/4?batch_id=2`, { waitUntil: 'domcontentloaded' });
  await settle(page, 700);
  await page.locator('#invoice-history').screenshot({ path: `${OUT}/05-other-batch-invoice-0102.png` });
}

// Admin: users list and the permission pages
{
  const { context, page } = await signedInPage('admin', desktop);
  await page.goto(`${BASE}/admin/users`, { waitUntil: 'domcontentloaded' });
  await settle(page);
  await page.screenshot({ path: `${OUT}/06-admin-users-list.png` });

  await page.goto(`${BASE}/admin/users/2/permissions`, { waitUntil: 'domcontentloaded' });
  await settle(page);
  await page.screenshot({ path: `${OUT}/07-admin-permissions-sarah.png`, fullPage: true });

  await page.goto(`${BASE}/admin/users/3/permissions`, { waitUntil: 'domcontentloaded' });
  await settle(page);
  await page.screenshot({ path: `${OUT}/08-admin-permissions-omar.png`, fullPage: true });
}

// Omar: restricted clerk
{
  const { context, page } = await signedInPage('omar', desktop);
  await page.goto(`${BASE}/invoices/?batch_id=1`, { waitUntil: 'domcontentloaded' });
  await settle(page);
  await page.screenshot({ path: `${OUT}/09-restricted-clerk-invoice-list.png` });

  await page.goto(`${BASE}/invoices/5?batch_id=1`, { waitUntil: 'domcontentloaded' });
  await settle(page);
  await page.screenshot({ path: `${OUT}/10-restricted-clerk-invoice-0004.png` });
  await page.locator('#invoice-history').screenshot({ path: `${OUT}/11-restricted-clerk-notes-links.png` });
}

// Sarah on a phone-sized screen
{
  const { context, page } = await signedInPage('sarah', { width: 390, height: 844 }, {
    deviceScaleFactor: 2, isMobile: true, hasTouch: true,
  });
  await page.goto(`${BASE}/invoices/1?batch_id=1`, { waitUntil: 'domcontentloaded' });
  await settle(page, 1000);
  await page.locator('#invoice-history').screenshot({ path: `${OUT}/12-mobile-notes-links-0001.png` });
}

await browser.close();
console.log('screenshots written to', OUT);
