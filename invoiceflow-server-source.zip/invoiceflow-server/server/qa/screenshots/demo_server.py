"""Demo server for screenshots ONLY. Temporary SQLite database + sample data. Never for production.

Run from anywhere:  python qa/screenshots/demo_server.py   (serves on http://127.0.0.1:5055)

Accounts (all synthetic):
  admin / Admin@12345   administrator
  sarah / Sarah@12345   data entry, a few switches turned off by the admin
  omar  / Omar@12345    data entry, most switches turned off (restricted clerk)
"""
import io
import os
import sys
from datetime import date
from decimal import Decimal

HERE = os.path.dirname(os.path.abspath(__file__))
SERVER = os.path.abspath(os.path.join(HERE, '..', '..'))
sys.path.insert(0, os.path.join(SERVER, 'qa'))
sys.path.insert(0, SERVER)
os.chdir(SERVER)

import sqlite_harness as h  # noqa: E402

app = h.make_app()

from PIL import Image, ImageDraw  # noqa: E402
from app.extensions import db  # noqa: E402
from app.models import User, Invoice, Batch  # noqa: E402
from app.permissions import set_capabilities  # noqa: E402
from app.services.invoice_history_service import add_note, create_link  # noqa: E402
from werkzeug.datastructures import FileStorage  # noqa: E402

with app.app_context():
    admin = User(username='admin', email='admin@demo.test', role='admin', api_key='demo-admin-key')
    admin.set_password('Admin@12345')
    sarah = User(username='sarah', email='sarah@demo.test', role='data_entry', api_key='demo-sarah-key')
    sarah.set_password('Sarah@12345')
    omar = User(username='omar', email='omar@demo.test', role='data_entry', api_key='demo-omar-key')
    omar.set_password('Omar@12345')
    db.session.add_all([admin, sarah, omar])
    db.session.add(Batch(id=2, name='Batch 2', numbering_mode='repeat', start_book=1, start_serial=101, archived=False))
    db.session.flush()

    def mk(batch, serial, day, amounts, owner):
        i = Invoice(batch_id=batch, date=date(2026, 10, day), serial_number=serial,
                    total_amount=Decimal(str(round(sum(amounts), 3))),
                    created_by=owner.id, updated_by=owner.id)
        i.set_amounts(amounts)
        db.session.add(i)
        db.session.flush()
        return i

    inv1 = mk(1, '0001', 14, [120.500, 45.250], sarah)
    inv2 = mk(1, '0002', 15, [88.000], sarah)
    inv3 = mk(1, '0003', 15, [36.750, 12.000], sarah)
    old = mk(2, '0102', 2, [210.000], sarah)
    omar_inv = mk(1, '0004', 16, [54.500], omar)
    db.session.commit()

    # Permissions set by the admin.
    set_capabilities(db.session.get(User, sarah.id), {'links.delete': False, 'data.export': False},
                     admin_id=admin.id)
    set_capabilities(db.session.get(User, omar.id), {
        'invoice.create': False, 'invoice.delete': False, 'media.upload': False, 'media.delete': False,
        'notes.create': False, 'notes.delete': False, 'links.create': False, 'links.delete': False,
        'data.export': False, 'data.import': False,
    }, admin_id=admin.id)
    db.session.commit()

    # Attachment: a generated PNG "scanned" page.
    img = Image.new('RGB', (640, 420), 'white')
    d = ImageDraw.Draw(img)
    d.text((30, 30), 'Customer re-issue reference', fill='black')
    d.text((30, 70), 'Old invoice #0102 (Batch 2) - OMR 210.000', fill='black')
    d.rectangle((30, 120, 600, 360), outline='black', width=3)
    d.text((50, 150), 'Scanned copy of printed invoice', fill='black')
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)

    sarah_user = db.session.get(User, sarah.id)
    add_note(db.session.get(Invoice, inv1.id), sarah_user,
             'Customer asked to re-issue this invoice. Old invoice was never paid.', [])
    add_note(db.session.get(Invoice, inv1.id), sarah_user, 'Scanned reference attached.',
             [FileStorage(stream=buf, filename='scan-0102.png', content_type='image/png')])
    add_note(db.session.get(Invoice, old.id), sarah_user, 'Original invoice, amount carried forward.', [])

    # Duplicate of the other-batch invoice, amount merged into 0001 (excluded from totals).
    link, err = create_link(db.session.get(Invoice, inv1.id), sarah_user, '0102', 'duplicate', 'merge',
                            'Re-issued after customer request', linked_batch_id=2)
    assert err is None, err
    create_link(db.session.get(Invoice, inv3.id), sarah_user, '0002', 'related', 'none', 'Same customer, same day')
    db.session.commit()
    print('demo ids: admin', admin.id, 'sarah', sarah.id, 'omar', omar.id,
          'invoices', inv1.id, inv2.id, inv3.id, old.id, omar_inv.id, flush=True)

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5055, debug=False, threaded=True, use_reloader=False)
