"""Demo server for screenshots ONLY. SQLite + sample data. Not for production."""
import io
import os
import sys
from datetime import date
from decimal import Decimal

sys.path.insert(0, '/home/user/work/tests')
os.chdir('/home/user/work/invoiceflow-server/server')
sys.path.insert(0, '/home/user/work/invoiceflow-server/server')
import sqlite_harness as h  # noqa: E402

app = h.make_app()

from PIL import Image, ImageDraw  # noqa: E402
from app.extensions import db  # noqa: E402
from app.models import User, Invoice, Batch, InvoiceNote, InvoiceNoteMedia, InvoiceLink  # noqa: E402
from app.services.invoice_history_service import add_note, create_link  # noqa: E402
from werkzeug.datastructures import FileStorage  # noqa: E402

with app.app_context():
    admin = User(username='admin', email='admin@demo.test', role='admin')
    admin.set_password('Admin@12345')
    sarah = User(username='sarah', email='sarah@demo.test', role='data_entry')
    sarah.set_password('Sarah@12345')
    db.session.add_all([admin, sarah])
    db.session.add_all([
        Batch(id=2, name='Batch 2', numbering_mode='repeat', start_book=1, start_serial=101, archived=False),
    ])
    db.session.flush()

    def mk(batch, serial, day, amounts):
        i = Invoice(batch_id=batch, date=date(2026, 10, day), serial_number=serial,
                    total_amount=Decimal(str(round(sum(amounts), 3))),
                    created_by=sarah.id, updated_by=sarah.id)
        i.set_amounts(amounts)
        db.session.add(i)
        db.session.flush()
        return i

    inv1 = mk(1, '0001', 14, [120.500, 45.250])
    inv2 = mk(1, '0002', 15, [88.000])
    inv3 = mk(1, '0003', 15, [36.750, 12.000])
    old = mk(2, '0102', 2, [210.000])
    db.session.commit()

    # Attachment: a generated PNG "scanned" page.
    img = Image.new('RGB', (640, 420), 'white')
    d = ImageDraw.Draw(img)
    d.text((30, 30), 'Customer re-issue reference', fill='black')
    d.text((30, 70), 'Old invoice #0102 (Batch 2) - OMR 210.000', fill='black')
    d.rectangle((30, 120, 600, 360), outline='black', width=3)
    d.text((50, 150), 'Scanned copy of printed invoice', fill='black')
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)

    admin_user = db.session.get(User, admin.id)
    sarah_user = db.session.get(User, sarah.id)
    add_note(db.session.get(Invoice, inv1.id), sarah_user,
             'Customer asked to re-issue this invoice. Old invoice was never paid.', [])
    add_note(db.session.get(Invoice, inv1.id), sarah_user, 'Scanned reference attached.',
             [FileStorage(stream=buf, filename='scan-0102.png', content_type='image/png')])
    add_note(db.session.get(Invoice, old.id), sarah_user, 'Original invoice, amount carried forward.', [])

    # Duplicate of the other-batch invoice, amount merged into 0001.
    link, err = create_link(db.session.get(Invoice, inv1.id), sarah_user, '0102', 'duplicate', 'merge',
                            'Re-issued after customer request', linked_batch_id=2)
    assert err is None, err
    create_link(db.session.get(Invoice, inv3.id), sarah_user, '0002', 'related', 'none', 'Same customer, same day')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5055, debug=False, threaded=True, use_reloader=False)
