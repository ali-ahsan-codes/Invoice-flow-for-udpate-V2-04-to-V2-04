"""Safe, database-free contract test for the server's native-app invoice QR."""
import json
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from flask import Flask
from app.routes.media import _build_invoice_qr_payload, bp as media_bp

app = Flask(__name__)
app.register_blueprint(media_bp)
invoice = SimpleNamespace(id=184, batch_id=2, serial_number="0001")


def check(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"PASS {name}")


with app.test_request_context("/", base_url="https://invoice.example/"):
    focus = json.loads(_build_invoice_qr_payload(invoice, mode="app", scan="focus"))
    check(
        "focus QR carries v2 serial, invoice ID, batch ID, server URL and focus hint",
        focus == {
            "type": "invoice",
            "version": 2,
            "batch_id": 2,
            "invoice_id": 184,
            "serial": "0001",
            "base_url": "https://invoice.example",
            "scan": "focus",
            "target": "invoice",
        },
    )

    auto = json.loads(_build_invoice_qr_payload(invoice, mode="app", scan="auto"))
    check("auto QR carries the same batch identity and auto hint", auto["batch_id"] == 2 and auto["scan"] == "auto")

    web_url = _build_invoice_qr_payload(invoice, mode="web")
    check("browser-fallback QR retains its batch_id query", "batch_id=2" in web_url and web_url.endswith("/media/m/0001?batch_id=2"))

print("3 server mobile QR contract checks passed")
