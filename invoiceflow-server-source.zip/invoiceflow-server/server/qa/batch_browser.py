"""Real browser batch lifecycle and cross-tab regression on sample DB."""
import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from support.demo_app import app
from app.extensions import db
from app.models import Batch,Book,Invoice
from playwright.sync_api import sync_playwright
ROOT=Path('/home/user/qa-work/screenshots');BASE='http://127.0.0.1:5000';results=[]
def check(name,condition):
 results.append({'test':name,'passed':bool(condition)});print('PASS' if condition else 'FAIL',name,flush=True);assert condition,name
with sync_playwright() as p:
 b=p.chromium.launch();ctx=b.new_context(viewport={'width':1440,'height':1000});pg=ctx.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
 pg.goto(BASE+'/auth/login');pg.fill('#username','admin');pg.fill('#password','Preview@2026');pg.click('[type=submit]');pg.wait_for_url('**/dashboard*')
 pg.goto(BASE+'/batches/');pg.screenshot(path=str(ROOT/'batch-01-management.png'),full_page=True)
 pg.fill('[name=name]','Batch 2');pg.select_option('[name=mode]','repeat');pg.fill('[name=count]','4');pg.fill('[name=capacity]','50');pg.get_by_role('button',name='Create batch',exact=True).click();pg.wait_for_timeout(700)
 check('Create Repeat batch button persists batch','Batch 2' in pg.locator('main').inner_text())
 with app.app_context():bid=Batch.query.filter_by(name='Batch 2').order_by(Batch.id.desc()).first().id
 pg.goto(BASE+f'/invoices/start-session?batch_id={bid}&book=1');pg.locator('#start-session-form [type=submit]').click();pg.wait_for_url('**/invoices/create*');pg.wait_for_timeout(500)
 check('Batch 2 entry starts at repeated serial 0001',pg.locator('[name=serial_number]').input_value()=='0001')
 pg.screenshot(path=str(ROOT/'batch-02-repeat-entry.png'),full_page=True)
 # Another tab changes default batch; the existing entry tab must remain pinned.
 other=ctx.new_page();other.goto(BASE+'/dashboard?batch_id=1');other.select_option('#batch-selector','1');other.wait_for_timeout(400)
 pg.fill('[name=date]','2025-10-01');pg.fill('.amount-field-input','12.750')
 with pg.expect_response(lambda r:r.request.method=='POST' and '/invoices/create' in r.url) as response:pg.locator('#invoice-form [type=submit]').click()
 check('Cross-tab batch switch cannot misroute saved entry',response.value.json()['success'])
 with app.app_context():inv=Invoice.query.filter_by(batch_id=bid,serial_number='0001').first();iid=inv.id;check('Repeated serial is stored against Batch 2 book 1',inv.book_record.batch_id==bid and inv.book_page==1)
 pg.wait_for_timeout(500);check('Save advances only within Batch 2',pg.locator('[name=serial_number]').input_value()=='0002')
 pg.goto(BASE+f'/invoices/?batch_id={bid}');pg.wait_for_timeout(700);pg.screenshot(path=str(ROOT/'batch-03-repeat-list.png'),full_page=True)
 check('Invoice list shows batch context and does not combine books',f'Batch ID {bid}' in pg.locator('main').inner_text() and pg.locator('a[href*="/invoices/1?"]').count()==0)
 pg.goto(BASE+f'/admin/books/1?batch_id={bid}');pg.wait_for_timeout(700);pg.screenshot(path=str(ROOT/'batch-04-book-detail.png'),full_page=True)
 check('Book detail is scoped to repeated batch','12.750' in pg.locator('main').inner_text())
 pg.goto(BASE+f'/media/m/0001?batch_id={bid}');pg.wait_for_timeout(500);pg.screenshot(path=str(ROOT/'batch-05-mobile-scan.png'),full_page=True)
 check('Batch-specific mobile scan identifies correct invoice',f'Batch ID {bid}' in pg.locator('main').inner_text())
 response=pg.goto(BASE+'/media/m/0001');check('Ambiguous old QR produces visible 409',response.status==409);pg.screenshot(path=str(ROOT/'batch-06-ambiguous-qr.png'),full_page=True)
 pg.goto(BASE+'/batches/');pg.fill('[name=name]','Batch 3');pg.select_option('[name=mode]','continue');pg.fill('[name=count]','2');pg.get_by_role('button',name='Create batch',exact=True).click();pg.wait_for_timeout(700)
 with app.app_context():batch3=Batch.query.filter_by(name='Batch 3').order_by(Batch.id.desc()).first();bid3=batch3.id;check('Continue button uses full preceding printed range',batch3.start_book==5 and batch3.start_serial==201)
 pg.screenshot(path=str(ROOT/'batch-07-continue-configuration.png'),full_page=True)
 pg.goto(BASE+f'/invoices/start-session?batch_id={bid3}&book=5');pg.locator('#start-session-form [type=submit]').click();pg.wait_for_url('**/invoices/create*');pg.wait_for_timeout(400)
 check('Continued batch form derives first serial correctly',pg.locator('[name=serial_number]').input_value()=='0201');pg.screenshot(path=str(ROOT/'batch-08-continue-entry.png'),full_page=True)
 # Actually archive verified Batch 1; no automatic assumption of missing pages.
 pg.goto(BASE+'/batches/');form=pg.locator('form[action$="/1/archive"]');form.locator('[name=verified]').check();form.get_by_role('button',name='Archive batch').click();pg.wait_for_timeout(600)
 with app.app_context():check('Archive button persists administrator verification',db.session.get(Batch,1).archived)
 pg.goto(BASE+'/invoices/1/edit?batch_id=1');pg.wait_for_timeout(500);check('Archived admin correction screen stays available','Archived' in pg.locator('main').inner_text());pg.screenshot(path=str(ROOT/'batch-09-archived-admin-correction.png'),full_page=True)
 # mobile management + repeated entry captures
 pg.set_viewport_size({'width':390,'height':844});pg.goto(BASE+'/batches/');pg.wait_for_timeout(400);check('Batch management fits mobile viewport',not pg.evaluate('document.documentElement.scrollWidth>innerWidth'));pg.screenshot(path=str(ROOT/'batch-10-management-mobile.png'),full_page=True)
 pg.goto(BASE+f'/invoices/start-session?batch_id={bid}&book=1');pg.locator('#start-session-form [type=submit]').click();pg.wait_for_url('**/invoices/create*');pg.wait_for_timeout(400);check('Batch 2 mobile entry fits viewport',not pg.evaluate('document.documentElement.scrollWidth>innerWidth'));pg.screenshot(path=str(ROOT/'batch-11-entry-mobile.png'),full_page=True)
 check('No JavaScript errors during lifecycle and switching',not errors)
 b.close()
# Restore sample dataset after actual browser actions, leaving lifecycle screenshots as evidence.
with app.app_context():
 db.session.get(Batch,1).archived=False
 for bid in [bid3,bid]:
  for inv in Invoice.query.filter_by(batch_id=bid).all():db.session.delete(inv)
  db.session.flush()
  for book in Book.query.filter_by(batch_id=bid).all():db.session.delete(book)
  db.session.flush();db.session.delete(db.session.get(Batch,bid))
 db.session.commit()
Path('/home/user/qa-work/batch-browser-results.json').write_text(json.dumps(results,indent=2))


