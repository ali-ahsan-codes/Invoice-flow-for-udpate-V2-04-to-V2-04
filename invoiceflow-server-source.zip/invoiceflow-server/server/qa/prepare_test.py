"""Destructive preparation helper check after batch_test; isolated test DB only."""
import os,sys,subprocess,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from sqlalchemy import create_engine,text
url='mysql+pymysql://invoiceflow:preview-only-password@127.0.0.1/invoiceflow_batch_test'
e=create_engine(url)
with e.begin() as c:
    c.execute(text('DELETE FROM invoice_media WHERE invoice_id IN (SELECT id FROM invoices WHERE batch_id<>1)'))
    c.execute(text('DELETE FROM invoices WHERE batch_id<>1'))
    c.execute(text('DELETE FROM books WHERE batch_id<>1'))
    c.execute(text('DELETE FROM batches WHERE id<>1'))
    c.execute(text('ALTER TABLE batches AUTO_INCREMENT=2'))
    original=[tuple(r) for r in c.execute(text('SELECT * FROM invoices WHERE batch_id=1'))]
    media=[tuple(r) for r in c.execute(text('SELECT * FROM invoice_media'))]
for _ in range(2):
    subprocess.run([sys.executable,'prepare_batches.py'],cwd=Path(__file__).resolve().parents[1],env={**os.environ,'DATABASE_URL':url,'SCHEDULER_ENABLED':'False'},check=True)
with e.connect() as c:
    assert c.execute(text('SELECT COUNT(*) FROM books WHERE batch_id=2')).scalar()==100
    assert c.execute(text('SELECT COUNT(*) FROM batches')).scalar()==2
    assert original==[tuple(r) for r in c.execute(text('SELECT * FROM invoices WHERE batch_id=1'))]
    assert media==[tuple(r) for r in c.execute(text('SELECT * FROM invoice_media'))]
print('PASS offline preparation creates Batch 2 exactly once; preserves all Batch 1 invoice/media columns')
Path('/home/user/qa-work/prepare-results.json').write_text(json.dumps([{'test':'Offline 100-book preparation is idempotent and creates empty repeated Batch 2 exactly once','passed':True},{'test':'Full startup/preparation preserves every column of existing Batch 1 invoice and media rows','passed':True}],indent=2))


