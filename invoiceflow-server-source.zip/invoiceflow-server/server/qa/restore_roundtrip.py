"""Destructive CLI restore on invoiceflow_batch_test only; never production."""
import os,sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
os.environ['DATABASE_URL']=os.environ.get('QA_DATABASE_URL', 'mysql+pymysql://invoiceflow:preview-only-password@127.0.0.1/invoiceflow_batch_test')
from config import Config
class TestConfig(Config):
    SCHEDULER_ENABLED=False
    BACKUP_DIR='/home/user/qa-work/restore-backups'
from app import create_app
from app.extensions import db
from app.models import Invoice,Book,Batch,InvoiceMedia,AuditLog
from app.services.backup_service import create_backup,_execute_sql_file
app=create_app(TestConfig, upgrade_schema=True)
with app.app_context():
    from app.detection import DetectionPolicy,ReviewCase
    policy=db.session.get(DetectionPolicy,1);policy.invoice_limit=1;policy.manual_enabled=True;policy.automatic_enabled=False
    db.session.flush();db.session.info['detect_all']=True;db.session.commit()
    case=ReviewCase.query.filter_by(kind='invoice',status='open').first()
    if case:
        case.status='cleared';case.review_note='Verified restore regression';case.reviewed_by=1;db.session.commit()
    review_before=[(c.case_key,c.status,c.fingerprint,c.review_note) for c in ReviewCase.query.order_by(ReviewCase.id)]
    before=(Batch.query.count(),Book.query.count(),Invoice.query.count(),InvoiceMedia.query.count())
    inv=Invoice.query.first();iid=inv.id;total=inv.total_amount
    backup=create_backup(manual=True);assert backup['success'],backup
    inv.total_amount=123;db.session.commit();db.session.remove()
    ok,error=_execute_sql_file(backup['filepath']);assert ok,error
    after=(Batch.query.count(),Book.query.count(),Invoice.query.count(),InvoiceMedia.query.count())
    assert before==after and db.session.get(Invoice,iid).total_amount==total
    assert AuditLog.query.filter_by(action='original_history').count()==1
    assert review_before==[(c.case_key,c.status,c.fingerprint,c.review_note) for c in ReviewCase.query.order_by(ReviewCase.id)]
    assert db.session.get(DetectionPolicy,1).invoice_limit==1
    print('PASS isolated MySQL CLI backup/restore roundtrip: batches/books/invoices/media references/history/amount restored')
    from app.services.backup_service import create_backup_sqlalchemy
    _,path=create_backup_sqlalchemy(app.config['BACKUP_DIR'])
    inv=db.session.get(Invoice,iid);inv.total_amount=456;db.session.commit();db.session.remove()
    ok,error=_execute_sql_file(path);assert ok,error
    assert (Batch.query.count(),Book.query.count(),Invoice.query.count(),InvoiceMedia.query.count())==before and db.session.get(Invoice,iid).total_amount==total
    assert review_before==[(c.case_key,c.status,c.fingerprint,c.review_note) for c in ReviewCase.query.order_by(ReviewCase.id)]
    print('PASS fallback SQLAlchemy backup/restore includes all batches, books and revision')
Path('/home/user/qa-work/restore-results.json').write_text(json.dumps([{'test':'Isolated MySQL CLI backup/restore restores batch/book/invoice/media row counts, amount and original history','passed':True},{'test':'Fallback SQLAlchemy backup/restore includes every batch/book/invoice/media reference and revision','passed':True},{'test':'Both backup/restore paths retain detection settings, cases and verification fingerprints/notes','passed':True}],indent=2))


