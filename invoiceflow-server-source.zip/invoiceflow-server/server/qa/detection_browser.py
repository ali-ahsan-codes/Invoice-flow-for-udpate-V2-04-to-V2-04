"""Actual browser settings, live admin review, verification, modes, responsive captures."""
import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from support.demo_app import app
from app.extensions import db
from app.models import Invoice
from app.detection import DetectionPolicy,ReviewCase
from playwright.sync_api import sync_playwright
ROOT=Path('/home/user/qa-work/screenshots');ROOT.mkdir(parents=True,exist_ok=True)
BASE='http://127.0.0.1:5000';out=[]
def check(n,ok):out.append({'test':n,'passed':bool(ok)});print('PASS' if ok else 'FAIL',n,flush=True);assert ok,n
with sync_playwright() as p:
 b=p.chromium.launch();ctx=b.new_context(viewport={'width':1440,'height':1000});pg=ctx.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
 pg.goto(BASE+'/auth/login');pg.fill('#username','admin');pg.fill('#password','Preview@2026');pg.click('[type=submit]');pg.wait_for_url('**/dashboard*')
 pg.goto(BASE+'/admin/review/settings');pg.check('#manual_enabled');pg.uncheck('#automatic_enabled');pg.fill('#invoice_limit','200');pg.fill('#user_daily_limit','400');pg.fill('#batch_daily_limit','400');pg.get_by_role('button',name='Save detection settings').click();pg.wait_for_timeout(600)
 check('Browser saves three distinct manual limits and automatic toggle',pg.locator('#invoice_limit').input_value()=='200.000' and not pg.locator('#automatic_enabled').is_checked())
 pg.screenshot(path=str(ROOT/'safety-01-manual-settings-desktop.png'),full_page=True)
 review=ctx.new_page();review.goto(BASE+'/admin/review/');review.wait_for_timeout(500);boot=review.evaluate('performance.timeOrigin')
 with app.app_context():
  inv=db.session.get(Invoice,1);old_total=inv.total_amount;old_amounts=inv.amounts_json;inv.total_amount=300;inv.set_amounts([300]);db.session.commit()
  case=ReviewCase.query.filter_by(invoice_id=1,status='open').first();cid=case.id
 review.wait_for_function('(id)=>document.querySelector("#review-case-list").innerText.includes("Case #"+id)',arg=cid,timeout=15000)
 check('New flag appears live in administrator review without refresh',review.evaluate('performance.timeOrigin')==boot)
 review.screenshot(path=str(ROOT/'safety-02-open-cases-desktop.png'),full_page=True)
 pg.goto(BASE+'/invoices/1?batch_id=1');pg.wait_for_timeout(400);check('Flag banner links to admin case',pg.get_by_role('link',name='Review case #'+str(cid)).count()>0);pg.screenshot(path=str(ROOT/'safety-03-invoice-warning.png'),full_page=True)
 pg.goto(BASE+f'/admin/review/{cid}');pg.wait_for_timeout(400);pg.screenshot(path=str(ROOT/'safety-04-case-verification-desktop.png'),full_page=True)
 pg.fill('#note','Verified original paper invoice. 300 is correct for this case.');pg.get_by_role('button',name='Verified — unflag case').click();pg.wait_for_timeout(600)
 check('Actual verify button unflags and shows review history',pg.get_by_text('Verified at:',exact=False).count()>0)
 pg.screenshot(path=str(ROOT/'safety-05-verified-case.png'),full_page=True)
 pg.goto(BASE+'/admin/review/');pg.get_by_role('button',name='Recheck existing data').click();pg.wait_for_timeout(400)
 with app.app_context():check('Recheck button does not repeatedly flag verified unchanged invoice',db.session.get(ReviewCase,cid).status=='cleared')
 pg.goto(BASE+'/admin/review/settings');pg.uncheck('#manual_enabled');pg.check('#automatic_enabled');pg.fill('#invoice_limit','');pg.fill('#user_daily_limit','');pg.fill('#batch_daily_limit','');pg.get_by_role('button',name='Save detection settings').click();pg.wait_for_timeout(450);pg.screenshot(path=str(ROOT/'safety-06-automatic-only-settings.png'),full_page=True)
 check('Automatic-only browser mode persists with blank thresholds',pg.locator('#automatic_enabled').is_checked() and not pg.locator('#manual_enabled').is_checked() and pg.locator('#invoice_limit').input_value()=='')
 # show meaningful automatic anomaly against real synthetic historical values
 with app.app_context():inv=db.session.get(Invoice,1);inv.total_amount=3000;inv.set_amounts([3000]);db.session.commit();auto=ReviewCase.query.filter_by(invoice_id=1,status='open').first();auto_id=auto.id
 pg.goto(BASE+f'/admin/review/{auto_id}');pg.wait_for_timeout(400);check('Automatic reason is human-readable and reports sample count',pg.get_by_text('Data-based check',exact=True).count()>0 and 'historical samples' in pg.locator('main').inner_text());pg.screenshot(path=str(ROOT/'safety-07-automatic-anomaly.png'),full_page=True)
 for i,path,label in [(8,'/admin/review/settings','settings-mobile'),(9,'/admin/review/','queue-mobile'),(10,f'/admin/review/{auto_id}','case-mobile')]:
  pg.set_viewport_size({'width':390,'height':844});pg.goto(BASE+path);pg.wait_for_timeout(350);check('Responsive '+label,not pg.evaluate('document.documentElement.scrollWidth>innerWidth'));pg.screenshot(path=str(ROOT/f'safety-{i:02d}-{label}.png'),full_page=True)
 pg.set_viewport_size({'width':1440,'height':1000});pg.goto(BASE+'/admin/review/settings');pg.uncheck('#manual_enabled');pg.uncheck('#automatic_enabled');pg.get_by_role('button',name='Save detection settings').click();pg.wait_for_timeout(450)
 pg.screenshot(path=str(ROOT/'safety-11-both-disabled.png'),full_page=True)
 with app.app_context():check('Both disabled clears live queue without deleting history',ReviewCase.query.filter_by(status='open').count()==0 and ReviewCase.query.count()>0)
 pg.goto(BASE+'/admin/review/?status=resolved');pg.wait_for_timeout(400);pg.screenshot(path=str(ROOT/'safety-12-resolved-history.png'),full_page=True)
 check('No browser JavaScript errors through settings/review interactions',not errors)
 b.close()
with app.app_context():
 inv=db.session.get(Invoice,1);inv.total_amount=old_total;inv.amounts_json=old_amounts
 policy=db.session.get(DetectionPolicy,1);policy.manual_enabled=True;policy.automatic_enabled=True;policy.invoice_limit=None;policy.user_daily_limit=None;policy.batch_daily_limit=None
 db.session.flush();db.session.info['detect_all']=True;db.session.commit()
Path('/home/user/qa-work/detection-browser-results.json').write_text(json.dumps(out,indent=2))


