"""Tests for per-user permissions (admin-controlled capabilities).

Covers: defaults, the admin page, enforcement on web routes, enforcement on the
mobile API, the legacy can_export flag, and the hidden buttons in the templates.

Runs through the real Flask app on a temporary SQLite database (sqlite_harness.py).
Run: python qa/permissions_test.py
"""
import io
import os
import sys
from datetime import date
from decimal import Decimal

sys.path.insert(0, os.path.dirname(__file__))
import sqlite_harness as h  # noqa: E402

app = h.make_app()
app.config['TESTING'] = True

from app.extensions import db  # noqa: E402
from app.models import User, Invoice, InvoiceLink, UserCapability, AuditLog
from app.permissions import (  # noqa: E402
    CAPABILITY_KEYS, CAPABILITY_LABELS, user_can, set_capabilities, reset_capabilities,
)

PASSED = []
XHR = {'X-Requested-With': 'XMLHttpRequest'}
SARAH_KEY = 'sarah-key-123'
H = {'X-API-Key': SARAH_KEY}


def check(label, cond, extra=''):
    if not cond:
        raise AssertionError(f'FAIL: {label} {extra}')
    PASSED.append(label)
    print('PASS', label)


def setup_data():
    with app.app_context():
        sarah = User(username='sarah', email='sarah@x.test', role='data_entry', api_key=SARAH_KEY)
        sarah.set_password('Sarah@12345')
        omar = User(username='omar', email='omar@x.test', role='data_entry', api_key='omar-key-456')
        omar.set_password('Omar@12345')
        admin = User(username='admin', email='admin@x.test', role='admin', api_key='admin-key-789')
        admin.set_password('Admin@12345')
        db.session.add_all([sarah, omar, admin])
        db.session.flush()

        def mk(serial, owner, amount, day=15):
            i = Invoice(batch_id=1, date=date(2026, 10, day), serial_number=serial,
                        total_amount=Decimal(str(amount)), created_by=owner.id, updated_by=owner.id)
            i.set_amounts([float(amount)])
            db.session.add(i)
            db.session.flush()
            return i.id

        ids = {
            'mine': mk('0001', sarah, 10.0),
            'mine2': mk('0002', sarah, 20.0),
            'other': mk('0003', omar, 5.0),
        }
        ids['sarah_id'] = sarah.id
        ids['omar_id'] = omar.id
        ids['admin_id'] = admin.id
        db.session.commit()
        return ids


def login(client, username, password):
    r = client.post('/auth/login', data={'username': username, 'password': password})
    assert r.status_code in (200, 302), r.status_code


def set_caps(user_id, mapping):
    """Helper: write overrides the same way the admin page does."""
    with app.app_context():
        user = db.session.get(User, user_id)
        set_capabilities(user, mapping, admin_id=None)
        db.session.commit()


def reset(user_id):
    with app.app_context():
        reset_capabilities(db.session.get(User, user_id))
        db.session.commit()


def caps_of(user_id):
    with app.app_context():
        user = db.session.get(User, user_id)
        return {k: user_can(user, k) for k in CAPABILITY_KEYS}


def main():
    ids = setup_data()
    sarah_id, omar_id, admin_id = ids['sarah_id'], ids['omar_id'], ids['admin_id']
    sarah_c = app.test_client()
    admin_c = app.test_client()
    login(sarah_c, 'sarah', 'Sarah@12345')
    login(admin_c, 'admin', 'Admin@12345')

    # ---------------- capability model ----------------
    check('catalogue has 12 capabilities', len(CAPABILITY_KEYS) == 12, str(len(CAPABILITY_KEYS)))
    check('every capability has a label', all(CAPABILITY_LABELS[k] for k in CAPABILITY_KEYS))
    check('defaults: data_entry user has every capability', all(caps_of(sarah_id).values()))
    check('admin has every capability', all(caps_of(admin_id).values()))
    with app.app_context():
        check('unknown capability raises', _raises(lambda: user_can(db.session.get(User, sarah_id), 'nope')))
        admin = db.session.get(User, admin_id)
        check('admin cannot be restricted (set_capabilities refuses)',
              _raises(lambda: set_capabilities(admin, {'links.create': False})))

    # ---------------- default: a regular user works as before ----------------
    r = sarah_c.post(f"/invoices/{ids['mine']}/links?batch_id=1",
                     data={'linked_serial': '0002', 'link_type': 'related', 'amount_action': 'none'},
                     headers=XHR)
    check('default allows linking (today\'s behaviour)', r.status_code == 200 and r.get_json().get('success'),
          r.get_data(as_text=True)[:200])
    with app.app_context():
        link = InvoiceLink.query.filter_by(invoice_id=ids['mine']).first()
        link_id = link.id if link else None
    check('link row created by default', link_id is not None)

    # ---------------- admin page ----------------
    r = admin_c.get(f'/admin/users/{sarah_id}/permissions')
    check('admin can open permissions page', r.status_code == 200)
    html = r.get_data(as_text=True)
    check('page lists every capability', all(f'name="cap_{k}"' in html for k in CAPABILITY_KEYS))
    r = sarah_c.get(f'/admin/users/{sarah_id}/permissions')
    check('data-entry user cannot open admin permissions page', r.status_code == 302)
    r = admin_c.get(f'/admin/users/{admin_id}/permissions')
    check('admin own account redirects (admins always have all)', r.status_code == 302)
    r = admin_c.get('/admin/users')
    check('users list links to permissions for data-entry users',
          f'/admin/users/{sarah_id}/permissions' in r.get_data(as_text=True))

    # Turn off linking through the admin form (checkbox names cap_<key>, every other box on).
    form = {f'cap_{k}': 'on' for k in CAPABILITY_KEYS if k != 'links.create'}
    r = admin_c.post(f'/admin/users/{sarah_id}/permissions', data=form)
    check('admin saves form (302 back to page)', r.status_code == 302)
    check('form turned links.create off', caps_of(sarah_id)['links.create'] is False)
    check('other capabilities stay on', all(v for k, v in caps_of(sarah_id).items() if k != 'links.create'))
    with app.app_context():
        log = AuditLog.query.filter_by(action='update_permissions').order_by(AuditLog.id.desc()).first()
        check('change is written to the audit log', log is not None and 'links.create' in (log.details or ''),
              str(log and log.details))

    # ---------------- web enforcement ----------------
    r = sarah_c.post(f"/invoices/{ids['mine']}/links?batch_id=1",
                     data={'linked_serial': '0003', 'link_type': 'related', 'amount_action': 'none'},
                     headers=XHR)
    body = r.get_json() or {}
    check('web: link create denied with 403 + capability key',
          r.status_code == 403 and body.get('capability') == 'links.create', f'{r.status_code} {body}')
    check('web: denial message names the function', 'Link invoices' in body.get('error', ''))
    r = sarah_c.post(f"/invoices/{ids['mine']}/links/{link_id}/delete?batch_id=1", headers=XHR)
    check('web: link delete still allowed when only links.create is off', r.status_code != 403, str(r.status_code))

    # Non-AJAX request: flash + redirect back, not a 403 page.
    r = sarah_c.post(f"/invoices/{ids['mine']}/links?batch_id=1",
                     data={'linked_serial': '0003', 'link_type': 'related', 'amount_action': 'none'},
                     headers={'Referer': f"/invoices/{ids['mine']}"})
    check('web: non-AJAX denial redirects back', r.status_code == 302)

    # Turn off notes, uploads, invoice create/edit/delete, export, import.
    set_caps(sarah_id, {'notes.create': False, 'notes.delete': False, 'media.upload': False,
                        'media.delete': False, 'invoice.create': False, 'invoice.edit': False,
                        'invoice.delete': False, 'data.export': False, 'data.import': False})
    check('admin-side change visible to user at once', caps_of(sarah_id)['notes.create'] is False)

    r = sarah_c.post(f"/invoices/{ids['mine']}/notes?batch_id=1", data={'body': 'hi'}, headers=XHR)
    check('web: note create denied', r.status_code == 403 and r.get_json()['capability'] == 'notes.create')
    r = sarah_c.post(f"/invoices/{ids['mine']}/edit?batch_id=1", data={}, headers=XHR)
    check('web: invoice edit denied', r.status_code == 403 and r.get_json()['capability'] == 'invoice.edit')
    r = sarah_c.post(f"/invoices/{ids['mine']}/delete?batch_id=1", headers=XHR)
    check('web: invoice delete denied', r.status_code == 403 and r.get_json()['capability'] == 'invoice.delete')
    r = sarah_c.post('/invoices/create?batch_id=1', data={}, headers=XHR)
    check('web: invoice create denied', r.status_code == 403 and r.get_json()['capability'] == 'invoice.create')
    r = sarah_c.post(f"/media/upload/{ids['mine']}?batch_id=1", data={}, headers=XHR)
    check('web: upload denied', r.status_code == 403 and r.get_json()['capability'] == 'media.upload')
    r = sarah_c.post('/media/scan-upload/%d?batch_id=1' % ids['mine'],
                     data={'file': (io.BytesIO(b'%PDF-1.4 test'), 'a.pdf')}, content_type='multipart/form-data',
                     headers=XHR)
    check('web: scanner upload denied', r.status_code == 403 and r.get_json()['capability'] == 'media.upload')
    r = sarah_c.get('/invoices/export?type=all')
    check('web: CSV export denied (redirect)', r.status_code == 302)
    r = sarah_c.get('/import-export/export?type=all')
    check('web: import/export CSV export denied (redirect)', r.status_code == 302)
    r = sarah_c.get('/import-export/sample-csv')
    check('web: sample CSV denied for user without data.import', r.status_code == 302)
    r = sarah_c.get('/import-export/')
    check('web: import page denied for user without data.import', r.status_code == 302)

    # Read access is never removed by these switches.
    r = sarah_c.get(f"/invoices/{ids['mine']}")
    check('web: invoice view still works with every write off', r.status_code == 200)
    html = r.get_data(as_text=True)
    check('view hides note form when notes.create is off', 'invoices.note_create' not in html and 'Add note' not in html)
    check('view hides link form when links.create is off', 'Link another invoice' not in html)
    check('view hides upload button when media.upload is off', 'Upload Files' not in html)
    check('view hides edit/delete buttons when invoice.edit/delete are off',
          'btn btn-warning' not in html and 'deleteInvoice(' not in html.split('<script')[0])

    # Turn them all back on: the same page shows the controls again.
    set_caps(sarah_id, {k: True for k in CAPABILITY_KEYS})
    html = sarah_c.get(f"/invoices/{ids['mine']}").get_data(as_text=True)
    check('view shows note form again when allowed', 'Add note' in html)
    check('view shows link form again when allowed', 'Link another invoice' in html)
    check('view shows upload button again when allowed', 'Upload Files' in html)

    # ---------------- legacy can_export flag ----------------
    with app.app_context():
        u = db.session.get(User, sarah_id)
        u.can_export = False
        db.session.commit()
        reset_capabilities(u)
        db.session.commit()
    check('legacy: can_export=False with no override denies export', caps_of(sarah_id)['data.export'] is False)
    r = sarah_c.get('/invoices/export?type=all')
    check('legacy: export denied after can_export=False', r.status_code == 302)
    set_caps(sarah_id, {'data.export': True})
    with app.app_context():
        check('setting data.export keeps legacy can_export in sync',
              db.session.get(User, sarah_id).can_export is True)
    r = sarah_c.get('/invoices/export?type=all')
    check('export allowed after admin grants data.export', r.status_code == 200)

    # ---------------- mobile API enforcement ----------------
    set_caps(sarah_id, {'mobile.access': False})
    r = sarah_c.get('/api/v1/invoices/0001?batch_id=1', headers=H)
    check('api: mobile.access off -> 403', r.status_code == 403 and r.get_json()['capability'] == 'mobile.access')
    r = sarah_c.get('/api/v1/me', headers=H)
    body = r.get_json()
    check('api: /me still answers so the app can show the reason',
          r.status_code == 200 and body['capabilities']['mobile.access'] is False)
    check('api: /me reports capabilities map', set(body['capabilities']) == set(CAPABILITY_KEYS))
    set_caps(sarah_id, {'mobile.access': True, 'notes.create': False, 'links.create': False,
                        'media.upload': False, 'links.delete': False, 'notes.delete': False})
    r = sarah_c.get('/api/v1/invoices/0001?batch_id=1', headers=H)
    check('api: reads work with mobile.access on', r.status_code == 200)
    r = sarah_c.post('/api/v1/invoices/0001/notes?batch_id=1', headers=H, json={'body': 'x'})
    check('api: note create denied', r.status_code == 403 and r.get_json()['capability'] == 'notes.create')
    r = sarah_c.post('/api/v1/invoices/0001/links?batch_id=1', headers=H,
                     json={'linked_serial': '0002', 'link_type': 'related', 'amount_action': 'none'})
    check('api: link create denied', r.status_code == 403 and r.get_json()['capability'] == 'links.create')
    r = sarah_c.post('/api/v1/invoices/0001/media?batch_id=1', headers=H,
                     data={'file': (io.BytesIO(b'%PDF-1.4'), 'a.pdf')}, content_type='multipart/form-data')
    check('api: media upload denied', r.status_code == 403 and r.get_json()['capability'] == 'media.upload')
    r = sarah_c.delete(f"/api/v1/invoices/0001/links/{link_id}?batch_id=1", headers=H)
    check('api: link delete denied', r.status_code == 403 and r.get_json()['capability'] == 'links.delete')
    r = sarah_c.delete('/api/v1/invoices/0001/notes/999?batch_id=1', headers=H)
    check('api: note delete denied', r.status_code == 403 and r.get_json()['capability'] == 'notes.delete')
    body = sarah_c.get('/api/v1/me', headers=H).get_json()
    check('api: /me shows the denied functions as false',
          body['capabilities']['notes.create'] is False and body['capabilities']['media.upload'] is False
          and body['capabilities']['links.create'] is False and body['capabilities']['invoice.edit'] is True)

    # Admin key is never restricted.
    r = admin_c.get('/api/v1/invoices/0001?batch_id=1', headers={'X-API-Key': 'admin-key-789'})
    check('api: admin key still reads', r.status_code in (200, 404))

    # ---------------- reset to defaults ----------------
    set_caps(sarah_id, {'links.create': False})
    reset(sarah_id)
    with app.app_context():
        rows = UserCapability.query.filter_by(user_id=sarah_id).count()
    check('reset removes every override row', rows == 0, str(rows))
    check('after reset everything is allowed again (default)', all(caps_of(sarah_id).values()))

    # ---------------- admin POST presets ----------------
    r = admin_c.post(f'/admin/users/{sarah_id}/permissions', data={'preset': 'none'})
    check('preset "turn off all" works', r.status_code == 302 and not any(caps_of(sarah_id).values()))
    r = admin_c.post(f'/admin/users/{sarah_id}/permissions', data={'preset': 'all'})
    check('preset "allow all" works', r.status_code == 302 and all(caps_of(sarah_id).values()))
    r = admin_c.post(f'/admin/users/{sarah_id}/permissions', data={'preset': 'default'})
    check('preset "reset to defaults" works', r.status_code == 302)
    with app.app_context():
        check('reset preset leaves no rows', UserCapability.query.filter_by(user_id=sarah_id).count() == 0)

    # Other clerk is unaffected by Sarah's settings.
    set_caps(sarah_id, {'links.create': False})
    check('other user unaffected by a change to sarah', caps_of(omar_id)['links.create'] is True)

    # Admin page for a removed/unknown user
    r = admin_c.get('/admin/users/99999/permissions')
    check('unknown user -> 404', r.status_code == 404)

    # ---------------- book average ignores excluded merge sources ----------------
    with app.app_context():
        from app.models import Book
        book = Book(batch_id=1, book_number=77, capacity=50)
        db.session.add(book)
        db.session.flush()
        a = Invoice(batch_id=1, date=date(2026, 10, 20), serial_number='0801', total_amount=Decimal('10.000'),
                    created_by=sarah_id, updated_by=sarah_id, book_id=book.id, book_page=1)
        a.set_amounts([10.0])
        b = Invoice(batch_id=1, date=date(2026, 10, 21), serial_number='0802', total_amount=Decimal('30.000'),
                    created_by=sarah_id, updated_by=sarah_id, book_id=book.id, book_page=2)
        b.set_amounts([30.0])
        c = Invoice(batch_id=1, date=date(2026, 10, 22), serial_number='0803', total_amount=Decimal('100.000'),
                    created_by=sarah_id, updated_by=sarah_id, book_id=book.id, book_page=3)
        c.set_amounts([100.0])
        db.session.add_all([a, b, c])
        db.session.commit()
        ids_book = {'a': a.id, 'b': b.id, 'c': c.id}
    r = admin_c.get('/admin/books/77')
    check('book page loads', r.status_code == 200, str(r.status_code))
    check('book average over 3 counted invoices = 46.667', 'Avg 46.667' in r.get_data(as_text=True))
    r = admin_c.post(f"/invoices/{ids_book['c']}/links?batch_id=1",
                     data={'linked_serial': '0801', 'link_type': 'duplicate', 'amount_action': 'merge',
                           'exclude_from_totals': '1'},
                     headers=XHR)
    check('excluded merge saved on book invoice', r.status_code == 200 and r.get_json().get('success'),
          r.get_data(as_text=True)[:150])
    r = admin_c.get('/admin/books/77')
    check('excluded source does not lower the book average (2 counted invoices)', 'Avg 70.000' in r.get_data(as_text=True))

    print(f'\nALL {len(PASSED)} PERMISSION CHECKS PASSED')


def _raises(fn):
    try:
        fn()
    except ValueError:
        return True
    return False


if __name__ == '__main__':
    main()
