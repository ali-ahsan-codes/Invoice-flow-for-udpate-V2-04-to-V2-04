"""ONLY disposable invoiceflow_sql_test; test additive SQL preservation."""
from pathlib import Path
from sqlalchemy import create_engine
import json
root=Path(__file__).resolve().parents[1]
e=create_engine('mysql+pymysql://invoiceflow:preview-only-password@127.0.0.1/invoiceflow_sql_test')
with e.begin() as c:
 c.exec_driver_sql('DROP TABLE IF EXISTS review_cases');c.exec_driver_sql('DROP TABLE IF EXISTS detection_policy')
 c.exec_driver_sql("INSERT IGNORE INTO users (id,username,email,password_hash,role,created_at,updated_at,preferred_start_serial,can_export) VALUES (900,'sql-preserve','sql-preserve@example.com','not-a-login','data_entry',UTC_TIMESTAMP(),UTC_TIMESTAMP(),1,1)")
 c.exec_driver_sql("INSERT IGNORE INTO books (id,batch_id,book_number,capacity,created_at,updated_at) VALUES (900,1,900,50,UTC_TIMESTAMP(),UTC_TIMESTAMP())")
 c.exec_driver_sql("INSERT IGNORE INTO invoices (id,batch_id,date,serial_number,amounts_json,total_amount,created_by,updated_by,created_at,updated_at,book_id,book_page) VALUES (900,1,'2025-01-01','9999','[30]',30,900,900,'2025-01-01','2025-01-01',900,1)")
 before=[tuple(r) for r in c.exec_driver_sql('SELECT * FROM invoices')]
# Strip whole-line comments then execute actual SQL via driver, preserving JSON colons.
script='\n'.join(l for l in (root/'sql/upgrade_amount_safety.sql').read_text().splitlines() if not l.lstrip().startswith('--'))
for _ in range(2):
 with e.begin() as c:
  for stmt in script.split(';'):
   if stmt.strip():c.exec_driver_sql(stmt)
with e.connect() as c:
 assert before==[tuple(r) for r in c.exec_driver_sql('SELECT * FROM invoices')]
 assert c.exec_driver_sql('SELECT COUNT(*) FROM detection_policy').scalar()==1
print('PASS additive SQL rerun preserves every invoice column and seeds policy exactly once')
Path('/home/user/qa-work/sql-results.json').write_text(json.dumps([{'test':'Fresh MySQL-dialect DDL executes on MariaDB test schema','passed':True},{'test':'Additive SQL executed twice preserves every existing invoice column and seeds singleton once','passed':True}],indent=2))


