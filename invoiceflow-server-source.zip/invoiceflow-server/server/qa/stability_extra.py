"""Regression for read-only snapshots, delayed fetch races and alert persistence."""
import sys,json,re
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from support.demo_app import app
from app.models import AuditLog
from app.extensions import db
from playwright.sync_api import sync_playwright
out=[]
def check(n,c):out.append({'test':n,'passed':bool(c)});print('PASS' if c else 'FAIL',n,flush=True);assert c,n
with app.test_client() as c:
 login=c.get('/auth/login');token=re.search(r'name="csrf_token"[^>]*value="([^"]+)"',login.data.decode()).group(1)
 c.post('/auth/login',data={'username':'admin','password':'Preview@2026','csrf_token':token},follow_redirects=True)
 with c.session_transaction() as s:s['_flashes']=[('success','foreground-message')]
 r=c.get('/dashboard?batch_id=1',headers={'X-Live-Sync':'1'})
 check('Background HTML neither consumes pending flashes nor sets session cookies',r.status_code==200 and not r.headers.getlist('Set-Cookie') and b'foreground-message' not in r.data)
 with c.session_transaction() as s:check('Pending foreground notification stays in the session',s['_flashes']==[('success','foreground-message')])
 for path in ['/live/version?batch_id=1','/invoices/grid-data?batch_id=1&from_date=2026-01-01&to_date=2026-12-31&start_serial=1','/invoices/summary-data?batch_id=1&from_date=2026-01-01&to_date=2026-12-31']:
  reply=c.get(path,headers={'X-Live-Sync':'1'})
  check('Read-only background endpoint never sends session cookie: '+path.split('?')[0],reply.status_code==200 and not reply.headers.getlist('Set-Cookie'))
 r=c.get('/invoices/create?batch_id=1',headers={'X-Live-Sync':'1'})
 check('Missing entry session snapshot is a quiet 409 without redirect or cookie',r.status_code==409 and not r.headers.getlist('Set-Cookie'))
 with c.session_transaction() as s:s.pop('csrf_token',None)
 r=c.get('/dashboard?batch_id=1',headers={'X-Live-Sync':'1'})
 check('Snapshot never delivers newly generated unusable CSRF tokens',r.status_code==409 and r.json['code']=='csrf_session' and not r.headers.getlist('Set-Cookie'))
 c.delete_cookie('session');c.delete_cookie('remember_token');r=c.get('/invoices/create?batch_id=1',headers={'X-Live-Sync':'1'})
 check('Expired-session snapshot returns 401 without loading login or changing cookie',r.status_code==401 and not r.headers.getlist('Set-Cookie'))
BASE='http://127.0.0.1:5000'
with sync_playwright() as p:
 b=p.chromium.launch();ctx=b.new_context(viewport={'width':1440,'height':1000});pg=ctx.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
 pg.goto(BASE+'/auth/login');pg.fill('#username','admin');pg.fill('#password','Preview@2026');pg.click('[type=submit]');pg.wait_for_url('**/dashboard*')
 pg.goto(BASE+'/invoices/start-session?book=3&batch_id=1');pg.locator('#start-session-form [type=submit]').click();pg.wait_for_url('**/invoices/create*')
 pg.evaluate('''window.__originalFetch=window.fetch;
 window.fetch=async function(input,options){
   if(String(input).includes('/invoices/next-serial'))return new Promise(resolve=>{window.__lateSerial=()=>resolve(new Response(JSON.stringify({serial:'0101',page:1}),{status:200,headers:{'Content-Type':'application/json'}}));});
   return window.__originalFetch(input,options);
 };
 window.invoiceFormHandler.syncDateToSerial();void 0;''')
 pg.fill('[name=serial_number]','0108');pg.evaluate('__lateSerial()');pg.wait_for_timeout(150)
 check('Truly delayed serial lookup cannot replace subsequently typed serial',pg.locator('[name=serial_number]').input_value()=='0108')
 pg.evaluate('window.fetch=__originalFetch');pg.locator('.amount-field-input').first.fill('123.450')
 # Submit while a previous session cookie write has not returned: save must queue.
 pg.evaluate('''window.__savedPosts=0;window.fetch=async function(input,options){
 if(String(input).includes('/invoices/update-session'))return new Promise(resolve=>{window.__releaseSession=()=>resolve(new Response('{"success":true}',{status:200}));});
 if(String(input).includes('/invoices/create') && options?.method==='POST'){window.__savedPosts++;return new Response('{"success":false,"error":"Synthetic save blocked"}',{status:400,headers:{'Content-Type':'application/json'}});}
 return __originalFetch(input,options);
 };invoiceFormHandler.syncSessionToServer();void 0;''')
 pg.locator('#invoice-form [type=submit]').click();pg.wait_for_timeout(300)
 check('Foreground invoice save waits for pending session-cookie write',pg.evaluate('__savedPosts===0 && invoiceFormHandler._saving') and pg.locator('.amount-field-input').first.evaluate('(e)=>e.readOnly'))
 saved_date=pg.locator('[name=date]').input_value();pg.locator('.amount-field-input').first.focus();pg.keyboard.press('a');pg.keyboard.press('F7');check('Save-in-flight keyboard shortcuts cannot change draft rows or date',pg.locator('.amount-field-input').count()==1 and pg.locator('[name=date]').input_value()==saved_date)
 pg.evaluate('__releaseSession()');pg.wait_for_timeout(300)
 check('Failed queued save preserves draft and releases controls',pg.evaluate('__savedPosts===1 && !invoiceFormHandler._saving') and pg.locator('.amount-field-input').first.input_value()=='123.450' and not pg.locator('.amount-field-input').first.evaluate('(e)=>e.readOnly'))
 pg.evaluate('window.fetch=__originalFetch')
 # Status context updates independently while the form stays fixed.
 with app.app_context():
  from app.models import Batch
  batch=db.session.get(Batch,1);batch.archived=True;db.session.commit()
 pg.evaluate('InvoiceLive.refresh()');pg.wait_for_timeout(100)
 check('Batch archive status updates beside an untouched invoice draft','Archived' in pg.locator('.batch-context-strip').inner_text() and pg.locator('.amount-field-input').first.input_value()=='123.450')
 with app.app_context():batch=db.session.get(Batch,1);batch.archived=False;db.session.commit()
 # Entire pristine settings form has stable identities and edited values freeze as a set.
 pg.goto(BASE+'/admin/settings?batch_id=1');pg.evaluate('window.__settings=document.querySelector("#settings-form");window.__checkbox=document.querySelector("#media_required")');pg.fill('#number_of_books','123');pg.locator('main').click(position={'x':5,'y':5});pg.evaluate('InvoiceLive.refresh()')
 check('Dirty settings form and event-bound controls retain exact identities',pg.evaluate('__settings===document.querySelector("#settings-form") && __checkbox===document.querySelector("#media_required")') and pg.locator('#number_of_books').input_value()=='123')
 pg.goto(BASE+'/invoices/grid?batch_id=1');pg.wait_for_timeout(500);pg.locator('input[type=date]').first.fill('');pg.locator('main').click(position={'x':5,'y':5});pg.evaluate('InvoiceLive.refresh()');pg.wait_for_timeout(100)
 check('Incomplete report filters do not trigger unsolicited background toasts',pg.locator('.toast').count()==0)
 pg.goto(BASE+'/invoices/1?batch_id=1');pg.wait_for_timeout(300)
 check('Initial page sync uses server revision without nesting main content',pg.locator('main').count()==1 and pg.locator('meta[name=live-revision]').get_attribute('content'))
 for _ in range(4):pg.evaluate('InvoiceLive.refresh()')
 check('Repeated inner updates never nest page or table region wrappers',pg.locator('main').count()==1)
 # Browser gallery upload uses real input and fetch, no physical camera claim.
 pg.goto(BASE+'/media/m/0001?batch_id=1');pg.evaluate('window.__camera=document.getElementById("camera-input");window.__gallery=document.getElementById("gallery-input");window.__cameraButton=document.getElementById("camera-btn")')
 import io
 from PIL import Image
 bio=io.BytesIO();Image.new('RGB',(80,100),'#ccbbdd').save(bio,format='PNG')
 pg.set_input_files('#gallery-input',{'name':'stability-gallery.png','mimeType':'image/png','buffer':bio.getvalue()})
 pg.wait_for_selector('img.attachment-thumb',timeout=12000)
 check('Mobile gallery upload syncs its thumbnail without replacing file controls',pg.evaluate('__camera===document.getElementById("camera-input") && __gallery===document.getElementById("gallery-input") && __cameraButton===document.getElementById("camera-btn")'))
 with app.app_context():
  from app.models import InvoiceMedia
  for media in InvoiceMedia.query.filter_by(file_name='stability-gallery.png').all():
   fp=Path('/home/user/invoiceflow/uploads')/media.file_path
   if fp.exists():fp.unlink()
   db.session.delete(media)
  db.session.commit()
 pg.evaluate('InvoiceLive.refresh()');pg.wait_for_function('!document.querySelector("img.attachment-thumb")')
 check('Remote attachment deletion updates mobile gallery despite selected file state',pg.locator('#media-count-display').inner_text()=='0')
 # expired auth: keep document and field values, no login navigation
 pg.goto(BASE+'/invoices/1/edit?batch_id=1');pg.locator('.amount-field-input').first.fill('77.700');origin=pg.evaluate('performance.timeOrigin');ctx.clear_cookies();pg.evaluate('InvoiceLive.refresh()');pg.wait_for_timeout(200)
 check('Session expiry preserves visible draft without navigation or repeating toasts',pg.locator('.amount-field-input').first.input_value()=='77.700' and pg.evaluate('performance.timeOrigin')==origin and pg.locator('#live-status').inner_text()=='Session ended')
 check('No JavaScript errors across delayed fetch/session tests',not errors)
 b.close()
Path('/home/user/qa-work/stability-extra-results.json').write_text(json.dumps(out,indent=2))


