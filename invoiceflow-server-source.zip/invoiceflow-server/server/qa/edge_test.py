from pathlib import Path
import sys,io,json,math
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from support.demo_app import app
from app.extensions import db
from app.models import User,Invoice,InvoiceMedia,AuditLog
from app.services.invoice_service import create_invoice
from app.realtime import revision
from datetime import date
from PIL import Image
results=[]
def check(name,c):
 results.append({'test':name,'passed':bool(c)});print('PASS' if c else 'FAIL',name,flush=True);assert c,name
with app.app_context():
 app.config['TESTING']=True;app.config['WTF_CSRF_ENABLED']=False
 admin=User.query.filter_by(username='admin').first();clerk=User.query.filter_by(username='sarah').first();key=clerk.api_key;clerk.regenerate_api_key();db.session.commit();headers={'X-API-Key':clerk.api_key}
 c=app.test_client()
 check('API rejects missing key',c.get('/api/v1/me').status_code==401)
 check('API key permits scoped identity',c.get('/api/v1/me',headers=headers).status_code==200)
 check('API list clamps negative limit instead of SQL failure',c.get('/api/v1/invoices?limit=-1',headers=headers).status_code==200)
 check('API list rejects invalid date',c.get('/api/v1/invoices?date=wrong',headers=headers).status_code==400)
 check('API hides other-owner invoice',c.get('/api/v1/invoices/0001',headers=headers).status_code==404)
 check('API next/previous available',c.get('/api/v1/invoices/0002/next',headers=headers).status_code==200 and c.get('/api/v1/invoices/0003/prev',headers=headers).status_code==200)
 bio=io.BytesIO();Image.new('RGB',(80,60),'#845ac5').save(bio,format='PNG');bio.seek(0)
 token=revision();res=c.post('/api/v1/invoices/0002/media',headers=headers,data={'file':(bio,'api-edge.png')});print('API UPLOAD',res.status_code,res.json);check('Actual API multipart upload succeeds and invalidates',res.status_code in [200,201] and revision()!=token)
 check('API upload refuses disallowed extension',c.post('/api/v1/invoices/0002/media',headers=headers,data={'file':(io.BytesIO(b'data'),'bad.exe')}).status_code==400)
 c.post('/auth/login',data={'username':'admin','password':'Preview@2026'})
 check('Settings rejects non-object JSON',c.post('/admin/settings',json=[],headers={'X-Requested-With':'XMLHttpRequest'}).status_code==400)
 check('Desktop upload returns validation error for empty selection',c.post('/media/upload/1?batch_id=1',headers={'X-Requested-With':'XMLHttpRequest'}).status_code==400)
 for val in [float('nan'),float('inf'),-1,10000000]:
  inv,error=create_invoice({'date':date.today(),'serial_number':'edge-invalid','amounts':[val]},admin.id)
  check('Service rejects invalid amount '+str(val),inv is None and bool(error))
 # Ensure zero remains a valid amount.
 inv,error=create_invoice({'date':date.today(),'serial_number':'0101','amounts':[0]},admin.id);check('Zero amount invoice is valid',inv is not None and float(inv.total_amount)==0)
 db.session.delete(inv);db.session.commit()
 c.get('/auth/logout');c.post('/auth/login',data={'username':'sarah','password':'Preview@2026'})
 check('AJAX unauthorized delete returns 403 JSON',c.post('/invoices/1/delete?batch_id=1',headers={'X-Requested-With':'XMLHttpRequest'}).status_code==403)
 check('AJAX admin-only route returns 403 JSON',c.post('/admin/settings',json={},headers={'X-Requested-With':'XMLHttpRequest'}).status_code==403)
 for m in InvoiceMedia.query.filter_by(file_name='api-edge.png').all():
  path=Path('/home/user/invoiceflow/uploads')/m.file_path
  if path.exists():path.unlink()
  db.session.delete(m)
 clerk.api_key=key;db.session.commit()
 Path('edge-results.json').write_text(json.dumps(results,indent=2))


