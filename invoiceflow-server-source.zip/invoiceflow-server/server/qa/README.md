# Recorded QA support

This folder is **not a second application**. Local startup is `../launch.py`/Waitress; production WSGI is `../wsgi.py`.

- `results/`: saved passing workflow, route, mobile and live-sync assertions.
- `fixtures/`: restore-confirmation, maintenance and preview-only import HTML used for safe state captures.
- `support/demo_app.py`: isolated disposable demo database configuration/seeder formerly named `preview.py`. It contains sample-only credentials and must never run against production.
- Python scripts: tests/capture routines used during development. Imports were updated to the relocated helper; some scripts retain sandbox-specific paths (`/home/user`, `screenshots/`) and assume a server at `http://127.0.0.1:5000`. They require adaptation for another environment.

## Safe mobile QR contract test
`python qa/mobile_qr_contract_test.py` is database-free and safe to run from the server root. It exercises the actual server QR builder and verifies that v2 Focus/Auto QR payloads preserve `batch_id`, invoice identity, server URL, and the scan hint; it also checks the web-fallback URL carries its batch selector. The Android unit suite separately checks the client parser and API URL builder.

## Reproduction outline
1. Provision a **disposable** MySQL/MariaDB database and account matching the QA helper, or edit the helper for your isolated test database.
2. Install runtime requirements plus Playwright, requests and Pillow (Pillow is already a runtime dependency). Install Playwright Chromium and its platform dependencies.
3. Seed disposable data with the isolated helper, then start the SHIPPED launcher using DATABASE_URL pointing to that disposable schema, SECRET_KEY and SCHEDULER_ENABLED=False: `python launch.py --no-browser`. The browser evidence for this release was captured against this real entrypoint, not only the demo Flask server.
4. Review paths in the scripts before executing. Run tests from a directory that contains the expected `screenshots/` output folder and fixture paths. The existing scripts are recorded harnesses, not a portable automatic installation test suite.
5. Use the synthetic admin/data-entry accounts declared in the helper. Never point this harness at production: it creates/edits/deletes disposable records and exercises backup operations.
6. Compare newly obtained results with `results/`. The batch release includes rerun browser and backend suites. Some fixture paths intentionally reference the original sandbox; adapt before running elsewhere.

CLI and fallback restore were executed on isolated MariaDB batch-test and MySQL8 test databases. Factory reset, async web restore and physical camera workflows were not executed. Screenshot fixtures are visual evidence only. Refer to `../QA_REPORT.md` and `../BLUEPRINT.md` for exact results and remaining checks.

## New batch suites
`batch_test.py` destroys/rebuilds `invoiceflow_batch_test`; it must never be pointed at production. Run it first, followed by `restore_roundtrip.py`, then `prepare_test.py` (which deliberately trims the same disposable database before testing the preparation helper). `batch_browser.py` operates on the separate preview database and cleans up its sample batches after a successful run. A failed run can leave fixtures requiring manual QA cleanup. `production_smoke.py` expects a temporary Gunicorn on port 5001 and disposable environment credentials. Browser suites share sample IDs and should be run sequentially, not concurrently.

## Amount-safety regression
`detection_test.py` rebuilds invoiceflow_detection_test; `detection_concurrency.py` runs after it. These scripts are destructive only to explicitly disposable test data. `detection_browser.py` uses the separate preview data and changes/restores sample amounts and policy. `sql_upgrade_test.py` uses invoiceflow_sql_test. All have sandbox paths; adapt safely on staging, never production. Current results replace the old release evidence.

## Stability suites
`stability_test.py` checks anonymous login, repeated polling/reconnect, exact editor/main/input DOM identity, dynamic amount rows, manual serial, mobile layout, failed and successful saves, validation and quiet batch help. `stability_extra.py` checks read-only snapshot cookies/flashes, real delayed serial responses, pending session-write/save ordering, save-lock keyboard behavior, stable settings controls, invalid report filters expired-session draft retention, and actual browser gallery upload/remote deletion while keeping file-input identities. They use the disposable preview database; run sequentially with the other browser suites.

## Historical identity tests
Run `batch_controls_test.py`, then `identity_history_test.py` on the disposable batch schema. Tests cover prior corrected keys, owner reuse, raw SQL rejection, CLI/fallback restore, cascade release and concurrent claims. Never run against production.

## Startup repair validation
`startup_test.py` checks visible failures, database selection, BOM .env, independent cwd, port conflict, password redaction, no startup DDL and missing guard refusal. `mysql_runtime_test.py` explicitly provisions disposable runtime grants and tests actual MySQL8 definer procedures/triggers with no runtime DDL/reservation writes. Both must never be pointed at production. `history_browser.py` edits and deletes synthetic invoices through the browser, validating historical duplicate drafts/reuse. QA_DATABASE_URL can redirect the selected backend suites to a disposable second-engine schema. Actual Windows batch execution remains a target-PC check.


