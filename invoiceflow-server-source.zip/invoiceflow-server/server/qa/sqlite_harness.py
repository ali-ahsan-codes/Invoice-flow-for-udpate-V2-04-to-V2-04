"""Local test harness ONLY: runs the app on SQLite when no MySQL server is available.

Runs the real app code against SQLite. Patches just the MySQL-only startup gates
(URL validation and information_schema / trigger verification). Never used for production.
"""

import datetime
import os
import re
import sys
import tempfile

SERVER = os.environ.get('SERVER_DIR') or os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, SERVER)
os.chdir(SERVER)

import app.startup as startup  # noqa: E402
import app.utils.db_utils as db_utils  # noqa: E402

startup.validate_settings = lambda settings: None


def _create_and_seed():
    """Stands in for verify_schema(): create tables and seed the rows the app expects."""
    from app.extensions import db
    from app.models import Batch
    from app.detection import DetectionPolicy
    from app.realtime import LiveRevision
    db.create_all()
    if not db.session.get(Batch, 1):
        db.session.add(Batch(id=1, name='Batch 1', numbering_mode='repeat',
                             start_book=1, start_serial=1, archived=False))
    if not db.session.get(DetectionPolicy, 1):
        db.session.add(DetectionPolicy(id=1, manual_enabled=True, automatic_enabled=True, version=1))
    if not db.session.get(LiveRevision, 1):
        db.session.add(LiveRevision(id=1, token='x' * 32))
    db.session.commit()


db_utils.verify_schema = _create_and_seed

from sqlalchemy import event  # noqa: E402
from sqlalchemy.engine import Engine  # noqa: E402
from config import Config  # noqa: E402

TMP = tempfile.mkdtemp(prefix='ifh_')


@event.listens_for(Engine, 'connect')
def _sqlite_regexp(dbapi_conn, _rec):
    if type(dbapi_conn).__module__.startswith('sqlite3'):
        dbapi_conn.create_function(
            'regexp', 2,
            lambda pat, val: 1 if val is not None and re.search(pat, str(val)) else 0)
        # MySQL-compatible helpers used by reporting queries (summary/monthly totals).
        def _concat(*parts):
            return None if any(p is None for p in parts) else ''.join(str(p) for p in parts)
        def _lpad(val, length, pad):
            if val is None:
                return None
            text = str(val)
            return text[:length] if len(text) >= length else (str(pad) * length + text)[-length:]
        dbapi_conn.create_function('concat', -1, _concat)
        dbapi_conn.create_function('lpad', 3, _lpad)
        def _date_format(value, fmt):
            # MySQL DATE_FORMAT subset used by analytics ('%Y-%m', '%Y-%m-%d').
            if value is None:
                return None
            text = str(value)[:10]
            return datetime.date.fromisoformat(text).strftime(fmt)
        dbapi_conn.create_function('date_format', 2, _date_format)
        def _dayname(value):
            if value is None:
                return None
            return datetime.date.fromisoformat(str(value)[:10]).strftime('%A')
        dbapi_conn.create_function('dayname', 1, _dayname)
        def _hour(value):
            if value is None:
                return None
            return datetime.datetime.fromisoformat(str(value)).hour
        dbapi_conn.create_function('hour', 1, _hour)


class TestCfg(Config):
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(TMP, 'test.db')
    SQLALCHEMY_ENGINE_OPTIONS = {}
    SECRET_KEY = 'test-secret-key-for-local-harness-only-123456'
    SCHEDULER_ENABLED = False
    TESTING = True
    WTF_CSRF_ENABLED = False
    UPLOAD_FOLDER = os.path.join(TMP, 'uploads')
    BACKUP_DIR = os.path.join(TMP, 'backups')
    SESSION_COOKIE_SECURE = False


def make_app():
    from app import create_app
    return create_app(TestCfg)
