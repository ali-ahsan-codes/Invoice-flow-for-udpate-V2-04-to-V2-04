"""Administrator exports cover every batch; other users stay on the current batch.

Covers every export type on /import-export/export (all, books, daily, monthly, by_date),
the file names, and the batch column. Non-administrator exports must keep the current-batch scope.

Runs through the real Flask app on a temporary SQLite database (sqlite_harness.py).
Run: python qa/admin_export_all_batches_test.py
"""
import csv
import io
import os
import sys
from datetime import date
from decimal import Decimal

sys.path.insert(0, os.path.dirname(__file__))
import sqlite_harness as h  # noqa: E402

app = h.make_app()
app.config['TESTING'] = True

from app.extensions import db  # noqa: E402
from app.models import User, Batch, Book, Invoice  # noqa: E402

PASSED = []


def check(label, cond, extra=''):
    if not cond:
        raise AssertionError(f'FAIL: {label} {extra}')
    PASSED.append(label)
    print('PASS', label)


def setup():
    with app.app_context():
        admin = User(username='admin', email='admin@x.test', role='admin')
        admin.set_password('Admin@12345')
        admin.api_key = 'admin-key-789'
        sarah = User(username='sarah', email='sarah@x.test', role='data_entry')
        sarah.set_password('Sarah@12345')
        sarah.api_key = 'sarah-key-123'
        db.session.add_all([admin, sarah])
        db.session.flush()
        b2 = Batch(id=2, name='Batch Two', numbering_mode='repeat', start_book=1,
                   start_serial=101, archived=False)
        db.session.add(b2)
        db.session.flush()
        book1 = Book(batch_id=1, book_number=1, capacity=50)
        book2 = Book(batch_id=2, book_number=1, capacity=50)
        db.session.add_all([book1, book2])
        db.session.flush()
        b1 = db.session.get(Batch, 1)

        def mk(batch, book, serial, day, owner):
            inv = Invoice(batch_id=batch.id, book_id=book.id, book_page=5,
                          date=date(2026, 10, day), serial_number=serial,
                          total_amount=Decimal('10.000'), created_by=owner.id, updated_by=owner.id)
            inv.set_amounts([10.0])
            db.session.add(inv)
            db.session.flush()

        mk(b1, book1, '0005', 15, sarah)   # batch 1
        mk(b2, book2, '0005', 14, sarah)   # batch 2, different date
        mk(b2, book2, '0009', 16, sarah)   # batch 2
        db.session.commit()


def login(client, username, password):
    r = client.post('/auth/login', data={'username': username, 'password': password})
    assert r.status_code in (200, 302), r.status_code


def get_csv(client, query):
    r = client.get('/import-export/export?' + query)
    assert r.status_code == 200, (query, r.status_code, r.get_data(as_text=True)[:300])
    return r, list(csv.reader(io.StringIO(r.get_data(as_text=True).lstrip('\ufeff'))))


def total_row(rows):
    return next(r for r in rows if 'TOTAL' in r[:2])


def main():
    setup()
    admin_c = app.test_client()
    login(admin_c, 'admin', 'Admin@12345')
    sarah_c = app.test_client()
    login(sarah_c, 'sarah', 'Sarah@12345')

    # Admin: every-batch export on the batch 1 screen
    r, rows = get_csv(admin_c, 'type=all&batch_id=1')
    data = [x for x in rows[1:] if x]
    batch_col = {x[1] for x in data}
    check('admin all-invoices export has rows from every batch', batch_col == {'1', '2'}, str(batch_col))
    check('admin all-invoices export has all 3 invoices', len(data) == 3, str(len(data)))
    check('admin all-invoices file is named all_batches_', 'all_batches_' in r.headers['Content-Disposition'],
          r.headers['Content-Disposition'])

    r, rows = get_csv(admin_c, 'type=by_date&from_date=2026-10-14&to_date=2026-10-16&batch_id=1')
    t = total_row(rows)
    check('admin date summary counts all batches', t[1] == '3' and t[2] == '30.000', str(t))
    check('admin date summary file is named all_batches_', 'all_batches_' in r.headers['Content-Disposition'])
    check('admin date summary has no stamped batch column', rows[0][0] == 'Invoice Date', str(rows[0]))

    r, rows = get_csv(admin_c, 'type=daily&from_date=2026-10-14&to_date=2026-10-16&batch_id=1')
    total = sum(float(x[1]) for x in rows[1:] if x)
    check('admin daily totals include batch 2 days', abs(total - 30.0) < 1e-6, str(rows))

    r, rows = get_csv(admin_c, 'type=monthly&month=2026-10&batch_id=1')
    total = sum(float(x[1]) for x in rows[1:] if x)
    check('admin monthly total includes every batch', abs(total - 30.0) < 1e-6, str(rows))

    r, rows = get_csv(admin_c, 'type=books&batch_id=1')
    check('admin books export lists both batches', {x[0] for x in rows[1:] if x} == {'1', '2'}, str(rows))

    # Data-entry user: unchanged, current batch only
    r, rows = get_csv(sarah_c, 'type=all&batch_id=1')
    data = [x for x in rows[1:] if x]
    check('data-entry export stays on the current batch', len(data) == 1 and data[0][1] == '1', str(data))
    check('data-entry export keeps batch_ file name', 'batch_1_' in r.headers['Content-Disposition'])

    r, rows = get_csv(sarah_c, 'type=by_date&from_date=2026-10-14&to_date=2026-10-16&batch_id=1')
    t = total_row(rows)
    # data-entry files carry a Batch ID column first, so the TOTAL row is shifted by one
    check('data-entry date summary stays on the current batch', t[2] == '1' and t[3] == '10.000', str(t))
    check('data-entry date summary keeps batch_ file name', 'batch_1_' in r.headers['Content-Disposition'])

    print(f'\nALL {len(PASSED)} ADMIN EXPORT ALL-BATCH CHECKS PASSED')


if __name__ == '__main__':
    main()
