"""Admin search covers every batch and labels each result with its batch.

Covers the web invoice list (serial, book, date), the AJAX search endpoint, the mobile API
search, and the regression cases: data-entry users stay in their batch, admin browsing without a
query stays in the current batch, and the link lookup stays inside one batch.

Runs through the real Flask app on a temporary SQLite database (sqlite_harness.py).
Run: python qa/admin_all_batch_search_test.py
"""
import os
import sys
from datetime import date
from decimal import Decimal

sys.path.insert(0, os.path.dirname(__file__))
import sqlite_harness as h  # noqa: E402

app = h.make_app()
app.config['TESTING'] = True

from app.extensions import db  # noqa: E402
from app.models import User, Batch, Book, Invoice  # noqa: E402

PASSED = []


def check(label, cond, extra=''):
    if not cond:
        raise AssertionError(f'FAIL: {label} {extra}')
    PASSED.append(label)
    print('PASS', label)


def setup():
    with app.app_context():
        admin = User(username='admin', email='admin@x.test', role='admin')
        admin.set_password('Admin@12345')
        admin.api_key = 'admin-key-789'
        sarah = User(username='sarah', email='sarah@x.test', role='data_entry')
        sarah.set_password('Sarah@12345')
        sarah.api_key = 'sarah-key-123'
        db.session.add_all([admin, sarah])
        db.session.flush()
        b2 = Batch(id=2, name='Batch Two', numbering_mode='repeat', start_book=1,
                   start_serial=101, archived=False)
        db.session.add(b2)
        db.session.flush()
        book1 = Book(batch_id=1, book_number=1, capacity=50)
        book2 = Book(batch_id=2, book_number=1, capacity=50)
        db.session.add_all([book1, book2])
        db.session.flush()

        def mk(batch, book, serial, day, owner):
            inv = Invoice(batch_id=batch.id, book_id=book.id, book_page=5,
                          date=date(2026, 10, day), serial_number=serial,
                          total_amount=Decimal('10.000'), created_by=owner.id, updated_by=owner.id)
            inv.set_amounts([10.0])
            db.session.add(inv)
            db.session.flush()
            return inv.id

        ids = {
            'b1_0005': mk(db.session.get(Batch, 1), book1, '0005', 15, sarah),
            'b2_0005': mk(b2, book2, '0005', 14, sarah),
            'b2_0009': mk(b2, book2, '0009', 16, sarah),
        }
        db.session.commit()
        return ids


def login(client, username, password):
    r = client.post('/auth/login', data={'username': username, 'password': password})
    assert r.status_code in (200, 302), r.status_code


def main():
    ids = setup()
    admin_c = app.test_client()
    login(admin_c, 'admin', 'Admin@12345')
    sarah_c = app.test_client()
    login(sarah_c, 'sarah', 'Sarah@12345')

    # 1) Admin serial search from batch 1 finds the batch 2 invoice too, labelled.
    r = admin_c.get('/invoices/?batch_id=1&search_type=serial&query=0005')
    body = r.get_data(as_text=True)
    check('admin serial search returns 200', r.status_code == 200)
    check('admin serial search shows batch 1 match', f"/invoices/{ids['b1_0005']}" in body)
    check('admin serial search shows batch 2 match without switching', f"/invoices/{ids['b2_0005']}" in body)
    check('admin results carry a batch label', 'data-batch-label="2"' in body and 'Batch Two' in body)
    check('admin sees the all-batches banner', 'id="search-all-batches"' in body)

    # 2) Batch-only match from the other batch.
    body = admin_c.get('/invoices/?batch_id=1&search_type=serial&query=0009').get_data(as_text=True)
    check('admin finds a batch 2 only serial from batch 1 view', f"/invoices/{ids['b2_0009']}" in body)

    # 3) Book search covers all batches (book 1 exists in both).
    body = admin_c.get('/invoices/?batch_id=1&search_type=book&query=1').get_data(as_text=True)
    check('admin book search finds both batches',
          f"/invoices/{ids['b1_0005']}" in body and f"/invoices/{ids['b2_0009']}" in body)

    # 4) Admin browsing without a query stays in the current batch.
    body = admin_c.get('/invoices/?batch_id=1').get_data(as_text=True)
    check('admin browse without query stays in batch 1',
          f"/invoices/{ids['b1_0005']}" in body and f"/invoices/{ids['b2_0009']}" not in body)
    check('admin browse without query has no all-batches banner', 'id="search-all-batches"' not in body)

    # 5) Data entry user is still limited to their batch.
    body = sarah_c.get('/invoices/?batch_id=1&search_type=serial&query=0005').get_data(as_text=True)
    check('data entry search stays in batch 1', f"/invoices/{ids['b2_0005']}" not in body
          and f"/invoices/{ids['b1_0005']}" in body)
    check('data entry sees no all-batches banner', 'id="search-all-batches"' not in body)

    # 6) AJAX search endpoint: all batches for admin, each row carries batch_name.
    r = admin_c.get('/invoices/search?query=0005&search_type=serial',
                    headers={'X-Requested-With': 'XMLHttpRequest'})
    data = r.get_json()
    names = sorted((item['batch_id'], item['batch_name']) for item in data['results'])
    check('AJAX admin search returns both batches', names == [(1, 'Batch 1'), (2, 'Batch Two')], str(names))

    r = sarah_c.get('/invoices/search?query=0005&search_type=serial&batch_id=1',
                    headers={'X-Requested-With': 'XMLHttpRequest'})
    check('AJAX data entry search is not cross-batch by default',
          all(item['batch_id'] == 1 for item in r.get_json()['results']))

    # 7) Mobile API: admin search ignores batch selection and returns batch labels.
    api = app.test_client()
    r = api.get('/api/v1/invoices?q=0005', headers={'X-API-Key': 'admin-key-789'})
    payload = r.get_json()
    check('mobile admin search returns 200', r.status_code == 200, str(r.status_code))
    got = sorted(item['batch_id'] for item in payload['invoices'])
    check('mobile admin search returns both batches', got == [1, 2], str(got))
    check('mobile results include batch_name',
          all(item.get('batch_name') for item in payload['invoices']))

    r = api.get('/api/v1/invoices?q=0005&batch_id=1', headers={'X-API-Key': 'sarah-key-123'})
    got = sorted(item['batch_id'] for item in r.get_json()['invoices'])
    check('mobile data entry search stays in batch 1', got == [1], str(got))

    # 8) Link lookup stays inside the viewed batch (linking across batches is not allowed).
    r = admin_c.get('/invoices/link-lookup?batch_id=1&serial=0009&current=0')
    check('link lookup does not find a batch 2 invoice from batch 1',
          r.status_code in (400, 404) or r.get_json().get('found') is False, str(r.status_code))

    print(f'\nALL {len(PASSED)} ADMIN ALL-BATCH SEARCH CHECKS PASSED')


if __name__ == '__main__':
    main()
