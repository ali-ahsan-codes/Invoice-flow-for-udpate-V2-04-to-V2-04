from playwright.sync_api import sync_playwright
from pathlib import Path
import json
ROOT=Path('/home/user/qa-work/screenshots');BASE='http://127.0.0.1:5000'
routes=[('dashboard','/dashboard'),('invoices','/invoices/'),('start-session','/invoices/start-session'),('invoice-detail','/invoices/1'),('invoice-edit','/invoices/1/edit'),('grid','/invoices/grid'),('calendar','/invoices/calendar'),('summary','/invoices/summary'),('profile','/auth/profile'),('change-password','/auth/change-password'),('register','/auth/register'),('user-edit','/admin/users/2/edit'),('users','/admin/users'),('books','/admin/books'),('book-detail','/admin/books/2'),('backups','/backup/'),('import-export','/import-export/'),('import-legacy','/import-export/import-legacy'),('settings','/admin/settings'),('audit-log','/admin/audit-log'),('analytics','/admin/analytics/'),('scan','/media/scan'),('upload','/media/upload/1'),('mobile-scan','/media/m/0001'),('mobile-notfound','/media/m/9999'),('qr-sheet','/media/qr-sheet'),('batches','/batches/'),('amount-safety','/admin/review/settings'),('flagged-review','/admin/review/')]
with sync_playwright() as p:
 b=p.chromium.launch(); page=b.new_page(viewport={'width':1440,'height':1000},reduced_motion='reduce');errors=[];bad=[];result=[]
 page.on('pageerror',lambda e:errors.append(str(e)));page.on('response',lambda r:bad.append({'status':r.status,'url':r.url}) if r.status>=400 else None)
 page.goto(BASE+'/auth/login');page.screenshot(path=str(ROOT/'01-login.png'),full_page=True);page.fill('#username','admin');page.fill('#password','Preview@2026');page.click('[type=submit]');page.wait_for_url('**/dashboard*')
 for i,(name,path) in enumerate(routes,3):
  errors.clear();bad.clear();r=page.goto(BASE+path);page.wait_for_timeout(650);page.screenshot(path=str(ROOT/f'{i:02d}-{name}.png'),full_page=True)
  result.append({'name':name,'path':path,'status':r.status,'final_url':page.url,'js_errors':list(errors),'http_errors':list(bad),'overflow':page.evaluate('document.documentElement.scrollWidth > innerWidth')});print(json.dumps(result[-1]))
 b.close()
Path('/home/user/qa-work/screen-audit.json').write_text(json.dumps(result,indent=2))


