"""Credential-safe setup report; diagnosis does not migrate or rewrite invoices."""
import importlib.util
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import html

ROOT=Path(__file__).resolve().parent

def main():
    os.chdir(ROOT)
    out=[]
    def record(name,passed,detail):
        out.append({'test':name,'passed':bool(passed),'detail':detail})
        print(('PASS ' if passed else 'FAIL ')+name+': '+detail,flush=True)
    record('Python',sys.version_info >= (3,11),sys.version.split()[0]+'; requires Python 3.11+; tested on 3.13')
    missing=[]
    for module,dist in [('flask','Flask'),('flask_sqlalchemy','Flask-SQLAlchemy'),('flask_login','Flask-Login'),('flask_bcrypt','Flask-Bcrypt'),('flask_wtf','Flask-WTF'),('pymysql','PyMySQL'),('cryptography','cryptography'),('apscheduler','APScheduler'),('dotenv','python-dotenv'),('waitress','waitress'),('PIL','Pillow'),('qrcode','qrcode'),('email_validator','email-validator')]:
        ok=importlib.util.find_spec(module) is not None
        if not ok:missing.append(module)
        record('Library: '+dist,ok,importlib.metadata.version(dist) if ok else 'Install requirements.txt in the same interpreter/virtual environment.')
    record('Application files',(ROOT/'app/templates/auth/login.html').is_file() and (ROOT/'app/static/css/luxe.css').is_file(),'Extract the entire invoiceflow folder; do not run directly inside the ZIP.')
    if not missing:
        from app.startup import create_configured_app,explain_error
        # Never let diagnostics start schedules or migrate.
        os.environ['SCHEDULER_ENABLED']='False'
        import logging
        logging.getLogger('app.utils.db_utils').disabled=True
        try:
            app=create_configured_app()
            record('Configured database and schema',True,'Connection, reservation procedure/triggers and required schema verified without DDL.')
            response=app.test_client().get('/auth/login')
            record('Login page',response.status_code==200,f'HTTP {response.status_code}')
        except Exception as exc:
            record('Configured database and schema',False,explain_error(exc))
    else:
        record('Database/login self-check',False,'Not attempted until dependencies are installed.')
    folder=ROOT/'logs';folder.mkdir(exist_ok=True)
    (folder/'diagnostic-report.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    style='body{font:16px/1.65 system-ui;background:#f5f0fc;color:#2d2340;margin:0;padding:24px}main{max-width:1000px;margin:auto}article{background:white;border:1px solid #e8ddf6;border-radius:14px;padding:14px 20px;margin:12px 0}h1{color:#744bbb}.ok{color:#23765b}.fail{color:#b42d53}p{overflow-wrap:anywhere}'
    cards=''.join(f'<article><strong class="{"ok" if x["passed"] else "fail"}">{"PASS" if x["passed"] else "FAIL"} · {html.escape(x["test"])}</strong><p>{html.escape(x["detail"])}</p></article>' for x in out)
    (folder/'diagnostic-report.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>InvoiceFlow setup diagnosis</title><style>'+style+'</style><main><h1>InvoiceFlow · Setup diagnosis</h1><p>This check does not upgrade the schema, reset data or reveal database credentials.</p>'+cards+'</main></html>',encoding='utf-8')
    print('Report saved to logs/diagnostic-report.html')
    return 0 if all(x['passed'] for x in out) else 1

if __name__=='__main__':raise SystemExit(main())


