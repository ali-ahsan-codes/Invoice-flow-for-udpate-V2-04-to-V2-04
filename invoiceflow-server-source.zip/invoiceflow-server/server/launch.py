"""Visible cross-platform launcher: python launch.py [--no-browser] [--check]."""
import argparse
import os
import sys
import logging
import secrets
import threading
import time
import webbrowser
from pathlib import Path
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='Check configured app and login page, without binding a port.')
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    os.chdir(ROOT)
    logs = ROOT / 'logs'
    logs.mkdir(exist_ok=True)
    # Do NOT log tracebacks containing DB URLs or SQL parameters.
    logging.getLogger('app.utils.db_utils').disabled = True
    try:
        from app.startup import create_configured_app, explain_error
        app = create_configured_app()
        if args.check:
            response = app.test_client().get('/auth/login')
            if response.status_code != 200:
                raise RuntimeError(f'Login self-check returned HTTP {response.status_code}.')
            print('PASS: database, schema guards, libraries and login page are ready.', flush=True)
            return 0
        host = os.environ.get('FLASK_HOST', '0.0.0.0')
        port = int(os.environ.get('FLASK_PORT', '5000'))
        if not 1 <= port <= 65535: raise RuntimeError('FLASK_PORT must be between 1 and 65535.')
        from waitress import create_server
        server = create_server(app, host=host, port=port, threads=4)
        token = secrets.token_urlsafe(24)
        app.add_url_rule('/_launcher-ready/'+token, '_launcher_ready', lambda: ('InvoiceFlow ready',200))
        if not args.no_browser:
            def open_when_ready():
                for attempt in range(30):
                    try:
                        with urlopen(f'http://127.0.0.1:{port}/_launcher-ready/{token}', timeout=1) as response:
                            if response.read() == b'InvoiceFlow ready':
                                webbrowser.open(f'http://127.0.0.1:{port}/auth/login'); return
                    except Exception: time.sleep(0.25)
                print('Browser could not be opened automatically; use the address above.', flush=True)
            threading.Thread(target=open_when_ready, daemon=True).start()
        print(f'InvoiceFlow is running: http://127.0.0.1:{port}/auth/login', flush=True)
        print('Keep this window open. Press Ctrl+C to stop.', flush=True)
        server.run()
        return 0
    except KeyboardInterrupt:
        print('\nInvoiceFlow stopped.'); return 0
    except Exception as exc:
        try:
            from app.startup import explain_error
            message = explain_error(exc)
        except Exception:
            message = 'Python dependencies are missing. Run Setup InvoiceFlow.bat or pip install -r requirements.txt.'
        if isinstance(exc, OSError) and getattr(exc,'errno',None) in (98,10048):
            message = 'Port is already in use. Stop the existing server or set another FLASK_PORT in .env. No unrelated page was opened.'
        print('\nSTARTUP FAILED\n'+message, file=sys.stderr, flush=True)
        print('Open INSTALLATION-GUIDE.html and run python diagnose.py. Details: logs/startup.log', file=sys.stderr)
        from datetime import datetime
        with (logs/'startup.log').open('a',encoding='utf-8') as f:
            f.write(f'{datetime.now().isoformat()} {message}\n')
        return 1

if __name__ == '__main__':
    raise SystemExit(main())


