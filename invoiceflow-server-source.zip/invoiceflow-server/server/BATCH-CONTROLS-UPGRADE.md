# InvoiceFlow upgrade contract

## Batch controls and historical identity reservations · 9 October 2026

**This release requires a database upgrade**, even if amount safety is already installed.

| Batch state | Normal users | Administrators |
|---|---|---|
| Open | Usual authorized entry and viewing | Full access |
| Locked or archived | Read-only; no invoice/book/media mutations | Can enter and correct records |
| Hidden | Not listed or accessible by direct link/API | Visible and editable |

Administrators have View, Lock/Unlock, Hide/Unhide and Archive/Unarchive controls. States are independent and reversible; unarchive does not silently unlock/unhide. Archiving requires verification. Permission changes sync without resetting typed fields: a remote lock disables saves; a hidden workspace preserves the local draft with an access notice.

**Identity rule:** the same invoice date + numeric serial is reserved globally across all batches and states. Leading zeros are ignored. Every date/serial combination used by an invoice remains owned by that invoice, even after corrections. Only deleting that invoice releases all its combinations. Administrators cannot override this rule. An invoice can return to its own historical combination. Different dates can use the same serial in different batches, provided neither combination is reserved; the existing within-batch physical-page uniqueness still applies. CSV rename/skip/overwrite cannot evade another invoice's reservation.

### Additive schema and enforcement
- `batches.locked` and `batches.hidden`: non-null Boolean flags, default false.
- `invoices.serial_numeric`: persisted generated BIGINT, unsigned numeric cast of the preserved serial string.
- `uq_date_serial_numeric`: global unique index on current date/numeric serial; positive ASCII numeric serial check (1 through 2147483647).
- `invoice_identity_reservations`: composite primary key `(date, serial_numeric)`, owning `invoice_id` FK with ON DELETE CASCADE and invoice lookup index. No ownership transfer on correction.
- `invoices_reserve_ai` and `invoices_reserve_au`: AFTER INSERT/UPDATE database triggers claim keys transactionally. Conflicting ownership raises `INVOICE_IDENTITY_RESERVED` and rolls back the statement. Unique-key locking protects simultaneous claims, including ordinary raw SQL writes. App services check reservations first for readable errors.
- The reservation table is internal: never manually update/truncate/delete it. A privileged DBA can disable database protections; direct destructive schema operations are not an application permission boundary.
- Current and historical keys are included in CLI and fallback backups. Restore child-table ordering and computed-column exclusion are handled. Replacing the database with an older backup necessarily restores that backup's historical state; do not restore partial invoice-only dumps.

### Offline upgrade procedure (existing installation)
1. Finish/save drafts. Stop the application, scheduler and **all other writers**, including direct SQL clients. Back up the full database, uploaded files, configuration and matching source. Rehearse on a staging copy of the exact target server version.
2. In Workbench select the intended schema and run `sql/preflight_batch_controls.sql`. Both invalid-serial and duplicate-date/numeric-serial result sets must be empty. Conflicts report original IDs; the migration never deletes, renumbers or rewrites them. Resolve legitimate corrections manually with the data owner before retrying. Do not run fresh-install SQL over existing data.
3. Replace source while retaining `.env` and uploads. Install `requirements.txt`. Set `DATABASE_URL` to the intended schema, then run `python upgrade_database.py` while offline. Normal development uses `DATABASE_URL` too; any existing `DEV_DATABASE_URL` explicitly overrides it only for development, so align/remove that override. Offline schema account needs authorized CREATE/ALTER/INDEX/REFERENCES/TRIGGER/CREATE ROUTINE/ALTER ROUTINE and metadata privileges (MySQL binary logging may require DBA authorization); use a least-privilege runtime account after controlled upgrades where appropriate. MySQL DDL is not rollback-safe: a failure may leave additive changes; keep offline, inspect the error and recover from the matching backup if needed.
4. Run the verification statements in the preflight SQL comments. Confirm both reservation triggers and zero missing current reservations; reconcile original invoice/book IDs, dates, serial strings, amounts, counts, timestamps, media and audit rows.
5. Verify admin and normal-user permissions, corrections, historical duplicate rejection, deletion/reuse and a complete backup/restore in staging. Restart the application and reopen pages once for the new assets. Preserve original 100 books; `prepare_batches.py` remains the separate guarded helper for preparing an empty repeated-number Batch 2.

**Historical boundary:** at upgrade, all existing invoices' current keys are reserved. Older date/serial values corrected before this feature was installed cannot be reliably reconstructed and are not claimed. From installation onward, every successfully committed key is retained until invoice deletion. Rolled-back writes do not reserve keys.

New installations also run `python upgrade_database.py` after database/config setup and before entry. The fresh SQL schema alone is not sufficient: the Python migration installs/verifies the triggers. Your exact MySQL/Workbench installation must be validated in staging; this release was exercised on MySQL 8.4.7 and MariaDB on Linux, not physical Windows/Workbench.

## Startup repair release
Read `INSTALLATION-GUIDE.html` for the authoritative setup/recovery steps. New tools: `Setup InvoiceFlow.bat`, `Diagnose InvoiceFlow.bat`, `launch.py`, `diagnose.py`, `configure.py`. Normal startup never migrates. Run `upgrade_database.py` offline with authorized migration privileges before diagnosis/launch. Verification uses a parameterless SQL SECURITY DEFINER procedure (`invoiceflow_verify_identity_guards`); runtime requires EXECUTE, not TRIGGER privileges. Runtime should have SELECT only on reservation rows. PyMySQL[rsa] supports MySQL caching-SHA2 authentication. Existing admin credentials are not reapplied from legacy config during startup.


