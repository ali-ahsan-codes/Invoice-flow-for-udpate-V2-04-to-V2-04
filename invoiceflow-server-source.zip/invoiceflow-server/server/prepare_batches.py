"""Offline upgrade/checklist helper. Backup FIRST. Does not archive automatically."""
import os
from dotenv import load_dotenv
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '.env'), encoding='utf-8-sig')
if not os.environ.get('DATABASE_URL'): raise RuntimeError('DATABASE_URL is required')
from app import create_app
from app.extensions import db
from app.models import Batch, Book, Invoice
from config import Config
class MigrationConfig(Config):
    SCHEDULER_ENABLED=False
app=create_app(MigrationConfig, upgrade_schema=True)
with app.app_context():
    books=Book.query.filter_by(batch_id=1).order_by(Book.book_number).all()
    if len(books)!=100:
        raise RuntimeError(f'Expected 100 existing Batch 1 books, found {len(books)}. Review configuration; nothing was fabricated.')
    if Batch.query.count()==1:
        b=Batch(name='Batch 2',numbering_mode='repeat',start_book=1,start_serial=1)
        db.session.add(b);db.session.flush()
        for book in books:
            db.session.add(Book(batch_id=b.id,book_number=book.book_number,capacity=book.capacity,assigned_user_id=book.assigned_user_id))
        db.session.commit()
    print('Batch 1 records:',Invoice.query.filter_by(batch_id=1).count())
    print('Batch 1 books:',len(books))
    if not Batch.query.filter_by(name='Batch 2').first():
        raise RuntimeError('Existing batches found but none named Batch 2. Review in Batches; no new range was guessed.')
    print('Batch 2 is ready. Verify records/discrepancies and archive Batch 1 from Batches. No existing IDs or attachments changed.')


