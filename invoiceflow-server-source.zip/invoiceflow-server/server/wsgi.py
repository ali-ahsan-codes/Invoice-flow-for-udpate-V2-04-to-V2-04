"""Production WSGI entrypoint; migrations run offline before workers start."""
import os
from dotenv import load_dotenv
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '.env'), encoding='utf-8-sig')
if not os.environ.get('SECRET_KEY') or len(os.environ['SECRET_KEY']) < 32:
    raise RuntimeError('Set a random SECRET_KEY of at least 32 characters.')
if not os.environ.get('DATABASE_URL'):
    raise RuntimeError('Set DATABASE_URL for the production database.')
from app import create_app
from config import ProductionConfig
app = create_app(ProductionConfig)


