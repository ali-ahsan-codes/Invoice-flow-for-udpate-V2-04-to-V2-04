"""Local entrypoint. Same configured app used by diagnosis and desktop launcher."""
import os
from app.startup import create_configured_app
app = create_configured_app()

if __name__ == '__main__':
    # Waitress is cross-platform, with stable logging and no development reloader.
    from waitress import serve
    host = os.environ.get('FLASK_HOST', '0.0.0.0')
    port = int(os.environ.get('FLASK_PORT', '5000'))
    print(f'InvoiceFlow starting on http://127.0.0.1:{port}', flush=True)
    serve(app, host=host, port=port, threads=4)


