# InvoiceFlow — startup repair release QA report

**Date:** 9 October 2026. **Engines:** MySQL 8.4.7 and MariaDB. **Runtime:** Python 3.13 / Waitress local launcher, Gunicorn production smoke. **Browser:** Playwright Chromium, 1440×1000 desktop and 390×844 mobile. Synthetic disposable data only; customer database/configuration were not accessed.

## Outcome
**564 passing recorded behavior checks**, plus log-only permission/backup checks. **58 audited routes** (29 desktop, 29 mobile), separate login/entry/dialog/state/setup captures, **122 fresh PNG screenshots**. Audits show no page JavaScript exceptions or horizontal overflow. Missing-serial routes intentionally return404. One preparation record is a completion marker rather than a separate assertion.

| Evidence | Passing records |
|---|---:|
| `batch-browser-results.json` | 16 |
| `batch-controls-browser-results.json` | 14 |
| `batch-controls-results.json` | 72 |
| `batch-results.json` | 41 |
| `clean-install-results.json` | 2 |
| `detection-browser-results.json` | 12 |
| `detection-concurrency-results.json` | 2 |
| `detection-results.json` | 47 |
| `edge-results.json` | 17 |
| `guide-diagnostic-results.json` | 6 |
| `history-browser-results.json` | 7 |
| `identity-history-results.json` | 16 |
| `live-extra-results.json` | 8 |
| `live-test-results.json` | 17 |
| `modal-results.json` | 43 |
| `mysql-concurrency-results.json` | 2 |
| `mysql-controls-results.json` | 72 |
| `mysql-detection-results.json` | 47 |
| `mysql-identity-results.json` | 16 |
| `mysql-runtime-results.json` | 11 |
| `prepare-results.json` | 2 |
| `production-results.json` | 3 |
| `restore-results.json` | 3 |
| `sql-results.json` | 2 |
| `stability-extra-results.json` | 21 |
| `stability-results.json` | 14 |
| `startup-results.json` | 18 |
| `ui-actions-results.json` | 12 |
| `workflow-results.json` | 21 |

## Reproduced and corrected startup defects
1. Development run.py ignored DATABASE_URL and attempted guessed root connection credentials. Development now uses DATABASE_URL unless a legacy DEV_DATABASE_URL explicitly overrides it; there is no guessed root fallback. Production/offline upgrade require DATABASE_URL.
2. Windows launcher silently exited without .venv/pythonw/dependencies or after timeout. New visible batch launcher uses shared launch.py/Waitress, pauses on failure, honors port config and opens browser only for its own readiness reply.
3. Ordinary startup executed schema DDL/trigger creation. Real MySQL8 default binary logging rejected trigger installation for schema-only account (1419). Offline migration is explicit; normal startup performs read-only guard/schema verification. No weakening of server security or identity rule.
4. PyMySQL RSA extra was missing for common MySQL caching-SHA2 connections; requirements include it. Installed into a clean virtual environment and successfully ran the shipped launcher checks against real MySQL.
5. Runtime with no DDL cannot directly inspect trigger definitions. Parameterless durable-definer verification procedure permits runtime EXECUTE, without TRIGGER/drop privileges. Actual MySQL test confirms runtime can create/correct/delete invoices but cannot alter reservation rows or drop triggers. Repeated upgrades preserve procedure EXECUTE grants.
6. Startup could reapply legacy admin_config.json passwords. Ordinary startup no longer reads it; offline legacy setup leaves existing admins unchanged.
7. CLI backup failed for restricted runtime if MySQL dump tooling was installed. Failed partial CLI dump is removed and full consistent model-row fallback backup created with explicit method/warning. Offline recovery rebuilds schema/guards using migration privileges.

## Whole-app regression scope
- Login/remember/logout, safe redirects, profile validation, registration and reference-safe user deletion.
- Invoice create/edit/delete, amount-row add/remove/cap/totals, validation, book/session selection, grid/calendar/summary, reports and exports.
- Modals: top clickable submit, backdrop/body-lock cleanup, retry after failed deletion, remote live updates without duplicate modal IDs.
- Batch Repeat/Continue, legacy100 books, preparation preservation, View and all six reversible lifecycle actions; hidden/direct API denial; locked/archived normal-user read-only, admins correct all states.
- Global current/historical date+numeric serial reservation, padded raw SQL conflicts, CSV rename protection, owner return to prior key, deletion release, rollback and concurrent claims.
- Actual browser admin date+serial correction, historical collision message keeping exact typed draft, then reuse only after original deletion; desktop/mobile captures.
- Draft-safe live amounts/settings/file inputs, late response races, session write ordering, live list/book/attachment updates and authorization snapshots.
- Manual/automatic amount safety and verification, stale snapshot protections, daily scope and concurrent totals.
- CLI/fallback roundtrips on MariaDB and MySQL8 preserve historical reservations. Additive migration and direct-amount safety SQL preservation.
- Shipped visible launcher, no guessed database, BOM .env, arbitrary working directory, placeholder settings, bad credentials redaction, unsupported DB, occupied port, missing triggers refusal, diagnosis reports.
- Production one-worker/four-thread Gunicorn with MySQL runtime credentials, HTTPS CSRF test and secure cookies.

## Screenshots and test interpretation
All screenshot archive PNGs were created during this retest; none copied from the preceding release. `index.html` links full-resolution files. `history-*` demonstrates corrected-key retention; `setup-diagnosis-*` are real generated diagnostic reports, pass/fail. `startup-actual-console-transcript` is a rendering of recorded Linux launcher output, not a Windows screenshot. Restore/maintenance/import-preview fixture screens are labeled visual states, not destructive live restore execution. Camera screen proves UI rendering only.

## Limitations and observed environment issues
- No user startup error/launch method was supplied (clarification skipped), so reproduced code defects may not cover every local setup failure. Use the diagnosis report on the target computer.
- Windows .bat execution, Windows service integration, Workbench desktop, native mobile app and physical camera were not tested here. Shared Python launcher/Waitress were actually executed on Linux. Validate target PC and exact MySQL version in staging.
- One repeat browser run hit a navigation timeout during a resource-constrained parallel clean-install/two-database run; MySQL staging process was killed (137). Login remained reachable; rerunning sequentially and a reduced-memory staging DB passed. Evidence packages contain the successful reruns. No claim of sustained-load testing.
- Factory reset, interrupted recovery, distributed/multi-worker recovery and large-database throughput are not certified. Web restore remains disabled by default; built-in scheduler assumes one application process.
- Historical values corrected before the feature was installed cannot be reconstructed; current legacy keys are backfilled. From installation, committed keys remain until invoice deletion.
- Diagnosis/schema verification is read-only; operation startup may initialize missing singleton policy/revision rows, but it never rewrites invoices or installs DDL. DBA privileges can bypass database protections; maintain least-privilege runtime and durable definer accounts.
- This is broad regression coverage, not proof that every conceivable input/function is bug-free.

## Deployment gate
Preserve .env/database/uploads, stop all writers and back up. Run Setup InvoiceFlow.bat (Windows), configure DATABASE_URL, run upgrade_database.py offline with authorized migration account, configure runtime grants, diagnose and launch. MySQL1419 must be handled by the DBA, not by disabling protection. See INSTALLATION-GUIDE.html and BLUEPRINT.md.


