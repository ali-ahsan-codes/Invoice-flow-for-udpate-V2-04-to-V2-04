# Route inventory — amount-safety release

| Route | Methods | Endpoint |
|---|---|---|
| `/` | GET | `main.dashboard` |
| `/admin/analytics/` | GET | `analytics.index` |
| `/admin/analytics/data` | GET | `analytics.data` |
| `/admin/analytics/export` | GET | `analytics.export` |
| `/admin/audit-log` | GET | `admin.audit_log` |
| `/admin/audit-log/export` | GET | `admin.audit_log_export` |
| `/admin/books` | GET | `admin.books_index` |
| `/admin/books/<int:book_number>` | GET | `admin.book_detail` |
| `/admin/clear-audit-logs` | POST | `admin.clear_audit_logs` |
| `/admin/factory-reset` | POST | `admin.factory_reset` |
| `/admin/review/` | GET | `detection.index` |
| `/admin/review/<int:case_id>` | GET, POST | `detection.detail` |
| `/admin/review/rescan` | POST | `detection.rescan` |
| `/admin/review/settings` | GET, POST | `detection.settings` |
| `/admin/settings` | GET, POST | `admin.settings` |
| `/admin/users` | GET | `admin.users` |
| `/admin/users/<int:id>/delete` | POST | `admin.delete_user` |
| `/admin/users/<int:id>/edit` | GET, POST | `admin.edit_user` |
| `/api/v1/config` | GET | `api.config` |
| `/api/v1/invoices` | GET | `api.list_invoices` |
| `/api/v1/invoices/<serial>` | GET | `api.get_invoice` |
| `/api/v1/invoices/<serial>/media` | POST | `api.upload_media` |
| `/api/v1/invoices/<serial>/next` | GET | `api.next_invoice` |
| `/api/v1/invoices/<serial>/prev` | GET | `api.prev_invoice` |
| `/api/v1/me` | GET | `api.me` |
| `/auth/change-password` | GET, POST | `auth.change_password` |
| `/auth/connect-qr.svg` | GET | `auth.connect_qr` |
| `/auth/login` | GET, POST | `auth.login` |
| `/auth/logout` | GET | `auth.logout` |
| `/auth/profile` | GET, POST | `auth.profile` |
| `/auth/regenerate-api-key` | POST | `auth.regenerate_api_key` |
| `/auth/register` | GET, POST | `auth.register` |
| `/backup/` | GET | `backup.index` |
| `/backup/auto-toggle` | POST | `backup.auto_toggle` |
| `/backup/cleanup` | POST | `backup.cleanup` |
| `/backup/create` | POST | `backup.create` |
| `/backup/delete/<filename>` | POST | `backup.delete` |
| `/backup/download/<filename>` | GET | `backup.download` |
| `/backup/info/<filename>` | GET | `backup.info` |
| `/backup/restore` | POST | `backup.restore` |
| `/backup/restore-status` | GET | `backup.restore_status` |
| `/backup/status` | GET | `backup.status` |
| `/backup/upload-restore` | POST | `backup.upload_restore` |
| `/batches/` | GET, POST | `batches.index` |
| `/batches/<int:bid>/archive` | POST | `batches.archive` |
| `/batches/select` | POST | `batches.select` |
| `/dashboard` | GET | `main.dashboard` |
| `/import-export/` | GET | `import_export.index` |
| `/import-export/export` | GET | `import_export.export` |
| `/import-export/import` | GET, POST | `import_export.import_csv` |
| `/import-export/import-books` | POST | `import_export.import_books` |
| `/import-export/import-legacy` | GET, POST | `import_export.import_legacy` |
| `/import-export/sample-csv` | GET | `import_export.sample_csv` |
| `/invoices/` | GET | `invoices.index` |
| `/invoices/<int:id>` | GET | `invoices.view` |
| `/invoices/<int:id>/history` | GET | `invoices.history_json` |
| `/invoices/<int:id>/links` | POST | `invoices.link_create` |
| `/invoices/<int:id>/links/<int:link_id>/delete` | POST | `invoices.link_delete` |
| `/invoices/<int:id>/notes` | POST | `invoices.note_create` |
| `/invoices/<int:id>/notes/<int:note_id>/delete` | POST | `invoices.note_delete` |
| `/invoices/<int:id>/notes/attachments/<int:media_id>` | GET | `invoices.note_attachment` |
| `/invoices/<int:id>/delete` | POST | `invoices.delete` |
| `/invoices/<int:id>/edit` | GET, POST | `invoices.edit` |
| `/invoices/book-info` | GET | `invoices.book_info_endpoint` |
| `/invoices/calendar` | GET | `invoices.calendar` |
| `/invoices/calendar-data` | GET | `invoices.calendar_data` |
| `/invoices/create` | GET, POST | `invoices.create` |
| `/invoices/end-session` | POST | `invoices.end_session` |
| `/invoices/export` | GET | `invoices.export` |
| `/invoices/grid` | GET | `invoices.grid` |
| `/invoices/grid-data` | GET | `invoices.grid_data` |
| `/invoices/next-serial` | GET | `invoices.next_serial` |
| `/invoices/search` | GET, POST | `invoices.search` |
| `/invoices/start-session` | GET, POST | `invoices.start_session` |
| `/invoices/summary` | GET | `invoices.summary` |
| `/invoices/summary-data` | GET | `invoices.summary_data` |
| `/invoices/update-session` | POST | `invoices.update_session` |
| `/live/version` | GET | `live.version` |
| `/media/<int:invoice_id>/cleanup` | POST | `media.cleanup_orphaned` |
| `/media/delete/<int:media_id>` | POST | `media.delete` |
| `/media/download/<int:media_id>` | GET | `media.download` |
| `/media/m/<serial>` | GET | `media.mobile_scan` |
| `/media/qr-sheet` | GET | `media.qr_sheet` |
| `/media/qr/<serial>.png` | GET | `media.qr_png` |
| `/media/qr/<serial>.svg` | GET | `media.qr_svg` |
| `/media/scan` | GET | `media.scan_page` |
| `/media/scan-upload/<int:invoice_id>` | POST | `media.scan_upload` |
| `/media/thumb/<int:media_id>` | GET | `media.thumb` |
| `/media/toggle-required` | POST | `media.toggle_required` |
| `/media/upload/<int:invoice_id>` | GET, POST | `media.upload` |
| `/media/view/<int:media_id>` | GET | `media.view` |
| `/quick-stats` | GET | `main.quick_stats` |
| `/recent-invoices` | GET | `main.recent_invoices` |
| `/static/<path:filename>` | GET | `static` |

## Invoice notes, relations and merged amounts
- `POST /invoices/<id>/notes` (form: `body`, optional `files` ×N) adds a note with optional attachments. Attachments use the same allowed types as invoice media.
- `POST /invoices/<id>/links` (form: `linked_serial`, `link_type` = related | duplicate | adjustment, `amount_action` = none | merge, `link_note`) links two invoices (\`linked_batch_id\` selects the other invoice's batch; defaults to this batch; hidden batches are admin-only). `merge` appends the other invoice's total as one amount line on THIS invoice (Duplicate / Adjusted only). The other invoice is not changed.
- `POST /invoices/<id>/links/<link_id>/delete` removes a link and reverses its merged line (refused if that line was edited since).
- `GET /invoices/<id>/history` returns relations, merged amounts, notes and attachments from this invoice and every linked invoice the user may see (JSON).
- `link_create` also takes `exclude_from_totals` (1/0). It is only used with `amount_action=merge`: 1 (default in the form) leaves the linked invoice out of money totals, so its amount is counted once; 0 keeps both in totals. Plain relations ignore it. Reports use `totals_included_clause()` / `totals_amount_expr()` in `app/models.py`.
- Invoices with links cannot be deleted until unlinked. Visibility follows the invoice view (owner or administrator; hidden batches are administrator-only).
- Tables: `invoice_notes`, `invoice_note_media`, `invoice_links`, `user_capabilities`. Run `upgrade_database.py` offline (automatic) or the SQL files in `sql/` (manual). See `DEPLOY-CHECKLIST.md`.

## Per-user permissions (`app/permissions.py`)
Admins always have every function. For a data-entry user each function is an allow/deny switch in `user_capabilities`.
No row = allowed (default). `data.export` also follows the legacy `users.can_export` checkbox when no row exists.

| Capability | Web routes (decorator `@capability_required`) | Mobile API (decorator `@api_capability`) |
|---|---|---|
| `mobile.access` | — | every `/api/v1` endpoint except `GET /me` (checked in `require_api_key`) |
| `invoice.create` | `invoices.create` | — |
| `invoice.edit` | `invoices.edit` | — |
| `invoice.delete` | `invoices.delete` | — |
| `media.upload` | `media.upload`, `media.scan_upload` | `POST /invoices/<serial>/media` |
| `media.delete` | `media.delete` | — |
| `notes.create` | `invoices.note_create` | `POST /invoices/<serial>/notes` |
| `notes.delete` | `invoices.note_delete` | `DELETE /invoices/<serial>/notes/<id>` |
| `links.create` | `invoices.link_create` | `POST /invoices/<serial>/links` |
| `links.delete` | `invoices.link_delete` | `DELETE /invoices/<serial>/links/<id>` |
| `data.export` | `invoices.export`, `import_export.export` | — |
| `data.import` | `import_export.index`, `import_csv`, `import_books`, `import_legacy`, `sample_csv` | — |

- Denied web request: AJAX/JSON gets `403 {"success": false, "error": "...", "capability": "links.create"}`; a normal page request gets a flash message and a redirect back.
- Denied mobile request: `403 {"error": "...", "capability": "..."}`.
- `GET /api/v1/me` returns `"capabilities": {<key>: true|false, ...}` for all twelve keys and `"can_export"`. The app uses it to show or hide buttons.
- Templates use the `can('<key>')` helper to hide the matching buttons and forms.
- Admin page: `GET/POST /admin/users/<id>/permissions` (admin only). POST fields: `cap_<key>=on` for each allowed key, or `preset` = `custom` | `all` | `none` | `default`. Every change is written to the audit log (`update_permissions`). Admin accounts cannot be restricted.
- Unchanged, for every data-entry user: viewing invoices, notes, links, history and attachments; the owner-only rule for edit/delete; batch rules.

## Batch lifecycle additions
Admin-only POST `/batches/<id>/lock`, `/unlock`, `/hide`, `/unhide`, `/archive`, `/unarchive`; GET `/batches/<id>/view`. Normal-user hidden-batch direct access returns 404; locked/archived mutations return permission errors. See `app/batches.py` and `BATCH-CONTROLS-UPGRADE.md`.

## Launch and diagnostics
Use launch.py/Waitress for local launch; run.py uses the same configuration. Both normal startup and wsgi.py verify schema without DDL. upgrade_database.py is the explicit offline schema entrypoint. Launcher adds a process-specific readiness URL solely for local browser opening; this carries no user/invoice information. Diagnosis checks login via Flask test client and never binds a server.

## Mobile API: notes, links and history (`/api/v1`)
Auth `X-API-Key`. Invoice is addressed by serial; pass `batch_id` (required when the serial exists in more than one batch). Same batch, hidden-batch and ownership rules as the other mobile endpoints. Every mutation returns `{"success": true, "history": {...}}` with the refreshed history.
- `GET /invoices/<serial>/history`
- `POST /invoices/<serial>/notes` multipart: `body` (optional text), `files` (repeatable) or `file`. JSON `{"body": "..."}` also works for text-only notes. Returns 201.
- `DELETE /invoices/<serial>/notes/<note_id>` (author or admin)
- `GET /invoices/<serial>/notes/attachments/<media_id>` downloads an attachment (also for linked invoices the caller may see)
- `POST /invoices/<serial>/links` JSON or form: `linked_serial`, `linked_batch_id`, `link_type`, `amount_action`, `exclude_from_totals` (bool), `link_note`. Returns 201 with `link_id`.
- `DELETE /invoices/<serial>/links/<link_id>`

