# Route inventory — amount-safety release

| Route | Methods | Endpoint |
|---|---|---|
| `/` | GET | `main.dashboard` |
| `/admin/analytics/` | GET | `analytics.index` |
| `/admin/analytics/data` | GET | `analytics.data` |
| `/admin/analytics/export` | GET | `analytics.export` |
| `/admin/audit-log` | GET | `admin.audit_log` |
| `/admin/audit-log/export` | GET | `admin.audit_log_export` |
| `/admin/books` | GET | `admin.books_index` |
| `/admin/books/<int:book_number>` | GET | `admin.book_detail` |
| `/admin/clear-audit-logs` | POST | `admin.clear_audit_logs` |
| `/admin/factory-reset` | POST | `admin.factory_reset` |
| `/admin/review/` | GET | `detection.index` |
| `/admin/review/<int:case_id>` | GET, POST | `detection.detail` |
| `/admin/review/rescan` | POST | `detection.rescan` |
| `/admin/review/settings` | GET, POST | `detection.settings` |
| `/admin/settings` | GET, POST | `admin.settings` |
| `/admin/users` | GET | `admin.users` |
| `/admin/users/<int:id>/delete` | POST | `admin.delete_user` |
| `/admin/users/<int:id>/edit` | GET, POST | `admin.edit_user` |
| `/api/v1/config` | GET | `api.config` |
| `/api/v1/invoices` | GET | `api.list_invoices` |
| `/api/v1/invoices/<serial>` | GET | `api.get_invoice` |
| `/api/v1/invoices/<serial>/media` | POST | `api.upload_media` |
| `/api/v1/invoices/<serial>/next` | GET | `api.next_invoice` |
| `/api/v1/invoices/<serial>/prev` | GET | `api.prev_invoice` |
| `/api/v1/me` | GET | `api.me` |
| `/auth/change-password` | GET, POST | `auth.change_password` |
| `/auth/connect-qr.svg` | GET | `auth.connect_qr` |
| `/auth/login` | GET, POST | `auth.login` |
| `/auth/logout` | GET | `auth.logout` |
| `/auth/profile` | GET, POST | `auth.profile` |
| `/auth/regenerate-api-key` | POST | `auth.regenerate_api_key` |
| `/auth/register` | GET, POST | `auth.register` |
| `/backup/` | GET | `backup.index` |
| `/backup/auto-toggle` | POST | `backup.auto_toggle` |
| `/backup/cleanup` | POST | `backup.cleanup` |
| `/backup/create` | POST | `backup.create` |
| `/backup/delete/<filename>` | POST | `backup.delete` |
| `/backup/download/<filename>` | GET | `backup.download` |
| `/backup/info/<filename>` | GET | `backup.info` |
| `/backup/restore` | POST | `backup.restore` |
| `/backup/restore-status` | GET | `backup.restore_status` |
| `/backup/status` | GET | `backup.status` |
| `/backup/upload-restore` | POST | `backup.upload_restore` |
| `/batches/` | GET, POST | `batches.index` |
| `/batches/<int:bid>/archive` | POST | `batches.archive` |
| `/batches/select` | POST | `batches.select` |
| `/dashboard` | GET | `main.dashboard` |
| `/import-export/` | GET | `import_export.index` |
| `/import-export/export` | GET | `import_export.export` |
| `/import-export/import` | GET, POST | `import_export.import_csv` |
| `/import-export/import-books` | POST | `import_export.import_books` |
| `/import-export/import-legacy` | GET, POST | `import_export.import_legacy` |
| `/import-export/sample-csv` | GET | `import_export.sample_csv` |
| `/invoices/` | GET | `invoices.index` |
| `/invoices/<int:id>` | GET | `invoices.view` |
| `/invoices/<int:id>/history` | GET | `invoices.history_json` |
| `/invoices/<int:id>/links` | POST | `invoices.link_create` |
| `/invoices/<int:id>/links/<int:link_id>/delete` | POST | `invoices.link_delete` |
| `/invoices/<int:id>/notes` | POST | `invoices.note_create` |
| `/invoices/<int:id>/notes/<int:note_id>/delete` | POST | `invoices.note_delete` |
| `/invoices/<int:id>/notes/attachments/<int:media_id>` | GET | `invoices.note_attachment` |
| `/invoices/<int:id>/delete` | POST | `invoices.delete` |
| `/invoices/<int:id>/edit` | GET, POST | `invoices.edit` |
| `/invoices/book-info` | GET | `invoices.book_info_endpoint` |
| `/invoices/calendar` | GET | `invoices.calendar` |
| `/invoices/calendar-data` | GET | `invoices.calendar_data` |
| `/invoices/create` | GET, POST | `invoices.create` |
| `/invoices/end-session` | POST | `invoices.end_session` |
| `/invoices/export` | GET | `invoices.export` |
| `/invoices/grid` | GET | `invoices.grid` |
| `/invoices/grid-data` | GET | `invoices.grid_data` |
| `/invoices/next-serial` | GET | `invoices.next_serial` |
| `/invoices/search` | GET, POST | `invoices.search` |
| `/invoices/start-session` | GET, POST | `invoices.start_session` |
| `/invoices/summary` | GET | `invoices.summary` |
| `/invoices/summary-data` | GET | `invoices.summary_data` |
| `/invoices/update-session` | POST | `invoices.update_session` |
| `/live/version` | GET | `live.version` |
| `/media/<int:invoice_id>/cleanup` | POST | `media.cleanup_orphaned` |
| `/media/delete/<int:media_id>` | POST | `media.delete` |
| `/media/download/<int:media_id>` | GET | `media.download` |
| `/media/m/<serial>` | GET | `media.mobile_scan` |
| `/media/qr-sheet` | GET | `media.qr_sheet` |
| `/media/qr/<serial>.png` | GET | `media.qr_png` |
| `/media/qr/<serial>.svg` | GET | `media.qr_svg` |
| `/media/scan` | GET | `media.scan_page` |
| `/media/scan-upload/<int:invoice_id>` | POST | `media.scan_upload` |
| `/media/thumb/<int:media_id>` | GET | `media.thumb` |
| `/media/toggle-required` | POST | `media.toggle_required` |
| `/media/upload/<int:invoice_id>` | GET, POST | `media.upload` |
| `/media/view/<int:media_id>` | GET | `media.view` |
| `/quick-stats` | GET | `main.quick_stats` |
| `/recent-invoices` | GET | `main.recent_invoices` |
| `/static/<path:filename>` | GET | `static` |

## Invoice notes, relations and merged amounts
- `POST /invoices/<id>/notes` (form: `body`, optional `files` ×N) adds a note with optional attachments. Attachments use the same allowed types as invoice media.
- `POST /invoices/<id>/links` (form: `linked_serial`, `link_type` = related | duplicate | adjustment, `amount_action` = none | merge, `link_note`) links two invoices (\`linked_batch_id\` selects the other invoice's batch; defaults to this batch; hidden batches are admin-only). `merge` appends the other invoice's total as one amount line on THIS invoice (Duplicate / Adjusted only). The other invoice is not changed.
- `POST /invoices/<id>/links/<link_id>/delete` removes a link and reverses its merged line (refused if that line was edited since).
- `GET /invoices/<id>/history` returns relations, merged amounts, notes and attachments from this invoice and every linked invoice the user may see (JSON).
- Invoices with links cannot be deleted until unlinked. Visibility follows the invoice view (owner or administrator; hidden batches are administrator-only).
- Tables: `invoice_notes`, `invoice_note_media`, `invoice_links`. Run `upgrade_database.py` offline on existing databases.

## Batch lifecycle additions
Admin-only POST `/batches/<id>/lock`, `/unlock`, `/hide`, `/unhide`, `/archive`, `/unarchive`; GET `/batches/<id>/view`. Normal-user hidden-batch direct access returns 404; locked/archived mutations return permission errors. See `app/batches.py` and `BATCH-CONTROLS-UPGRADE.md`.

## Launch and diagnostics
Use launch.py/Waitress for local launch; run.py uses the same configuration. Both normal startup and wsgi.py verify schema without DDL. upgrade_database.py is the explicit offline schema entrypoint. Launcher adds a process-specific readiness URL solely for local browser opening; this carries no user/invoice information. Diagnosis checks login via Flask test client and never binds a server.


