# InvoiceFlow · Installation and recovery guide

**Startup repair release · 9 October 2026**  
The final source contains a working visible launcher, diagnosis tools, offline schema upgrade, full blueprint and tested screenshots. Your production database/files are not included and were not modified remotely.

> **Updating? Protect data first.** Finish drafts, stop every app/service/scheduler/SQL writer, back up the complete database **and** uploads, and keep your `.env`. Do not delete the live database/uploads or run a factory reset. Remove old *source* only after preserving configuration/data and verifying a matching backup. Extract the new source to one clean folder; do not merge multiple app versions or run from inside the ZIP.

## 1. Why the previous app could fail to start

- `run.py` previously ignored `DATABASE_URL` unless `DEV_DATABASE_URL` was also configured, then tried a guessed root password. The new development default uses `DATABASE_URL`; an existing `DEV_DATABASE_URL` is still an explicit **development override**. Production and offline upgrade use `DATABASE_URL`. Remove or align the override to avoid upgrading a different schema from the one you launch.
- The old Windows launcher required `.venv`/`pythonw.exe` and exited silently on errors. The new launcher remains visible, gives instructions, uses Python/Waitress, honors `FLASK_PORT`, and pauses after failure.
- Normal startup previously attempted schema DDL/trigger creation. On real MySQL 8.4, default binary logging can reject this for a schema-only account (error 1419). Normal startup now performs read-only schema/enforcement checks. Run `upgrade_database.py` **offline** with controlled migration privileges first.
- MySQL caching-SHA2 authentication may require cryptography. `PyMySQL[rsa]` is included in the installed requirements.

These are reproduced failures, not a claim that your particular PC has the identical cause. Run diagnosis if your installation still fails.

## 2. Requirements

- Python **3.11 or newer**, tested Python 3.13. Use a fresh virtual environment for the new source; do not copy one from another PC.
- Running MySQL Server 8.0.16+ (CHECK constraint enforcement) or compatible MariaDB. This release was tested on **MySQL 8.4.7 and MariaDB**. Workbench is a database administration interface, **not** the server.
- Persistent writable upload/backup/log paths, enough disk space, and database connectivity. Production needs HTTPS and a service manager.
- Libraries in `requirements.txt` are pinned. Runtime fonts/styles/scripts are local. Initial Python/package installation requires internet or a prepared wheelhouse.

| Library | Use |
|---|---|
| Flask, Werkzeug | HTTP routing/server integration |
| Flask-SQLAlchemy, SQLAlchemy, PyMySQL[rsa] | Transactions, MySQL, caching-SHA2 auth |
| Flask-Login, Flask-Bcrypt, Flask-WTF, email-validator | Authentication/password hashing, CSRF and validation |
| APScheduler | Optional automatic backups |
| python-dotenv | This application's `.env`, including Windows UTF-8 BOM |
| Pillow, qrcode | Attachments, thumbnails and QR images |
| Waitress | Visible cross-platform launcher / Windows WSGI |
| Gunicorn | Linux production, one worker with threads |

## 3. Windows setup

1. Extract `InvoiceFlow-FINAL-Source.zip`; open its `invoiceflow` folder.
2. Double-click **Setup InvoiceFlow.bat**. It checks Python, creates `.venv`, installs requirements, copies `.env.example` only if `.env` is absent and initializes a random secret only if blank/placeholder. It does not touch your database or uploads.
3. Edit `.env` in a text editor. Keep the intended **existing** database when upgrading; do not accidentally point to an empty new database.
4. Complete the offline database upgrade in section 6.
5. Double-click **Diagnose InvoiceFlow.bat**. All checks should pass.
6. Double-click **Invoicing app.bat**. Keep its window open. The browser opens only after this process has bound its port and returned its own readiness response.

Equivalent terminal commands:

```powershell
cd C:\InvoiceFlow\invoiceflow
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
# Preserve an existing .env; copy the example only for a new installation.
.\.venv\Scripts\python.exe configure.py --initialize-secret
# Edit .env BEFORE the next commands.
.\.venv\Scripts\python.exe upgrade_database.py
.\.venv\Scripts\python.exe diagnose.py
.\.venv\Scripts\python.exe launch.py
```

**Windows .bat execution was not tested on Windows in this sandbox.** The shared Python launcher, diagnosis, Waitress and application were executed on Linux. Rehearse the batch scripts on your target PC.

## 4. Linux / offline library installation

```sh
cd /srv/invoiceflow
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
# Keep an existing .env; create from the example only if absent.
.venv/bin/python configure.py --initialize-secret
# Edit .env, back up, stop writers, then:
.venv/bin/python upgrade_database.py
.venv/bin/python diagnose.py
.venv/bin/python launch.py --no-browser
```

For an offline PC prepare wheels on a connected computer with the **same OS/architecture/Python version**, then copy them:

```sh
python -m pip download -r requirements.txt -d wheelhouse
python -m pip install --no-index --find-links=wheelhouse -r requirements.txt
```

The source ZIP does not bundle Python, MySQL or a wheelhouse. The HTML guide itself needs no network.

## 5. Database connection and configuration

Example `.env` (replace credentials; never use QA sample accounts):

```ini
FLASK_CONFIG=development
SECRET_KEY=YOUR_RANDOM_64_CHARACTER_SECRET
DATABASE_URL=mysql+pymysql://invoiceflow_app:ENCODED_PASSWORD@127.0.0.1:3306/YOUR_DATABASE?charset=utf8mb4
FLASK_HOST=0.0.0.0
FLASK_PORT=5000
SCHEDULER_ENABLED=False
UPLOAD_FOLDER=uploads
BACKUP_DIR=backups
ALLOW_WEB_RESTORE=False
MAINTENANCE_MODE=False
```

`DEV_DATABASE_URL`, if present, overrides `DATABASE_URL` for development only. Do not keep a stale override. `wsgi.py`, `upgrade_database.py` and `prepare_batches.py` require `DATABASE_URL`. Diagnosis uses the same FLASK_CONFIG as the launcher. Relative upload/backup paths resolve against this source folder, not the shortcut/service working directory.

Percent-encode only the database password when it includes `@ : / # % ?`. Example:

```sh
python -c "from urllib.parse import quote; print(quote('your-password', safe=''))"
```

Do not put real passwords in screenshots/logs/public reports. For production set `FLASK_CONFIG=production`, a random secret of 32+ characters and HTTPS. Production secure cookies cannot be disabled by the example's development settings. A plain HTTP production browser may display login but will not retain secure sessions.

## 6. MySQL Workbench: offline schema upgrade

### New database
Open Workbench as a DBA. Create the intended schema and a durable migration account, or inspect and customize `sql/create_database.sql`. That script's account creation does not reset an existing password. Restrict accounts to the actual app host; never blindly grant `%` access. SQLite and incompatible unsigned foreign-key schemas are not supported.

### Existing database
1. Stop **all writers**, including direct SQL/mobile clients. Back up full SQL with triggers/routines and copy uploads separately. Restore/rehearse on staging first.
2. Select the intended schema in Workbench and run **`sql/preflight_batch_controls.sql`**. Invalid serials or duplicate date + numeric serial must be resolved deliberately with the data owner. The migration reports original IDs and does not delete or renumber invoices automatically. Preserve original 100-book assignments/records.
3. Set `DATABASE_URL` to your migration account and run **`python upgrade_database.py`**. This is the only normal installation entrypoint that performs schema creation/migration. Repeated upgrades preserve invoice IDs/timestamps/amounts/serial strings and do not reset existing administrator credentials.
4. Confirm the helper prints its verification success. Run in Workbench:

```sql
SELECT DATABASE(), VERSION();
SHOW COLUMNS FROM batches;
SHOW COLUMNS FROM invoices;
SHOW INDEX FROM invoices;
SHOW CREATE TABLE invoice_identity_reservations;
SHOW TRIGGERS;
CALL invoiceflow_verify_identity_guards();
SELECT COUNT(*) AS missing_current_reservations
FROM invoices i LEFT JOIN invoice_identity_reservations r
 ON r.date=i.date AND r.serial_numeric=i.serial_numeric AND r.invoice_id=i.id
WHERE r.invoice_id IS NULL;
```

There must be two expected invoice reservation triggers and zero missing current reservations. Unexpected trigger/procedure definitions abort the upgrade/startup for DBA review; they are not automatically replaced. Do not repeatedly retry unknown DDL failures on your only copy.

### Privileges and MySQL binary logging

Migration needs controlled CREATE/ALTER/INDEX/REFERENCES/TRIGGER/CREATE ROUTINE/ALTER ROUTINE privileges, metadata visibility and SELECT/INSERT/UPDATE. CLI backup/restore may need additional routine/definer privileges. With binary logging enabled MySQL may also require authorized administrator privileges for trigger installation (error 1419). A DBA must perform/authorize that offline step. **The app never changes `log_bin_trust_function_creators`, disables binary logging or skips identity enforcement to start.**

Use a durable authorized definer/migration account, not a temporary account later deleted. Both triggers and the verification routine depend on the definer's continued privileges. The parameterless procedure returns only guard metadata; it lets runtime verify enforcement without granting runtime TRIGGER/DROP privileges.

After upgrade switch to the runtime account. Use `sql/configure_runtime_privileges.sql` after inspecting/customizing its database/account/host. It adds grants and does not revoke existing broad privileges: your DBA must remove any broader runtime reservation/DDL grants deliberately. Suggested grants, adapted by your DBA:

```sql
-- Replace YOUR_DATABASE, account and host. Execute only after upgrade.
GRANT SELECT ON YOUR_DATABASE.* TO 'invoiceflow_app'@'127.0.0.1';
GRANT EXECUTE ON PROCEDURE YOUR_DATABASE.invoiceflow_verify_identity_guards
 TO 'invoiceflow_app'@'127.0.0.1';
-- Grant INSERT/UPDATE/DELETE individually on app tables EXCEPT
-- invoice_identity_reservations (internal; triggers/cascade own its writes):
-- users, batches, books, invoices, invoice_media, audit_logs, backup_records,
-- system_settings, live_revision, detection_policy, review_cases.
```

Do **not** grant runtime DELETE/UPDATE/INSERT on reservation rows or TRIGGER/DDL privileges. Tested MySQL runtime can insert/correct/delete invoices, and definer triggers / FK cascade manage reservations; it cannot release reservations directly or drop their triggers. Configure privileged backup tooling separately if least-privilege runtime cannot run CLI dumps; fallback app SQL backups are available and require only SELECT. Recovery always needs a maintenance account, never ordinary runtime.

## 7. First administrator and launch

After successful offline upgrade:

```powershell
.\.venv\Scripts\python.exe -m flask --app run create-admin --username admin --email YOUR_EMAIL
.\.venv\Scripts\python.exe diagnose.py
.\.venv\Scripts\python.exe launch.py
```

The command prompts for the password; no sample admin is installed. `create-admin` can deliberately reset an existing admin, so use it only for initial setup or an intended reset. Automatic startup does not reset passwords from `admin_config.json`.

`python run.py` is also supported and uses Waitress. `python launch.py --check` validates the configured app without binding a server. `launch.py --no-browser` starts without opening a browser. Port 5000 is the default; set another FLASK_PORT if occupied. Do not assume any process listening on that port is InvoiceFlow.

## 8. Troubleshooting

Run `Diagnose InvoiceFlow.bat` or `python diagnose.py`, then read **`logs/diagnostic-report.html`**. Reports omit passwords and do not migrate. Launcher errors are in `logs/startup.log` without raw connection strings/tracebacks.

| Symptom | Action |
|---|---|
| Window closes / no `.venv` | Run Setup InvoiceFlow.bat; new launcher pauses on failure. Extract the full folder. |
| Missing library | Use the same `.venv` Python to install requirements; include PyMySQL[rsa]. |
| No database configured | Set DATABASE_URL in this folder's `.env`; remove stale DEV_DATABASE_URL. |
| Login rejected / 1045 / 1698 | Check account/password/host grants. Dedicated MySQL account, not guessed root/socket auth. |
| Cannot connect / 2003 | Start MySQL service; check host, port, firewall and network. Workbench alone is not a server. |
| Schema missing / trigger missing | Keep offline; run upgrade_database.py with authorized migration account. |
| MySQL 1419 | DBA must authorize offline trigger installation under server binary-log policy. Do not weaken protection to bypass it. |
| Verification procedure inaccessible | Grant EXECUTE; check definer exists and can inspect the schema. |
| Unexpected trigger/procedure | DBA inspect; do not silently drop existing customer logic. A deliberate replacement requires regranting procedure EXECUTE. |
| Port occupied | Stop the old app or choose FLASK_PORT. Launcher does not open another app's page. |
| Production login loops on HTTP | Use HTTPS; production cookies are Secure. |
| Different empty records after upgrade | Verify DATABASE_URL and any DEV_DATABASE_URL; do not delete or re-enter original data. |
| Duplicate date/serial after correction | Intended: current/prior keys remain reserved until the owning invoice is deleted. |

If still failing, provide the diagnosis report and visible error (redact any credentials). The sandbox cannot diagnose an unseen Windows machine's services/configuration.

## 9. Batch / entry / amount-safety behavior

- Admin controls: View, Lock/Unlock, Hide/Unhide, Archive/Unarchive. States independent. Archive requires verification; unlocking does not unhide/unarchive.
- Normal users: locked/archived read-only, hidden omitted/inaccessible by direct link and API. Admins retain correction/entry access to all states.
- Global identity is **date + numeric serial**, ignoring leading zeros. Every committed historical combination remains owned by the invoice. Correction does not release it; deletion alone releases all its combinations. Same serial on a different unreserved date may occur in another batch. One physical serial/page per batch remains enforced.
- At upgrade only existing **current** combinations can be backfilled. Old pre-feature corrected values cannot be reconstructed reliably. Rolled-back writes do not reserve keys.
- `prepare_batches.py` is the guarded offline helper for exactly 100 existing Batch 1 books and empty repeated-number Batch 2; it preserves legacy records, never fabricates books and never automatically archives. Future batches can Repeat or Continue numbering.
- Manual per-invoice, per-user daily and batch-day thresholds independently configurable; automatic historical checks independently toggleable. Both can be disabled. Admin verify/clear records with notes; flags never rewrite amounts.
- Automatic checks are a heuristic, not guaranteed typo/fraud detection. Invoice baselines need 20 earlier positive invoices within 180 days, daily baselines 14 earlier active days. Zero totals are exempt; incomplete low daily totals are not flagged. Full model details: BLUEPRINT.md.
- After offline raw SQL amount changes use `python -m flask --app run rescan-flags`; raw SQL does not run Python detection/live hooks. Database reservation triggers still enforce identity.

## 10. Production and live updates

Linux HTTPS reverse-proxy/service example:

```sh
.venv/bin/gunicorn --bind 127.0.0.1:8000 --workers 1 --threads 4 wsgi:app
```

Windows production can use Waitress under a service manager and HTTPS reverse proxy; secure-cookie configuration is in production mode. Do not expose the database or backend port directly to the internet. Use **one application process** for built-in scheduling; disable scheduler during maintenance. Configure restart/log rotation and persistent writable paths.

Authenticated visible pages poll an opaque DB revision about every 1.5 seconds. Authorized read-only islands and images update without manual refresh. Forms/amount rows/file choices/drafts are preserved; permission changes disable save without resetting inputs. Hidden/revoked snapshots retain drafts with a notice. Offline/reconnect/modal safety can defer updates. Deployment requires reopening pages once to load changed assets. Raw filesystem/SQL changes outside application hooks are not automatically broadcast; explicitly record a revision/app audit event.

## 11. Backup, restore and rollback

- Back up all tables, triggers and routines **including historical reservation ownership**, and copy uploaded files separately. SQL alone does not contain images/documents.
- CLI dumps use single-transaction, routines and triggers. SQLAlchemy fallback excludes generated columns, uses a consistent snapshot, stores all model rows including reservations/policy/cases and rebuilds enforcement during controlled restore.
- Web restore disabled by default; use offline DBA restore. Stop all app/other writers first; restore full dump and corresponding uploads/source/config; run upgrade_database.py with migration account; regrant runtime EXECUTE if needed; diagnose and reconcile before restarting.
- Retain/restore durable definer accounts/grants. Cross-server MySQL/MariaDB dumps are not guaranteed compatible; use your target engine's tooling and staging tests.
- Compare original IDs/date/serial strings/amounts/timestamps/books/media/audit counts. Restoring an older backup restores its older historical state; do not combine invoice-only dumps with newer reservation tables.
- MySQL DDL is not rollback-safe. On partial failure keep offline; inspect safely or restore the matching full backup. Never delete invoices merely to make migration pass.

## 12. Acceptance checklist and evidence

- Setup and diagnosis pass; launcher stays visible and correct configured DB opens.
- First/last original books and attached files reconcile; no password reset or auto-renumber.
- Admin/normal-user permissions; all six reversible batch actions.
- Create/edit/delete, historical collision/reuse, CSV errors/exports, reports/calendar/grid, profiles/users, QR/media/upload, books and live drafts.
- Amount safety toggles, review/verify/rescan; complete backup/restore staging roundtrip.
- Windows scripts, hardware camera and native mobile client tested on the actual target machines (not covered by Linux sandbox).

**QA_REPORT.md records this release's fresh results and exact remaining limitations.** Screenshots include synthetic data and clearly labeled restore/maintenance/import-preview fixtures. Tests are extensive regression coverage, not a proof that every conceivable action/input is bug-free. Do not run destructive `qa/` harnesses against production.


