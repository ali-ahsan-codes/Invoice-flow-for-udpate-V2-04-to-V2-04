# Test report — invoice notes, attachments & relations

## Automated (run locally, SQLite harness)
- `python qa/invoice_history_test.py` → **79 checks passed**
  (notes/attachments, access rules, link/merge/unlink, index shift on multiple merges,
  tampered-line refusal, cross-batch links, hidden-batch refusal, batch lock, delete guards, audit rows).
- `python qa/mobile_qr_contract_test.py` → 3 checks passed (existing, DB-free).
- Static check (pyflakes) on changed modules: no undefined names. Pre-existing unused imports left as-is.
- MySQL DDL for the three tables generated from the models and the upgrade SQL parsed with a MySQL grammar.

## Screenshots
`qa/screenshots/` — captured from the demo server (`demo_server.py`) with headless Chromium:
01 login, 02 invoice page top, 03 relations & notes section, 04 related link, 05 other-batch invoice, 06 mobile history.

## Not tested in this environment
- **MySQL 8.x / MariaDB runtime** (no server available): run `sql/upgrade_invoice_history.sql` or `upgrade_database.py` in staging first.
- **Android app**: could not be built or unit-tested here (no JDK / Android SDK / Gradle downloads). Static check: all endpoints the app calls (`/api/v1/invoices/<serial>`, `/next`, `/media`, `/me`, `/config`) exist and are unchanged.
- Full legacy Selenium/Playwright QA suites in `qa/` need the original MySQL preview database and sandbox paths; not run.
