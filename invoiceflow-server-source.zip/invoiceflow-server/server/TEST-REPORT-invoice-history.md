# Test report — invoice notes, attachments & relations

## Automated (run locally, SQLite harness)
- `python qa/invoice_history_test.py` → **79 checks passed**
  (notes/attachments, access rules, link/merge/unlink, index shift on multiple merges,
  tampered-line refusal, cross-batch links, hidden-batch refusal, batch lock, delete guards, audit rows).
- `python qa/mobile_qr_contract_test.py` → 3 checks passed (existing, DB-free).
- Static check (pyflakes) on changed modules: no undefined names. Pre-existing unused imports left as-is.
- MySQL DDL for the three tables generated from the models and the upgrade SQL parsed with a MySQL grammar.

## Screenshots
`qa/screenshots/` — captured from the demo server (`demo_server.py`) with headless Chromium:
01 login, 02 invoice page top, 03 relations & notes section, 04 related link, 05 other-batch invoice, 06 mobile history.

## Not tested in this environment
- **MySQL 8.x / MariaDB runtime** (no server available): run `sql/upgrade_invoice_history.sql` or `upgrade_database.py` in staging first.
- **Android app**: could not be built or unit-tested here (no JDK / Android SDK / Gradle downloads). Static check: all endpoints the app calls (`/api/v1/invoices/<serial>`, `/next`, `/media`, `/me`, `/config`) exist and are unchanged.
- Full legacy Selenium/Playwright QA suites in `qa/` need the original MySQL preview database and sandbox paths; not run.

## Round 2: exclude-from-totals, mobile API, file types, Android

Run with `python qa/exclusion_and_mobile_api_test.py` (SQLite harness): **47 / 47 checks pass.**
Existing `qa/invoice_history_test.py`: **79 / 79 pass** after the change.
`qa/mobile_qr_contract_test.py`: 3 / 3 pass (the 3 QR checks, unchanged).

Covered: merge with exclude and with include (totals count once / twice); unlink restores totals; relation-only link ignores the choice; API link/note/attachment/delete with batch scoping and hidden batch; other clerk refused; executable, SVG and `.html` refused even with an image MIME; CSV and WEBP accepted; sample CSV download works.

Not run here (environment): MySQL-backed tests (`batch_test`, `detection_test`, `sql_upgrade_test`, `startup_test` and others) need a MySQL server; `workflow_test` needs a browser build. Run them on staging.

Android (`invoiceflow-android-source-by_agent`): new `NotesLinksApiTest.kt` (Robolectric, stub server) and the new `InvoiceHistoryScreen`. **Not compiled or run**: no Java / Android SDK in the sandbox. Static checks only (brace balance, all called functions exist). Build and run the unit tests before release.

