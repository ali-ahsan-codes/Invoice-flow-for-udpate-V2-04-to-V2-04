# InvoiceFlow — Complete Application Blueprint

**Release:** FINAL · 9 October 2026  
**Canonical source:** `invoiceflow/` in `InvoiceFlow-FINAL-Source.zip`  
**Startup:** production `wsgi:app`; local `run.py` → `create_app()`. See `DEPLOYMENT.md`.  
**Evidence:** `QA_REPORT.md`, `qa/results/` and the separate newly captured screenshot archive.

## 1. Product scope
InvoiceFlow is a Flask/MySQL invoice-entry and administration application with browser-based desktop/mobile interfaces and a scoped mobile API. It tracks invoices, serials, amounts, books/pages, attachments and audit activity; provides summaries and exports; and includes database backup/restore operations.

This is one modular application, not multiple apps. Route blueprints separate features; templates render screens; services implement shared business operations; static assets provide the shared UI and live-sync behavior. The QA sample helper is test support only.

### Role boundaries
- **Administrator:** administration, users/books/settings/audit, analytics and backup tooling; access to invoice workflows.
- **Data-entry user:** permitted invoice and scanning workflows, scoped to ownership where enforced, with export permission controls.
- **API client:** API-key authentication with user scope; key generation/connect QR available through account workflows.
- **Unauthenticated visitor:** login and selected QR/mobile missing-state behavior; private workflows require authentication. Some QR URL-generation routes are intentionally not private invoice-data endpoints.

Authorization is enforced by decorators and route/service checks; notifications do not grant access. Preserve these checks when extending the app.

## 2. Architecture
```text
Desktop browser / mobile browser / API client
                    |
             HTTP(S) + session / API key
                    |
          Flask application factory
          routes → services → SQLAlchemy
                    |                |
          Jinja templates       MySQL/MariaDB
                    |                |
          Local CSS / JS      revision row + business data
                    |
      Native dataset loaders / keyed DOM morphing
                    |
      Updated UI without document reload

Server filesystem: uploads + thumbnail cache + SQL backups
Scheduler: automated backup task within the application process
```

### Core stack
Python, Flask, Jinja2, Flask-SQLAlchemy/SQLAlchemy, PyMySQL, Flask-Login, Flask-WTF/CSRF, Flask-Bcrypt, APScheduler, Pillow, qrcode and dotenv. Browser assets are local Bootstrap, Font Awesome, Chart.js, Idiomorph, DM Sans and Manrope. Runtime CDN access is unnecessary.

## 3. Source layout and responsibilities
```text
invoiceflow/
├── wsgi.py                     Production WSGI entrypoint
├── prepare_batches.py          Offline 100-book migration/preparation
├── DEPLOYMENT.md               Upgrade/restore runbook
├── launch.py                   Visible cross-platform Waitress launcher
├── diagnose.py                 Credential-safe setup report
├── configure.py                Non-destructive secret initializer
├── run.py                      Local Waitress entrypoint
├── upgrade_database.py         Explicit offline migration/verification
├── config.py                   Development / production / testing configs
├── .env.example                Environment template, no real credentials
├── requirements.txt            Runtime Python dependencies
├── Invoicing app.bat            Visible Windows launcher for launch.py/Waitress
├── reset_admin_password.py     Administrative recovery utility
├── README.md                   Installation and release guidance
├── BLUEPRINT.md                This architecture/operations document
├── QA_REPORT.md                Test results and caveats
├── app/
│   ├── __init__.py              Factory, read-only schema gate, middleware
│   ├── extensions.py            DB, login, bcrypt, CSRF, scheduler
│   ├── models.py                Main database models
│   ├── forms.py                 WTForms validation
│   ├── commands.py              Flask administration commands
│   ├── realtime.py              Transaction-scoped revision model/hooks
│   ├── routes/                  Feature HTTP blueprints
│   ├── services/                Invoice, audit, import, backup operations
│   ├── utils/                   Permissions, validation, dates, DB helpers
│   ├── templates/              Shared base plus feature screens
│   └── static/
│       ├── css/                 Base style, luxe UI, font declarations
│       ├── js/                  Form/grid helpers and live sync
│       ├── fonts/               DM Sans / Manrope
│       ├── vendor/              Local framework/chart/morphing assets
│       ├── webfonts/            Local Font Awesome files
│       └── licenses/            Third-party notices
└── qa/
    ├── README.md                QA execution/environment notes
    ├── results/                 Recorded machine-readable results
    ├── fixtures/                Non-destructive state captures
    ├── support/demo_app.py      Isolated disposable sample-data helper
    └── *.py                     Recorded test/capture scripts
```
`uploads/`, `backups/`, `instance/`, `.venv/`, logs and caches are runtime data, not distributed sample source. The application creates required runtime directories. Never overwrite production uploads/backups during an upgrade.

## 4. HTTP blueprint map
| Module | URL prefix | Responsibility |
|---|---|---|
| main | `/` | Dashboard, recent invoices, quick stats |
| batches | `/batches` | Repeat/Continue creation, selector, verified archive |
| auth | `/auth` | Login/logout, register, profile, password, connect QR/API key |
| invoices | `/invoices` | Session selection, invoice CRUD/search, serial/book helpers, grid/calendar/summary/export |
| admin | `/admin` | Users, book index/detail, settings, audit/export, destructive reset/cleanup |
| analytics | `/admin/analytics` | Dashboard, aggregate data and export |
| media | `/media` | Attachments, thumbnails, QR codes/sheet, mobile scan and upload |
| import_export | `/import-export` | CSV exports, invoice/book imports, legacy import, sample CSV |
| backup | `/backup` | Create/download/delete/cleanup, restore/upload/status, automatic toggle |
| api | `/api/v1` | API-key user/config, scoped invoice list/detail/adjacent invoice, media upload |
| live | `/live` | Authenticated opaque revision polling |

`ROUTES.md` is generated from the final application's route map and lists every endpoint and allowed method. It is the authoritative route inventory for this release.

## 5. Screen and UI blueprint
Shared `base.html` owns navigation, topbar, flashes, local assets and live-sync status. The luxe CSS overlays the retained base stylesheet; these are intentional layers, not competing app versions.

### Screen groups
- Account: login, registration/user-edit state, profile, password.
- Work area: dashboard, invoices, work-session selection, invoice create/edit/detail.
- Data views: grid, calendar, summary and admin analytics.
- Administration: users, books, book detail, settings and audit.
- Files: upload, scanning index, mobile capture, missing invoice state and QR sheet.
- Operations: import/export, legacy import, import preview, backups, restore confirmation and maintenance.

Page templates include the batch manager and request-error screen, plus shared base and multiple create/edit or register/edit states. Screenshots include desktop and mobile states, login errors/navigation, and additional live-file/book views.

### Visual requirements
Violet glass/gradient surfaces, dark navigation, modern locally served typography, gentle transitions, focus states, mobile navigation, reduced-motion handling and print styles. Numeric book/serial values use proportional DM Sans with tabular numerals rather than the former monospaced font.

### Compact book detail
- Four summary metric cards: usage, total/average, missing pages, date range.
- Tabs: invoices; missing pages; insights/information.
- Invoice cards: page, serial, date, amount, file count/first thumbnail and open action.
- Twelve records fetched per page. Pagination changes URL/history and refreshes cards in place.
- SQL aggregates compute whole-book statistics; attachment queries cover only the displayed invoices.
- Bounded card panel scroll on mobile and desktop avoids an unbounded vertical invoice table.

## 6. Database blueprint
Business models live in `app/models.py`; `LiveRevision` lives in `app/realtime.py`.

| Table | Important fields / purpose |
|---|---|
| users | Unique username/email, password hash, role, timestamps/login, preferred serial, export flag, unique nullable API key |
| batches | Immutable ID, name, Repeat/Continue mode, first book/serial, archive/lock/hidden flags, created time |
| books | Batch FK + batch-unique printed book number, capacity, assigned user FK, timestamps |
| invoices | Date, batch FK + batch-unique serial string, generated numeric serial + global current date/serial uniqueness, JSON amount list, decimal total (10,3), creator/updater FKs, timestamps, media-required flag, book FK/page |
| invoice_identity_reservations | Every current/prior date + numeric serial; owning invoice FK with deletion cascade |
| invoice_media | Invoice FK, filename/relative path, size, MIME type, uploader FK/time |
| audit_logs | User FK, action, details text, IP, timestamp |
| backup_records | Filename, byte size, creation time |
| system_settings | Unique key, text value, update time |
| live_revision | Singleton ID 1 and opaque 32-character token |

### Relationships
```text
Batch ──< Book / Invoice
User ──< Invoice (created_by / updated_by)
User ──< Book (assigned_user_id)
User ──< InvoiceMedia (uploaded_by)
User ──< AuditLog (user_id)
Book ──< Invoice (book_id)
Invoice ──< InvoiceMedia (invoice_id)
SystemSetting / BackupRecord / LiveRevision: independent records
```
Media belongs to an invoice with ORM delete-orphan cascading. User deletion reassigns referenced invoice/media/audit records to the acting administrator and clears book assignments rather than breaking foreign keys.

### Initialization and upgrades
`create_app()` normally verifies schema/triggers without DDL. Only explicit offline upgrade (upgrade_database.py / guarded preparation) calls create_app(upgrade_schema=True), creating missing schema/legacy columns and running named-lock-protected migration. It does NOT backfill/rewrite historical book assignments at startup. New batch columns assign legacy records Batch 1; composite unique indexes are installed before removing global uniqueness. A composite database FK prevents invoices referencing books from another batch. Existing IDs, serial strings, dates, amounts, users, timestamps, media and history are preserved. Migration failures abort startup; MySQL DDL is not transactionally reversible. Offline backup/staging reconciliation is mandatory. The migration helper is idempotent, not an Alembic history.

### Batch lifecycle and identity
`app/batches.py` resolves explicit request context, scopes Invoice/Book ORM queries, pins browser forms/fetch/links and implements Batches. ID-based invoice links resolve the record's actual batch; explicitly conflicting links fail. Global administration (user deletion, factory reset, backups) deliberately opts out of batch filtering. Audit logs remain a global history with batch IDs in new invoice actions; historical logs are not rewritten.

Repeat defaults to Book 1 / Serial 0001. Continue begins after the last configured book/range of the preceding batch, not its last entered invoice. Explicit printed origins can override defaults. Capacity determines cumulative ranges within each batch. Printed capacity cannot be silently changed once entry starts; out-of-range entry cannot auto-create books. New serial input is numeric and canonical padded form; numeric comparison handles continued ranges above 9999. Book and invoice internal IDs never reset when printed numbering repeats.

Batch 1 archiving requires explicit administrator verification and another open batch. Archived records stay reportable. Normal-user writes are blocked; administrators retain entry/import/edit/delete and attachment correction access. The offline 100-book helper creates Batch 2 only when appropriate, without fabricating legacy records. Eight recent batch-specific work sessions are retained; changing the active batch in another tab does not move a pending entry.

## 7. Principal workflows
### Authentication
Login validates credentials, maintains optional remember behavior and restricts redirect targets. Logout clears authentication/remember state. Account changes validate data; CSRF applies to normal browser mutations. First administrator creation is a CLI operation with prompted password; production credentials are not bundled.

### Invoice entry
1. Choose/continue a book and work date; obtain usage and suggested next serial.
2. Enter amounts; frontend computes totals and supports dynamic amount rows (maximum 20).
3. Server validates, assigns book/page and persists invoice/audit data.
4. Successful entry advances the form's working serial/date state without discarding the workflow.
5. Browser mutation hints and the committed revision tell other clients to update.

### Invoice editing/conflicts
Browser edit forms carry `source_version`. Updating obtains a row lock, re-reads the invoice and checks the submitted source version against `updated_at`. A stale browser draft is rejected, leaving the newer stored invoice intact. Drafts remain local; this is not simultaneous collaborative field editing. Callers that omit the optional version do not get this same version-based conflict protection.

### Attachments
Desktop multipart upload supports allowed file types; AJAX response updates attachment lists/thumbnails without navigation. Mobile scanning uploads through its existing JSON route. Delete requests update connected views. Downloads/thumbnails enforce ownership/admin checks. Filenames are sanitized; media IDs/path records connect files to invoices. Filesystem changes and database transactions are not a single atomic filesystem/database operation; retain operational backups of both.

### Reporting and import/export
Grid/calendar/summary/analytics have dedicated JSON loaders. They reload current filters/ranges on revision changes while retaining native controls. CSV import supports preview/mapping and duplicate handling; book and legacy imports have separate workflows. Validate a representative CSV on staging before batch changes.

### Backup and restore
SQL backups include all batches, books, invoices, metadata, users, settings, audit and live revision; attachment files require a separate filesystem backup. Preferred MySQL CLI and SQLAlchemy fallback roundtrips are tested on disposable data. Post-restore verification reapplies missing batch schema and changes the live revision. Web restore is disabled by default because thread/process-local maintenance is not a distributed recovery solution. Follow the offline restore runbook. Factory reset is destructive across all batches and requires separate acceptance testing; normal deletion remains record-scoped.

## 8. Live synchronization contract
### Change detection
SQLAlchemy session flush/bulk hooks mark a transaction dirty. Before commit, the singleton revision token is changed using the same transaction. Rollback clears dirty state and never publishes committed data that did not exist. This catches application ORM writes, uploads, imports and audited operations across application instances sharing the database.

### Client behavior
1. Visible authenticated page requests `/live/version` approximately every **1.5 seconds**.
2. If unchanged, no full page/dataset refresh is performed.
3. If changed, the current page's authorized HTML snapshot or native dataset loader is fetched.
4. Initial HTML includes its revision; no unconditional initial snapshot/morph. Editor pages never morph the form or any ancestor. Only explicitly marked read-only `data-live-region` islands (attachments, list results, book usage, case snapshots) update. General read-only pages use inner-content morphing, keeping the main element stable. Active book tabs have stable IDs.
5. Background HTML/version/report requests are read-only session snapshots: they neither consume action flashes nor set authentication/session cookies. This avoids older polling responses replacing newer foreground session state. HTTP 401/409 preserves the page and draft rather than following redirects.
6. Invoice save locks controls until confirmed; session writes serialize, save waits for an in-flight session write, and stale serial/date/report responses are ignored. Amount reset is limited to explicit successful save. Dirty settings remain a unit; pristine settings update values without replacing event-bound controls.
7. Only action flashes auto-dismiss. Batch context is a stable strip, and QR instructions are collapsible help; background refresh never recreates transient notifications.
8. Same-tab successful mutations and BroadcastChannel hints schedule earlier checks (~80 ms).
9. Hidden tabs defer checking and catch up on visibility; offline/failures retry with increasing delay up to 30 seconds.

### Permissions and limits
- Version response contains an opaque revision and an admin-only aggregate review count; no invoice/user/filename/amount details.
- Every snapshot still runs normal authorization; a denied live invoice snapshot returns 403 rather than patching a redirected list into the screen.
- A removed invoice snapshot returns 404; a notice explains that local unsaved input has been kept.
- Typical visible remote latency is **1–2 seconds plus network/rendering**, not zero-latency WebSocket push.
- Raw SQL or external filesystem edits outside application hooks are not detected automatically; explicitly bump revision or record an application audit event.
- Draft preservation is intentional: a currently edited invoice is not silently rewritten by a remote change. Review newer data before resolving a conflict.
- Large-scale concurrency/load performance has not been tested. Global invalidation can refresh unrelated visible screens after any application mutation; consider topic-specific revisions if production scale requires it.

## 9. Configuration, installation and deployment
`DEPLOYMENT.md` is authoritative. `.env.example` documents variables; production startup requires a real `DATABASE_URL` and random 32+ character secret, secure cookies and HTTPS. Use one Gunicorn worker with threads. `SCHEDULER_ENABLED` controls the built-in backup job; `ALLOW_WEB_RESTORE=False` is the safe default; `MAINTENANCE_MODE=True` stops request database access. Local launcher/run.py use DATABASE_URL, with an optional legacy DEV_DATABASE_URL development override. QA helpers are never production entrypoints.

## 10. Operational contracts
- Keep database + uploads + matching source/config backup sets. SQL and files are not one atomic transaction.
- Invoice CSV imports commit row by row; later failures do not roll back successful rows.
- All invoice/book/summary exports carry batch identity. Reports default to selected batch, not a mixed historical total.
- API lists may span batches if no selector; every row includes identity. With more than one batch, serial detail/adjacent/upload endpoints require `batch_id` and return JSON 409 if missing. Web serial-only QR links refuse ambiguity. QR v2 contains batch/invoice ID. Native client updates are outside this source package.
- No ordinary user may correct archived attachments or invoices. Permissions are independent of batch selection.
- Runtime dependencies and source assets are included; credentials/database/attachment content are not.

## 11. Verification and acceptance evidence
See `QA_REPORT.md` and `qa/results/` for current, rerun results. Route screenshots cover login, all main desktop/mobile screens, batch lifecycle, validation and deletion dialogs; state fixtures are labeled. Migration uses 100 synthetic legacy books, repeated and continued series, import rejection and preservation checks. Destructive restore was tested only on the disposable batch database. Hardware camera/native-client, interrupted restore, production user data and sustained load remain acceptance tasks. No claim of exhaustive assurance is made.

## 12. Final release and cleanup policy
This release contains one canonical application source tree and one screenshot archive. Superseded generated source ZIPs, merged-code documents, alternate galleries, root-level scratch scripts/logs and redundant screenshot exports were removed from the workspace. The original user-uploaded `uploads/code.md` is preserved as input provenance, not an alternative final release.

The separate screenshot archive contains images/index/report only—no second application. QA support is explicitly segregated from runtime code. Runtime data, credentials, virtual environments and thumbnail caches are excluded from distribution. `MANIFEST.sha256` lets you verify source-file integrity.


## Latest UI/bug-fix revision
The modal stacking fix, larger typography/controls and violet glass styling are retained. Batch regression additionally fixed disappearing validation messages, batch context on cross-tab writes, global URL-query concatenation errors, numeric navigation past 9999, all-batch user cleanup, row prevalidation for imports and missing batch/book/revision data in fallback backups. `QA_REPORT.md` supersedes all previous counts.

## Amount safety extension
`app/detection.py` owns `detection_policy` (singleton configurable manual/automatic modes and three optional limits) and `review_cases` (invoice/user-day/batch-day case identity, reasons, snapshot/fingerprint, Open/Cleared/Resolved status, reviewer/note). No new invoice amount/flag columns or renumbering are required. Database tables are created additively; explicit Workbench scripts are in `sql/`.

A Session before-commit hook, installed before the live-revision hook, derives cases transactionally from all affected invoice dates. Creates/edits/deletes, CSV import and normal ORM writes are covered; raw SQL requires `rescan-flags`. Book/serial batch identity remains independent. The singleton policy lock serializes computation, with READ COMMITTED database isolation to observe preceding committed daily totals. Service writers acquire policy before invoice locks. Two concurrent-save regression cases pass; production throughput remains unbenchmarked.

Statistical baselines use earlier positive invoice dates within 180 days, capped at 20,000 history rows. Prefer user history, then batch, then cross-batch invoice history; 20 samples, max 500. Daily groups need 14 observations, max 90. Daily outliers are high-only because a low day may be unfinished. Invoice low/high positives use conservative median/MAD references; zero is exempt. Open suspicious historical invoice/day cases are excluded from baselines. This is a transparent heuristic, not an external ML/fraud classifier or guaranteed typo detector. Exact formula and settings are in INSTALLATION-GUIDE.html.

Admin routes: `/admin/review/`, `/admin/review/settings`, `/admin/review/<case_id>`, and POST rescan. Admin invoice detail/list and live sidebar badge show flags; clerks cannot view review metadata. Notification counts are admin-only. Draft review notes and their ancestor containers are never morphed; the read-only source snapshot may update beside them. Stale policy versions/source fingerprints are rejected. Clear keeps a review audit snapshot; source changes can reopen; corrections/disabling checks resolve without pretending an admin verified them. Invoice/date/user/day membership identifies a case independently of mutable detection policy/baseline, so unchanged verified cases do not repeatedly reopen on settings rescans.

Both MySQL CLI and fallback dumps include policy/cases; user deletion clears reviewer FKs while audit retains original identity. Case invoice FK uses ON DELETE SET NULL to retain removed-source evidence. Factory reset deletes all cases before invoice reset (destructive workflow not executed). Large full rescans run synchronously; use maintenance/off-peak operation on large datasets. Windows production WSGI option is Waitress; Linux Gunicorn remains supported.

## Batch controls and historical identity reservations · 9 October 2026

**This release requires a database upgrade**, even if amount safety is already installed.

| Batch state | Normal users | Administrators |
|---|---|---|
| Open | Usual authorized entry and viewing | Full access |
| Locked or archived | Read-only; no invoice/book/media mutations | Can enter and correct records |
| Hidden | Not listed or accessible by direct link/API | Visible and editable |

Administrators have View, Lock/Unlock, Hide/Unhide and Archive/Unarchive controls. States are independent and reversible; unarchive does not silently unlock/unhide. Archiving requires verification. Permission changes sync without resetting typed fields: a remote lock disables saves; a hidden workspace preserves the local draft with an access notice.

**Identity rule:** the same invoice date + numeric serial is reserved globally across all batches and states. Leading zeros are ignored. Every date/serial combination used by an invoice remains owned by that invoice, even after corrections. Only deleting that invoice releases all its combinations. Administrators cannot override this rule. An invoice can return to its own historical combination. Different dates can use the same serial in different batches, provided neither combination is reserved; the existing within-batch physical-page uniqueness still applies. CSV rename/skip/overwrite cannot evade another invoice's reservation.

### Additive schema and enforcement
- `batches.locked` and `batches.hidden`: non-null Boolean flags, default false.
- `invoices.serial_numeric`: persisted generated BIGINT, unsigned numeric cast of the preserved serial string.
- `uq_date_serial_numeric`: global unique index on current date/numeric serial; positive ASCII numeric serial check (1 through 2147483647).
- `invoice_identity_reservations`: composite primary key `(date, serial_numeric)`, owning `invoice_id` FK with ON DELETE CASCADE and invoice lookup index. No ownership transfer on correction.
- `invoices_reserve_ai` and `invoices_reserve_au`: AFTER INSERT/UPDATE database triggers claim keys transactionally. Conflicting ownership raises `INVOICE_IDENTITY_RESERVED` and rolls back the statement. Unique-key locking protects simultaneous claims, including ordinary raw SQL writes. App services check reservations first for readable errors.
- The reservation table is internal: never manually update/truncate/delete it. A privileged DBA can disable database protections; direct destructive schema operations are not an application permission boundary.
- Current and historical keys are included in CLI and fallback backups. Restore child-table ordering and computed-column exclusion are handled. Replacing the database with an older backup necessarily restores that backup's historical state; do not restore partial invoice-only dumps.

### Offline upgrade procedure (existing installation)
1. Finish/save drafts. Stop the application, scheduler and **all other writers**, including direct SQL clients. Back up the full database, uploaded files, configuration and matching source. Rehearse on a staging copy of the exact target server version.
2. In Workbench select the intended schema and run `sql/preflight_batch_controls.sql`. Both invalid-serial and duplicate-date/numeric-serial result sets must be empty. Conflicts report original IDs; the migration never deletes, renumbers or rewrites them. Resolve legitimate corrections manually with the data owner before retrying. Do not run fresh-install SQL over existing data.
3. Replace source while retaining `.env` and uploads. Install `requirements.txt`. Set `DATABASE_URL` to the intended schema, then run `python upgrade_database.py` while offline. Normal development uses `DATABASE_URL` too; any existing `DEV_DATABASE_URL` explicitly overrides it only for development, so align/remove that override. Offline schema account needs authorized CREATE/ALTER/INDEX/REFERENCES/TRIGGER/CREATE ROUTINE/ALTER ROUTINE and metadata privileges (MySQL binary logging may require DBA authorization); use a least-privilege runtime account after controlled upgrades where appropriate. MySQL DDL is not rollback-safe: a failure may leave additive changes; keep offline, inspect the error and recover from the matching backup if needed.
4. Run the verification statements in the preflight SQL comments. Confirm both reservation triggers and zero missing current reservations; reconcile original invoice/book IDs, dates, serial strings, amounts, counts, timestamps, media and audit rows.
5. Verify admin and normal-user permissions, corrections, historical duplicate rejection, deletion/reuse and a complete backup/restore in staging. Restart the application and reopen pages once for the new assets. Preserve original 100 books; `prepare_batches.py` remains the separate guarded helper for preparing an empty repeated-number Batch 2.

**Historical boundary:** at upgrade, all existing invoices' current keys are reserved. Older date/serial values corrected before this feature was installed cannot be reliably reconstructed and are not claimed. From installation onward, every successfully committed key is retained until invoice deletion. Rolled-back writes do not reserve keys.

New installations also run `python upgrade_database.py` after database/config setup and before entry. The fresh SQL schema alone is not sufficient: the Python migration installs/verifies the triggers. Your exact MySQL/Workbench installation must be validated in staging; this release was exercised on MySQL 8.4.7 and MariaDB on Linux, not physical Windows/Workbench.

## Startup repair release
Read `INSTALLATION-GUIDE.html` for the authoritative setup/recovery steps. New tools: `Setup InvoiceFlow.bat`, `Diagnose InvoiceFlow.bat`, `launch.py`, `diagnose.py`, `configure.py`. Normal startup never migrates. Run `upgrade_database.py` offline with authorized migration privileges before diagnosis/launch. Verification uses a parameterless SQL SECURITY DEFINER procedure (`invoiceflow_verify_identity_guards`); runtime requires EXECUTE, not TRIGGER privileges. Runtime should have SELECT only on reservation rows. PyMySQL[rsa] supports MySQL caching-SHA2 authentication. Existing admin credentials are not reapplied from legacy config during startup.


