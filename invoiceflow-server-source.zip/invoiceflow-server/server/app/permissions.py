# app/permissions.py
"""
Per-user capabilities (what a data-entry user is allowed to do).

Admins always have every capability. For data-entry users the effective value
is, in order:
  1. an explicit row in user_capabilities (set by an admin), otherwise
  2. for 'data.export' the legacy users.can_export flag, otherwise
  3. DEFAULT_ALLOWED (True): new and existing users keep today's behaviour
     until an admin switches a function off.
"""

from flask import g

from app.extensions import db

# (key, group, label, description)
CAPABILITIES = [
    ('mobile.access', 'Mobile app', 'Use the mobile scanner app',
     'Lets the app connect with this user\'s API key and use the invoice endpoints.'),
    ('invoice.create', 'Invoices', 'Create invoices',
     'Add new invoices in the web app and the mobile app.'),
    ('invoice.edit', 'Invoices', 'Edit invoices',
     'Change invoice details. Data-entry users still only touch their own invoices.'),
    ('invoice.delete', 'Invoices', 'Delete invoices',
     'Remove invoices. Data-entry users still only touch their own invoices.'),
    ('media.upload', 'Documents', 'Upload photos and documents',
     'Attach scanned pages and files to an invoice (web, scanner page, and mobile app).'),
    ('media.delete', 'Documents', 'Delete uploaded files',
     'Remove attached photos and documents.'),
    ('notes.create', 'Notes', 'Add notes and note attachments',
     'Write notes on an invoice, optionally with files attached.'),
    ('notes.delete', 'Notes', 'Delete notes',
     'Remove notes on an invoice.'),
    ('links.create', 'Links', 'Link invoices (merge or relation)',
     'Link a past and a current invoice, mark duplicates or adjustments.'),
    ('links.delete', 'Links', 'Remove links',
     'Remove an existing link between invoices.'),
    ('data.export', 'Data', 'Export CSV files',
     'Download invoice CSV exports.'),
    ('data.import', 'Data', 'Import CSV and book files',
     'Import invoices, books and legacy files, and download the sample CSV.'),
]

CAPABILITY_KEYS = [c[0] for c in CAPABILITIES]
CAPABILITY_LABELS = {c[0]: c[2] for c in CAPABILITIES}
DEFAULT_ALLOWED = True

DENIED_MESSAGE = 'Your admin has not allowed this action for your account: {label}.'


def capability_label(cap):
    return CAPABILITY_LABELS.get(cap, cap)


def _overrides_for(user):
    """Cache the overrides of one user for the current request."""
    from app.models import UserCapability
    cache = g.setdefault('_capability_cache', {})
    if user.id not in cache:
        cache[user.id] = {row.capability: bool(row.allowed)
                          for row in UserCapability.query.filter_by(user_id=user.id).all()}
    return cache[user.id]


def user_can(user, cap, *, refresh=False):
    """True if `user` may perform capability `cap`."""
    if user is None or not getattr(user, 'is_authenticated', True):
        return False
    if cap not in CAPABILITY_LABELS:
        raise ValueError(f'Unknown capability: {cap}')
    if user.is_admin():
        return True
    if not user.is_data_entry():
        return False
    if refresh:
        g.pop('_capability_cache', None)
    overrides = _overrides_for(user)
    if cap in overrides:
        return overrides[cap]
    if cap == 'data.export':
        return bool(user.can_export)
    return DEFAULT_ALLOWED


def effective_capabilities(user):
    """{capability: bool} for every capability, for the given user."""
    return {key: user_can(user, key) for key in CAPABILITY_KEYS}


def set_capabilities(user, allowed_map, admin_id=None):
    """Store an explicit allow/deny for every key in allowed_map.

    Returns a dict of {cap: (old, new)} for the entries that actually changed.
    The legacy can_export flag is kept in sync with data.export.
    """
    if user.is_admin():
        raise ValueError('Admins always have every capability; nothing to store.')
    from app.models import UserCapability
    changes = {}
    current = effective_capabilities(user)
    for cap, allowed in allowed_map.items():
        if cap not in CAPABILITY_LABELS:
            raise ValueError(f'Unknown capability: {cap}')
        allowed = bool(allowed)
        row = UserCapability.query.filter_by(user_id=user.id, capability=cap).first()
        if row is None:
            row = UserCapability(user_id=user.id, capability=cap)
            db.session.add(row)
        row.allowed = allowed
        row.updated_by = admin_id
        if cap == 'data.export':
            user.can_export = allowed
        if current.get(cap) != allowed:
            changes[cap] = (current.get(cap), allowed)
    db.session.flush()
    g.pop('_capability_cache', None)
    return changes


def reset_capabilities(user):
    """Remove every explicit override, falling back to defaults."""
    from app.models import UserCapability
    UserCapability.query.filter_by(user_id=user.id).delete(synchronize_session=False)
    db.session.flush()
    g.pop('_capability_cache', None)
