"""Database-backed invalidation: shared by workers; no invoice data in notifications.
Version changes commit atomically with application writes, never on rollback.
"""
import uuid
from flask import Blueprint, jsonify, request, g, session as flask_session
from flask.sessions import SecureCookieSessionInterface
from flask_login import current_user
from sqlalchemy import event, select, update
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from app.extensions import db

class LiveRevision(db.Model):
    __tablename__ = 'live_revision'
    id = db.Column(db.Integer, primary_key=True)
    token = db.Column(db.String(32), nullable=False)

@event.listens_for(Session, 'after_flush')
def mark_flush(session, context):
    if any(not isinstance(obj, LiveRevision) for obj in
           list(session.new) + list(session.dirty) + list(session.deleted)):
        session.info['live_dirty'] = True

@event.listens_for(Session, 'do_orm_execute')
def mark_bulk(state):
    if state.is_update or state.is_delete or state.is_insert:
        state.session.info['live_dirty'] = True

@event.listens_for(Session, 'before_commit')
def bump_at_commit(session):
    session.flush()
    if session.info.pop('live_dirty', False):
        # Core update: avoid recursion. Take the singleton lock LAST.
        session.connection().execute(update(LiveRevision.__table__).where(
            LiveRevision.id == 1).values(token=uuid.uuid4().hex))

@event.listens_for(Session, 'after_rollback')
def clear_rollback(session):
    session.info.pop('live_dirty', None)

bp = Blueprint('live', __name__, url_prefix='/live')

def revision():
    return db.session.execute(select(LiveRevision.token).where(
        LiveRevision.id == 1)).scalar_one_or_none() or 'uninitialized'

@bp.get('/version')
def version():
    if not current_user.is_authenticated:
        return jsonify(error='Authentication required'), 401
    payload = dict(revision=revision())
    if current_user.is_admin():
        from app.detection import ReviewCase
        payload['review_open_count'] = ReviewCase.query.filter_by(status='open').count()
    return jsonify(payload)

def is_snapshot_request():
    return (request.method in ('GET', 'HEAD') and request.headers.get('X-Live-Sync') == '1'
            and request.endpoint not in ('auth.login', 'auth.logout', 'static', None))

class SnapshotSafeSessionInterface(SecureCookieSessionInterface):
    def save_session(self, app, session, response):
        # Background HTML is read-only, including when a stale route wants to
        # flash/redirect. Never send an old cookie over a newer foreground save.
        if is_snapshot_request():
            protected = {self.get_cookie_name(app), app.config.get('REMEMBER_COOKIE_NAME', 'remember_token')}
            cookies = response.headers.getlist('Set-Cookie')
            response.headers.remove('Set-Cookie')
            for cookie in cookies:
                if cookie.split('=', 1)[0].strip() not in protected:
                    response.headers.add('Set-Cookie', cookie)
            response.vary.add('Cookie')
            response.vary.add('X-Live-Sync')
            response.headers['Cache-Control'] = 'no-store'
            return
        super().save_session(app, session, response)

def init_realtime(app):
    app.session_interface = SnapshotSafeSessionInterface()
    app.register_blueprint(bp)
    @app.before_request
    def capture_snapshot():
        if is_snapshot_request() and not current_user.is_authenticated:
            return jsonify(error='Authentication required'), 401
        if not request.path.startswith('/static/') and current_user.is_authenticated:
            g.live_revision = revision()
            g.snapshot_csrf_missing = is_snapshot_request() and not flask_session.get('csrf_token')
    @app.after_request
    def snapshot_header(response):
        if response.mimetype == 'text/html' and getattr(g, 'snapshot_csrf_missing', False):
            # A rendered token generated only in this discarded session is unusable.
            response = jsonify(error='Session token changed. Draft retained; sign in again.', code='csrf_session')
            response.status_code = 409
        if response.mimetype == 'text/html' or is_snapshot_request():
            response.vary.add('X-Live-Sync')
        if hasattr(g, 'live_revision'):
            response.headers['X-Live-Revision'] = g.live_revision
        return response
    with app.app_context():
        if db.session.get(LiveRevision, 1) is None:
            db.session.add(LiveRevision(id=1, token=uuid.uuid4().hex))
            try:
                db.session.commit()
            except IntegrityError:
                # Another worker seeded the same singleton concurrently.
                db.session.rollback()


