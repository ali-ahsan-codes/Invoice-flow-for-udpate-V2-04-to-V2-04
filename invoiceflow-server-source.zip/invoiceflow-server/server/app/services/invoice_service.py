# app/services/invoice_service.py

import os
import math
from sqlalchemy.exc import IntegrityError, DBAPIError
from datetime import date, datetime, timezone
from sqlalchemy import func, cast, Integer
from flask import current_app
from app import db
from app.models import Invoice, User, AuditLog, Book, Batch, InvoiceIdentityReservation, totals_included_clause, totals_amount_expr
from app.batches import current_batch_id, mutation_error
from app.utils.helpers import parse_date_string


# ============================================================
# Book serial range helpers
# ============================================================

def get_book_serial_range(book):
    """
    Return (start_serial, end_serial) for a book based on cumulative
    capacities of all books ordered by book_number.
    """
    batch = db.session.get(Batch, book.batch_id or current_batch_id())
    cumulative = batch.start_serial - 1
    for b in Book.query.execution_options(all_batches=True).filter_by(batch_id=batch.id).order_by(Book.book_number).all():
        if b.id == book.id:
            return cumulative + 1, cumulative + b.capacity
        cumulative += b.capacity
    return None, None


def _find_next_serial(book, exclude_invoice_id=None):
    """
    Core helper: find the next available serial in a book's range.

    Strategy:
      1. Look at all serials currently used in this book's range.
      2. Try max_used + 1 (continue from where we left off).
      3. If max+1 is out of range OR already taken, scan from `start`
         to find the first gap.
      4. If no gap exists, return None (book truly full).

    Uses a single DB query for the whole range — fast even on huge books.
    """
    start, end = get_book_serial_range(book)
    if start is None:
        return None

    # Single query: which of these are used?
    q = db.session.query(Invoice.serial_number, Invoice.id).filter(
        Invoice.batch_id == book.batch_id,
        cast(Invoice.serial_number, Integer).between(start,end)
    )
    rows = q.all()

    used = set()
    for s, inv_id in rows:
        if exclude_invoice_id and inv_id == exclude_invoice_id:
            continue
        if s:
            used.add(str(int(s)).zfill(4))

    # Highest used numeric serial
    max_used_num = None
    for s in used:
        try:
            n = int(s)
            if max_used_num is None or n > max_used_num:
                max_used_num = n
        except (ValueError, TypeError):
            continue

    # ---- Step 1: try max+1 (continue flow) ----
    if max_used_num is not None and max_used_num < end:
        candidate = str(max_used_num + 1).zfill(4)
        if candidate not in used:
            return candidate

    # ---- Step 2: fallback — scan from start for first gap ----
    for n in range(start, end + 1):
        s = str(n).zfill(4)
        if s not in used:
            return s

    return None


def get_book_usage(book):
    """
    Return usage info for a book:
    { start, end, capacity, used, remaining, next_serial, max_used_serial }
    """
    start, end = get_book_serial_range(book)
    used = Invoice.query.filter(Invoice.book_id == book.id).count()
    remaining = max(book.capacity - used, 0)

    max_used = db.session.query(func.max(cast(Invoice.serial_number, Integer))).filter(
        Invoice.book_id == book.id,
        Invoice.serial_number.isnot(None),
    ).scalar()

    next_serial = _find_next_serial(book)

    return {
        'start': start,
        'end': end,
        'capacity': book.capacity,
        'used': used,
        'remaining': remaining,
        'next_serial': next_serial,
        'next_page': (int(next_serial) - start + 1 if next_serial and str(next_serial).isdigit() and start is not None else None),
        'max_used_serial': max_used,
    }


def generate_next_serial_in_book(book_number, exclude_invoice_id=None):
    """
    Public wrapper. Returns (serial_str, error_message).
    If error, serial_str is None.
    """
    book = Book.query.filter_by(book_number=book_number).first()
    if not book:
        return None, f"Book #{book_number} is not configured."

    next_serial = _find_next_serial(book, exclude_invoice_id)
    if next_serial:
        return next_serial, None

    return None, f"Book #{book_number} is full ({book.capacity} pages used)."


# ============================================================
# Global serial (fallback)
# ============================================================

def generate_next_serial(date_obj=None, exclude_invoice_id=None):
    """Global next serial. Used only when no book is specified."""
    bid = current_batch_id()
    batch = db.session.get(Batch, bid)
    serials = Invoice.query.execution_options(all_batches=True).filter_by(batch_id=bid).all()
    nums = [int(i.serial_number) for i in serials if i.id != exclude_invoice_id and i.serial_number.isdigit()]
    return str(max(nums, default=batch.start_serial-1) + 1).zfill(4)


def get_recent_invoices(limit=10):
    return Invoice.query.order_by(Invoice.created_at.desc()).limit(limit).all()


# ============================================================
# Book assignment (serial determines book)
# ============================================================

def assign_invoice_book(invoice, serial_number):
    """
    Assign invoice to a book based on cumulative book capacities.
    The serial number is authoritative — book is derived from it.
    """
    bid = invoice.batch_id or current_batch_id()
    invoice.batch_id = bid
    batch = db.session.get(Batch, bid)
    invoice.book_id = None
    invoice.book_page = None
    try: serial = int(serial_number)
    except (TypeError, ValueError): return
    books = Book.query.execution_options(all_batches=True).filter_by(batch_id=bid).order_by(Book.book_number).all()
    cumulative = batch.start_serial - 1
    for book in books:
        if cumulative < serial <= cumulative + book.capacity:
            invoice.book_id = book.id; invoice.book_page = serial - cumulative; return
        cumulative += book.capacity
    # Entry is limited to configured printed ranges. No silent overflow books.
    return


# ============================================================
# CRUD
# ============================================================

def create_invoice(data, user_id, ip_address=None):
    """Create a new invoice."""
    from app.detection import policy_lock
    with db.session.no_autoflush: policy_lock(db.session)
    if not data.get('date'):
        return None, "Date is required."
    if not data.get('serial_number'):
        return None, "Serial number is required."

    amounts = data.get('amounts', [])
    if not amounts or len(amounts) == 0:
        return None, "At least one amount is required."

    try:
        amounts = [float(a) for a in amounts]
    except (TypeError, ValueError):
        return None, "All amounts must be valid numbers."

    if len(amounts) > 20 or any(not math.isfinite(a) or a < 0 for a in amounts):
        return None, 'Enter between 1 and 20 finite, non-negative amounts.'
    total_amount = sum(amounts)
    if not math.isfinite(total_amount) or total_amount > 9999999.999:
        return None, 'Invoice total exceeds the supported amount limit.'

    bid = data.get('batch_id') or current_batch_id()
    batch = Batch.query.filter_by(id=bid).with_for_update().populate_existing().first()
    if batch: db.session.info.setdefault('checked_batch_ids', set()).add(batch.id)
    error = mutation_error(batch, db.session.get(User, user_id))
    if error: return None, error
    raw_serial = str(data['serial_number']).strip()
    if not raw_serial.isascii() or not raw_serial.isdigit() or not 1 <= int(raw_serial) <= 2147483647:
        return None, 'Printed serial must be a positive number.'
    data['serial_number'] = str(int(raw_serial)).zfill(4)
    invoice_date = data['date']
    if isinstance(invoice_date, str):
        try: invoice_date = date.fromisoformat(invoice_date)
        except ValueError: return None, 'Invalid invoice date.'
    data['date'] = invoice_date
    conflict = InvoiceIdentityReservation.query.filter(
        InvoiceIdentityReservation.date == invoice_date, InvoiceIdentityReservation.serial_numeric == int(raw_serial),
        InvoiceIdentityReservation.invoice_id != -1).first()
    if conflict:
        return None, 'This date and serial are reserved by an existing invoice (including its previous values). Delete the original invoice before reusing the combination.'

    existing = Invoice.query.execution_options(all_batches=True).filter(Invoice.batch_id == bid, cast(Invoice.serial_number, Integer) == int(data['serial_number'])).first()
    if existing:
        return None, f"Serial number {data['serial_number']} already exists."

    invoice = Invoice(
        batch_id=bid,
        date=data['date'],
        serial_number=data['serial_number'],
        total_amount=total_amount,
        created_by=user_id,
        updated_by=user_id,
        media_required=data.get('media_required', False),
    )
    invoice.set_amounts(amounts)
    assign_invoice_book(invoice, data['serial_number'])

    if not invoice.book_id:
        return None, 'Serial is outside this batch’s configured printed book ranges.'
    db.session.add(invoice)
    try:
        db.session.commit()
    except DBAPIError as exc:
        db.session.rollback()
        if not isinstance(exc, IntegrityError) and 'INVOICE_IDENTITY_RESERVED' not in str(exc): raise
        return None, 'Date/serial already exists globally, or serial already exists in this batch. Nothing was saved.'

    audit = AuditLog(
        user_id=user_id,
        action='create_invoice',
        details={
            'invoice_id': invoice.id,
            'batch_id': invoice.batch_id,
            'date': invoice.date.isoformat(),
            'serial_number': invoice.serial_number,
            'amounts': amounts,
            'total': float(total_amount),
        },
        ip_address=ip_address,
    )
    db.session.add(audit)
    db.session.commit()

    return invoice, None


def update_invoice(invoice_id, data, user_id, ip_address=None):
    from app.detection import policy_lock
    with db.session.no_autoflush: policy_lock(db.session)
    invoice = Invoice.query.filter_by(id=invoice_id).with_for_update().populate_existing().first()
    if not invoice:
        return None, "Invoice not found."

    batch = Batch.query.filter_by(id=invoice.batch_id).with_for_update().populate_existing().first()
    if batch: db.session.info.setdefault('checked_batch_ids', set()).add(batch.id)
    error = mutation_error(batch, db.session.get(User, user_id))
    if error: return None, error

    if data.get('source_version') and data['source_version'] != (invoice.updated_at.isoformat() if invoice.updated_at else ''):
        return None, 'This invoice changed elsewhere. Your draft has not been saved. Review the latest invoice before retrying.'

    if not data.get('date'):
        return None, "Date is required."
    if not data.get('serial_number'):
        return None, "Serial number is required."

    amounts = data.get('amounts', [])
    if not amounts or len(amounts) == 0:
        return None, "At least one amount is required."

    try:
        amounts = [float(a) for a in amounts]
    except (TypeError, ValueError):
        return None, "All amounts must be valid numbers."

    if len(amounts) > 20 or any(not math.isfinite(a) or a < 0 for a in amounts):
        return None, 'Enter between 1 and 20 finite, non-negative amounts.'
    total_amount = sum(amounts)
    if not math.isfinite(total_amount) or total_amount > 9999999.999:
        return None, 'Invoice total exceeds the supported amount limit.'

    raw_serial = str(data['serial_number']).strip()
    if not raw_serial.isascii() or not raw_serial.isdigit() or not 1 <= int(raw_serial) <= 2147483647:
        return None, 'Printed serial must be a positive number.'
    data['serial_number'] = str(int(raw_serial)).zfill(4)
    invoice_date = data['date']
    if isinstance(invoice_date, str):
        try: invoice_date = date.fromisoformat(invoice_date)
        except ValueError: return None, 'Invalid invoice date.'
    data['date'] = invoice_date
    conflict = InvoiceIdentityReservation.query.filter(
        InvoiceIdentityReservation.date == invoice_date, InvoiceIdentityReservation.serial_numeric == int(raw_serial),
        InvoiceIdentityReservation.invoice_id != (invoice_id if 'invoice_id' in locals() else -1)).first()
    if conflict:
        return None, 'This date and serial are reserved by an existing invoice (including its previous values). Delete the original invoice before reusing the combination.'

    existing = Invoice.query.filter(
        cast(Invoice.serial_number, Integer) == int(data['serial_number']),
        Invoice.id != invoice_id,
        Invoice.batch_id == invoice.batch_id,
    ).first()
    if existing:
        return None, f"Serial number {data['serial_number']} already exists."

    probe = Invoice(batch_id=invoice.batch_id)
    assign_invoice_book(probe, data['serial_number'])
    if not probe.book_id:
        return None, 'Serial is outside this batch’s configured printed book ranges.'

    invoice.date = data['date']
    invoice.serial_number = data['serial_number']
    invoice.total_amount = total_amount
    invoice.updated_by = user_id
    invoice.updated_at = datetime.now(timezone.utc)
    invoice.media_required = data.get('media_required', False)
    invoice.set_amounts(amounts)
    assign_invoice_book(invoice, data['serial_number'])

    try:
        db.session.commit()
    except DBAPIError as exc:
        db.session.rollback()
        if not isinstance(exc, IntegrityError) and 'INVOICE_IDENTITY_RESERVED' not in str(exc): raise
        return None, 'Date/serial already exists globally, or serial already exists in this batch. Nothing was saved.'

    audit = AuditLog(
        user_id=user_id,
        action='edit_invoice',
        details={
            'invoice_id': invoice.id,
            'batch_id': invoice.batch_id,
            'date': invoice.date.isoformat(),
            'serial_number': invoice.serial_number,
            'amounts': amounts,
            'total': float(total_amount),
        },
        ip_address=ip_address,
    )
    db.session.add(audit)
    db.session.commit()

    return invoice, None


def delete_invoice(invoice_id, user_id, ip_address=None):
    from app.detection import policy_lock
    with db.session.no_autoflush: policy_lock(db.session)
    invoice = Invoice.query.get(invoice_id)
    if not invoice:
        return False, "Invoice not found."

    batch = Batch.query.filter_by(id=invoice.batch_id).with_for_update().populate_existing().first()
    if batch: db.session.info.setdefault('checked_batch_ids', set()).add(batch.id)
    error = mutation_error(batch, db.session.get(User, user_id))
    if error: return False, error

    from app.services.invoice_history_service import count_links, note_attachment_path
    link_count = count_links(invoice.id)
    if link_count:
        return False, (f'This invoice is linked to {link_count} other invoice(s). '
                       'Remove the links first; this also reverses any merged amount.')

    invoice_snapshot = {
        'invoice_id': invoice.id,
            'batch_id': invoice.batch_id,
        'serial_number': invoice.serial_number,
        'date': invoice.date.isoformat(),
        'total': float(invoice.total_amount),
    }

    upload_folder = current_app.config.get('UPLOAD_FOLDER', 'uploads')
    if not os.path.isabs(upload_folder):
        upload_folder = os.path.join(current_app.root_path, '..', upload_folder)
    os.makedirs(upload_folder, exist_ok=True)

    for media in invoice.media.all():
        file_path = os.path.join(upload_folder, media.file_path)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except OSError:
                pass

    note_paths = [note_attachment_path(m) for note in invoice.notes.all() for m in note.attachments]
    for path in note_paths:
        if os.path.isfile(path):
            try:
                os.remove(path)
            except OSError:
                pass

    db.session.add(AuditLog(
        user_id=user_id,
        action='delete_invoice',
        details=invoice_snapshot,
        ip_address=ip_address,
    ))

    db.session.delete(invoice)
    db.session.commit()
    return True, None


def get_invoice_by_id(invoice_id):
    return Invoice.query.get(invoice_id)


def search_invoices(query, search_type='serial', user_id=None, all_batches=False):
    """Serial or date search. all_batches=True (administrators) searches every batch;
    callers must label results with their batch."""
    base = Invoice.query.execution_options(all_batches=True) if all_batches else Invoice.query
    if search_type == 'serial':
        q = base.filter(Invoice.serial_number.like(f'%{query}%'))
    else:
        search_date = parse_date_string(query, '%Y-%m-%d')
        if not search_date:
            return []
        q = base.filter(Invoice.date == search_date)

    if user_id is not None:
        q = q.filter(Invoice.created_by == user_id)

    return q.order_by(Invoice.date.desc(), Invoice.serial_number.asc()).all()


def get_daily_totals(start_date, end_date, user_id=None):
    query = db.session.query(
        Invoice.date,
        func.sum(totals_amount_expr()).label('total')
    ).filter(Invoice.date.between(start_date, end_date), totals_included_clause())
    if user_id is not None:
        query = query.filter(Invoice.created_by == user_id)
    results = query.group_by(Invoice.date).order_by(Invoice.date).all()
    return [{'date': r.date.isoformat(), 'total': float(r.total)} for r in results]


def get_monthly_totals(start_date, end_date, user_id=None):
    month_str = func.concat(
        func.extract('year', Invoice.date), '-',
        func.lpad(func.extract('month', Invoice.date), 2, '0')
    )
    query = db.session.query(
        month_str.label('month'),
        func.sum(totals_amount_expr()).label('total')
    ).filter(Invoice.date.between(start_date, end_date), totals_included_clause())
    if user_id is not None:
        query = query.filter(Invoice.created_by == user_id)
    results = query.group_by(month_str).order_by(month_str).all()
    return [{'month': r.month, 'total': float(r.total)} for r in results]


def get_work_days_summary(start_date, end_date, user_id=None):
    query = Invoice.query.filter(Invoice.date.between(start_date, end_date), totals_included_clause())
    if user_id is not None:
        query = query.filter(Invoice.created_by == user_id)

    total_revenue = query.with_entities(func.sum(Invoice.total_amount)).scalar() or 0
    invoice_count = query.count()
    working_days = query.with_entities(func.count(func.distinct(Invoice.date))).scalar() or 0
    delta = end_date - start_date
    calendar_days = delta.days + 1

    return {
        'total_amount': float(total_revenue),
        'invoice_count': invoice_count,
        'working_days': working_days,
        'calendar_days': calendar_days,
    }


