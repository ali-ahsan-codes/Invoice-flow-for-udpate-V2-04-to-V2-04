# app/services/audit_service.py

import json
from datetime import datetime, timezone
from flask_login import current_user
from app import db
from app.models import AuditLog, User
from app.utils.helpers import get_client_ip, safe_json_loads


def log_action(user_id=None, action=None, details=None, ip_address=None, commit=True):
    """
    Log a user action to the audit trail.
    
    Args:
        user_id (int): ID of the user performing the action (or None if system)
        action (str): The action performed (e.g., 'login', 'create_invoice', 'delete_invoice')
        details (dict): Additional details about the action (will be JSON serialized)
        ip_address (str): Client IP address
        commit (bool): Whether to commit immediately (default True)
    
    Returns:
        AuditLog: The created audit log entry
    """
    if details is None:
        details = {}
    
    if user_id is None:
        try:
            if current_user and getattr(current_user, 'is_authenticated', False):
                user_id = current_user.id
            else:
                admin_user = User.query.filter_by(role='admin').first()
                if admin_user:
                    user_id = admin_user.id
        except Exception:
            pass

    if user_id is None:
        # Cannot persist audit log without valid user_id FK
        return None

    # Convert details to JSON string
    if isinstance(details, dict):
        details_json = json.dumps(details)
    else:
        details_json = str(details)
    
    # Create audit log entry
    audit = AuditLog(
        user_id=user_id,
        action=action,
        details=details_json,
        ip_address=ip_address,
        timestamp=datetime.now(timezone.utc)
    )
    
    db.session.add(audit)
    
    if commit:
        try:
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            # Don't let audit logging failure break the main operation
            print(f"Audit log failed: {e}")
    
    return audit


def log_action_decorator(action_name):
    """
    Decorator to automatically log actions from functions.
    Usage: @log_action_decorator('create_invoice')
    
    The decorated function must return a dict with 'user_id' and 'details',
    or we extract them from the function's return value or arguments.
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            # Execute the function
            result = func(*args, **kwargs)
            
            # Try to extract user_id from kwargs or current_user
            user_id = kwargs.get('user_id')
            if user_id is None and current_user.is_authenticated:
                user_id = current_user.id
            
            # Try to get details from result or kwargs
            details = kwargs.get('details', {})
            if isinstance(result, dict) and 'details' in result:
                details = result['details']
            elif isinstance(result, dict) and 'invoice' in result:
                # If function returns an invoice, log it
                details = {
                    'invoice_id': result.get('invoice_id'),
                    'serial_number': result.get('serial_number')
                }
            
            # Get IP address
            ip = get_client_ip()
            
            # Log the action
            log_action(user_id, action_name, details, ip)
            
            return result
        return wrapper
    return decorator


def get_audit_logs(
    user_id=None, 
    action=None, 
    from_date=None, 
    to_date=None, 
    page=1, 
    per_page=50,
    order_by='desc'
):
    """
    Retrieve audit logs with optional filters and pagination.
    
    Args:
        user_id (int): Filter by user ID
        action (str): Filter by action type
        from_date (datetime): Start date for filter
        to_date (datetime): End date for filter
        page (int): Page number for pagination
        per_page (int): Items per page
        order_by (str): 'desc' or 'asc'
    
    Returns:
        tuple: (logs, pagination)
    """
    query = AuditLog.query
    
    # Apply filters
    if user_id is not None:
        query = query.filter(AuditLog.user_id == user_id)
    
    if action is not None:
        query = query.filter(AuditLog.action == action)
    
    if from_date is not None:
        query = query.filter(AuditLog.timestamp >= from_date)
    
    if to_date is not None:
        query = query.filter(AuditLog.timestamp <= to_date)
    
    # Apply ordering
    if order_by == 'desc':
        query = query.order_by(AuditLog.timestamp.desc())
    else:
        query = query.order_by(AuditLog.timestamp.asc())
    
    # Paginate
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    # Add user info to each log
    for log in pagination.items:
        log.user = User.query.get(log.user_id)
        log.details_dict = safe_json_loads(log.details) or {}
    
    return pagination


def get_action_types():
    """
    Get a list of all unique action types in the audit log.
    """
    actions = db.session.query(AuditLog.action).distinct().order_by(AuditLog.action).all()
    return [action[0] for action in actions]


def log_backup_action(action_type, filename=None, size=None, success=True):
    """
    Convenience function to log backup/restore actions.
    """
    details = {
        'action_type': action_type,
        'filename': filename,
        'size': size,
        'success': success
    }
    
    user_id = None
    try:
        if current_user and getattr(current_user, 'is_authenticated', False):
            user_id = current_user.id
    except Exception:
        user_id = None

    if not user_id:
        try:
            admin_user = User.query.filter_by(role='admin').first()
            if admin_user:
                user_id = admin_user.id
        except Exception:
            pass

    ip_address = None
    try:
        ip_address = get_client_ip()
    except Exception:
        ip_address = '127.0.0.1'
    
    return log_action(
        user_id=user_id,
        action=f'backup_{action_type}',
        details=details,
        ip_address=ip_address
    )


