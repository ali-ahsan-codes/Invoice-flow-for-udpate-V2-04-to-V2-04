# app/services/invoice_history_service.py
"""Invoice relations, merged amounts, and notes/attachments (complete invoice history).

Rules
- Invoices can be linked across batches. Serials repeat per batch, so a link is always made to
  an explicit (batch, serial) pair.
- Non-admin users may only create/see links, notes and attachments on invoices they created
  (the same rule the invoice view already applies) and only in batches that are not hidden.
  Hidden linked invoices are counted, not shown.
- 'merge' copies the linked invoice's total into the RECEIVING invoice as one extra amount line.
  The linked invoice itself is never changed, so its own record stays intact.
  Unlinking removes that line again (only if it still matches what was merged).
- Invoices that still have links cannot be deleted; unlink first so merged amounts are reversed.
"""

import os
import logging
from datetime import datetime, timezone
from decimal import Decimal

from flask import current_app
from sqlalchemy import or_, and_
from werkzeug.utils import secure_filename

from app import db
from app.models import Invoice, Batch, InvoiceNote, InvoiceNoteMedia, InvoiceLink
from app.batches import mutation_error
from app.services.audit_service import log_action
from app.utils.helpers import allowed_file, generate_unique_filename

logger = logging.getLogger(__name__)

LINK_TYPES = ('related', 'duplicate', 'adjustment')
AMOUNT_ACTIONS = ('none', 'merge')
MERGEABLE_TYPES = ('duplicate', 'adjustment')
MAX_NOTE_CHARS = 2000
MAX_NOTE_FILES = 10
MAX_AMOUNT_LINES = 20
MAX_TOTAL = 9999999.999


# ============================================================
# Helpers
# ============================================================

def can_access_invoice(invoice, user):
    if invoice is None or user is None or not getattr(user, 'is_authenticated', False):
        return False
    if not user.is_admin():
        if invoice.created_by != user.id:
            return False
        batch = db.session.get(Batch, invoice.batch_id)
        if batch is None or batch.hidden:
            return False
    return True


def get_invoice_any_batch(invoice_id):
    """Load an invoice regardless of the request's current batch scope."""
    if not invoice_id:
        return None
    return (Invoice.query.execution_options(all_batches=True)
            .filter(Invoice.id == invoice_id).first())


def _upload_root():
    folder = current_app.config.get('UPLOAD_FOLDER', 'uploads')
    if not os.path.isabs(folder):
        folder = os.path.join(current_app.root_path, '..', folder)
    return folder


def _note_folder(invoice_id):
    path = os.path.join(_upload_root(), f'invoice_{invoice_id}', 'notes')
    os.makedirs(path, exist_ok=True)
    return path


def _remove_quietly(path):
    try:
        if path and os.path.isfile(path):
            os.remove(path)
    except OSError:
        pass


def _round3(value):
    return float(Decimal(str(value)).quantize(Decimal('0.001')))


def _lock_invoice_for_update(invoice_id, user):
    """Lock batch + invoice rows the same way update_invoice does. Returns (invoice, error)."""
    from app.detection import policy_lock
    with db.session.no_autoflush:
        policy_lock(db.session)
    invoice = Invoice.query.execution_options(all_batches=True).filter_by(id=invoice_id).with_for_update().populate_existing().first()
    if not invoice:
        return None, 'Invoice not found.'
    batch = Batch.query.filter_by(id=invoice.batch_id).with_for_update().populate_existing().first()
    if batch:
        db.session.info.setdefault('checked_batch_ids', set()).add(batch.id)
    error = mutation_error(batch, user)
    if error:
        return None, error
    return invoice, None


def _link_query_for(invoice_id):
    return InvoiceLink.query.filter(or_(InvoiceLink.invoice_id == invoice_id,
                                        InvoiceLink.linked_invoice_id == invoice_id))


def count_links(invoice_id):
    return _link_query_for(invoice_id).count()


def count_notes(invoice_id):
    return InvoiceNote.query.filter_by(invoice_id=invoice_id).count()


def get_accessible_invoice_by_serial(batch_id, serial_number, user):
    """Find an invoice in the given batch by printed serial. Returns None unless the user may access it."""
    try:
        number = int(str(serial_number).strip())
    except (TypeError, ValueError):
        return None
    if not 1 <= number <= 2147483647:
        return None
    invoice = (Invoice.query.execution_options(all_batches=True)
               .filter(Invoice.batch_id == batch_id, Invoice.serial_numeric == number)
               .first())
    return invoice if can_access_invoice(invoice, user) else None


# ============================================================
# Notes (comments) with attachments
# ============================================================

def add_note(invoice, user, body, files, ip_address=None):
    """Create a note on an invoice. Text, attachments, or both. Returns (note, error)."""
    if not can_access_invoice(invoice, user):
        return None, 'Invoice not found.'

    body = (body or '').strip()
    if len(body) > MAX_NOTE_CHARS:
        return None, f'Note must be {MAX_NOTE_CHARS} characters or fewer.'

    uploads = [f for f in (files or []) if f is not None and f.filename]
    if not body and not uploads:
        return None, 'Write a note or attach at least one file.'
    if len(uploads) > MAX_NOTE_FILES:
        return None, f'Attach up to {MAX_NOTE_FILES} files per note.'

    planned = []
    for f in uploads:
        original = secure_filename(f.filename)
        if not original or not allowed_file(original):
            return None, f'{f.filename}: File type not allowed.'
        planned.append((f, original))

    batch = db.session.get(Batch, invoice.batch_id)
    error = mutation_error(batch, user)
    if error:
        return None, error

    note = InvoiceNote(invoice_id=invoice.id, body=body or None, created_by=user.id)
    db.session.add(note)
    db.session.flush()

    saved_paths = []
    try:
        folder = _note_folder(invoice.id)
        for f, original in planned:
            stored = generate_unique_filename(original)
            full_path = os.path.join(folder, stored)
            f.save(full_path)
            saved_paths.append(full_path)
            db.session.add(InvoiceNoteMedia(
                note_id=note.id,
                file_name=original[:255],
                file_path=os.path.relpath(full_path, _upload_root()),
                file_size=os.path.getsize(full_path),
                mime_type=(f.content_type or 'application/octet-stream')[:100],
                uploaded_by=user.id,
            ))
        db.session.commit()
    except Exception:
        db.session.rollback()
        for path in saved_paths:
            _remove_quietly(path)
        logger.exception('Invoice note attachment save failed for invoice %s', invoice.id)
        return None, 'An attachment could not be saved. Nothing was saved.'

    log_action(
        user_id=user.id,
        action='add_invoice_note',
        details={
            'invoice_id': invoice.id,
            'note_id': note.id,
            'has_text': bool(body),
            'attachments': len(planned),
        },
        ip_address=ip_address,
    )
    return note, None


def delete_note(invoice, note, user, ip_address=None):
    """Delete a note and its files. Allowed for the note's author or an administrator."""
    if note is None or note.invoice_id != invoice.id or not can_access_invoice(invoice, user):
        return False, 'Note not found.'
    if not (user.is_admin() or note.created_by == user.id):
        return False, 'Only the author or an administrator can delete this note.'

    batch = db.session.get(Batch, invoice.batch_id)
    error = mutation_error(batch, user)
    if error:
        return False, error

    paths = [os.path.join(_upload_root(), m.file_path) for m in note.attachments]
    note_id = note.id
    db.session.delete(note)
    db.session.commit()
    for path in paths:
        _remove_quietly(path)

    log_action(
        user_id=user.id,
        action='delete_invoice_note',
        details={'invoice_id': invoice.id, 'note_id': note_id, 'attachments': len(paths)},
        ip_address=ip_address,
    )
    return True, None


def note_attachment_path(media):
    return os.path.join(_upload_root(), media.file_path)


# ============================================================
# Relations / merged amounts
# ============================================================

def create_link(invoice, user, linked_serial, link_type='related', amount_action='none',
                link_note=None, ip_address=None, linked_batch_id=None):
    """Link `invoice` to another invoice by (batch, printed serial). Batch defaults to this invoice's batch.

    amount_action='merge' appends the other invoice's total to THIS invoice's amounts.
    Returns (link, error).
    """
    if not can_access_invoice(invoice, user):
        return None, 'Invoice not found.'
    if link_type not in LINK_TYPES:
        return None, 'Choose a valid relation type.'
    if amount_action not in AMOUNT_ACTIONS:
        return None, 'Choose whether to merge the amount or only link.'
    if amount_action == 'merge' and link_type not in MERGEABLE_TYPES:
        return None, 'Amount merge is available for Duplicate or Adjusted relations only.'
    link_note = (link_note or '').strip()[:2000] or None

    try:
        target_batch_id = int(linked_batch_id) if linked_batch_id not in (None, '') else invoice.batch_id
    except (TypeError, ValueError):
        return None, 'Choose a valid batch for the other invoice.'
    if target_batch_id != invoice.batch_id:
        target_batch = db.session.get(Batch, target_batch_id)
        if target_batch is None or (target_batch.hidden and not user.is_admin()):
            return None, 'Choose a valid batch for the other invoice.'

    other = get_accessible_invoice_by_serial(target_batch_id, linked_serial, user)
    if other is None:
        return None, (f'No invoice with serial {str(linked_serial or "").strip() or "?"} '
                      'in the selected batch is available to you.')
    if other.id == invoice.id:
        return None, 'An invoice cannot be linked to itself.'

    existing = InvoiceLink.query.filter(or_(
        and_(InvoiceLink.invoice_id == invoice.id, InvoiceLink.linked_invoice_id == other.id),
        and_(InvoiceLink.invoice_id == other.id, InvoiceLink.linked_invoice_id == invoice.id),
    )).first()
    if existing:
        return None, 'These invoices are already linked.'

    receiver, error = _lock_invoice_for_update(invoice.id, user)
    if error:
        db.session.rollback()
        return None, error

    link = InvoiceLink(
        invoice_id=receiver.id,
        linked_invoice_id=other.id,
        link_type=link_type,
        amount_action=amount_action,
        note=link_note,
        created_by=user.id,
    )

    if amount_action == 'merge':
        amounts = receiver.get_amounts()
        add_value = _round3(other.total_amount)
        if add_value <= 0:
            db.session.rollback()
            return None, f'Invoice {other.serial_number} has no amount to merge.'
        if len(amounts) + 1 > MAX_AMOUNT_LINES:
            db.session.rollback()
            return None, f'This invoice already has {MAX_AMOUNT_LINES} amount lines; merge is not possible.'
        new_total = _round3(sum(amounts) + add_value)
        if new_total > MAX_TOTAL:
            db.session.rollback()
            return None, 'Merged total exceeds the supported amount limit.'

        link.merged_line_index = len(amounts)
        link.merged_amount = Decimal(str(add_value))
        amounts.append(add_value)
        receiver.set_amounts(amounts)
        receiver.total_amount = Decimal(str(new_total))
        receiver.updated_by = user.id
        receiver.updated_at = datetime.now(timezone.utc)

    db.session.add(link)
    db.session.commit()

    log_action(
        user_id=user.id,
        action='link_invoice',
        details={
            'invoice_id': receiver.id,
            'linked_invoice_id': other.id,
            'link_type': link_type,
            'amount_action': amount_action,
            'merged_amount': float(link.merged_amount) if link.merged_amount is not None else None,
            'link_id': link.id,
        },
        ip_address=ip_address,
    )
    return link, None


def delete_link(invoice, link, user, ip_address=None):
    """Remove a link. If it merged an amount, that amount line is removed from the receiver."""
    if link is None or invoice.id not in (link.invoice_id, link.linked_invoice_id):
        return False, 'Link not found.'

    receiver_id = link.invoice_id
    other_id = link.linked_invoice_id
    receiver_ref = get_invoice_any_batch(receiver_id)
    other_ref = get_invoice_any_batch(other_id)
    if not (can_access_invoice(receiver_ref, user) and can_access_invoice(other_ref, user)):
        return False, 'Link not found.'

    receiver, error = _lock_invoice_for_update(receiver_id, user)
    if error:
        db.session.rollback()
        return False, error

    link = InvoiceLink.query.filter_by(id=link.id).with_for_update().first()
    if link is None:
        db.session.rollback()
        return False, 'Link not found.'

    if link.amount_action == 'merge' and link.merged_amount is not None:
        amounts = receiver.get_amounts()
        idx = link.merged_line_index
        if (idx is None or not 0 <= idx < len(amounts)
                or _round3(amounts[idx]) != _round3(link.merged_amount)):
            db.session.rollback()
            return False, ('The merged amount line was changed after linking. '
                           'Correct the amount lines manually, then unlink.')
        del amounts[idx]
        receiver.set_amounts(amounts)
        receiver.total_amount = Decimal(str(_round3(sum(amounts))))
        receiver.updated_by = user.id
        receiver.updated_at = datetime.now(timezone.utc)
        # Keep other merges on the same receiver pointing at their correct lines.
        for other_link in InvoiceLink.query.filter(
                InvoiceLink.invoice_id == receiver_id,
                InvoiceLink.amount_action == 'merge',
                InvoiceLink.merged_line_index > idx).all():
            other_link.merged_line_index -= 1

    details = {
        'invoice_id': receiver_id,
        'linked_invoice_id': other_id,
        'link_type': link.link_type,
        'amount_action': link.amount_action,
        'merged_amount': float(link.merged_amount) if link.merged_amount is not None else None,
        'link_id': link.id,
    }
    db.session.delete(link)
    db.session.commit()

    log_action(user_id=user.id, action='unlink_invoice', details=details, ip_address=ip_address)
    return True, None


def _relation_label(link, viewing_receiver):
    if link.link_type == 'duplicate':
        return 'Duplicate of' if viewing_receiver else 'Has duplicate'
    if link.link_type == 'adjustment':
        return 'Adjusted from' if viewing_receiver else 'Adjusted into'
    return 'Related to'


def _invoice_summary(inv):
    return {
        'id': inv.id,
        'batch_id': inv.batch_id,
        'batch': inv.batch.name if inv.batch else None,
        'serial_number': inv.serial_number,
        'date': inv.date.isoformat() if inv.date else None,
        'total_amount': float(inv.total_amount) if inv.total_amount is not None else 0.0,
        'created_by': inv.creator.username if inv.creator else None,
    }


def _note_payload(note, viewing_invoice_id, serial):
    return {
        'id': note.id,
        'invoice_id': note.invoice_id,
        'invoice_serial': serial,
        'is_own': note.invoice_id == viewing_invoice_id,
        'body': note.body or '',
        'author': note.author.username if note.author else None,
        'created_at': note.created_at.isoformat() if note.created_at else None,
        'can_delete': False,  # set by caller
        'attachments': [{
            'id': m.id,
            'file_name': m.file_name,
            'file_size': m.file_size,
            'mime_type': m.mime_type,
            'uploaded_by': m.uploader.username if m.uploader else None,
            'uploaded_at': m.uploaded_at.isoformat() if m.uploaded_at else None,
        } for m in note.attachments],
    }


def build_history(invoice, user):
    """Complete history for an invoice: its relations, and notes/attachments from itself and
    every linked invoice the user can access. Hidden linked invoices are only counted."""
    relations = []
    hidden_links = 0
    visible_ids = {invoice.id}

    links = _link_query_for(invoice.id).order_by(InvoiceLink.created_at.desc(), InvoiceLink.id.desc()).all()
    for link in links:
        viewing_receiver = link.invoice_id == invoice.id
        other_id = link.linked_invoice_id if viewing_receiver else link.invoice_id
        other = get_invoice_any_batch(other_id)
        if not can_access_invoice(other, user):
            hidden_links += 1
            continue
        visible_ids.add(other.id)
        relations.append({
            'id': link.id,
            'link_type': link.link_type,
            'relation': _relation_label(link, viewing_receiver),
            'amount_action': link.amount_action,
            'merged': link.amount_action == 'merge' and link.merged_amount is not None,
            'receiver_side': viewing_receiver,
            'merged_amount': float(link.merged_amount) if link.merged_amount is not None else None,
            'note': link.note or '',
            'created_by': link.creator.username if link.creator else None,
            'created_at': link.created_at.isoformat() if link.created_at else None,
            'can_unlink': True,
            'other': _invoice_summary(other),
        })

    notes = []
    serials = {}
    for inv in Invoice.query.execution_options(all_batches=True).filter(Invoice.id.in_(visible_ids)).all():
        serials[inv.id] = inv.serial_number
    note_rows = (InvoiceNote.query.filter(InvoiceNote.invoice_id.in_(visible_ids))
                 .order_by(InvoiceNote.created_at.asc(), InvoiceNote.id.asc()).all())
    for note in note_rows:
        payload = _note_payload(note, invoice.id, serials.get(note.invoice_id))
        payload['can_delete'] = bool(user.is_admin() or note.created_by == user.id)
        notes.append(payload)

    return {
        'invoice': _invoice_summary(invoice),
        'relations': relations,
        'hidden_link_count': hidden_links,
        'notes': notes,
    }
