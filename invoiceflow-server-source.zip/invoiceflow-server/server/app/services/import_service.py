# app/services/import_service.py

from app import db
from app.models import Invoice, AuditLog, Book, InvoiceIdentityReservation
from app.services.invoice_service import create_invoice, update_invoice, generate_next_serial, assign_invoice_book
from app.services.audit_service import log_action
from app.utils.helpers import parse_date_string


def parse_amounts(amounts_str, separator='|'):
    """
    Parse amounts from a string, split by separator.
    Returns list of floats or None if parsing fails.
    """
    if not amounts_str:
        return None
    
    try:
        # Try pipe first, then comma, then semicolon
        if separator in amounts_str:
            parts = amounts_str.split(separator)
        elif ',' in amounts_str:
            parts = amounts_str.split(',')
        elif ';' in amounts_str:
            parts = amounts_str.split(';')
        else:
            # Maybe single number
            parts = [amounts_str]
        
        amounts = []
        for p in parts:
            p = p.strip()
            if p:
                amounts.append(float(p))
        return amounts if amounts else None
    except (ValueError, TypeError):
        return None


def parse_serial(serial_str):
    """
    Parse and validate serial number.
    Returns serial number as zero-padded string, or None if invalid.
    """
    if not serial_str:
        return None
    serial_str = serial_str.strip()
    # Remove leading zeros if any, but preserve as string
    # We want to pad to 4 digits: if numeric, convert to int, then pad
    try:
        # Try to parse as integer
        serial_int = int(serial_str)
        if serial_int < 0:
            return None
        return str(serial_int).zfill(4)
    except ValueError:
        # If non-numeric, keep as is but validate length
        if len(serial_str) > 20:
            return None
        return serial_str


def validate_invoice_row(row, col_map):
    """
    Validate a single row of CSV data.
    Returns dict with parsed data and error messages.
    """
    errors = []
    
    # Extract fields based on mapping
    date_str = row.get(col_map.get('date'))
    serial_str = row.get(col_map.get('serial_number'))
    amounts_str = row.get(col_map.get('amounts'))
    total_str = row.get(col_map.get('total'))
    
    # Parse date
    if not date_str:
        errors.append("Date is missing")
        invoice_date = None
    else:
        invoice_date = parse_date_string(date_str, '%Y-%m-%d')
        if not invoice_date:
            errors.append(f"Invalid date format: {date_str}")
    
    # Parse serial
    if not serial_str:
        errors.append("Serial number is missing")
        serial_num = None
    else:
        serial_num = parse_serial(serial_str)
        if not serial_num:
            errors.append(f"Invalid serial number: {serial_str}")
    
    # Parse amounts
    if not amounts_str:
        errors.append("Amounts are missing")
        amounts = None
    else:
        amounts = parse_amounts(amounts_str)
        if not amounts:
            errors.append(f"Invalid amounts format: {amounts_str}")
        elif len(amounts) == 0:
            errors.append("At least one amount is required")
    
    # Parse total (optional)
    total_amount = None
    if total_str:
        try:
            total_amount = float(total_str)
        except ValueError:
            errors.append(f"Invalid total amount: {total_str}")
    
    # Calculate total if not provided
    if amounts and total_amount is None:
        total_amount = sum(amounts)
    elif amounts and total_amount is not None and abs(sum(amounts) - total_amount) > 0.001:
        # Warn if total doesn't match sum, but use the sum
        # We'll use the sum for consistency
        total_amount = sum(amounts)
    
    return {
        'date': invoice_date,
        'serial_number': serial_num,
        'amounts': amounts,
        'total_amount': total_amount,
        'errors': errors,
        'valid': len(errors) == 0
    }


def apply_imported_book_page(invoice, row, col_book=None, col_page=None):
    """Apply explicit book/page values from an exported or legacy CSV row."""
    if not col_book or not col_page:
        return
    raw_book = (row.get(col_book) or '').strip()
    raw_page = (row.get(col_page) or '').strip()
    if not raw_book or not raw_page:
        return
    try:
        book_number = int(raw_book)
        page = int(raw_page)
    except ValueError:
        return
    if book_number < 1 or page < 1:
        return

    from app.services.invoice_service import get_book_serial_range
    book = Book.query.filter_by(batch_id=invoice.batch_id, book_number=book_number).first()
    if not book: raise ValueError('Imported book is not configured in this batch.')
    start, end = get_book_serial_range(book)
    if page > book.capacity or not invoice.serial_number.isdigit() or int(invoice.serial_number) != start + page - 1:
        raise ValueError('Imported book/page does not match the configured serial range.')
    invoice.book_id = book.id
    invoice.book_page = page


def import_invoices_from_csv(rows, header, col_map, duplicate_handling='skip', 
                           user_id=None, ip_address=None, legacy_mode=False,
                           col_id=None, col_book=None, col_page=None):
    """
    Import invoices from CSV rows.
    Returns dict with import statistics.
    
    Args:
        rows: List of CSV rows (as lists)
        header: List of column headers
        col_map: Dict mapping system fields to column names
        duplicate_handling: 'skip', 'overwrite', or 'rename'
        user_id: User ID who is importing
        ip_address: Client IP
        legacy_mode: If True, handle legacy format with Book/Page
        col_id: Legacy column name for ID
        col_book: Legacy column name for Book
        col_page: Legacy column name for Page
    """
    imported = 0
    skipped = 0
    errors = 0
    error_details = []
    
    for row_num, row in enumerate(rows, start=2):  # start at 2 for human-readable (1-indexed with header)
        # Skip empty rows
        if not row or all(cell == '' for cell in row):
            continue
        
        # Map row to dict using header
        row_dict = {}
        for i, col in enumerate(header):
            if i < len(row):
                row_dict[col] = row[i]
            else:
                row_dict[col] = ''
        
        # Validate
        parsed = validate_invoice_row(row_dict, col_map)
        
        if not parsed['valid']:
            errors += 1
            error_details.append({
                'row': row_num,
                'errors': parsed['errors']
            })
            continue
        
        from app.batches import current_batch_id
        batch_col = next((k for k in row_dict if k and k.strip().lower() == 'batch id'), None)
        if batch_col and str(row_dict.get(batch_col,'')).strip() != str(current_batch_id()):
            errors += 1
            error_details.append({'row': row_num, 'errors': ['Batch ID differs from selected batch. Import batches separately.']})
            continue

        # Check the ORIGINAL physical identity before skip/overwrite/rename.
        # Never silently renumber a duplicate of a hidden/archived invoice.
        reservation = InvoiceIdentityReservation.query.filter(
            InvoiceIdentityReservation.date == parsed['date'], InvoiceIdentityReservation.serial_numeric == int(parsed['serial_number'])).first() if str(parsed['serial_number']).isdigit() else None
        collision = db.session.get(Invoice, reservation.invoice_id, execution_options={'all_batches':True}) if reservation else None
        if reservation and not (duplicate_handling == 'overwrite' and collision and collision.batch_id == current_batch_id() and int(collision.serial_number) == int(parsed['serial_number'])):
            errors += 1
            error_details.append({'row': row_num, 'errors': ['Date and serial already in use. Original record must be deleted before reuse.']})
            continue
        # Check for duplicate serial
        existing = Invoice.query.filter_by(serial_number=parsed['serial_number']).first()
        
        if existing:
            if duplicate_handling == 'skip':
                skipped += 1
                continue
            elif duplicate_handling == 'overwrite':
                # Update existing invoice
                # We'll use the update logic
                try:
                    probe = Invoice(batch_id=existing.batch_id, serial_number=parsed['serial_number'])
                    assign_invoice_book(probe, probe.serial_number)
                    apply_imported_book_page(probe, row_dict, col_book, col_page)
                    existing, error = update_invoice(existing.id, parsed, user_id, ip_address)
                    if error: raise ValueError(error)
                    imported += 1
                    # Log edit
                    log_action(
                        user_id=user_id,
                        action='edit_invoice',
                        details={
                            'invoice_id': existing.id,
                            'serial_number': existing.serial_number,
                            'source': 'csv_import_overwrite'
                        },
                        ip_address=ip_address
                    )
                    continue
                except Exception as e:
                    db.session.rollback()
                    errors += 1
                    error_details.append({
                        'row': row_num,
                        'errors': [f"Overwrite failed: {str(e)}"]
                    })
                    continue
            elif duplicate_handling == 'rename':
                # Generate a new serial number
                new_serial = generate_next_serial(parsed['date'])
                parsed['serial_number'] = new_serial
                # Continue to create
            else:
                # Unknown handling -> skip
                skipped += 1
                continue
        
        # Create new invoice
        try:
            from app.batches import current_batch_id
            probe = Invoice(batch_id=current_batch_id(), serial_number=parsed['serial_number'])
            assign_invoice_book(probe, probe.serial_number)
            apply_imported_book_page(probe, row_dict, col_book, col_page)
            # Prepare data for create
            data = {
                'date': parsed['date'],
                'serial_number': parsed['serial_number'],
                'amounts': parsed['amounts'],
                'media_required': False  # Default, can be overridden later
            }
            
            # If we have a total, we could use it, but create_invoice calculates it
            invoice, error = create_invoice(data, user_id, ip_address)
            if error:
                errors += 1
                error_details.append({
                    'row': row_num,
                    'errors': [f"Creation failed: {error}"]
                })
                continue

            apply_imported_book_page(invoice, row_dict, col_book, col_page)
            db.session.commit()
            
            imported += 1
            
            # If legacy mode, we might store original ID or book/page in details
            if legacy_mode and col_id and row_dict.get(col_id):
                # Log the original ID as a note (optional)
                # Could store in a separate field, but we'll just log it
                audit = AuditLog(
                    user_id=user_id,
                    action='import_legacy_invoice',
                    details={
                        'invoice_id': invoice.id,
                        'serial_number': invoice.serial_number,
                        'legacy_id': row_dict.get(col_id),
                        'legacy_book': row_dict.get(col_book),
                        'legacy_page': row_dict.get(col_page)
                    },
                    ip_address=ip_address
                )
                db.session.add(audit)
                db.session.commit()
                
        except Exception as e:
            db.session.rollback()
            errors += 1
            error_details.append({
                'row': row_num,
                'errors': [f"Unexpected error: {str(e)}"]
            })
            continue
    
    return {
        'imported': imported,
        'skipped': skipped,
        'errors': errors,
        'error_details': error_details[:10]  # Limit for display
    }

