# app/services/backup_service.py

import os
import re
import glob
import shutil
import subprocess
import threading
from datetime import datetime, date, timedelta
from sqlalchemy import text
from sqlalchemy.engine import make_url
from flask import current_app, has_app_context
from app import db
from app.models import BackupRecord, SystemSetting
from app.services.audit_service import log_action, log_backup_action
from app.utils.helpers import format_file_size


# ============================================================
# Restore state — module-level so it survives request boundaries
# ============================================================

_restore_lock = threading.Lock()
_restore_state = {
    'in_progress': False,
    'stage': 'idle',
    'progress': 0,
    'filename': None,
    'safety_backup': None,
    'started_at': None,
    'finished_at': None,
    'success': None,
    'message': None,
    'error': None,
}


def is_restore_in_progress():
    with _restore_lock:
        return _restore_state['in_progress']


def get_restore_state():
    with _restore_lock:
        return dict(_restore_state)


def _set_restore_state(**kwargs):
    with _restore_lock:
        _restore_state.update(kwargs)


# ============================================================
# Paths & settings
# ============================================================

def get_backup_dir():
    backup_dir = current_app.config.get('BACKUP_DIR', 'backups')
    if not os.path.isabs(backup_dir):
        backup_dir = os.path.join(current_app.root_path, '..', backup_dir)
    os.makedirs(backup_dir, exist_ok=True)
    return backup_dir


def get_backup_retention_count():
    try:
        retention = SystemSetting.get_value('backup_retention')
        if retention:
            return int(retention)
    except Exception:
        pass
    return current_app.config.get('BACKUP_RETENTION_COUNT', 20)


def get_backup_interval_minutes():
    try:
        interval = SystemSetting.get_value('backup_interval')
        if interval:
            return int(interval)
    except Exception:
        pass
    return current_app.config.get('BACKUP_INTERVAL_MINUTES', 2)


def get_database_url():
    return current_app.config.get('SQLALCHEMY_DATABASE_URI', '')


def parse_db_connection_string(connection_string):
    """Decode SQLAlchemy URLs correctly, including escaped passwords and options."""
    if connection_string and '://' in connection_string:
        url = make_url(connection_string)
        if url.get_backend_name() not in ('mysql', 'mariadb') or not url.database:
            raise ValueError('SQL backups require a MySQL or MariaDB database URL.')
        return {
            'user': url.username or '',
            'password': url.password or '',
            'host': url.host or 'localhost',
            'port': str(url.port or 3306),
            'database': url.database,
        }
    return {
        'user': os.environ.get('MYSQL_USER', 'root'),
        'password': os.environ.get('MYSQL_PASSWORD', ''),
        'host': os.environ.get('MYSQL_HOST', 'localhost'),
        'port': os.environ.get('MYSQL_PORT', '3306'),
        'database': os.environ.get('MYSQL_DATABASE', 'invoiceflow_db'),
    }


def is_mysqldump_available():
    return shutil.which('mysqldump') is not None


def is_mysql_cli_available():
    return shutil.which('mysql') is not None


RESTORE_TABLE_ORDER = [
    'invoice_identity_reservations',
    'review_cases',
    'detection_policy',
    'invoice_media',
    'invoices',
    'audit_logs',
    'books',
    'backup_records',
    'system_settings',
    'users',
    'batches',
    'live_revision',
]


def _drop_restore_tables_with_mysql(db_config):
    drop_sql = "SET FOREIGN_KEY_CHECKS=0;\nDROP PROCEDURE IF EXISTS invoiceflow_verify_identity_guards;\n"
    for table in RESTORE_TABLE_ORDER:
        drop_sql += f"DROP TABLE IF EXISTS `{table}`;\n"
    drop_sql += "SET FOREIGN_KEY_CHECKS=1;\n"

    cmd = [
        'mysql',
        f'--host={db_config["host"]}',
        f'--port={db_config["port"]}',
        f'--user={db_config["user"]}',
        f'--password={db_config["password"]}',
        db_config['database'],
    ]

    proc = subprocess.run(
        cmd,
        input=drop_sql,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
    )
    if proc.returncode != 0:
        err = (proc.stderr or '').replace(db_config.get('password', ''), '***')
        return False, f"mysql table cleanup failed: {err}"
    return True, None


def _drop_restore_tables_with_sqlalchemy():
    try:
        with db.engine.connect() as conn:
            with conn.begin():
                conn.execute(text('SET FOREIGN_KEY_CHECKS=0'))
                conn.execute(text('DROP PROCEDURE IF EXISTS invoiceflow_verify_identity_guards'))
                for table in RESTORE_TABLE_ORDER:
                    conn.execute(text(f'DROP TABLE IF EXISTS `{table}`'))
                conn.execute(text('SET FOREIGN_KEY_CHECKS=1'))
        return True, None
    except Exception as exc:
        return False, f"SQLAlchemy table cleanup failed: {str(exc)}"


def _is_sqlalchemy_fallback_dump(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            head = f.read(2000)
        return '-- SQLAlchemy fallback dump' in head
    except Exception:
        return False


# ============================================================
# SQL sanitizer — strips statements that would block other
# connections during a restore.
# ============================================================

def _sanitize_sql_content(content):
    """
    Remove LOCK TABLES / UNLOCK TABLES statements and prepend a header
    that disables foreign-key and unique-key checks so the restore runs
    without holding table-level locks that would block every other
    request during the restore window.
    """
    out_lines = []
    for line in content.split('\n'):
        stripped = line.strip().upper()
        if stripped.startswith('LOCK TABLES'):
            continue
        if stripped.startswith('UNLOCK TABLES'):
            continue
        out_lines.append(line)

    header = (
        "SET FOREIGN_KEY_CHECKS=0;\n"
        "SET UNIQUE_CHECKS=0;\n"
        "SET AUTOCOMMIT=1;\n"
    )
    footer = (
        "\nSET UNIQUE_CHECKS=1;\n"
        "SET FOREIGN_KEY_CHECKS=1;\n"
    )
    return header + '\n'.join(out_lines) + footer


# ============================================================
# Create backup
# ============================================================

def create_backup_sqlalchemy(backup_dir):
    from app.models import Invoice, InvoiceMedia, User, AuditLog, BackupRecord, SystemSetting, Book, Batch, InvoiceIdentityReservation
    from app.realtime import LiveRevision
    from app.detection import DetectionPolicy, ReviewCase

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    filename = f"backup_{timestamp}.sql"
    filepath = os.path.join(backup_dir, filename)

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write("-- SQLAlchemy fallback dump\n")
        f.write(f"-- Generated: {datetime.now().isoformat()}\n\n")
        f.write("SET FOREIGN_KEY_CHECKS=0;\n\n")
        # Consistent repeatable-read snapshot across invoices and reservation history.
        db.session.remove()
        db.session.execute(text('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ'))
        db.session.execute(text('START TRANSACTION WITH CONSISTENT SNAPSHOT'))

        tables = [
            ('detection_policy', DetectionPolicy),
            ('review_cases', ReviewCase),
            ('batches', Batch),
            ('books', Book),
            ('live_revision', LiveRevision),
            ('users', User),
            ('invoices', Invoice),
            ('invoice_identity_reservations', InvoiceIdentityReservation),
            ('invoice_media', InvoiceMedia),
            ('audit_logs', AuditLog),
            ('backup_records', BackupRecord),
            ('system_settings', SystemSetting),
        ]

        for table_name, model in tables:
            f.write(f"-- Table: {table_name}\n")
            rows = db.session.query(model).execution_options(all_batches=True).all()
            if not rows:
                continue
            columns = [c.key for c in model.__table__.columns if c.computed is None]
            for row in rows:
                values = []
                for col in columns:
                    val = getattr(row, col)
                    if val is None:
                        values.append('NULL')
                    elif isinstance(val, bool):
                        values.append('1' if val else '0')
                    elif isinstance(val, (datetime, date)):
                        values.append(f"'{val.isoformat()}'")
                    elif isinstance(val, (int, float)):
                        values.append(str(val))
                    elif hasattr(val, '__float__'):
                        values.append(str(val))
                    else:
                        val_escaped = str(val).replace('\\', '\\\\').replace("'", "''")
                        values.append(f"'{val_escaped}'")
                f.write(f"INSERT INTO `{table_name}` (`{'`, `'.join(columns)}`) VALUES ({', '.join(values)});\n")
            f.write("\n")

        f.write("SET FOREIGN_KEY_CHECKS=1;\n")

    db.session.rollback()  # End the read-only snapshot before audit/record writes.
    return filename, filepath


def create_backup(manual=True):
    try:
        backup_dir = get_backup_dir()
        db_url = get_database_url()
        db_config = parse_db_connection_string(db_url)
        warning = None
        method = 'sqlalchemy'

        if is_mysqldump_available():
            method = 'mysql'
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
            filename = f"backup_{timestamp}.sql"
            filepath = os.path.join(backup_dir, filename)

            cmd = [
                'mysqldump',
                f'--host={db_config["host"]}',
                f'--port={db_config["port"]}',
                f'--user={db_config["user"]}',
                f'--password={db_config["password"]}',
                '--single-transaction',
                '--routines',
                '--triggers',
                db_config['database'],
            ]

            with open(filepath, 'w', encoding='utf-8') as f:
                result = subprocess.run(
                    cmd, stdout=f, stderr=subprocess.PIPE, text=True, check=False
                )

            if result.returncode != 0:
                # A restricted runtime account cannot dump routine/trigger DDL.
                # Remove the incomplete file and take a complete model-row snapshot.
                # Offline restore recreates guards with the migration account.
                try: os.remove(filepath)
                except OSError: pass
                warning = 'MySQL CLI dump unavailable/denied; complete SQLAlchemy data backup created. Offline restore requires the migration account to rebuild schema/guards.'
                method = 'sqlalchemy'
                filename, filepath = create_backup_sqlalchemy(backup_dir)
        else:
            filename, filepath = create_backup_sqlalchemy(backup_dir)

        file_size = os.path.getsize(filepath)
        db.session.add(BackupRecord(filename=filename, size=file_size))
        db.session.commit()

        log_backup_action('manual' if manual else 'auto', filename=filename, size=file_size, success=True)
        rotate_backups()

        return {
            'success': True,
            'filename': filename,
            'filepath': filepath,
            'size': file_size,
            'size_formatted': format_file_size(file_size),
            'method': method,
            'warning': warning,
        }

    except Exception as e:
        log_backup_action('failed', filename=None, success=False)
        return {'success': False, 'error': f"Backup failed: {str(e)}", 'filename': None}


def rotate_backups():
    backup_dir = get_backup_dir()
    retention_count = get_backup_retention_count()
    backup_files = glob.glob(os.path.join(backup_dir, 'backup_*.sql'))

    if len(backup_files) <= retention_count:
        return 0

    backup_files.sort(key=os.path.getmtime)
    files_to_delete = len(backup_files) - retention_count

    deleted_count = 0
    for filepath in backup_files[:files_to_delete]:
        try:
            filename = os.path.basename(filepath)
            os.remove(filepath)
            BackupRecord.query.filter(BackupRecord.filename == filename).delete()
            db.session.commit()
            log_action(
                user_id=None,
                action='backup_rotated',
                details={'filename': filename, 'reason': 'retention_limit'},
                commit=True,
            )
            deleted_count += 1
        except Exception as e:
            print(f"Failed to delete old backup {filepath}: {e}")

    return deleted_count


def auto_backup_job(app=None):
    app_obj = app or (current_app._get_current_object() if has_app_context() else None)
    if app_obj is None:
        print("Auto backup skipped: no Flask app was supplied and no app context exists.")
        return

    with app_obj.app_context():
        try:
            # Don't fire a backup while a restore is running.
            if is_restore_in_progress():
                return
            enabled = SystemSetting.get_value('auto_backup_enabled', 'True')
            if enabled.lower() != 'true':
                return
            result = create_backup(manual=False)
            if result['success']:
                print(f"Auto backup created: {result['filename']} ({result['size_formatted']})")
            else:
                print(f"Auto backup failed: {result.get('error', 'Unknown error')}")
        except Exception as e:
            print(f"Auto backup job failed: {e}")


# ============================================================
# List / info
# ============================================================

def get_backup_files():
    backup_dir = get_backup_dir()
    backup_files = glob.glob(os.path.join(backup_dir, 'backup_*.sql'))

    result = []
    for filepath in backup_files:
        try:
            filename = os.path.basename(filepath)
            stat = os.stat(filepath)

            match = re.search(r'backup_(\d{8}_\d{6})\.sql', filename)
            timestamp_str = match.group(1) if match else None
            if timestamp_str:
                try:
                    timestamp = datetime.strptime(timestamp_str, '%Y%m%d_%H%M%S')
                except ValueError:
                    timestamp = datetime.fromtimestamp(stat.st_mtime)
            else:
                timestamp = datetime.fromtimestamp(stat.st_mtime)

            result.append({
                'filename': filename,
                'filepath': filepath,
                'size': stat.st_size,
                'size_formatted': format_file_size(stat.st_size),
                'created_at': timestamp.isoformat(),
                'created_at_formatted': timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            })
        except Exception as e:
            print(f"Error reading backup file {filepath}: {e}")
            continue

    result.sort(key=lambda x: x['created_at'], reverse=True)
    return result


def get_backup_info(filename):
    backup_dir = get_backup_dir()
    filepath = os.path.join(backup_dir, filename)

    if not os.path.exists(filepath):
        return None

    stat = os.stat(filepath)
    match = re.search(r'backup_(\d{8}_\d{6})\.sql', filename)
    timestamp_str = match.group(1) if match else None
    if timestamp_str:
        try:
            timestamp = datetime.strptime(timestamp_str, '%Y%m%d_%H%M%S')
        except ValueError:
            timestamp = datetime.fromtimestamp(stat.st_mtime)
    else:
        timestamp = datetime.fromtimestamp(stat.st_mtime)

    is_valid = False
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            head = f.read(2000)
            if ('CREATE TABLE' in head
                    or 'INSERT INTO' in head
                    or '-- MySQL dump' in head
                    or '-- SQLAlchemy fallback dump' in head):
                is_valid = True
    except Exception:
        pass

    return {
        'filename': filename,
        'filepath': filepath,
        'size': stat.st_size,
        'size_formatted': format_file_size(stat.st_size),
        'created_at': timestamp.isoformat(),
        'created_at_formatted': timestamp.strftime('%Y-%m-%d %H:%M:%S'),
        'is_valid': is_valid,
        'last_modified': datetime.fromtimestamp(stat.st_mtime).isoformat(),
    }


# ============================================================
# Restore — shared engine
# ============================================================

def _execute_sql_file(filepath):
    ok, error = _replay_sql_file(filepath)
    if not ok:
        return ok, error
    try:
        from app.utils.db_utils import ensure_columns, migrate_batches
        from app.realtime import LiveRevision
        import uuid
        db.session.remove()
        db.create_all()
        ensure_columns(current_app._get_current_object())
        migrate_batches()
        revision = db.session.get(LiveRevision, 1)
        if revision: revision.token = uuid.uuid4().hex
        else: db.session.add(LiveRevision(id=1, token=uuid.uuid4().hex))
        from app.detection import DetectionPolicy
        if db.session.get(DetectionPolicy,1) is None: db.session.add(DetectionPolicy(id=1))
        db.session.info['detect_all'] = True
        db.session.commit()
        return True, None
    except Exception as exc:
        db.session.rollback()
        return False, 'Post-restore schema verification failed; keep offline: ' + str(exc)


def _replay_sql_file(filepath):
    """
    Execute a .sql file against the current database.

    Strategy:
    - SQLAlchemy fallback dumps: drop via ORM, db.create_all(), replay inserts.
    - Real mysql dumps: drop, then hand to the mysql CLI with LOCK/UNLOCK
      statements stripped and FK checks disabled (see _sanitize_sql_content).
    - No mysql CLI: SQLAlchemy fallback path.
    """
    db_url = get_database_url()
    db_config = parse_db_connection_string(db_url)

    # Flush the pool so any stale connections don't hold old metadata /
    # open transactions across the restore boundary.
    try:
        db.session.remove()
        db.engine.dispose()
    except Exception:
        pass

    # 1) SQLAlchemy fallback dumps (rows-only inserts) need the ORM schema first.
    if _is_sqlalchemy_fallback_dump(filepath):
        ok, err = _drop_restore_tables_with_sqlalchemy()
        if not ok:
            return False, err

        try:
            db.create_all()
        except Exception as exc:
            return False, f"SQLAlchemy schema rebuild failed: {str(exc)}"

        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            sql_lines = f.readlines()

        statements = []
        current_stmt = []
        for line in sql_lines:
            stripped = line.strip()
            if not stripped or stripped.startswith('--') or stripped.startswith('/*'):
                continue
            upper = stripped.upper()
            if upper.startswith('LOCK TABLES') or upper.startswith('UNLOCK TABLES'):
                continue
            current_stmt.append(line)
            if stripped.endswith(';'):
                statements.append("".join(current_stmt))
                current_stmt = []
        if current_stmt:
            statements.append("".join(current_stmt))

        try:
            with db.engine.connect() as conn:
                with conn.begin():
                    conn.execute(text('SET FOREIGN_KEY_CHECKS=0'))
                    for stmt in statements:
                        stmt_clean = stmt.strip()
                        if stmt_clean:
                            conn.exec_driver_sql(stmt_clean)
                    conn.execute(text('SET FOREIGN_KEY_CHECKS=1'))
        except Exception as exc:
            return False, f"SQLAlchemy restore failed: {str(exc)}"

        return True, None

    # 2) Full mysql dumps with DDL go through the mysql CLI.
    if is_mysql_cli_available():
        ok, err = _drop_restore_tables_with_mysql(db_config)
        if not ok:
            return False, err

        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            raw = f.read()

        sanitized = _sanitize_sql_content(raw)

        cmd = [
            'mysql',
            f'--host={db_config["host"]}',
            f'--port={db_config["port"]}',
            f'--user={db_config["user"]}',
            f'--password={db_config["password"]}',
            db_config['database'],
        ]
        proc = subprocess.run(
            cmd,
            input=sanitized,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=False,
        )
        if proc.returncode != 0:
            err = (proc.stderr or '').replace(db_config.get('password', ''), '***')
            return False, f"mysql restore failed: {err}"

        # Flush the pool again so nothing holds stale connections.
        try:
            db.session.remove()
            db.engine.dispose()
        except Exception:
            pass

        return True, None

    # 3) Final fallback for environments without mysql CLI: rebuild ORM schema.
    ok, err = _drop_restore_tables_with_sqlalchemy()
    if not ok:
        return False, err

    try:
        db.create_all()
    except Exception as exc:
        return False, f"SQLAlchemy schema rebuild failed: {str(exc)}"

    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        sql_lines = f.readlines()

    statements = []
    current_stmt = []
    for line in sql_lines:
        stripped = line.strip()
        if not stripped or stripped.startswith('--') or stripped.startswith('/*'):
            continue
        upper = stripped.upper()
        if upper.startswith('LOCK TABLES') or upper.startswith('UNLOCK TABLES'):
            continue
        current_stmt.append(line)
        if stripped.endswith(';'):
            statements.append("".join(current_stmt))
            current_stmt = []
    if current_stmt:
        statements.append("".join(current_stmt))

    try:
        with db.engine.connect() as conn:
            with conn.begin():
                conn.execute(text('SET FOREIGN_KEY_CHECKS=0'))
                for stmt in statements:
                    stmt_clean = stmt.strip()
                    if stmt_clean:
                        conn.exec_driver_sql(stmt_clean)
                conn.execute(text('SET FOREIGN_KEY_CHECKS=1'))
    except Exception as exc:
        return False, f"SQLAlchemy restore failed: {str(exc)}"

    return True, None


def restore_backup(filename):
    try:
        backup_dir = get_backup_dir()
        filepath = os.path.join(backup_dir, filename)

        if not os.path.exists(filepath):
            return {'success': False, 'error': f"Backup file '{filename}' not found."}

        ok, err = _execute_sql_file(filepath)
        if not ok:
            log_backup_action('restore', filename=filename, success=False)
            return {'success': False, 'error': err}

        log_backup_action('restore', filename=filename, success=True)
        return {'success': True, 'message': f"Database restored from {filename}"}

    except Exception as e:
        log_backup_action('restore', filename=filename, success=False)
        return {'success': False, 'error': f"Restore failed: {str(e)}"}


# ============================================================
# Background restore worker — this is the fix for the hang
# ============================================================

def start_restore_in_background(app, filepath, original_name):
    """
    Kick off a restore on a background thread. Returns immediately.
    The restore state is tracked in the module-level _restore_state dict,
    which the /backup/restore-status endpoint reads.
    """
    with _restore_lock:
        if _restore_state['in_progress']:
            return False, 'A restore is already in progress.'
        _restore_state.update({
            'in_progress': True,
            'stage': 'starting',
            'progress': 0,
            'filename': original_name,
            'safety_backup': None,
            'started_at': datetime.now().isoformat(),
            'finished_at': None,
            'success': None,
            'message': None,
            'error': None,
        })

    def _worker(app_obj, path, name):
        with app_obj.app_context():
            try:
                _set_restore_state(stage='validating', progress=5)
                valid, reason = validate_sql_file(path)
                if not valid:
                    _set_restore_state(
                        in_progress=False,
                        finished_at=datetime.now().isoformat(),
                        success=False,
                        error=f'SQL file validation failed: {reason}',
                        stage='failed',
                        progress=0,
                    )
                    return

                _set_restore_state(stage='creating_safety_backup', progress=10)
                safety = create_backup(manual=True)
                if not safety.get('success'):
                    _set_restore_state(
                        in_progress=False,
                        finished_at=datetime.now().isoformat(),
                        success=False,
                        error=f'Could not create safety backup: {safety.get("error", "unknown")}',
                        stage='failed',
                        progress=0,
                    )
                    return

                _set_restore_state(
                    stage='restoring',
                    progress=40,
                    safety_backup=safety['filename'],
                )

                ok, err = _execute_sql_file(path)
                if not ok:
                    _set_restore_state(
                        in_progress=False,
                        finished_at=datetime.now().isoformat(),
                        success=False,
                        error=err,
                        stage='failed',
                        progress=0,
                    )
                    return

                try:
                    log_action(
                        user_id=None,
                        action='restore_backup',
                        details={
                            'source': 'upload',
                            'filename': name,
                            'safety_backup': safety['filename'],
                            'success': True,
                        },
                        commit=True,
                    )
                except Exception:
                    pass

                _set_restore_state(
                    in_progress=False,
                    finished_at=datetime.now().isoformat(),
                    success=True,
                    message=f"Database restored successfully from '{name}'. "
                            f"Safety backup saved as {safety['filename']}.",
                    stage='done',
                    progress=100,
                )

            except Exception as e:
                _set_restore_state(
                    in_progress=False,
                    finished_at=datetime.now().isoformat(),
                    success=False,
                    error=str(e),
                    stage='failed',
                    progress=0,
                )
            finally:
                if path and os.path.exists(path):
                    try:
                        os.remove(path)
                    except OSError:
                        pass

    t = threading.Thread(target=_worker, args=(app, filepath, original_name), daemon=True)
    t.start()
    return True, None


# ============================================================
# Validation, delete, cleanup, test
# ============================================================

def validate_sql_file(filepath):
    try:
        size = os.path.getsize(filepath)
        if size == 0:
            return False, 'File is empty.'
        if size > 2 * 1024 * 1024 * 1024:
            return False, 'File is larger than 2 GB.'

        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            head = f.read(4000)

        markers = ['CREATE TABLE', 'INSERT INTO', '-- MySQL dump',
                   '-- SQLAlchemy fallback dump', 'SET FOREIGN_KEY_CHECKS']
        if not any(m in head for m in markers):
            return False, ('File does not look like a MySQL/SQL dump '
                           '(no CREATE TABLE / INSERT INTO / dump header found).')
        return True, None
    except Exception as e:
        return False, f'Could not read file: {e}'


def delete_backup(filename):
    try:
        backup_dir = get_backup_dir()
        filepath = os.path.join(backup_dir, filename)

        if not os.path.exists(filepath):
            return {'success': False, 'error': f"Backup file '{filename}' not found."}

        os.remove(filepath)
        BackupRecord.query.filter(BackupRecord.filename == filename).delete()
        db.session.commit()

        log_action(
            user_id=None,
            action='backup_deleted',
            details={'filename': filename},
            commit=True,
        )
        return {'success': True, 'message': f"Backup '{filename}' deleted successfully."}

    except Exception as e:
        return {'success': False, 'error': f"Failed to delete backup: {str(e)}"}


def cleanup_old_backups(max_age_days=30):
    cutoff_date = datetime.now() - timedelta(days=max_age_days)
    backup_dir = get_backup_dir()
    backup_files = glob.glob(os.path.join(backup_dir, 'backup_*.sql'))

    deleted_count = 0
    for filepath in backup_files:
        try:
            mtime = datetime.fromtimestamp(os.path.getmtime(filepath))
            if mtime < cutoff_date:
                filename = os.path.basename(filepath)
                os.remove(filepath)
                BackupRecord.query.filter(BackupRecord.filename == filename).delete()
                deleted_count += 1
        except Exception:
            continue

    if deleted_count > 0:
        db.session.commit()
        log_action(
            user_id=None,
            action='backup_cleanup',
            details={'deleted_count': deleted_count, 'max_age_days': max_age_days},
            commit=True,
        )

    return {'deleted_count': deleted_count}


def test_backup_system():
    try:
        backup_dir = get_backup_dir()
        test_file = os.path.join(backup_dir, '.test_write')
        try:
            with open(test_file, 'w') as f:
                f.write('test')
            os.remove(test_file)
        except Exception as e:
            return {
                'success': False,
                'mysqldump_available': is_mysqldump_available(),
                'error': f"Backup directory '{backup_dir}' is not writable: {e}",
            }

        has_mysqldump = is_mysqldump_available()
        if has_mysqldump:
            return {
                'success': True,
                'mysqldump_available': True,
                'message': "mysqldump available and backup directory writable.",
            }
        return {
            'success': True,
            'mysqldump_available': False,
            'message': ("mysqldump not found; SQLAlchemy SQL dump fallback is active "
                        "and directory writable."),
        }

    except Exception as e:
        return {
            'success': False,
            'mysqldump_available': False,
            'error': f"Backup system test failed: {str(e)}",
        }


