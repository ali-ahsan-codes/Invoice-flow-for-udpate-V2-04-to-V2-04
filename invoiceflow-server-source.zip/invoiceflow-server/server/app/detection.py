"""Transactional typo checks and admin review. Statistical hints, not fraud verdicts.

Every normal ORM invoice commit also commits its derived cases. A singleton policy
lock serializes detector work. No invoice values/timestamps are rewritten. Raw SQL
changes require the administrator's explicit rescan command/button.
"""
import hashlib
import json
from datetime import datetime, timezone, timedelta
from decimal import Decimal, InvalidOperation
from statistics import median
from flask import Blueprint, request, render_template, redirect, url_for, flash, abort
from flask_login import current_user
from sqlalchemy import event, select, inspect, func
from sqlalchemy.orm import Session
from app.extensions import db
from app.models import Invoice, Batch, User, AuditLog
from app.utils.decorators import admin_required


def now():
    return datetime.now(timezone.utc)


class DetectionPolicy(db.Model):
    __tablename__ = 'detection_policy'
    id = db.Column(db.Integer, primary_key=True)
    manual_enabled = db.Column(db.Boolean, nullable=False, default=True)
    automatic_enabled = db.Column(db.Boolean, nullable=False, default=True)
    invoice_limit = db.Column(db.Numeric(13, 3), nullable=True)
    user_daily_limit = db.Column(db.Numeric(13, 3), nullable=True)
    batch_daily_limit = db.Column(db.Numeric(13, 3), nullable=True)
    version = db.Column(db.Integer, nullable=False, default=1)
    updated_at = db.Column(db.DateTime, nullable=False, default=now)


class ReviewCase(db.Model):
    __tablename__ = 'review_cases'
    id = db.Column(db.Integer, primary_key=True)
    case_key = db.Column(db.String(128), nullable=False, unique=True)
    kind = db.Column(db.String(20), nullable=False)
    batch_id = db.Column(db.Integer, db.ForeignKey('batches.id', ondelete='CASCADE'), nullable=False)
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoices.id', ondelete='SET NULL'), nullable=True)
    subject_user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    invoice_date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(16), nullable=False, default='open')
    fingerprint = db.Column(db.String(64), nullable=False)
    reasons_json = db.Column(db.Text, nullable=False)
    snapshot_json = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=now)
    updated_at = db.Column(db.DateTime, nullable=False, default=now)
    reviewed_by = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    reviewed_at = db.Column(db.DateTime, nullable=True)
    review_note = db.Column(db.Text, nullable=True)
    resolution = db.Column(db.String(120), nullable=True)
    __table_args__ = (db.Index('ix_review_status_batch_date', 'status', 'batch_id', 'invoice_date'),
                      db.Index('ix_review_invoice', 'invoice_id'))

    @property
    def snapshot(self):
        return json.loads(self.snapshot_json)

    @property
    def reasons(self):
        return json.loads(self.reasons_json)


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def fingerprint(value):
    return hashlib.sha256(encode(value).encode()).hexdigest()


def money(value):
    return str(Decimal(str(value)).quantize(Decimal('0.001')))


def policy_lock(session):
    session.info['batch_write_lock'] = True
    return session.execute(select(DetectionPolicy).where(DetectionPolicy.id == 1)
                           .with_for_update().execution_options(populate_existing=True, all_batches=True)).scalar_one()


@event.listens_for(Session, 'before_flush')
def collect_changes(session, context, instances):
    if session.info.get('detect_running') or not getattr(db, '_detector_ready', False):
        return
    scopes = session.info.setdefault('detect_scopes', set())
    for inv in list(session.new) + list(session.dirty) + list(session.deleted):
        if not isinstance(inv, Invoice):
            continue
        if inv in session.dirty and not session.is_modified(inv, include_collections=False):
            continue
        session.info.setdefault('detect_refs', []).append(inv)
        state = inspect(inv)
        dates = {inv.date}
        batches = {inv.batch_id}
        dates.update(state.attrs.date.history.deleted)
        batches.update(state.attrs.batch_id.history.deleted)
        for bid in batches:
            for day in dates:
                if bid and day: scopes.add((bid, day))


@event.listens_for(Session, 'after_flush_postexec')
def collect_default_identity(session, context):
    for inv in session.info.pop('detect_refs', []):
        if inv.batch_id and inv.date:
            session.info.setdefault('detect_scopes', set()).add((inv.batch_id, inv.date))


@event.listens_for(Session, 'after_begin')
def prepare_session(session, transaction, connection):
    # Initialization creates these tables before installing the ready flag.
    session.info['detect_ready'] = bool(getattr(db, '_detector_ready', False))


@event.listens_for(Session, 'after_rollback')
def discard_work(session):
    session.info.pop('detect_scopes', None)
    session.info.pop('detect_refs', None)
    session.info.pop('detect_all', None)
    session.info.pop('detect_running', None)


def heuristic(amount, values, label, minimum, allow_low=True):
    if amount <= 0 or len(values) < minimum:
        return []
    values = [float(v) for v in values if v > 0]
    if len(values) < minimum:
        return []
    typical = median(values)
    mad = median([abs(v - typical) for v in values])
    scale = max(1.4826 * mad, typical * .15, 1.0)
    high = max(typical + 6 * scale, typical * 4, typical + 10)
    low = min(typical - 6 * scale, typical / 10)
    direction = 'high' if amount > high else ('low' if allow_low and amount < low and typical - amount >= 10 else None)
    if not direction:
        return []
    return [{'source': 'automatic', 'text': f'Unusually {direction} compared with {label}. '
             f'Typical {typical:.3f}; {len(values)} historical samples; '
             f"{'upper' if direction == 'high' else 'lower'} reference {(high if direction == 'high' else low):.3f}. "
             'Possible typing error; verify against the paper invoice.',
             'median': round(typical, 3), 'sample_count': len(values), 'direction': direction}]


def manual_reason(amount, limit, enabled, label):
    if enabled and limit is not None and Decimal(str(amount)) > limit:
        return [{'source': 'manual', 'text': f'{label} {money(amount)} exceeds the configured limit {money(limit)}.',
                 'limit': money(limit)}]
    return []


def evaluate(session, policy, scopes, full=False):
    """Evaluate whole affected dates, including old date on moves and remaining totals on delete."""
    if full:
        scopes = set(session.execute(select(Invoice.batch_id, Invoice.date).distinct()
                                    .execution_options(all_batches=True)).all())
        scopes.update(session.execute(select(ReviewCase.batch_id, ReviewCase.invoice_date).distinct()).all())
    if not scopes:
        return
    user_names = dict(session.execute(select(User.id, User.username)).all())
    batch_names = dict(session.execute(select(Batch.id, Batch.name)).all())
    history_cache = {}
    # Existing open suspicious invoices do not contaminate statistical baselines.
    excluded = set(session.scalars(select(ReviewCase.invoice_id).where(
        ReviewCase.kind == 'invoice', ReviewCase.status == 'open', ReviewCase.invoice_id.is_not(None))))
    bad_days = set(session.execute(select(ReviewCase.batch_id, ReviewCase.invoice_date).where(
        ReviewCase.status == 'open')).all())
    for bid, day in sorted(scopes, key=lambda x: (x[1], x[0])):
        cases = {c.case_key: c for c in session.scalars(select(ReviewCase).where(
            ReviewCase.batch_id == bid, ReviewCase.invoice_date == day))}
        invoices = list(session.scalars(select(Invoice).where(Invoice.batch_id == bid, Invoice.date == day)
                        .order_by(Invoice.id).execution_options(all_batches=True, populate_existing=True)))
        # Fetch moved invoice cases in one query rather than one lookup per invoice.
        invoice_cases = {c.case_key: c for c in session.scalars(select(ReviewCase).where(
            ReviewCase.invoice_id.in_([i.id for i in invoices])))} if invoices else {}
        seen = set()
        cache_key = day
        if cache_key not in history_cache:
            history_cache[cache_key] = list(session.execute(select(
                Invoice.id, Invoice.batch_id, Invoice.created_by, Invoice.date, Invoice.total_amount
            ).where(Invoice.date < day, Invoice.date >= day - timedelta(days=180), Invoice.total_amount > 0)
              .order_by(Invoice.date.desc(), Invoice.id.desc()).limit(20000)
              .execution_options(all_batches=True)).all()) if policy.automatic_enabled else []
        history = [r for r in history_cache[cache_key] if r.id not in excluded]
        high_today = set()

        def store(key, kind, amount, reasons, snapshot, invoice_id=None, user_id=None):
            seen.add(key)
            case = cases.get(key)
            if case is None:
                case = invoice_cases.get(key)
            fp = fingerprint(snapshot)
            if reasons:
                if case is None:
                    case = ReviewCase(case_key=key, kind=kind, batch_id=bid, invoice_id=invoice_id,
                                      subject_user_id=user_id, invoice_date=day, status='open',
                                      fingerprint=fp, snapshot_json=encode(snapshot), reasons_json=encode(reasons))
                    session.add(case);cases[key] = case
                elif case.status != 'cleared' or case.fingerprint != fp:
                    dirty = case.fingerprint != fp or case.status != 'open' or case.reasons_json != encode(reasons)
                    case.status = 'open';case.fingerprint = fp
                    case.snapshot_json = encode(snapshot);case.reasons_json = encode(reasons)
                    case.invoice_id = invoice_id;case.subject_user_id = user_id;case.resolution = None
                    case.invoice_date = day;case.batch_id = bid
                    if dirty: case.updated_at = now()
                    if dirty and case.reviewed_at:
                        # AuditLog retains the former review. Current case is no longer verified.
                        case.reviewed_by = None;case.reviewed_at = None;case.review_note = None
            elif case is not None and case.status == 'open':
                case.status = 'resolved';case.resolution = 'No longer matches enabled checks';case.updated_at = now()
            return case

        for inv in invoices:
            amount = float(inv.total_amount)
            reasons = manual_reason(inv.total_amount, policy.invoice_limit, policy.manual_enabled, 'Invoice total')
            if policy.automatic_enabled:
                own = [float(r.total_amount) for r in history if r.created_by == inv.created_by][:500]
                same_batch = [float(r.total_amount) for r in history if r.batch_id == bid][:500]
                values, label = (own, 'this user’s previous invoices') if len(own) >= 20 else (
                    (same_batch, 'previous invoices in this batch') if len(same_batch) >= 20 else
                    ([float(r.total_amount) for r in history][:500], 'previous invoices across batches'))
                reasons += heuristic(amount, values, label, 20)
            snap = {'kind': 'invoice', 'invoice_id': inv.id, 'serial': inv.serial_number, 'batch_id': bid,
                    'batch_name': batch_names.get(bid, 'Deleted batch'), 'date': day.isoformat(),
                    'user_id': inv.created_by, 'user': user_names.get(inv.created_by, 'Former user'),
                    'amount': money(inv.total_amount), 'amounts': inv.get_amounts(),
                    'book_id': inv.book_id, 'page': inv.book_page}
            case = store(f'invoice:{inv.id}', 'invoice', amount, reasons, snap, inv.id, inv.created_by)
            if case and case.status == 'open':high_today.add(inv.id)

        groups = [(None, invoices)]
        groups.extend((uid, [i for i in invoices if i.created_by == uid]) for uid in sorted({i.created_by for i in invoices}))
        for uid, members in groups:
            kind = 'batch_day' if uid is None else 'user_day'
            total = sum((i.total_amount for i in members), Decimal(0))
            reasons = manual_reason(total, policy.batch_daily_limit if uid is None else policy.user_daily_limit,
                                    policy.manual_enabled, 'Combined batch daily total' if uid is None else 'User daily total')
            if policy.automatic_enabled and members:
                histgroups = {}
                for r in history:
                    if (r.batch_id, r.date) in bad_days:continue
                    if uid is not None and r.created_by != uid:continue
                    if uid is None and r.batch_id != bid:continue
                    k = (r.batch_id, r.date)
                    histgroups[k] = histgroups.get(k, 0) + float(r.total_amount)
                # New batches can learn combined per-batch daily history from earlier batches.
                if uid is None and len(histgroups) < 14:
                    histgroups = {}
                    for r in history:
                        if (r.batch_id, r.date) in bad_days:continue
                        k = (r.batch_id, r.date)
                        histgroups[k] = histgroups.get(k, 0) + float(r.total_amount)
                values = list(histgroups.values())[:90]
                reasons += heuristic(float(total), values, 'previous active daily totals (same scope)', 14, allow_low=False)
            member_data = [(i.id, money(i.total_amount), i.created_by, i.serial_number, i.get_amounts()) for i in members]
            snap = {'kind': kind, 'batch_id': bid, 'batch_name': batch_names.get(bid, 'Deleted batch'),
                    'date': day.isoformat(), 'user_id': uid, 'user': user_names.get(uid, 'All users'),
                    'amount': money(total), 'invoice_count': len(members), 'members_digest': fingerprint(member_data),
                    'sample_invoice_ids': [i.id for i in members[:30]]}
            store(f'{kind}:{bid}:{day.isoformat()}:{uid or 0}', kind, total, reasons if members else [], snap, user_id=uid)
        for key, case in cases.items():
            if key not in seen and case.status == 'open':
                case.status = 'resolved';case.resolution = 'Source invoice/day removed or moved';case.updated_at = now()
        excluded.update(high_today)


def reconcile_before_commit(session):
    if session.info.get('detect_running') or not getattr(db, '_detector_ready', False):
        return
    affected = bool(session.info.get('detect_scopes') or session.info.get('detect_all')) or any(
        isinstance(i, Invoice) for i in list(session.new) + list(session.dirty) + list(session.deleted))
    if not affected:return
    session.info['detect_running'] = True
    try:
        # Capture attribute history before flush, then serialize computed totals.
        session.info['detect_running'] = False
        session.info['detect_ready'] = True
        collect_changes(session, None, None)
        session.info['detect_running'] = True
        with session.no_autoflush:
            policy = policy_lock(session)
        pending = [i for i in list(session.new)+list(session.dirty) if isinstance(i,Invoice)]
        session.flush()
        for inv in pending:
            if inv.batch_id and inv.date:session.info.setdefault('detect_scopes',set()).add((inv.batch_id,inv.date))
        evaluate(session, policy, session.info.pop('detect_scopes', set()), full=session.info.pop('detect_all', False))
        session.flush()
    finally:
        session.info.pop('detect_running', None)


bp = Blueprint('detection', __name__, url_prefix='/admin/review')


def parse_limit(raw):
    if not raw.strip():return None
    try:value = Decimal(raw)
    except InvalidOperation:raise ValueError('Limits must be numeric amounts.')
    if not value.is_finite() or value <= 0 or value > Decimal('9999999999.999') or value != value.quantize(Decimal('.001')):
        raise ValueError('Enter a positive limit up to 9999999999.999, with at most three decimal places; blank disables that limit.')
    return value


@bp.route('/settings', methods=['GET', 'POST'])
@admin_required
def settings():
    policy = db.session.get(DetectionPolicy, 1)
    if request.method == 'POST':
        try:
            limits = [parse_limit(request.form.get(k, '')) for k in ('invoice_limit','user_daily_limit','batch_daily_limit')]
            policy = policy_lock(db.session)
            if request.form.get('version', type=int) != policy.version:abort(409, 'Settings changed in another tab. Reload and retry.')
            policy.manual_enabled = request.form.get('manual_enabled') == 'on'
            policy.automatic_enabled = request.form.get('automatic_enabled') == 'on'
            policy.invoice_limit, policy.user_daily_limit, policy.batch_daily_limit = limits
            policy.version += 1;policy.updated_at = now()
            db.session.add(AuditLog(user_id=current_user.id, action='detection_settings', details={
                'manual':policy.manual_enabled,'automatic':policy.automatic_enabled,
                'invoice_limit':str(limits[0]),'user_daily_limit':str(limits[1]),'batch_daily_limit':str(limits[2])}))
            db.session.flush()
            db.session.info['detect_all'] = True
            db.session.commit()
            flash('Detection settings saved. Existing data rechecked; verified unchanged cases stay cleared.', 'success')
            return redirect(url_for('detection.settings'))
        except ValueError as exc:
            db.session.rollback();flash(str(exc), 'danger')
            return render_template('admin/detection_settings.html', policy=policy, submitted=request.form), 400
    return render_template('admin/detection_settings.html', policy=policy, submitted=None)


@bp.get('/')
@admin_required
def index():
    status = request.args.get('status', 'open')
    if status not in ('open','cleared','resolved','all'):abort(400, 'Invalid review status')
    batch = request.args.get('review_batch', type=int)
    q = ReviewCase.query
    if status != 'all':q = q.filter_by(status=status)
    if batch:q = q.filter_by(batch_id=batch)
    cases = q.order_by(ReviewCase.updated_at.desc(), ReviewCase.id.desc()).paginate(page=request.args.get('page',1,type=int),per_page=25,error_out=False)
    counts = dict(db.session.execute(select(ReviewCase.status, func.count(ReviewCase.id)).group_by(ReviewCase.status)).all())
    return render_template('admin/review_cases.html', cases=cases, counts=counts, status=status, review_batch=batch)


@bp.post('/rescan')
@admin_required
def rescan():
    db.session.info['detect_all'] = True
    db.session.add(AuditLog(user_id=current_user.id, action='detection_rescan', details={'requested':True}))
    db.session.commit()
    flash('Existing invoices and daily totals rechecked.', 'success')
    return redirect(url_for('detection.index'))


@bp.route('/<int:case_id>', methods=['GET', 'POST'])
@admin_required
def detail(case_id):
    case = db.session.get(ReviewCase, case_id)
    if not case:abort(404)
    if request.method == 'POST':
        note = request.form.get('note','').strip()
        if not 3 <= len(note) <= 2000:abort(400, 'Add a verification note (3–2000 characters).')
        policy = policy_lock(db.session)
        case = db.session.scalar(select(ReviewCase).where(ReviewCase.id==case_id).with_for_update().execution_options(populate_existing=True))
        db.session.info['detect_running'] = True
        try:
            evaluate(db.session, policy, {(case.batch_id, case.invoice_date)})
            db.session.flush()
            if case.status != 'open' or case.fingerprint != request.form.get('fingerprint'):
                abort(409, 'Case changed or is no longer open. Reopen it before verifying.')
            case.status='cleared';case.reviewed_by=current_user.id;case.reviewed_at=now();case.updated_at=now();case.review_note=note
            db.session.add(AuditLog(user_id=current_user.id,action='clear_review_case',details={
                'case_id':case.id,'case_key':case.case_key,'fingerprint':case.fingerprint,'note':note,
                'snapshot':case.snapshot,'reasons':case.reasons}))
            db.session.commit()
        finally:db.session.info.pop('detect_running',None)
        flash('Verified and unflagged. The review remains in history.', 'success')
        return redirect(url_for('detection.detail',case_id=case.id))
    return render_template('admin/review_case.html', case=case)


def init_detection(app):
    with app.app_context():
        if db.session.get(DetectionPolicy, 1) is None:
            db.session.add(DetectionPolicy(id=1));db.session.commit()
    db._detector_ready = True
    if not event.contains(Session, 'before_commit', reconcile_before_commit):
        event.listen(Session, 'before_commit', reconcile_before_commit, insert=True)
    app.register_blueprint(bp)

    @app.context_processor
    def review_context():
        if not current_user.is_authenticated or not current_user.is_admin():
            return dict(review_open_count=0, flagged_invoice_ids=set(), review_for_invoice=lambda inv: [])
        from app.batches import current_batch_id
        flagged = set(db.session.scalars(select(ReviewCase.invoice_id).where(ReviewCase.status=='open',ReviewCase.kind=='invoice',ReviewCase.batch_id==current_batch_id())))
        def cases_for(inv):
            return ReviewCase.query.filter(ReviewCase.status=='open',ReviewCase.batch_id==inv.batch_id,
                ((ReviewCase.invoice_id==inv.id) | ((ReviewCase.invoice_date==inv.date) & (ReviewCase.kind=='batch_day')) |
                 ((ReviewCase.invoice_date==inv.date) & (ReviewCase.kind=='user_day') & (ReviewCase.subject_user_id==inv.created_by)))).all()
        return dict(review_open_count=ReviewCase.query.filter_by(status='open').count(), flagged_invoice_ids=flagged, review_for_invoice=cases_for)


