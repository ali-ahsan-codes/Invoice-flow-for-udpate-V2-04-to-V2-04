# app/forms.py

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, IntegerField, FloatField, SelectField, BooleanField, DateField, FieldList, SubmitField, HiddenField
from wtforms.validators import DataRequired, Email, Length, NumberRange, Optional, ValidationError, EqualTo
from datetime import date
import re
import math

from app.models import User, Invoice


class LoginForm(FlaskForm):
    """Login form."""
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=80)])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')


class UserCreateForm(FlaskForm):
    """Admin form to create or edit users."""
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=80)])
    email = StringField('Email', validators=[DataRequired(), Email(), Length(max=120)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    role = SelectField('Role', choices=[('data_entry', 'Data Entry'), ('admin', 'Admin')], validators=[DataRequired()])
    can_export = BooleanField('Allow Export (CSV)', default=True)
    submit = SubmitField('Create User')

    def __init__(self, original_user=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.original_user = original_user
        if original_user:
            self.password.validators = [Optional(), Length(min=6)]
            self.confirm_password.validators = [EqualTo('password')]
            self.submit.label.text = 'Save Changes'

    def validate_username(self, field):
        if self.original_user and self.original_user.username == field.data:
            return
        if User.query.filter_by(username=field.data).first():
            raise ValidationError('Username already taken.')

    def validate_email(self, field):
        if self.original_user and self.original_user.email == field.data:
            return
        if User.query.filter_by(email=field.data).first():
            raise ValidationError('Email already registered.')


class InvoiceForm(FlaskForm):
    """
    Main invoice entry/editing form.

    Fields:
      date           — invoice date
      book_number    — the book the user is working on (set by work session)
      serial_number  — the invoice serial; auto-filled from the book
      amounts        — one or more decimal amounts (0 allowed)
      invoice_id     — hidden, for edit tracking
      media_required — per-invoice override
    """
    date = DateField('Date', validators=[DataRequired()], default=date.today)
    book_number = IntegerField('Book Number', validators=[Optional(), NumberRange(min=1)])
    serial_number = StringField('Serial Number', validators=[DataRequired(), Length(max=20)])
    amounts = FieldList(
        FloatField('Amount', validators=[Optional(), NumberRange(min=0)], default=0),
        min_entries=1, max_entries=20
    )
    invoice_id = HiddenField('Invoice ID')
    media_required = BooleanField('Media Required (Admin Override)', default=False)
    submit = SubmitField('Save Invoice')

    def validate_amounts(self, field):
        for amount in field.data:
            if amount is not None and (not math.isfinite(amount) or amount < 0):
                raise ValidationError('Amounts must be finite non-negative numbers.')

    def validate_serial_number(self, field):
        """Ensure serial number is alphanumeric and unique (unless editing same invoice)."""
        if not re.match(r'^[a-zA-Z0-9\-_]+$', field.data):
            raise ValidationError('Serial number can only contain letters, numbers, hyphens, and underscores.')
        if field.data.isdigit():
            field.data = str(int(field.data)).zfill(4)
        invoice_id = self.invoice_id.data
        existing = Invoice.query.filter(Invoice.serial_number == field.data)
        if invoice_id:
            existing = existing.filter(Invoice.id != invoice_id)
        if existing.first():
            raise ValidationError('Serial number already exists. Please choose a unique one.')


class InvoiceSearchForm(FlaskForm):
    """Search invoices by serial, date, or book."""
    search_type = SelectField(
        'Search By',
        choices=[
            ('serial', 'Serial Number'),
            ('date', 'Date'),
            ('book', 'Book Number'),
        ],
        validators=[DataRequired()]
    )
    query = StringField('Query', validators=[DataRequired()])
    submit = SubmitField('Search')


class UserProfileForm(FlaskForm):
    """Form for users to update their own profile."""
    email = StringField('Email', validators=[DataRequired(), Email(), Length(max=120)])
    preferred_start_serial = IntegerField('Preferred Starting Serial', validators=[Optional(), NumberRange(min=1)])
    submit = SubmitField('Update Profile')

    def validate_email(self, field):
        from flask_login import current_user
        existing = User.query.filter_by(email=field.data).first()
        if existing and existing.id != current_user.id:
            raise ValidationError('Email already registered.')


class PasswordChangeForm(FlaskForm):
    """Form for changing password (user or admin)."""
    current_password = PasswordField('Current Password', validators=[DataRequired()])
    new_password = PasswordField('New Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('new_password')])
    submit = SubmitField('Change Password')


