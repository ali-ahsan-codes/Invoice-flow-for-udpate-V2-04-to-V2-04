# app/commands.py

import click
from flask import current_app
from app.extensions import db
from app.models import User
from app.utils.db_utils import ensure_database_exists


def register_commands(app):
    """Register custom Flask CLI commands."""

    @app.cli.command("rescan-flags")
    def rescan_flags():
        """Reconcile all invoice/daily cases after migration or direct SQL changes."""
        db.session.info['detect_all'] = True
        db.session.commit()
        click.echo('Invoice and daily review cases reconciled.')

    @app.cli.command("set-password")
    @click.argument("username")
    @click.argument("password")
    def set_password_command(username, password):
        """Set or reset password for a user.

        Example: flask set-password admin MyNewPassword123
        """
        user = User.query.filter_by(username=username).first()
        if not user:
            click.echo(f"Error: User '{username}' not found.")
            return
        user.set_password(password)
        db.session.commit()
        click.echo(f"Successfully updated password for user '{username}'.")

    @app.cli.command("create-admin")
    @click.option("--username", default="admin", help="Admin username (default: admin)")
    @click.option("--email", default="admin@example.com", help="Admin email")
    @click.option("--password", prompt=True, hide_input=True, confirmation_prompt=True, help="Admin password")
    def create_admin_command(username, email, password):
        """Create or reset admin account credentials."""
        user = User.query.filter_by(username=username).first()
        if not user:
            user = User.query.filter_by(role='admin').first()

        if user:
            user.username = username
            user.email = email
            user.role = 'admin'
            user.set_password(password)
            db.session.commit()
            click.echo(f"Admin user '{username}' credentials updated.")
        else:
            user = User(username=username, email=email, role='admin')
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            click.echo(f"Admin user '{username}' created successfully.")

    @app.cli.command("list-users")
    def list_users_command():
        """List all users in the database."""
        users = User.query.all()
        if not users:
            click.echo("No users found.")
            return
        click.echo(f"{'ID':<6}{'Username':<20}{'Role':<15}{'Email':<30}")
        click.echo("-" * 70)
        for u in users:
            click.echo(f"{u.id:<6}{u.username:<20}{u.role:<15}{u.email or '':<30}")

    @app.cli.command("init-db")
    def init_db_command():
        """
        Create the database (if it doesn't exist) and all tables.
        This command uses the current DATABASE_URL from the config.
        """
        click.echo("Ensuring database exists...")
        ensure_database_exists(current_app._get_current_object())
        click.echo("Creating all tables...")
        db.create_all()
        click.echo("Database initialized successfully.")

    @app.cli.command("set-setting")
    @click.argument("key")
    @click.argument("value")
    def set_setting_command(key, value):
        """Set a system setting (key, value) in the database."""
        from app.models import SystemSetting
        SystemSetting.set_value(key, value)
        click.echo(f"Setting '{key}' set to '{value}'.")

    @app.cli.command("get-setting")
    @click.argument("key")
    @click.option("--default", default=None, help="Default value if key not found")
    def get_setting_command(key, default):
        """Get a system setting value from the database."""
        from app.models import SystemSetting
        value = SystemSetting.get_value(key, default)
        click.echo(value)

    @app.cli.command("check-books")
    def check_books_command():
        """
        Report invoices whose stored book/page differs from the current
        calculation. Useful for spotting drift after changing book config.

        If the CSV export shows a book number that doesn't match the
        invoice detail page, run this to see the mismatch.
        """
        from app.models import Invoice
        from app.utils.helpers import calculate_book_page

        mismatches = []
        for inv in Invoice.query.all():
            stored_book = inv.book_record.book_number if inv.book_record else None
            stored_page = inv.book_page
            calc_book, calc_page = calculate_book_page(inv.serial_number, inv.batch_id)
            if (stored_book != calc_book) or (stored_page != calc_page):
                mismatches.append((
                    inv.id, inv.serial_number,
                    stored_book, stored_page,
                    calc_book, calc_page
                ))

        click.echo(f"Found {len(mismatches)} invoices where stored != calculated.")
        if mismatches:
            click.echo(f"{'ID':<8}{'Serial':<16}{'Stored':<16}{'Calculated':<16}")
            click.echo("-" * 56)
            for m in mismatches[:100]:
                stored = f"({m[2]}, {m[3]})" if m[2] is not None else "None"
                calc = f"({m[4]}, {m[5]})" if m[4] is not None else "None"
                click.echo(f"{m[0]:<8}{m[1]:<16}{stored:<16}{calc:<16}")
            if len(mismatches) > 100:
                click.echo(f"... and {len(mismatches) - 100} more.")
            click.echo("")
            click.echo("To overwrite stored values with the calculated ones, run:")
            click.echo("    flask recompute-books --yes")

    @app.cli.command("recompute-books")
    @click.option("--yes", is_flag=True, help="Skip confirmation prompt.")
    def recompute_books_command(yes):
        """
        Re-assign book_id/book_page on ALL invoices using the current book
        configuration. Overwrites stored values — use this when the CSV you
        export shows stale book numbers after a settings change.
        """
        from app.models import Invoice
        from app.services.invoice_service import assign_invoice_book

        total = Invoice.query.count()
        if not yes:
            click.confirm(
                f"This will recompute book/page for {total} invoices. Continue?",
                abort=True,
            )

        updated = 0
        for inv in Invoice.query.all():
            assign_invoice_book(inv, inv.serial_number)
            updated += 1
        db.session.commit()
        click.echo(f"Recomputed book/page for {updated} invoices.")


