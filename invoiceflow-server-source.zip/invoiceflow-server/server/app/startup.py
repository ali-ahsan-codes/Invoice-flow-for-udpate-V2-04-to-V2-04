"""Readable, credential-safe launch checks shared by desktop and WSGI."""
import os
from pathlib import Path
from sqlalchemy.engine import make_url

ROOT = Path(__file__).resolve().parents[1]


def validate_settings(settings):
    value = settings.get('SQLALCHEMY_DATABASE_URI', '')
    if not value:
        raise RuntimeError('No database configured. Copy .env.example to .env and set DATABASE_URL to your MySQL database. Existing DEV_DATABASE_URL is also supported for development.')
    try:
        url = make_url(value)
    except Exception:
        raise RuntimeError('Database URL is invalid. Use mysql+pymysql://user:encoded_password@host:3306/database; percent-encode special password characters.') from None
    if url.drivername not in ('mysql+pymysql', 'mariadb+pymysql') or not url.database:
        raise RuntimeError('Configure a MySQL/MariaDB URL with the PyMySQL driver and a database name. SQLite is not supported.')
    if 'CHANGE_ME' in value.upper():
        raise RuntimeError('Replace the CHANGE_ME database credentials in .env before starting.')
    secret = settings.get('SECRET_KEY', '')
    if not secret or 'CHANGE_ME' in secret.upper():
        raise RuntimeError('Set SECRET_KEY in .env to a random secret (32+ characters recommended).')
    if settings.get('SESSION_COOKIE_SECURE') and (len(secret) < 32 or secret == 'dev-secret-key-change-in-production'):
        raise RuntimeError('Production requires a random SECRET_KEY of at least 32 characters.')
    # Stable paths, independent of a shortcut/service working directory.
    for key in ('UPLOAD_FOLDER', 'BACKUP_DIR'):
        path = Path(settings[key])
        if not path.is_absolute():
            settings[key] = str(ROOT / path)


def explain_error(exc):
    """Do not include connection strings, passwords or arbitrary SQL parameters."""
    from sqlalchemy.exc import DBAPIError
    from pymysql.err import MySQLError
    if isinstance(exc, (DBAPIError, MySQLError)):
        code = getattr(getattr(exc, 'orig', exc), 'args', (None,))[0]
        messages = {
            1044: 'Database access denied. Check grants for this database/account.',
            1045: 'Database login rejected. Check username/password and account host grants in .env.',
            1698: 'Database login rejected (socket/root authentication). Use a dedicated MySQL account and its password, not a guessed root login.',
            1049: 'Database does not exist. Create the intended schema in Workbench and run the offline upgrade.',
            2003: 'Cannot connect to MySQL. Start the database service and verify host/port/firewall in .env.',
            2005: 'Database hostname cannot be resolved. Check the host in .env.',
            1419: 'MySQL binary logging prevented trigger installation. Ask your DBA to run the offline upgrade with authorized migration privileges. The app will NOT disable duplicate protection or change server security settings automatically.',
            1142: 'Database privilege missing. Upgrade needs controlled DDL/TRIGGER/CREATE VIEW grants; ordinary runtime needs DML and EXECUTE on the verification procedure.',
            1449: 'A database routine/trigger definer account is missing. Restore the durable migration account and privileges, then verify offline.',
            1356: 'The verification procedure or its definer privileges are invalid. Repair with the offline upgrade account.',
        }
        return messages.get(code, f'Database operation failed (error {code}). Check the schema and MySQL permissions with your DBA.')
    if isinstance(exc, RuntimeError):
        return str(exc)
    if isinstance(exc, ModuleNotFoundError):
        return 'A Python library is missing. Run .venv\\Scripts\\python.exe -m pip install -r requirements.txt (Windows), or python -m pip install -r requirements.txt.'
    return f'{type(exc).__name__}: startup failed. Check Python compatibility, installed requirements and the configured paths.'


def create_configured_app():
    # config.py loads only this application's .env, not a parent directory's.
    from config import config
    name = os.environ.get('FLASK_CONFIG', 'development').strip().lower()
    if name not in config:
        raise RuntimeError(f'Unknown FLASK_CONFIG: {name}. Use development or production.')
    from app import create_app
    return create_app(config[name])


