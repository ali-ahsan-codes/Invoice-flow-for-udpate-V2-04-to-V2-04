"""Batch context, explicit query scoping and administrator lifecycle."""
from flask import Blueprint, request, session, g, abort, redirect, url_for, render_template, flash, has_request_context
from flask_login import current_user, login_required
from sqlalchemy import event
from sqlalchemy.orm import Session, with_loader_criteria
from app.extensions import db
from app.models import Batch, Book, Invoice, InvoiceMedia, AuditLog
from app.utils.decorators import admin_required

bp = Blueprint('batches', __name__, url_prefix='/batches')

def mutation_error(batch, actor):
    if not batch: return 'Batch not found.'
    if actor and actor.is_admin(): return None
    if batch.hidden: return 'Batch not found.'
    if batch.locked or batch.archived: return 'Batch is read-only. Administrator corrections only.'
    return None

def visible_batches():
    q = Batch.query
    if not (current_user.is_authenticated and current_user.is_admin()): q = q.filter_by(hidden=False)
    return q


def current_batch_id():
    if has_request_context() and getattr(g, 'batch_id', None):
        return g.batch_id
    return 1

@event.listens_for(Session, 'do_orm_execute')
def scope_batch(state):
    if not has_request_context() or state.execution_options.get('all_batches'):
        return
    if state.is_update or state.is_delete or state.is_insert:
        table = getattr(state.statement, 'table', None)
        if getattr(table, 'name', None) in ('invoices','books','invoice_media'):
            actor = getattr(g, 'api_user', None) or current_user
            if not actor.is_authenticated or not actor.is_admin():
                abort(403, 'Bulk invoice/book/media changes require an administrator.')
    if state.is_column_load or getattr(g,'batch_resolving_actor',False): return
    if state.is_select or state.is_update or state.is_delete:
        g.batch_resolving_actor = True
        try:
            actor = getattr(g, 'api_user', None) or current_user
            admin = actor.is_authenticated and actor.is_admin()
        finally: g.batch_resolving_actor = False
        if not admin:
            visible = db.select(Batch.id).where(Batch.hidden.is_(False))
            state.statement = state.statement.options(
                with_loader_criteria(Invoice, lambda cls: cls.batch_id.in_(visible), include_aliases=True),
                with_loader_criteria(Book, lambda cls: cls.batch_id.in_(visible), include_aliases=True),
                with_loader_criteria(InvoiceMedia, lambda cls: cls.invoice_id.in_(db.select(Invoice.id).where(Invoice.batch_id.in_(visible))), include_aliases=True))
        if getattr(g, 'batch_id', None) and not state.is_relationship_load:
            bid = g.batch_id
            state.statement = state.statement.options(
                with_loader_criteria(Invoice, lambda cls: cls.batch_id == bid, include_aliases=True),
                with_loader_criteria(Book, lambda cls: cls.batch_id == bid, include_aliases=True))

def init_batches(app):
    app.register_blueprint(bp)
    @app.before_request
    def batch_context():
        g.pop('api_user', None)
        g.pop('batch_id', None)
        g.pop('current_batch', None)
        if request.path.startswith('/static/') or request.endpoint in ('auth.login','auth.logout','live.version'):
            return
        # API and printed serial-only QR routes must explicitly disambiguate.
        explicit_only = request.blueprint == 'api' or request.endpoint in ('media.qr_svg','media.qr_png','media.mobile_scan')
        raw = request.args.get('batch_id')
        if raw is None and request.method == 'POST':
            raw = request.form.get('batch_id')
            if raw is None and request.is_json:
                body = request.get_json(silent=True)
                raw = body.get('batch_id') if isinstance(body,dict) else None
        if raw is not None:
            try: bid = int(raw)
            except (ValueError,TypeError): abort(400, 'Invalid batch_id')
        elif explicit_only:
            return
        else:
            bid = session.get('batch_id')
            if bid is None:
                batch = visible_batches().filter_by(archived=False).order_by(Batch.id.desc()).first() or visible_batches().first()
                bid = batch.id if batch else 1
        if request.method == 'POST' and raw is None and request.blueprint in ('invoices','import_export','media'):
            abort(400, 'Explicit batch_id required for writes. Reopen this page.')
        batch = db.session.get(Batch, bid)
        if not batch: abort(404, 'Batch not found')
        if request.blueprint != 'api' and batch.hidden and not (current_user.is_authenticated and current_user.is_admin()):
            if raw is not None or request.method != 'GET' or request.headers.get('X-Live-Sync') == '1':
                abort(404, 'Batch not found')
            batch = visible_batches().order_by(Batch.archived, Batch.id.desc()).first()
            if not batch: abort(404, 'No visible batch is available. Contact an administrator.')
            bid = batch.id
        # ID-based links always retain the invoice's identity, irrespective of selected batch.
        args = request.view_args or {}
        invoice_id = args.get('invoice_id') or (args.get('id') if request.blueprint == 'invoices' else None)
        if request.blueprint == 'media' and args.get('media_id'):
            from app.models import InvoiceMedia
            media = db.session.get(InvoiceMedia, args['media_id'])
            invoice_id = media.invoice_id if media else None
        if invoice_id:
            inv = db.session.get(Invoice, invoice_id)
            if inv:
                if raw is not None and bid != inv.batch_id: abort(409, 'Invoice belongs to a different batch.')
                batch = db.session.get(Batch, inv.batch_id); bid = inv.batch_id
        g.batch_id = bid
        g.current_batch = batch
        if request.blueprint != 'api' and batch.hidden and not (current_user.is_authenticated and current_user.is_admin()):
            abort(404, 'Batch not found')
        if request.method in ('POST','PUT','PATCH','DELETE') and request.blueprint in ('invoices','media','import_export') and request.endpoint not in ('invoices.search','invoices.end_session'):
            from app.detection import policy_lock
            policy_lock(db.session)
            db.session.refresh(batch, with_for_update=True)
            if invoice_id:
                target = Invoice.query.execution_options(all_batches=True).filter_by(id=invoice_id).with_for_update().populate_existing().first()
                if target and target.batch_id != batch.id: abort(409, 'Invoice batch changed. Reopen this page.')
            db.session.info.setdefault('checked_batch_ids', set()).add(batch.id)
            error = mutation_error(batch, current_user if current_user.is_authenticated else None)
            if error: abort(403, error)
    @app.context_processor
    def context():
        if not current_user.is_authenticated or request.endpoint in ('auth.login','auth.logout','live.version'):
            return dict(batches=[], current_batch=None)
        return dict(batches=visible_batches().order_by(Batch.id).all(), current_batch=getattr(g,'current_batch',None))

@bp.post('/select')
@login_required
def select():
    bid = request.form.get('batch_id', type=int)
    batch = db.session.get(Batch, bid)
    if not batch or (batch.hidden and not (current_user.is_authenticated and current_user.is_admin())): abort(404)
    session['batch_id'] = bid
    session.pop('work_session', None)
    return redirect(url_for('invoices.index' if (batch.locked or batch.archived) and not (current_user.is_authenticated and current_user.is_admin()) else 'invoices.start_session', batch_id=bid))

@bp.route('/', methods=['GET','POST'])
@login_required
@admin_required
def index():
    if request.method == 'POST':
        try:
            mode = request.form.get('mode')
            if mode not in ('repeat','continue'): raise ValueError('Choose Repeat or Continue numbering.')
            previous = Batch.query.order_by(Batch.id.desc()).with_for_update().first()
            source = Book.query.execution_options(all_batches=True).filter_by(batch_id=previous.id).order_by(Book.book_number).all()
            count = int(request.form.get('count','100')); capacity = int(request.form.get('capacity','50'))
            if not 1 <= count <= 10000 or not 1 <= capacity <= 1000: raise ValueError('Invalid book count/capacity.')
            from app.services.invoice_service import get_book_serial_range
            suggested_book = source[-1].book_number + 1 if mode == 'continue' and source else 1
            suggested_serial = get_book_serial_range(source[-1])[1] + 1 if mode == 'continue' and source else 1
            start_book = int(request.form.get('start_book') or suggested_book)
            start_serial = int(request.form.get('start_serial') or suggested_serial)
            if start_book < 1 or start_serial < 1: raise ValueError('Origins must be positive.')
            if len(request.form.get('name','').strip()) > 80: raise ValueError('Batch name must be 80 characters or fewer.')
            if start_book + count > 2147483647 or start_serial + count*capacity > 2147483647: raise ValueError('Printed range exceeds supported limit.')
            batch = Batch(name=request.form.get('name','').strip() or f'Batch {previous.id+1}', numbering_mode=mode, start_book=start_book, start_serial=start_serial)
            db.session.add(batch); db.session.flush()
            for n in range(count): db.session.add(Book(batch_id=batch.id, book_number=start_book+n, capacity=capacity))
            db.session.add(AuditLog(user_id=current_user.id, action='create_batch', details={'batch_id':batch.id,'mode':mode,'start_book':start_book,'start_serial':start_serial,'books':count,'capacity':capacity}))
            db.session.commit(); session['batch_id']=batch.id; session.pop('work_session',None)
            flash('Batch created. Confirm physical printing matches the configured ranges before entry.', 'success')
        except (ValueError, TypeError) as exc:
            db.session.rollback(); flash(str(exc),'danger')
        return redirect(url_for('batches.index'))
    rows=[]
    for batch in Batch.query.order_by(Batch.id).all():
        books = Book.query.execution_options(all_batches=True).filter_by(batch_id=batch.id).all()
        used = Invoice.query.execution_options(all_batches=True).filter_by(batch_id=batch.id).count()
        rows.append(dict(batch=batch,books=len(books),capacity=sum(b.capacity for b in books),used=used))
    return render_template('admin/batches.html', rows=rows)

@bp.get('/<int:bid>/view')
@login_required
@admin_required
def view(bid):
    if not db.session.get(Batch,bid): abort(404)
    return redirect(url_for('invoices.index', batch_id=bid))

@bp.post('/<int:bid>/<action>')
@login_required
@admin_required
def lifecycle(bid, action):
    states = {'lock':('locked',True),'unlock':('locked',False),
              'hide':('hidden',True),'unhide':('hidden',False),
              'archive':('archived',True),'unarchive':('archived',False)}
    if action not in states: abort(404)
    from app.detection import policy_lock
    policy_lock(db.session)
    batch = Batch.query.filter_by(id=bid).with_for_update().populate_existing().first()
    if not batch: abort(404)
    if action == 'archive' and request.form.get('verified') != 'yes':
        abort(400, 'Verify records before archiving.')
    column, value = states[action]
    setattr(batch, column, value)
    db.session.add(AuditLog(user_id=current_user.id,action=action+'_batch',details={'batch_id':bid,'state':column,'value':value}))
    db.session.commit()
    flash(f'Batch {bid}: {action} completed.', 'success')
    return redirect(url_for('batches.index'))


@event.listens_for(Session, 'after_commit')
@event.listens_for(Session, 'after_rollback')
def clear_batch_write_lock(session):
    session.info.pop('batch_write_lock', None)
    session.info.pop('checked_batch_ids', None)

@event.listens_for(Session, 'before_flush')
def protect_normal_user_flush(session, context, instances):
    # Defense against future code committing midway through a guarded request.
    # Never take locks here: the singleton must be locked BEFORE row locks.
    if not has_request_context(): return
    actor = getattr(g, 'api_user', None) or current_user
    if not actor.is_authenticated or actor.is_admin(): return
    for obj in list(session.new) + list(session.dirty) + list(session.deleted):
        if not isinstance(obj, (Invoice, Book, InvoiceMedia)): continue
        if obj in session.dirty and not session.is_modified(obj, include_collections=False): continue
        from sqlalchemy import inspect
        if isinstance(obj, InvoiceMedia):
            parent = session.get(Invoice, obj.invoice_id)
            bids = {parent.batch_id} if parent else set()
        else:
            bids = {obj.batch_id or current_batch_id()}
            bids.update(inspect(obj).attrs.batch_id.history.deleted)
        if not session.info.get('batch_write_lock') or not bids or not bids.issubset(session.info.get('checked_batch_ids', set())):
            abort(409, 'Permission transaction ended. Nothing saved; reopen the page.')


