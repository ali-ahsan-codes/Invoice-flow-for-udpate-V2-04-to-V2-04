# app/__init__.py

import os
import json
import logging
from flask import Flask, request, render_template
import atexit
from datetime import datetime, date, timedelta, timezone

from app.extensions import db, login_manager, bcrypt, csrf, scheduler
from app.utils.db_utils import ensure_database_exists, ensure_columns
from app.models import User


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def create_app(config_class=None, *, upgrade_schema=False):
    app = Flask(__name__)

    if config_class is None:
        app.config.from_object('config.Config')
    else:
        app.config.from_object(config_class)

    os.makedirs(app.instance_path, exist_ok=True)

    @app.before_request
    def maintenance_gate_first():
        if request.path.startswith('/static/'):
            return
        from app.services.backup_service import is_restore_in_progress
        if app.config.get('MAINTENANCE_MODE') or is_restore_in_progress():
            if request.endpoint == 'backup.restore_status' and not app.config.get('MAINTENANCE_MODE'):
                return
            return app.jinja_env.get_template('maintenance.html').render(), 503, {'Retry-After':'60'}

    from app.startup import validate_settings
    validate_settings(app.config)
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message_category = 'info'

    # 'strong' = invalidate session if client fingerprint (IP + UA) changes.
    # Switch to 'basic' if mobile users get logged out too often.
    login_manager.session_protection = 'strong'

    bcrypt.init_app(app)
    csrf.init_app(app)

    from app.detection import init_detection
    from app.realtime import init_realtime

    with app.app_context():
        from app.utils.db_utils import migrate_batches
        if upgrade_schema:
            ensure_database_exists(app)
            db.create_all()
            ensure_columns(app)
            migrate_batches()
        else:
            from app.utils.db_utils import verify_schema
            verify_schema()

        # Never rewrite legacy invoice assignments/timestamps during startup.
        # Unassigned legacy invoices are preserved for administrator review.

        if upgrade_schema:
            create_admin_from_config(app)

    from app.routes import blueprints
    for bp in blueprints:
        app.register_blueprint(bp)

    from app.batches import init_batches
    init_batches(app)
    init_realtime(app)
    init_detection(app)

    @app.errorhandler(409)
    @app.errorhandler(400)
    @app.errorhandler(403)
    def request_error(error):
        if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            from flask import jsonify
            return jsonify(success=False, error=error.description), error.code
        return render_template('request_error.html', error=error), error.code

    # ---------- Date format Jinja filters ----------
    from app.utils.helpers import format_date_display, format_datetime_display
    app.jinja_env.filters['localdate'] = format_date_display
    app.jinja_env.filters['localdatetime'] = format_datetime_display

    # ---------- Maintenance mode ----------
    MAINTENANCE_WHITELIST_ENDPOINTS = {
        'static',
        'backup.restore_status',
    }

    @app.before_request
    def _check_maintenance_mode():
        try:
            from app.services.backup_service import is_restore_in_progress
            if not is_restore_in_progress():
                return None
        except Exception:
            return None

        if request.endpoint in MAINTENANCE_WHITELIST_ENDPOINTS:
            return None
        if request.path.startswith('/static/'):
            return None

        return render_template('maintenance.html'), 503

    # ---------- No-cache headers (blocks browser back button) ----------
    @app.after_request
    def _add_no_cache_headers(response):
        # Skip static assets
        if request.endpoint == 'static' or request.path.startswith('/static/'):
            return response

        # Skip file downloads (they set their own headers)
        if response.mimetype in ('text/csv', 'application/octet-stream',
                                  'image/svg+xml', 'image/png',
                                  'application/sql'):
            return response

        # Skip backup downloads
        if request.endpoint and request.endpoint.startswith('backup.download'):
            return response

        # Strongest possible no-cache directives.
        # 'no-store' + 'private' + 'max-age=0' works across all browsers
        # including Safari and Firefox which sometimes ignore one alone.
        response.headers['Cache-Control'] = (
            'no-store, no-cache, must-revalidate, max-age=0, private'
        )
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        return response

    # ---------- Template globals ----------
    from app.permissions import user_can as _user_can
    from flask_login import current_user as _current_user

    def _template_can(capability):
        return _user_can(_current_user, capability)

    @app.context_processor
    def inject_template_globals():
        from app.utils.helpers import get_date_format_label
        today = date.today()
        now_dt = datetime.now(timezone.utc)
        return {
            'current_date': today,
            'current_datetime': now_dt,
            'now': now_dt,
            'datetime': datetime,
            'date': date,
            'timedelta': timedelta,
            'system_date_format': get_date_format_label(),
            'can': _template_can,
        }

    from app.commands import register_commands
    register_commands(app)

    if app.config.get('SCHEDULER_ENABLED', True) and not scheduler.running:
        from app.services.backup_service import auto_backup_job
        interval_minutes = app.config.get('BACKUP_INTERVAL_MINUTES', 2)
        scheduler.add_job(
            func=auto_backup_job,
            args=[app],
            trigger='interval',
            minutes=interval_minutes,
            id='auto_backup',
            replace_existing=True
        )
        scheduler.start()
        atexit.register(lambda: scheduler.shutdown())

    return app


@login_manager.user_loader
def load_user(user_id):
    from app.models import User
    try:
        return db.session.get(User, int(user_id))
    except (ValueError, TypeError):
        return None


def create_admin_from_config(app):
    config_path = os.path.join(app.root_path, '..', 'admin_config.json')
    if not os.path.exists(config_path):
        return

    try:
        with open(config_path, 'r') as f:
            data = json.load(f)
    except Exception as e:
        logger.error(f"Failed to read admin_config.json: {e}")
        return

    username = data.get('username', 'admin')
    password = data.get('password')
    email = data.get('email', 'admin@example.com')

    if not username or not password:
        logger.error("admin_config.json missing username or password.")
        return

    admin = User.query.filter_by(username=username).first()
    if not admin:
        admin = User.query.filter_by(role='admin').first()

    if admin:
        logger.info('Existing administrator preserved; admin_config.json is not reapplied.')
        return
    else:
        admin = User(username=username, email=email, role='admin')
        admin.set_password(password)
        db.session.add(admin)
        db.session.commit()
        logger.info(f"Admin user '{username}' created.")

    try:
        os.remove(config_path)
        logger.info("admin_config.json deleted after processing.")
    except Exception as e:
        logger.warning(f"Could not delete admin_config.json: {e}")


