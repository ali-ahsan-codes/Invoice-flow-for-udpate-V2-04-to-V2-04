# app/extensions.py

from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_bcrypt import Bcrypt
from flask_wtf.csrf import CSRFProtect
from apscheduler.schedulers.background import BackgroundScheduler

# Initialize extensions (no app context yet)
db = SQLAlchemy()
login_manager = LoginManager()
bcrypt = Bcrypt()
csrf = CSRFProtect()

# Background scheduler for automated backups and other periodic tasks
scheduler = BackgroundScheduler()

    # Scheduler is started separately in the app factory to allow configuration
    # from app.config. We do not initialize it here to keep it flexible.

    # Optionally set up user loader if not done elsewhere
    # We'll keep the loader in __init__.py for clarity.


