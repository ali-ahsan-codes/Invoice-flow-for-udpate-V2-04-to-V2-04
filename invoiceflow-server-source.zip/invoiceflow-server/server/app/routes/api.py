from sqlalchemy import cast, Integer
# app/routes/api.py
"""
JSON API for the InvoiceFlow mobile scanner app.

Auth: X-API-Key: <user.api_key>   (or ?api_key=... as a fallback)
All endpoints are scoped to the caller's own invoices unless the caller is
an admin.

Every invoice payload includes BOTH:
  - "date": the raw ISO date (YYYY-MM-DD), stable for the app to parse
  - "date_display": the date rendered in the admin-configured format
  - "date_format": the current format token, e.g. "DD/MM/YYYY"

The mobile app can use "date_display" directly for display, or read
"date_format" once (from /me) and format client-side.
"""

import os
import json
from functools import wraps
from datetime import datetime
from flask import Blueprint, request, jsonify, current_app, g
from werkzeug.utils import secure_filename

from app import db, csrf
from app.models import User, Invoice, InvoiceMedia, SystemSetting
from app.services.audit_service import log_action
from app.utils.helpers import (
    get_invoice_book_page, generate_unique_filename,
    allowed_file, format_file_size,
    DATE_FORMAT_PATTERNS, DEFAULT_DATE_FORMAT, get_date_format_label,
)

bp = Blueprint('api', __name__, url_prefix='/api/v1')

csrf.exempt(bp)


# ------------------------------------------------------------------ auth

def require_api_key(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        key = request.headers.get('X-API-Key')
        if not key:
            auth = request.headers.get('Authorization', '')
            if auth.startswith('Bearer '):
                key = auth[7:]
        if not key:
            key = request.args.get('api_key')
        if not key:
            return jsonify({'error': 'API key required'}), 401

        user = User.query.filter_by(api_key=key).first()
        if not user:
            return jsonify({'error': 'Invalid API key'}), 401

        g.api_user = user
        batch = getattr(g, 'current_batch', None)
        if batch:
            if batch.hidden and not user.is_admin(): return jsonify(error='Batch not found'), 404
            if request.method in ('POST','PUT','PATCH','DELETE'):
                from app.batches import mutation_error
                from app.detection import policy_lock
                policy_lock(db.session); db.session.refresh(batch, with_for_update=True)
                db.session.info.setdefault('checked_batch_ids', set()).add(batch.id)
                error = mutation_error(batch, user)
                if error: return jsonify(error=error), 403
        return f(*args, **kwargs)
    return wrapper


# ------------------------------------------------------------------ format

def _date_pattern():
    fmt = SystemSetting.get_value('date_format', DEFAULT_DATE_FORMAT)
    return DATE_FORMAT_PATTERNS.get(fmt, DATE_FORMAT_PATTERNS[DEFAULT_DATE_FORMAT])


def _format_date(date_obj):
    if not date_obj:
        return None
    try:
        return date_obj.strftime(_date_pattern())
    except Exception:
        return date_obj.isoformat() if hasattr(date_obj, 'isoformat') else str(date_obj)


def _format_datetime(dt_obj):
    if not dt_obj:
        return None
    try:
        return dt_obj.strftime(f'{_date_pattern()} %H:%M')
    except Exception:
        return dt_obj.isoformat() if hasattr(dt_obj, 'isoformat') else str(dt_obj)


# ------------------------------------------------------------- serialize

def _serialize_invoice(inv):
    book, page = get_invoice_book_page(inv)
    media_count = inv.media.count()
    return {
        'id': inv.id,
        'serial_number': inv.serial_number,
        'batch_id': inv.batch_id,
        'batch_name': inv.batch.name,
        'date': inv.date.isoformat(),                 # ISO — for internal logic
        'date_display': _format_date(inv.date),       # formatted — for direct display
        'book': book,
        'page': page,
        'total_amount': float(inv.total_amount),
        'amounts': inv.get_amounts(),
        'media_count': media_count,
        'has_media': media_count > 0,
        'media_required': bool(inv.media_required),
        'created_at': inv.created_at.isoformat() if inv.created_at else None,
        'created_at_display': _format_datetime(inv.created_at),
        'updated_at': inv.updated_at.isoformat() if inv.updated_at else None,
        'updated_at_display': _format_datetime(inv.updated_at),
    }


def _scoped_query():
    q = Invoice.query
    if not g.api_user.is_admin():
        q = q.filter(Invoice.created_by == g.api_user.id)
    return q


def _resolve_serial(serial):
    from flask import abort
    from app.models import Batch
    if not getattr(g, 'batch_id', None) and (Batch.query if g.api_user.is_admin() else Batch.query.filter_by(hidden=False)).count() > 1:
        abort(409, description='Multiple batches are configured. Supply batch_id for serial lookup or upload.')
    matches = _scoped_query().filter(Invoice.serial_number == serial).limit(2).all()
    if len(matches) > 1:
        abort(409, description='Ambiguous serial. Supply batch_id explicitly.')
    inv = matches[0] if matches else None
    if inv:
        if inv.batch.hidden and not g.api_user.is_admin(): abort(404)
        if request.method in ('POST','PUT','PATCH','DELETE'):
            from app.batches import mutation_error
            from app.detection import policy_lock
            policy_lock(db.session); db.session.refresh(inv.batch, with_for_update=True)
            db.session.info.setdefault('checked_batch_ids', set()).add(inv.batch_id)
            error = mutation_error(inv.batch, g.api_user)
            if error: abort(403, error)
    return inv


# ----------------------------------------------------------- endpoints

@bp.route('/me', methods=['GET'])
@require_api_key
def me():
    """
    Called by the app right after scanning the connection QR.
    Returns the authenticated user AND the server's date format so the
    app can either display dates client-side or use date_display directly.
    """
    u = g.api_user
    return jsonify({
        'id': u.id,
        'username': u.username,
        'email': u.email,
        'role': u.role,
        'can_export': bool(u.can_export),
        'date_format': get_date_format_label(),
        'server_time': datetime.utcnow().isoformat() + 'Z',
    })


@bp.route('/config', methods=['GET'])
@require_api_key
def config():
    """Small config endpoint — the app can poll this to keep its local
    date-format in sync with the server without reconnecting."""
    return jsonify({
        'date_format': get_date_format_label(),
        'date_format_example': _format_date(datetime.utcnow().date()),
    })


@bp.route('/invoices/<serial>', methods=['GET'])
@require_api_key
def get_invoice(serial):
    serial = serial.strip().lstrip('#')
    inv = _resolve_serial(serial)
    if not inv:
        return jsonify({'error': 'Invoice not found'}), 404
    return jsonify(_serialize_invoice(inv))


@bp.route('/invoices/<serial>/next', methods=['GET'])
@require_api_key
def next_invoice(serial):
    serial = serial.strip().lstrip('#')
    origin = _resolve_serial(serial)
    if not origin:
        return jsonify(error='Invoice not found'), 404
    nxt = (_scoped_query().filter(Invoice.batch_id == origin.batch_id)
           .filter(cast(Invoice.serial_number, Integer) > int(origin.serial_number))
           .order_by(cast(Invoice.serial_number, Integer).asc())
           .first())
    if not nxt:
        return jsonify({'error': 'No next invoice'}), 404
    return jsonify(_serialize_invoice(nxt))


@bp.route('/invoices/<serial>/prev', methods=['GET'])
@require_api_key
def prev_invoice(serial):
    serial = serial.strip().lstrip('#')
    origin = _resolve_serial(serial)
    if not origin:
        return jsonify(error='Invoice not found'), 404
    prv = (_scoped_query().filter(Invoice.batch_id == origin.batch_id)
           .filter(cast(Invoice.serial_number, Integer) < int(origin.serial_number))
           .order_by(cast(Invoice.serial_number, Integer).desc())
           .first())
    if not prv:
        return jsonify({'error': 'No previous invoice'}), 404
    return jsonify(_serialize_invoice(prv))


@bp.route('/invoices', methods=['GET'])
@require_api_key
def list_invoices():
    """Search / list. Query params: q, date (YYYY-MM-DD), limit (<=200)."""
    q_text = (request.args.get('q') or '').strip()
    date_str = (request.args.get('date') or '').strip()
    try:
        limit = max(1, min(int(request.args.get('limit', 50)), 200))
    except ValueError:
        limit = 50

    q = _scoped_query()
    if q_text:
        q = q.filter(Invoice.serial_number.ilike(f'%{q_text}%'))
    if date_str:
        try:
            d = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'Invalid date. Use YYYY-MM-DD.'}), 400
        q = q.filter(Invoice.date == d)

    q = q.order_by(cast(Invoice.serial_number, Integer).asc()).limit(limit)
    return jsonify({
        'invoices': [_serialize_invoice(i) for i in q.all()],
        'date_format': get_date_format_label(),
    })


@bp.route('/invoices/<serial>/media', methods=['POST'])
@require_api_key
def upload_media(serial):
    serial = serial.strip().lstrip('#')
    inv = _resolve_serial(serial)
    if not inv:
        return jsonify({'error': 'Invoice not found'}), 404

    if (inv.batch.archived or inv.batch.locked or inv.batch.hidden) and not g.api_user.is_admin():
        return jsonify(error='Archived batch corrections require administrator'), 403
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    file = request.files['file']
    if not file or file.filename == '':
        return jsonify({'error': 'Empty file'}), 400

    original = secure_filename(file.filename) or 'capture.jpg'
    if not allowed_file(original):
        return jsonify({'error': 'File type not allowed'}), 400

    upload_folder = current_app.config.get('UPLOAD_FOLDER', 'uploads')
    if not os.path.isabs(upload_folder):
        upload_folder = os.path.join(current_app.root_path, '..', upload_folder)
    invoice_folder = os.path.join(upload_folder, f'invoice_{inv.id}')
    os.makedirs(invoice_folder, exist_ok=True)

    unique = generate_unique_filename(original)
    path = os.path.join(invoice_folder, unique)
    file.save(path)
    size = os.path.getsize(path)

    media = InvoiceMedia(
        invoice_id=inv.id,
        file_name=original,
        file_path=os.path.relpath(path, upload_folder),
        file_size=size,
        mime_type=file.content_type or 'application/octet-stream',
        uploaded_by=g.api_user.id,
    )
    db.session.add(media)
    db.session.commit()

    log_action(
        user_id=g.api_user.id,
        action='upload_media',
        details={'invoice_id': inv.id, 'serial_number': inv.serial_number,
        'batch_id': inv.batch_id,
        'batch_name': inv.batch.name,
                 'filename': original, 'size': size, 'source': 'mobile_api'},
        ip_address=request.remote_addr,
    )

    return jsonify({
        'success': True,
        'media_id': media.id,
        'filename': original,
        'size': size,
        'size_formatted': format_file_size(size),
        'media_count': inv.media.count(),
        'invoice': _serialize_invoice(inv),
    }), 201


@bp.errorhandler(409)
@bp.errorhandler(400)
@bp.errorhandler(404)
def api_error(error):
    return jsonify(error=error.description), error.code


