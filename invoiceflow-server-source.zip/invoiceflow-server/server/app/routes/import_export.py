# app/routes/import_export.py

import csv
import io
import json
import os
from datetime import datetime, date, timedelta
from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for, send_file, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from sqlalchemy import func as sqlfunc
from app import db
from app.models import Invoice, User, AuditLog, Book, SystemSetting, totals_included_clause
from app.services.invoice_service import create_invoice, generate_next_serial
from app.services.audit_service import log_action
from app.services.import_service import import_invoices_from_csv, get_csv_columns
from app.utils.decorators import admin_required
from app.utils.helpers import (
    get_client_ip, format_date, calculate_book_page, get_invoice_book_page,
    DATE_FORMAT_PATTERNS, DEFAULT_DATE_FORMAT,
)

bp = Blueprint('import_export', __name__, url_prefix='/import-export')


def csv_response(output, filename):
    from app.batches import current_batch_id
    filename = f'batch_{current_batch_id()}_{filename}'
    rows=list(csv.reader(io.StringIO(output.getvalue())))
    if rows and 'Batch ID' not in rows[0]:
        output=io.StringIO();writer=csv.writer(output)
        writer.writerow(['Batch ID']+rows[0])
        for row in rows[1:]: writer.writerow([current_batch_id()]+row)
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8-sig')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=filename
    )


def _display_pattern():
    """Return the currently configured strftime pattern for output."""
    fmt = SystemSetting.get_value('date_format', DEFAULT_DATE_FORMAT)
    return DATE_FORMAT_PATTERNS.get(fmt, DATE_FORMAT_PATTERNS[DEFAULT_DATE_FORMAT])


@bp.route('/')
@login_required
@admin_required
def index():
    """Import/Export main page."""
    return render_template('admin/import_export.html')


@bp.route('/export')
@login_required
def export():
    """
    Export invoices to CSV.
    Types:
      all       — every invoice
      daily     — daily totals (one row per day: date + total)
      monthly   — monthly totals
      by_date   — date-wise summary (date, count, total, first added)
      books     — book configuration
      template  — blank fill-in template
    """
    if not current_user.is_admin() and not current_user.can_export:
        flash('You do not have permission to export data.', 'danger')
        return redirect(url_for('invoices.index'))

    export_type = request.args.get('type', 'all')
    display_pattern = _display_pattern()

    if export_type == 'books':
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Batch ID', 'Book Number', 'Pages Per Book', 'Assigned User', 'Used Pages', 'Remaining Pages'])
        for book in Book.query.order_by(Book.book_number).all():
            writer.writerow([
                book.batch_id,
                book.book_number,
                book.capacity,
                book.assigned_user.username if book.assigned_user else '',
                book.used_count,
                book.remaining_count,
            ])
        filename = f"invoice_books_{date.today().isoformat()}.csv"

    elif export_type == 'template':
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Date', 'Serial Number', 'Book', 'Page', 'Amounts', 'Total Amount'])
        writer.writerow(['2024-01-15', '0001', '1', '1', '100.500|50.250', '150.750'])
        writer.writerow(['2024-01-15', '0002', '1', '2', '200.000', '200.000'])
        writer.writerow(['2024-01-16', '0003', '1', '3', '75.250|25.000', '100.250'])
        filename = 'invoice_import_template.csv'

    elif export_type == 'daily':
        from_date = request.args.get('from_date')
        to_date = request.args.get('to_date')
        if not from_date or not to_date:
            flash('Date range required for daily export.', 'danger')
            return redirect(url_for('import_export.index'))

        try:
            start_date = datetime.strptime(from_date, '%Y-%m-%d').date()
            end_date = datetime.strptime(to_date, '%Y-%m-%d').date()
        except ValueError:
            flash('Invalid date format. Use YYYY-MM-DD.', 'danger')
            return redirect(url_for('import_export.index'))

        from app.services.invoice_service import get_daily_totals
        daily_totals = get_daily_totals(start_date, end_date, user_id=None if current_user.is_admin() else current_user.id)

        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Date', 'Total Amount'])
        for item in daily_totals:
            try:
                d = datetime.strptime(item['date'], '%Y-%m-%d').date()
                date_str = d.strftime(display_pattern)
            except Exception:
                date_str = item['date']
            writer.writerow([date_str, f"{item['total']:.3f}"])

        filename = f"daily_totals_{from_date}_to_{to_date}.csv"

    elif export_type == 'monthly':
        month = request.args.get('month')
        if not month:
            flash('Month required (YYYY-MM) for monthly export.', 'danger')
            return redirect(url_for('import_export.index'))

        try:
            month_date = datetime.strptime(month, '%Y-%m').date()
        except ValueError:
            flash('Invalid month format. Use YYYY-MM.', 'danger')
            return redirect(url_for('import_export.index'))

        from app.services.invoice_service import get_monthly_totals
        from_date = month_date.replace(day=1)
        if month_date.month == 12:
            to_date = month_date.replace(year=month_date.year + 1, month=1, day=1) - timedelta(days=1)
        else:
            to_date = month_date.replace(month=month_date.month + 1, day=1) - timedelta(days=1)

        monthly_totals = get_monthly_totals(from_date, to_date, user_id=None if current_user.is_admin() else current_user.id)

        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Month', 'Total Amount'])
        for item in monthly_totals:
            writer.writerow([item['month'], f"{item['total']:.3f}"])

        filename = f"monthly_totals_{month}.csv"

    elif export_type == 'by_date':
        # ---------- Date-wise summary ----------
        from_date = request.args.get('from_date')
        to_date = request.args.get('to_date')
        if not from_date or not to_date:
            flash('Date range required for date-wise export.', 'danger')
            return redirect(url_for('import_export.index'))

        try:
            start_date = datetime.strptime(from_date, '%Y-%m-%d').date()
            end_date = datetime.strptime(to_date, '%Y-%m-%d').date()
        except ValueError:
            flash('Invalid date format. Use YYYY-MM-DD.', 'danger')
            return redirect(url_for('import_export.index'))

        q = db.session.query(
            Invoice.date.label('invoice_date'),
            sqlfunc.count(Invoice.id).label('count'),
            sqlfunc.sum(Invoice.total_amount).label('total'),
            sqlfunc.min(Invoice.created_at).label('first_added'),
        ).filter(Invoice.date.between(start_date, end_date), totals_included_clause())

        if not current_user.is_admin():
            q = q.filter(Invoice.created_by == current_user.id)

        rows = q.group_by(Invoice.date).order_by(Invoice.date).all()

        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Invoice Date', 'Invoices', 'Total Amount', 'Added Date'])

        grand_count = 0
        grand_total = 0.0
        for r in rows:
            inv_date_str = r.invoice_date.strftime(display_pattern)
            added_str = r.first_added.strftime(display_pattern) if r.first_added else ''
            total = float(r.total or 0)
            writer.writerow([inv_date_str, r.count, f"{total:.3f}", added_str])
            grand_count += r.count
            grand_total += total

        writer.writerow([])
        writer.writerow(['TOTAL', grand_count, f"{grand_total:.3f}", ''])

        filename = f'invoices_by_date_{from_date}_to_{to_date}.csv'

    else:
        # ---------- All invoices ----------
        if current_user.is_admin():
            invoices = Invoice.query.order_by(Invoice.date.desc(), Invoice.serial_number.desc()).all()
        else:
            invoices = Invoice.query.filter(Invoice.created_by == current_user.id).order_by(
                Invoice.date.desc(), Invoice.serial_number.desc()
            ).all()

        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([
            'ID', 'Batch ID', 'Date', 'Serial Number', 'Book', 'Page',
            'Amounts', 'Total Amount', 'Created By', 'Created At', 'Updated At'
        ])

        for inv in invoices:
            book, page = get_invoice_book_page(inv)
            amounts_str = '|'.join([f"{a:.3f}" for a in inv.get_amounts()])
            creator = User.query.get(inv.created_by)
            writer.writerow([
                inv.id,
                inv.batch_id,
                inv.date.strftime(display_pattern),
                inv.serial_number,
                book if book is not None else '',
                page if page is not None else '',
                amounts_str,
                f"{inv.total_amount:.3f}",
                creator.username if creator else '',
                inv.created_at.strftime(f'{display_pattern} %H:%M') if inv.created_at else '',
                inv.updated_at.strftime(f'{display_pattern} %H:%M') if inv.updated_at else ''
            ])

        filename = f"all_invoices_{date.today().isoformat()}.csv"

    log_action(
        user_id=current_user.id,
        action='export_invoices',
        details={'type': export_type, 'filename': filename},
        ip_address=get_client_ip()
    )

    return csv_response(output, filename)


@bp.route('/import-books', methods=['POST'])
@login_required
@admin_required
def import_books():
    is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    file = request.files.get('books_file')
    if not file or not file.filename.lower().endswith('.csv'):
        if is_ajax:
            return jsonify(success=False, error='Please upload a CSV file containing book data.')
        flash('Please upload a CSV file containing book data.', 'danger')
        return redirect(url_for('import_export.index'))

    def _pick(row, *keys):
        lower = {k.lower().strip(): v for k, v in row.items() if k}
        for k in keys:
            if k.lower() in lower:
                return (lower[k.lower()] or '').strip()
        return ''

    try:
        content = file.read().decode('utf-8-sig')
        reader = csv.DictReader(io.StringIO(content))
        rows = list(reader)
        if not rows:
            raise ValueError('The book CSV contains no data rows.')

        imported = 0
        max_book_number = 0
        capacities = []

        for idx, row in enumerate(rows, start=2):
            from app.batches import current_batch_id
            raw_batch = _pick(row, 'Batch ID')
            if raw_batch and raw_batch != str(current_batch_id()):
                raise ValueError('Import books separately into the matching selected batch.')
            raw_book = _pick(row, 'Book Number', 'Book No', 'BookNo', 'Book', 'book_number')
            raw_pages = _pick(row, 'Pages Per Book', 'Pages', 'Capacity', 'pages_per_book', 'PagesPerBook')

            if not raw_book or not raw_pages:
                raise ValueError(f"Row {idx}: missing Book Number or Pages.")

            try:
                book_number = int(raw_book)
                capacity = int(raw_pages)
            except ValueError:
                raise ValueError(f"Row {idx}: Book Number and Pages must be integers.")

            if book_number < 1 or capacity < 1:
                raise ValueError(f"Row {idx}: values must be positive.")

            book = Book.query.filter_by(book_number=book_number).first()
            if book is None:
                if Invoice.query.first():
                    raise ValueError('Cannot change book configuration after batch entry has started.')
                book = Book(book_number=book_number, capacity=capacity)
                db.session.add(book)
            else:
                if book.capacity != capacity and Invoice.query.first():
                    raise ValueError('Cannot change printed capacities after batch entry has started.')
                book.capacity = capacity

            username = _pick(row, 'Assigned User', 'User', 'assigned_user', 'Username')
            if username:
                user = User.query.filter_by(username=username).first()
                if user is None:
                    raise ValueError(f"Row {idx}: user '{username}' not found.")
                book.assigned_user = user

            max_book_number = max(max_book_number, book_number)
            capacities.append(capacity)
            imported += 1

        SystemSetting.set_value('number_of_books', str(max_book_number))
        if capacities and len(set(capacities)) == 1:
            SystemSetting.set_value('pages_per_book', str(capacities[0]))

        db.session.commit()
        msg = f'Book import complete: {imported} books created/updated.'
        if is_ajax:
            return jsonify(success=True, message=msg)
        flash(msg, 'success')

    except (ValueError, UnicodeDecodeError) as error:
        db.session.rollback()
        err = f'Book import failed: {error}'
        if is_ajax:
            return jsonify(success=False, error=str(error))
        flash(err, 'danger')

    return redirect(url_for('import_export.index'))


@bp.route('/import', methods=['GET', 'POST'])
@login_required
@admin_required
def import_csv():
    is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    if request.method == 'GET':
        return render_template('admin/import_export.html')

    if 'csv_file' not in request.files:
        if is_ajax:
            return jsonify(success=False, error='No file uploaded.')
        flash('No file uploaded.', 'danger')
        return redirect(url_for('import_export.import_csv'))

    file = request.files['csv_file']
    if file.filename == '':
        if is_ajax:
            return jsonify(success=False, error='No file selected.')
        flash('No file selected.', 'danger')
        return redirect(url_for('import_export.import_csv'))

    if not file.filename.endswith('.csv'):
        if is_ajax:
            return jsonify(success=False, error='Only CSV files are allowed.')
        flash('Only CSV files are allowed.', 'danger')
        return redirect(url_for('import_export.import_csv'))

    try:
        content = file.read().decode('utf-8-sig')
        lines = content.splitlines()
        if not lines:
            if is_ajax:
                return jsonify(success=False, error='CSV file is empty.')
            flash('CSV file is empty.', 'danger')
            return redirect(url_for('import_export.import_csv'))

        reader = csv.reader(lines)
        header = next(reader)
        rows = list(reader)

        if not rows:
            if is_ajax:
                return jsonify(success=False, error='CSV file has no data rows.')
            flash('CSV file has no data rows.', 'danger')
            return redirect(url_for('import_export.import_csv'))

        columns = header
        lower_columns = [c.strip().lower() for c in columns]
        is_legacy = any(c in {'book', 'book number', 'book no', 'bookno'} for c in lower_columns) or \
            any(c in {'page', 'page number', 'page no', 'pageno'} for c in lower_columns)

    except Exception as e:
        if is_ajax:
            return jsonify(success=False, error=f'Error reading CSV: {str(e)}')
        flash(f'Error reading CSV: {str(e)}', 'danger')
        return redirect(url_for('import_export.import_csv'))

    preview_mode = request.form.get('preview') == 'true' or 'preview' in request.args
    if preview_mode:
        preview_rows = []
        for i, row in enumerate(rows[:10]):
            preview_rows.append({columns[j]: row[j] if j < len(row) else '' for j in range(len(columns))})

        return render_template(
            'admin/import_preview.html',
            columns=columns,
            preview_rows=preview_rows,
            total_rows=len(rows),
            is_legacy=is_legacy,
            filename=file.filename
        )

    try:
        col_map = {
            'date': request.form.get('col_date'),
            'serial_number': request.form.get('col_serial') or request.form.get('col_serial_number'),
            'amounts': request.form.get('col_amounts'),
            'total': request.form.get('col_total'),
            'created': request.form.get('col_created'),
            'updated': request.form.get('col_updated'),
        }

        def find_col(targets):
            lower_map = {item.strip().lower(): item for item in columns}
            for target in targets:
                key = target.strip().lower()
                if key in lower_map:
                    return lower_map[key]
            return None

        if not col_map['date'] or not col_map['serial_number'] or not col_map['amounts']:
            if not col_map['date']:
                col_map['date'] = find_col(['date'])
            if not col_map['serial_number']:
                col_map['serial_number'] = find_col([
                    'serial number', 'serial_number', 'serial no', 'serialno'
                ])
            if not col_map['amounts']:
                col_map['amounts'] = find_col(['amounts', 'amount'])
            if not col_map['total']:
                col_map['total'] = find_col(['total amount', 'total', 'total_amount'])
            if not col_map['created']:
                col_map['created'] = find_col(['created at', 'created', 'created_at'])
            if not col_map['updated']:
                col_map['updated'] = find_col(['updated at', 'updated', 'updated_at'])

        col_id = request.form.get('col_id')
        if not col_id and is_legacy:
            col_id = find_col(['id'])

        col_book = request.form.get('col_book') or request.form.get('col_book_number')
        if not col_book and is_legacy:
            col_book = find_col(['book number', 'book', 'book no', 'bookno'])

        col_page = request.form.get('col_page') or request.form.get('col_page_number')
        if not col_page and is_legacy:
            col_page = find_col(['page number', 'page', 'page no', 'pageno'])

        duplicate_handling = request.form.get('duplicate_handling', 'skip')

        if not col_map['date'] or not col_map['serial_number'] or not col_map['amounts']:
            if is_ajax:
                return jsonify(success=False, error='Date, Serial Number, and Amounts columns must be mapped.')
            flash('Date, Serial Number, and Amounts columns must be mapped.', 'danger')
            return redirect(url_for('import_export.import_csv'))

        import_result = import_invoices_from_csv(
            rows, header, col_map,
            duplicate_handling=duplicate_handling,
            user_id=current_user.id,
            ip_address=get_client_ip(),
            legacy_mode=is_legacy,
            col_id=col_id,
            col_book=col_book,
            col_page=col_page
        )

        msg = (
            f"Import complete: {import_result['imported']} imported, "
            f"{import_result['skipped']} skipped, "
            f"{import_result['errors']} errors."
        )
        if is_ajax:
            return jsonify(success=True, message=msg)

        flash(msg, 'success' if import_result['errors'] == 0 else 'warning')

        log_action(
            user_id=current_user.id,
            action='import_old_data',
            details={
                'filename': file.filename,
                'imported': import_result['imported'],
                'skipped': import_result['skipped'],
                'errors': import_result['errors']
            },
            ip_address=get_client_ip()
        )

        return redirect(url_for('import_export.index'))

    except Exception as e:
        if is_ajax:
            return jsonify(success=False, error=f'Import failed: {str(e)}')
        flash(f'Import failed: {str(e)}', 'danger')
        return redirect(url_for('import_export.import_csv'))


@bp.route('/import-legacy', methods=['GET', 'POST'])
@login_required
@admin_required
def import_legacy():
    is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    if request.method == 'GET':
        return render_template('admin/import_legacy.html')

    if 'csv_file' not in request.files:
        if is_ajax:
            return jsonify(success=False, error='No file uploaded.')
        flash('No file uploaded.', 'danger')
        return redirect(url_for('import_export.import_legacy'))

    file = request.files['csv_file']
    if file.filename == '':
        if is_ajax:
            return jsonify(success=False, error='No file selected.')
        flash('No file selected.', 'danger')
        return redirect(url_for('import_export.import_legacy'))

    if not file.filename.endswith('.csv'):
        if is_ajax:
            return jsonify(success=False, error='Only CSV files are allowed.')
        flash('Only CSV files are allowed.', 'danger')
        return redirect(url_for('import_export.import_legacy'))

    try:
        content = file.read().decode('utf-8-sig')
        lines = content.splitlines()
        if not lines:
            if is_ajax:
                return jsonify(success=False, error='CSV file is empty.')
            flash('CSV file is empty.', 'danger')
            return redirect(url_for('import_export.import_legacy'))

        reader = csv.reader(lines)
        header = next(reader)
        rows = list(reader)

        if not rows:
            if is_ajax:
                return jsonify(success=False, error='CSV file has no data rows.')
            flash('CSV file has no data rows.', 'danger')
            return redirect(url_for('import_export.import_legacy'))

        expected_header = ['ID', 'Batch ID', 'Date', 'Serial Number', 'Book', 'Page', 'Amounts', 'Total Amount', 'Created At', 'Updated At']
        if not all(col in header for col in expected_header[:3]):
            if is_ajax:
                return jsonify(success=False, error='CSV format does not match the expected legacy format.')
            flash('CSV format does not match the expected legacy format.', 'danger')
            return redirect(url_for('import_export.import_legacy'))

        col_map = {
            'date': 'Date',
            'serial_number': 'Serial Number',
            'amounts': 'Amounts',
            'total': 'Total Amount',
            'created': 'Created At',
            'updated': 'Updated At'
        }

        duplicate_handling = request.form.get('duplicate_handling', 'skip')

        import_result = import_invoices_from_csv(
            rows, header, col_map,
            duplicate_handling=duplicate_handling,
            user_id=current_user.id,
            ip_address=get_client_ip(),
            legacy_mode=True,
            col_id='ID',
            col_book='Book',
            col_page='Page'
        )

        msg = (
            f"Legacy import complete: {import_result['imported']} imported, "
            f"{import_result['skipped']} skipped, {import_result['errors']} errors."
        )
        if is_ajax:
            return jsonify(success=True, message=msg)

        flash(msg, 'success' if import_result['errors'] == 0 else 'warning')

        log_action(
            user_id=current_user.id,
            action='import_legacy_data',
            details={
                'filename': file.filename,
                'imported': import_result['imported'],
                'skipped': import_result['skipped'],
                'errors': import_result['errors']
            },
            ip_address=get_client_ip()
        )

        return redirect(url_for('import_export.index'))

    except Exception as e:
        if is_ajax:
            return jsonify(success=False, error=f'Import failed: {str(e)}')
        flash(f'Import failed: {str(e)}', 'danger')
        return redirect(url_for('import_export.import_legacy'))


@bp.route('/sample-csv')
@login_required
@admin_required
def sample_csv():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Date', 'Serial Number', 'Book', 'Page', 'Amounts', 'Total Amount'])
    writer.writerow(['2026-09-01', '0001', '1', '1', '10.500|5.250|3.000', '18.750'])
    writer.writerow(['2026-09-02', '0002', '1', '2', '7.500|2.000', '9.500'])
    writer.writerow(['2026-09-03', '0003', '1', '3', '15.000', '15.000'])

    from app.batches import current_batch_id
    filename = f'batch_{current_batch_id()}_sample_invoices_import.csv'
    rows=list(csv.reader(io.StringIO(output.getvalue())))
    if rows and 'Batch ID' not in rows[0]:
        output=io.StringIO();writer=csv.writer(output)
        writer.writerow(['Batch ID']+rows[0])
        for row in rows[1:]: writer.writerow([current_batch_id()]+row)
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8-sig')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=filename
    )


