from sqlalchemy import cast, Integer
# app/routes/media.py

import os
import io
import json
import mimetypes
from datetime import datetime
from flask import (
    Blueprint, render_template, request, jsonify, flash, redirect,
    url_for, send_file, current_app, abort
)
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app import db
from app.models import Invoice, InvoiceMedia
from app.services.invoice_service import get_invoice_by_id
from app.services.audit_service import log_action
from app.utils.decorators import data_entry_required, admin_required, owner_or_admin_required, capability_required
from app.utils.helpers import get_client_ip, allowed_file, generate_unique_filename, format_file_size, get_invoice_book_page

bp = Blueprint('media', __name__, url_prefix='/media')


def _is_ajax():
    return request.headers.get('X-Requested-With') == 'XMLHttpRequest'


def get_upload_folder():
    upload_folder = current_app.config.get('UPLOAD_FOLDER', 'uploads')
    if not os.path.isabs(upload_folder):
        upload_folder = os.path.join(current_app.root_path, '..', upload_folder)
    os.makedirs(upload_folder, exist_ok=True)
    return upload_folder


def get_invoice_upload_path(invoice_id):
    upload_folder = get_upload_folder()
    invoice_folder = os.path.join(upload_folder, f'invoice_{invoice_id}')
    os.makedirs(invoice_folder, exist_ok=True)
    return invoice_folder


def is_media_required():
    from app.models import SystemSetting
    try:
        value = SystemSetting.get_value('media_required', 'False')
        return value.lower() == 'true'
    except Exception:
        return current_app.config.get('MEDIA_REQUIRED', False)


def _lookup_invoice_by_serial(serial):
    if not serial:
        return None
    serial = serial.strip().lstrip('#').strip()
    matches = Invoice.query.filter(Invoice.serial_number == serial).limit(2).all()
    if len(matches) > 1:
        from flask import abort
        abort(409, description='Ambiguous printed serial. Open this link with ?batch_id=YOUR_BATCH_ID.')
    if matches:
        from flask import g
        g.batch_id = matches[0].batch_id
        g.current_batch = matches[0].batch
    return matches[0] if matches else None


def _user_scope_query():
    q = Invoice.query
    if not current_user.is_admin():
        q = q.filter(Invoice.created_by == current_user.id)
    return q


def _get_adjacent_invoices(invoice):
    base = _user_scope_query()
    prev_inv = (base
                .filter(Invoice.batch_id == invoice.batch_id, cast(Invoice.serial_number, Integer) < int(invoice.serial_number))
                .order_by(cast(Invoice.serial_number, Integer).desc())
                .first())
    next_inv = (base
                .filter(Invoice.batch_id == invoice.batch_id, cast(Invoice.serial_number, Integer) > int(invoice.serial_number))
                .order_by(cast(Invoice.serial_number, Integer).asc())
                .first())
    return prev_inv, next_inv


# ============================================================
# QR payload builder
# ============================================================

def _build_invoice_qr_payload(invoice, mode='web', scan='auto'):
    """
    Build the string encoded into the invoice QR.

    mode:
      'web' — browser URL (fallback for phones without the app)
      'app' — JSON payload for the InvoiceFlow mobile app

    scan (only meaningful when mode='app'):
      'auto'  — app stays in AUTO mode (auto-advance on each scan).
                Used on printed sheets where you scan one after another.
      'focus' — app locks onto this invoice (FOCUS mode).
                Used when printing a QR for one specific invoice.
    """
    if scan not in ('auto', 'focus'):
        scan = 'auto'

    if mode == 'app':
        payload = {
            'type': 'invoice',
            'version': 2,
            'batch_id': invoice.batch_id,
            'invoice_id': invoice.id,
            'serial': invoice.serial_number,
            'base_url': request.url_root.rstrip('/'),
            'scan': scan,
        }
        return json.dumps(payload, separators=(',', ':'))

    # Web fallback: browser URL
    return url_for('media.mobile_scan', serial=invoice.serial_number, batch_id=invoice.batch_id, _external=True)


# ============================================================
# QR codes
# ============================================================

@bp.route('/qr/<serial>.svg')
def qr_svg(serial):
    invoice = _lookup_invoice_by_serial(serial)
    if not invoice:
        abort(404)

    mode = (request.args.get('mode') or 'web').lower()
    scan = (request.args.get('scan') or 'auto').lower()
    payload = _build_invoice_qr_payload(invoice, mode, scan)

    try:
        import qrcode
        import qrcode.image.svg
        factory = qrcode.image.svg.SvgPathImage
        qr = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_M,
                           box_size=10, border=2, image_factory=factory)
        qr.add_data(payload)
        qr.make(fit=True)
        img = qr.make_image()
        buf = io.BytesIO()
        img.save(buf)
        buf.seek(0)
        resp = send_file(buf, mimetype='image/svg+xml',
                         download_name=f'invoice_{invoice.serial_number}_qr_{mode}_{scan}.svg')
        resp.headers['Cache-Control'] = 'private, no-store'
        return resp
    except ImportError:
        abort(500, description='qrcode library not installed. Run: pip install qrcode')


@bp.route('/qr/<serial>.png')
def qr_png(serial):
    invoice = _lookup_invoice_by_serial(serial)
    if not invoice:
        abort(404)

    mode = (request.args.get('mode') or 'web').lower()
    scan = (request.args.get('scan') or 'auto').lower()
    payload = _build_invoice_qr_payload(invoice, mode, scan)

    try:
        import qrcode
        qr = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_M,
                           box_size=10, border=2)
        qr.add_data(payload)
        qr.make(fit=True)
        img = qr.make_image(fill_color='black', back_color='white')
        buf = io.BytesIO()
        img.save(buf, format='PNG')
        buf.seek(0)
        resp = send_file(buf, mimetype='image/png',
                         download_name=f'invoice_{invoice.serial_number}_qr_{mode}_{scan}.png')
        resp.headers['Cache-Control'] = 'private, no-store'
        return resp
    except ImportError:
        abort(501, description='Pillow not installed. Use the .svg variant instead.')


# ============================================================
# Thumbnails
# ============================================================

@bp.route('/thumb/<int:media_id>')
@login_required
@data_entry_required
def thumb(media_id):
    media = InvoiceMedia.query.get(media_id)
    if not media:
        abort(404)

    invoice = get_invoice_by_id(media.invoice_id)
    if not invoice:
        abort(404)

    if not current_user.is_admin() and invoice.created_by != current_user.id:
        abort(403)

    upload_folder = get_upload_folder()
    file_path = os.path.join(upload_folder, media.file_path)
    if not os.path.exists(file_path):
        abort(404)

    if not (media.mime_type and media.mime_type.startswith('image/')):
        abort(404)

    cache_dir = os.path.join(upload_folder, '.thumbs')
    os.makedirs(cache_dir, exist_ok=True)
    thumb_path = os.path.join(cache_dir, f'{media_id}.jpg')

    if not os.path.exists(thumb_path):
        try:
            from PIL import Image, ImageOps
            img = Image.open(file_path)
            img = ImageOps.exif_transpose(img)
            img = img.convert('RGB')
            img.thumbnail((240, 240), Image.LANCZOS)
            img.save(thumb_path, 'JPEG', quality=82)
        except Exception:
            return send_file(file_path, mimetype=media.mime_type)

    resp = send_file(thumb_path, mimetype='image/jpeg')
    resp.headers['Cache-Control'] = 'private, no-store'
    return resp


# ============================================================
# Web fallback uploader
# ============================================================

@bp.route('/m/<serial>')
@login_required
@data_entry_required
def mobile_scan(serial):
    invoice = _lookup_invoice_by_serial(serial)
    if not invoice:
        return render_template('media/mobile_scan_notfound.html', serial=serial), 404

    if not current_user.is_admin() and invoice.created_by != current_user.id:
        flash('You do not have permission to attach files to this invoice.', 'danger')
        return redirect(url_for('invoices.index'))

    book, page = get_invoice_book_page(invoice)
    existing_media = invoice.media.all()
    media_required = is_media_required() or invoice.media_required
    prev_inv, next_inv = _get_adjacent_invoices(invoice)

    return render_template(
        'media/mobile_scan.html',
        invoice=invoice,
        book=book,
        page=page,
        existing_media=existing_media,
        media_required=media_required,
        prev_invoice=prev_inv,
        next_invoice=next_inv,
    )


# ============================================================
# Scan list
# ============================================================

@bp.route('/scan')
@login_required
@data_entry_required
def scan_page():
    show = request.args.get('show', 'without')
    q = (request.args.get('q') or '').strip()
    date_str = (request.args.get('date') or '').strip()
    sort = request.args.get('sort', 'serial_asc')
    limit = request.args.get('limit', 200, type=int)

    query = _user_scope_query()

    if show == 'without':
        query = query.filter(~Invoice.media.any())
    elif show == 'with':
        query = query.filter(Invoice.media.any())

    if q:
        like = f'%{q}%'
        query = query.filter(Invoice.serial_number.ilike(like))

    if date_str:
        try:
            d = datetime.strptime(date_str, '%Y-%m-%d').date()
            query = query.filter(Invoice.date == d)
        except ValueError:
            date_str = ''

    if sort == 'date_desc':
        query = query.order_by(Invoice.date.desc(), Invoice.serial_number.desc())
    elif sort == 'serial_desc':
        query = query.order_by(cast(Invoice.serial_number, Integer).desc())
    else:
        query = query.order_by(cast(Invoice.serial_number, Integer).asc())

    invoices = query.limit(limit).all()

    invoice_data = []
    for inv in invoices:
        book, page = get_invoice_book_page(inv)
        invoice_data.append({
            'invoice': inv,
            'book': book,
            'page': page,
            'media_count': inv.media.count(),
        })

    return render_template(
        'media/scan.html',
        invoices=invoice_data,
        show=show,
        q=q,
        date_str=date_str,
        sort=sort,
        total=len(invoice_data),
    )


# ============================================================
# Upload endpoint (web fallback)
# ============================================================

@bp.route('/scan-upload/<int:invoice_id>', methods=['POST'])
@login_required
@data_entry_required
@capability_required('media.upload')
def scan_upload(invoice_id):
    invoice = get_invoice_by_id(invoice_id)
    if not invoice:
        return jsonify({'success': False, 'error': 'Invoice not found'}), 404

    if not current_user.is_admin() and invoice.created_by != current_user.id:
        return jsonify({'success': False, 'error': 'Permission denied'}), 403

    if 'file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400

    file = request.files['file']
    if not file or file.filename == '':
        return jsonify({'success': False, 'error': 'Empty file'}), 400

    mime = (file.content_type or '').lower()
    original_filename = secure_filename(file.filename) or ''
    if '.' not in original_filename:
        ext = 'jpg'
        if 'png' in mime: ext = 'png'
        elif 'gif' in mime: ext = 'gif'
        elif 'webp' in mime: ext = 'webp'
        elif 'heic' in mime: ext = 'heic'
        original_filename = f'capture.{ext}'

    # Decide by the file extension only: a client-sent image/* MIME must not let .svg/.html through.
    if not allowed_file(original_filename):
        return jsonify({'success': False, 'error': 'File type not allowed'}), 400

    try:
        unique_filename = generate_unique_filename(original_filename)
        upload_path = get_invoice_upload_path(invoice_id)
        file_path = os.path.join(upload_path, unique_filename)

        file.save(file_path)
        file_size = os.path.getsize(file_path)

        final_mime = file.content_type
        if not final_mime or final_mime == 'application/octet-stream':
            guessed, _ = mimetypes.guess_type(original_filename)
            final_mime = guessed or 'image/jpeg'

        media = InvoiceMedia(
            invoice_id=invoice_id,
            file_name=original_filename,
            file_path=os.path.relpath(file_path, get_upload_folder()),
            file_size=file_size,
            mime_type=final_mime,
            uploaded_by=current_user.id,
        )
        db.session.add(media)
        db.session.commit()

        log_action(
            user_id=current_user.id,
            action='upload_media',
            details={'invoice_id': invoice_id, 'serial_number': invoice.serial_number,
                     'filename': original_filename, 'size': file_size, 'source': 'mobile_scan'},
            ip_address=get_client_ip(),
        )

        return jsonify({
            'success': True,
            'media_id': media.id,
            'filename': original_filename,
            'size': file_size,
            'size_formatted': format_file_size(file_size),
            'media_count': invoice.media.count(),
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================
# QR sheet
# ============================================================

@bp.route('/qr-sheet')
@login_required
@data_entry_required
def qr_sheet():
    from_serial = request.args.get('from', '0001')
    count = request.args.get('count', 60, type=int)
    show = request.args.get('show', 'all')
    qr_mode = (request.args.get('mode') or 'app').lower()
    scan_mode = (request.args.get('scan') or 'auto').lower()
    if qr_mode not in ('app', 'web'):
        qr_mode = 'app'
    if scan_mode not in ('auto', 'focus'):
        scan_mode = 'auto'
    count = max(1, min(count, 400))

    try:
        start_num = int(str(from_serial).lstrip('#'))
    except (ValueError, TypeError):
        start_num = 1
    pad = len(str(from_serial).lstrip('#'))

    serials = [str(start_num + i).zfill(pad) for i in range(count)]

    query = Invoice.query.filter(Invoice.serial_number.in_(serials))
    if not current_user.is_admin():
        query = query.filter(Invoice.created_by == current_user.id)
    if show == 'without':
        query = query.filter(~Invoice.media.any())

    found = {inv.serial_number: inv for inv in query.all()}
    rows = [{'serial': s, 'invoice': found.get(s)} for s in serials]

    return render_template(
        'media/qr_sheet.html',
        rows=rows,
        from_serial=from_serial,
        count=count,
        show=show,
        qr_mode=qr_mode,
        scan_mode=scan_mode,
    )


# ============================================================
# Desktop upload / delete / download / view
# ============================================================

@bp.route('/upload/<int:invoice_id>', methods=['GET', 'POST'])
@login_required
@data_entry_required
@owner_or_admin_required(Invoice, 'invoice_id')
@capability_required('media.upload')
def upload(invoice_id):
    invoice = get_invoice_by_id(invoice_id)
    if not invoice:
        flash('Invoice not found.', 'danger')
        return redirect(url_for('invoices.index'))

    media_required = is_media_required() or invoice.media_required
    existing_media = invoice.media.all()

    if request.method == 'GET':
        return render_template('media/upload.html',
                               invoice=invoice,
                               existing_media=existing_media,
                               media_required=media_required,
                               max_file_size=current_app.config.get('MAX_CONTENT_LENGTH', 16 * 1024 * 1024))

    if 'files' not in request.files:
        if _is_ajax():
            return jsonify(success=False, error='No files selected.'), 400
        flash('No files selected.', 'warning')
        return redirect(url_for('media.upload', invoice_id=invoice_id))

    files = request.files.getlist('files')
    if not files or all(f.filename == '' for f in files):
        if _is_ajax():
            return jsonify(success=False, error='No files selected.'), 400
        flash('No files selected.', 'warning')
        return redirect(url_for('media.upload', invoice_id=invoice_id))

    uploaded_files = []
    errors = []

    for file in files:
        if file.filename == '':
            continue
        if not allowed_file(file.filename):
            errors.append(f"{file.filename}: File type not allowed.")
            continue

        original_filename = secure_filename(file.filename)
        unique_filename = generate_unique_filename(original_filename)
        upload_path = get_invoice_upload_path(invoice_id)
        file_path = os.path.join(upload_path, unique_filename)

        try:
            file.save(file_path)
            file_size = os.path.getsize(file_path)

            media = InvoiceMedia(
                invoice_id=invoice_id,
                file_name=original_filename,
                file_path=os.path.relpath(file_path, get_upload_folder()),
                file_size=file_size,
                mime_type=file.content_type or 'application/octet-stream',
                uploaded_by=current_user.id,
            )
            db.session.add(media)
            db.session.commit()

            log_action(
                user_id=current_user.id,
                action='upload_media',
                details={'invoice_id': invoice_id, 'filename': original_filename, 'size': file_size},
                ip_address=get_client_ip(),
            )
            uploaded_files.append({'filename': original_filename,
                                   'size': format_file_size(file_size),
                                   'id': media.id})
        except Exception as e:
            db.session.rollback()
            errors.append(f"{original_filename}: {str(e)}")
            if os.path.exists(file_path):
                os.remove(file_path)
            continue

    if _is_ajax():
        return jsonify(success=bool(uploaded_files), uploaded=uploaded_files, errors=errors,
                       error='; '.join(errors) or 'No files uploaded.'), (200 if uploaded_files else 400)

    if media_required and not uploaded_files and not existing_media:
        flash('Media is required for this invoice. Please upload at least one file.', 'danger')
        return redirect(url_for('media.upload', invoice_id=invoice_id))

    if uploaded_files:
        flash(f"Uploaded {len(uploaded_files)} file(s) successfully.", 'success')
    if errors:
        flash(f"Errors occurred: {'; '.join(errors)}", 'warning')

    return redirect(url_for('media.upload', invoice_id=invoice_id))


@bp.route('/delete/<int:media_id>', methods=['POST'])
@login_required
@data_entry_required
@capability_required('media.delete')
def delete(media_id):
    media = InvoiceMedia.query.get(media_id)
    if not media:
        if _is_ajax():
            return jsonify({'success': False, 'error': 'Media not found'}), 404
        flash('Media not found.', 'danger')
        return redirect(request.referrer or url_for('invoices.index'))

    if not current_user.is_admin() and media.uploaded_by != current_user.id:
        if _is_ajax():
            return jsonify({'success': False, 'error': 'Permission denied'}), 403
        flash('Permission denied.', 'danger')
        return redirect(request.referrer or url_for('invoices.index'))

    invoice = get_invoice_by_id(media.invoice_id)
    if not invoice:
        if _is_ajax():
            return jsonify({'success': False, 'error': 'Invoice not found'}), 404
        flash('Invoice not found.', 'danger')
        return redirect(request.referrer or url_for('invoices.index'))

    if not current_user.is_admin() and invoice.created_by != current_user.id:
        if _is_ajax():
            return jsonify({'success': False, 'error': 'Permission denied'}), 403
        flash('Permission denied.', 'danger')
        return redirect(request.referrer or url_for('invoices.index'))

    filename = media.file_name
    invoice_id = invoice.id
    redirect_target = url_for('invoices.view', id=invoice_id)

    try:
        upload_folder = get_upload_folder()
        file_path = os.path.join(upload_folder, media.file_path)
        if os.path.exists(file_path):
            os.remove(file_path)

        thumb_path = os.path.join(upload_folder, '.thumbs', f'{media_id}.jpg')
        if os.path.exists(thumb_path):
            try:
                os.remove(thumb_path)
            except OSError:
                pass

        db.session.delete(media)
        db.session.commit()

        log_action(
            user_id=current_user.id,
            action='delete_media',
            details={'invoice_id': invoice_id, 'filename': filename, 'media_id': media_id},
            ip_address=get_client_ip(),
        )

        message = f'File {filename} deleted.'
        if _is_ajax():
            return jsonify({'success': True, 'message': message})

        flash(message, 'success')
        return redirect(request.referrer or redirect_target)
    except Exception as e:
        db.session.rollback()
        if _is_ajax():
            return jsonify({'success': False, 'error': str(e)}), 500
        flash(f'Delete failed: {str(e)}', 'danger')
        return redirect(request.referrer or redirect_target)


@bp.route('/download/<int:media_id>')
@login_required
@data_entry_required
def download(media_id):
    media = InvoiceMedia.query.get(media_id)
    if not media:
        flash('File not found.', 'danger')
        return redirect(url_for('invoices.index'))

    invoice = get_invoice_by_id(media.invoice_id)
    if not invoice:
        flash('Invoice not found.', 'danger')
        return redirect(url_for('invoices.index'))

    if not current_user.is_admin() and invoice.created_by != current_user.id:
        flash('Permission denied.', 'danger')
        return redirect(url_for('invoices.index'))

    upload_folder = get_upload_folder()
    file_path = os.path.join(upload_folder, media.file_path)
    if not os.path.exists(file_path):
        flash('File not found on server.', 'danger')
        return redirect(url_for('invoices.view', id=media.invoice_id))

    log_action(
        user_id=current_user.id,
        action='download_media',
        details={'invoice_id': media.invoice_id, 'filename': media.file_name},
        ip_address=get_client_ip(),
    )

    return send_file(file_path, as_attachment=True,
                     download_name=media.file_name, mimetype=media.mime_type)


@bp.route('/view/<int:media_id>')
@login_required
@data_entry_required
def view(media_id):
    media = InvoiceMedia.query.get(media_id)
    if not media:
        abort(404)

    invoice = get_invoice_by_id(media.invoice_id)
    if not invoice:
        abort(404)

    if not current_user.is_admin() and invoice.created_by != current_user.id:
        abort(403)

    upload_folder = get_upload_folder()
    file_path = os.path.join(upload_folder, media.file_path)
    if not os.path.exists(file_path):
        abort(404)

    extension = media.file_name.rsplit('.', 1)[-1].lower() if '.' in media.file_name else ''
    if (media.mime_type and media.mime_type.startswith('image/') and 'svg' not in media.mime_type
            and extension in {'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'}):
        return send_file(file_path, mimetype=media.mime_type)
    return send_file(file_path, as_attachment=True,
                     download_name=media.file_name, mimetype=media.mime_type)


@bp.route('/toggle-required', methods=['POST'])
@login_required
@admin_required
def toggle_required():
    from app.models import SystemSetting
    enabled = request.form.get('enabled') == 'true'
    SystemSetting.set_value('media_required', str(enabled))
    log_action(user_id=current_user.id, action='settings_update',
               details={'setting': 'media_required', 'value': enabled},
               ip_address=get_client_ip())
    return jsonify({'success': True, 'message': f'Media required {enabled}'})


@bp.route('/<int:invoice_id>/cleanup', methods=['POST'])
@login_required
@admin_required
def cleanup_orphaned(invoice_id):
    invoice = get_invoice_by_id(invoice_id)
    if not invoice:
        return jsonify({'success': False, 'error': 'Invoice not found'}), 404

    upload_path = get_invoice_upload_path(invoice_id)
    if not os.path.exists(upload_path):
        return jsonify({'success': True, 'message': 'No files to clean up.'})

    files = set(os.listdir(upload_path))
    media_files = invoice.media.all()
    db_files = set(
        m.file_path.split('/')[-1] if '/' in m.file_path else m.file_path
        for m in media_files
    )
    orphans = files - db_files
    if not orphans:
        return jsonify({'success': True, 'message': 'No orphaned files found.'})

    deleted = []
    for orphan in orphans:
        try:
            os.remove(os.path.join(upload_path, orphan))
            deleted.append(orphan)
        except Exception:
            continue

    log_action(user_id=current_user.id, action='cleanup_media',
               details={'invoice_id': invoice_id, 'deleted': len(deleted), 'files': deleted[:10]},
               ip_address=get_client_ip())

    return jsonify({'success': True,
                    'message': f'Cleaned up {len(deleted)} orphaned file(s).',
                    'deleted': deleted[:20]})


