# app/routes/backup.py

import os
import tempfile
from datetime import datetime
from flask import (
    Blueprint, render_template, request, jsonify, flash, redirect,
    url_for, send_file, current_app, session
)
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app import db
from app.services.backup_service import (
    create_backup, get_backup_files, restore_backup, delete_backup,
    get_backup_info, test_backup_system, get_backup_dir, get_backup_retention_count,
    cleanup_old_backups, restore_backup_from_path, validate_sql_file,
    get_backup_interval_minutes,
    start_restore_in_background, is_restore_in_progress, get_restore_state,
)
from app.services.audit_service import log_action
from app.utils.decorators import admin_required
from app.utils.helpers import get_client_ip

bp = Blueprint('backup', __name__, url_prefix='/backup')


@bp.route('/')
@login_required
@admin_required
def index():
    backup_files = get_backup_files()
    retention_count = get_backup_retention_count()
    backup_dir = get_backup_dir()
    system_status = test_backup_system()

    context = {
        'backup_files': backup_files,
        'retention_count': retention_count,
        'backup_interval_minutes': get_backup_interval_minutes(),
        'backup_dir': backup_dir,
        'system_status': system_status,
        'total_backups': len(backup_files),
        'total_size': sum(f['size'] for f in backup_files),
        'max_upload_mb': current_app.config.get('BACKUP_UPLOAD_MAX_MB', 256),
        'restore_in_progress': is_restore_in_progress(),
    }
    return render_template('admin/backups.html', **context)


@bp.route('/create', methods=['POST'])
@login_required
@admin_required
def create():
    is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    if is_restore_in_progress():
        msg = 'A database restore is currently running. Please wait until it finishes.'
        if is_ajax:
            return jsonify({'success': False, 'error': msg}), 409
        flash(msg, 'warning')
        return redirect(url_for('backup.index'))

    try:
        result = create_backup(manual=True)
        if is_ajax:
            return jsonify(result)

        if result['success']:
            flash(f"Backup created successfully: {result['filename']} ({result.get('size_formatted', '')})", 'success')
        else:
            flash(f"Backup failed: {result.get('error', 'Unknown error')}", 'danger')

    except Exception as e:
        if is_ajax:
            return jsonify({'success': False, 'error': str(e)}), 500
        flash(f"Backup failed: {str(e)}", 'danger')

    return redirect(url_for('backup.index'))


@bp.route('/upload-restore', methods=['POST'])
@login_required
@admin_required
def upload_restore():
    if not current_app.config.get('ALLOW_WEB_RESTORE', False):
        from flask import abort
        abort(403, 'Web restore is disabled for safety. Follow the offline restore runbook in DEPLOYMENT.md.')
    """
    Upload a .sql file and restore the database from it.

    The restore runs on a background thread. This route returns immediately
    with a "started" response; the browser then polls /backup/restore-status
    for progress.
    """
    is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    def fail(msg, code=400):
        if is_ajax:
            return jsonify({'success': False, 'error': msg}), code
        flash(msg, 'danger')
        return redirect(url_for('backup.index'))

    if is_restore_in_progress():
        return fail('A restore is already running. Please wait until it finishes.', 409)

    if 'sql_file' not in request.files:
        return fail('No file uploaded.')

    file = request.files['sql_file']
    if not file or file.filename == '':
        return fail('No file selected.')

    if not file.filename.lower().endswith('.sql'):
        return fail('Only .sql files are allowed.')

    # Save to a temp file (streaming, no full read into memory).
    tmp_path = None
    try:
        fd, tmp_path = tempfile.mkstemp(prefix='uploaded_restore_', suffix='.sql')
        os.close(fd)
        file.save(tmp_path)

        # Validate structure before we kick off a background job.
        valid, reason = validate_sql_file(tmp_path)
        if not valid:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            return fail(f'SQL file validation failed: {reason}')

        # Hand off to a background thread. It will delete the temp file
        # itself once done (success or failure).
        ok, err = start_restore_in_background(
            current_app._get_current_object(),
            tmp_path,
            secure_filename(file.filename),
        )
        if not ok:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            return fail(err, 409)

        msg = 'Restore started in the background. Progress will update below.'
        if is_ajax:
            return jsonify({'success': True, 'message': msg, 'started': True})

        flash(msg, 'info')
        return redirect(url_for('backup.index'))

    except Exception as e:
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        return fail(f'Could not start restore: {str(e)}', 500)


@bp.route('/restore-status')
def restore_status():
    """
    Polled by the client during a restore. Deliberately does NOT go
    through @login_required — that would try to load the current user
    from the DB, which may be mid-restore. We authenticate via the
    session cookie instead, which never touches the database.
    """
    if not session.get('_user_id'):
        return jsonify({'error': 'Not logged in'}), 401
    return jsonify(get_restore_state())


@bp.route('/download/<filename>')
@login_required
@admin_required
def download(filename):
    backup_dir = get_backup_dir()
    filepath = os.path.join(backup_dir, filename)

    if not os.path.exists(filepath):
        flash('Backup file not found.', 'danger')
        return redirect(url_for('backup.index'))

    log_action(
        user_id=current_user.id,
        action='download_backup',
        details={'filename': filename},
        ip_address=get_client_ip(),
    )

    return send_file(
        filepath,
        as_attachment=True,
        download_name=filename,
        mimetype='application/sql',
    )


@bp.route('/restore', methods=['POST'])
@login_required
@admin_required
def restore():
    """Restore database from a backup file already in the backup directory."""
    if is_restore_in_progress():
        flash('A restore is already running. Please wait until it finishes.', 'warning')
        return redirect(url_for('backup.index'))

    filename = request.form.get('filename')
    if not filename:
        flash('No backup file specified.', 'danger')
        return redirect(url_for('backup.index'))

    confirm = request.form.get('confirm')
    if not confirm:
        info = get_backup_info(filename)
        if not info:
            flash('Backup file not found.', 'danger')
            return redirect(url_for('backup.index'))
        return render_template('admin/restore_confirm.html', backup=info)

    if confirm != 'yes':
        flash('Restore cancelled.', 'info')
        return redirect(url_for('backup.index'))

    if not current_app.config.get('ALLOW_WEB_RESTORE', False):
        from flask import abort
        abort(403, 'Web restore is disabled for safety. Follow the offline restore runbook in DEPLOYMENT.md.')
    result = restore_backup(filename)

    if result['success']:
        flash(result['message'], 'success')
        log_action(
            user_id=current_user.id,
            action='restore_backup',
            details={'filename': filename},
            ip_address=get_client_ip(),
        )
    else:
        flash(result.get('error', 'Restore failed.'), 'danger')

    return redirect(url_for('backup.index'))


@bp.route('/delete/<filename>', methods=['POST'])
@login_required
@admin_required
def delete(filename):
    result = delete_backup(filename)
    if result['success']:
        flash(result['message'], 'success')
    else:
        flash(result.get('error', 'Failed to delete backup.'), 'danger')
    return redirect(url_for('backup.index'))


@bp.route('/cleanup', methods=['POST'])
@login_required
@admin_required
def cleanup():
    max_age_days = request.form.get('max_age_days', 30, type=int)
    result = cleanup_old_backups(max_age_days)

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify(result)

    flash(f"Cleaned up {result.get('deleted_count', 0)} old backup(s).", 'success')
    return redirect(url_for('backup.index'))


@bp.route('/info/<filename>')
@login_required
@admin_required
def info(filename):
    info_data = get_backup_info(filename)
    if not info_data:
        return jsonify({'error': 'Backup file not found'}), 404
    return jsonify(info_data)


@bp.route('/status')
@login_required
@admin_required
def status():
    system_status = test_backup_system()
    backup_files = get_backup_files()

    return jsonify({
        'system_ready': system_status['success'],
        'system_message': system_status.get('message', system_status.get('error', 'Unknown')),
        'mysqldump_available': system_status.get('mysqldump_available', False),
        'total_backups': len(backup_files),
        'total_size': sum(f['size'] for f in backup_files),
        'backup_dir': get_backup_dir(),
        'retention_count': get_backup_retention_count(),
        'restore_in_progress': is_restore_in_progress(),
    })


@bp.route('/auto-toggle', methods=['POST'])
@login_required
@admin_required
def auto_toggle():
    from app.models import SystemSetting

    enabled = request.form.get('enabled') == 'true'
    SystemSetting.set_value('auto_backup_enabled', str(enabled))

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'enabled': enabled})

    flash(f"Auto backup {'enabled' if enabled else 'disabled'} successfully.", 'success')
    return redirect(url_for('backup.index'))


