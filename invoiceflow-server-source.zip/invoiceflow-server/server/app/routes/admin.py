# app/routes/admin.py

import csv
import io
import os
from datetime import datetime, timedelta, date, timezone
from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for, send_file, current_app
from flask_login import login_required, current_user
from sqlalchemy import func
from sqlalchemy.orm import joinedload
from app import db
from app.models import User, Invoice, InvoiceMedia, AuditLog, SystemSetting, Book, totals_amount_expr
from app.forms import UserCreateForm, AdminSettingsForm
from app.services.audit_service import log_action
from app.services.backup_service import create_backup
from app.utils.decorators import admin_required
from app.utils.helpers import (
    get_client_ip,
    DATE_FORMAT_PATTERNS, DATE_FORMAT_OPTIONS,
    DEFAULT_DATE_FORMAT, get_date_format_label,
)

bp = Blueprint('admin', __name__, url_prefix='/admin')


# ============================================
# User Management Routes
# ============================================

@bp.route('/users')
@login_required
@admin_required
def users():
    try:
        all_users = User.query.order_by(User.created_at.desc()).all()
        return render_template(
            'admin/users.html',
            users=all_users,
            current_date=datetime.now(timezone.utc)
        )
    except Exception as e:
        flash(f'Error loading users: {str(e)}', 'danger')
        return redirect(url_for('main.dashboard'))


@bp.route('/users/<int:id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_user(id):
    user = User.query.get_or_404(id)

    if user.id == current_user.id:
        flash('You cannot edit your own account here. Use Profile.', 'warning')
        return redirect(url_for('admin.users'))

    form = UserCreateForm(original_user=user, obj=user)
    if form.validate_on_submit():
        user.username = form.username.data
        user.email = form.email.data
        user.role = form.role.data
        user.can_export = form.can_export.data
        if form.password.data:
            user.set_password(form.password.data)
        db.session.commit()

        log_action(
            user_id=current_user.id,
            action='update_user',
            details={
                'target_user': user.username,
                'role': user.role,
                'email': user.email,
                'can_export': user.can_export
            },
            ip_address=get_client_ip()
        )
        flash(f'User {user.username} updated successfully.', 'success')
        return redirect(url_for('admin.users'))

    return render_template('auth/register.html', form=form, edit_mode=True, user=user)


@bp.route('/users/<int:id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_user(id):
    from app.detection import policy_lock
    with db.session.no_autoflush: policy_lock(db.session)
    user = User.query.get_or_404(id)

    if user.id == current_user.id:
        return jsonify({'success': False, 'error': 'You cannot delete yourself.'}), 400

    # The authenticated admin is never the target (self-delete is blocked).
    admin_user = current_user
    from app.detection import ReviewCase
    ReviewCase.query.filter_by(subject_user_id=user.id).update({'subject_user_id':None})
    ReviewCase.query.filter_by(reviewed_by=user.id).update({'reviewed_by':None})
    db.session.info['detect_all'] = True
    Invoice.query.execution_options(all_batches=True).filter_by(created_by=user.id).update({'created_by': admin_user.id}, synchronize_session=False)
    Invoice.query.execution_options(all_batches=True).filter_by(updated_by=user.id).update({'updated_by': admin_user.id}, synchronize_session=False)
    InvoiceMedia.query.filter_by(uploaded_by=user.id).update({'uploaded_by': admin_user.id}, synchronize_session=False)
    AuditLog.query.filter_by(user_id=user.id).update({'user_id': admin_user.id}, synchronize_session=False)
    Book.query.execution_options(all_batches=True).filter_by(assigned_user_id=user.id).update({'assigned_user_id': None}, synchronize_session=False)

    log_action(
        user_id=current_user.id,
        action='delete_user',
        details={
            'deleted_user': user.username,
            'reassigned_to': admin_user.username
        },
        ip_address=get_client_ip()
    )

    db.session.expire(user)
    db.session.delete(user)
    db.session.commit()

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': 'User deleted.'})
    flash('User deleted. Invoices reassigned to the administrator.', 'success')
    return redirect(url_for('admin.users'))


# ============================================
# Books
# ============================================
@bp.route('/books')
@login_required
@admin_required
def books_index():
    """List all configured books with page usage and totals."""
    # Aggregate: count + total per book_id in one query
    aggregates = dict(
        (row[0], {'count': int(row[1] or 0), 'total': float(row[2] or 0)})
        for row in db.session.query(
            Invoice.book_id,
            func.count(Invoice.id),
            func.sum(totals_amount_expr()),
        )
        .filter(Invoice.book_id.isnot(None))
        .group_by(Invoice.book_id)
        .all()
    )

    books_data = []
    for book in Book.query.order_by(Book.book_number).all():
        agg = aggregates.get(book.id, {'count': 0, 'total': 0.0})
        used = agg['count']
        books_data.append({
            'book': book,
            'used': used,
            'remaining': max(book.capacity - used, 0),
            'missing': max(book.capacity - used, 0),
            'total_amount': agg['total'],
            'completion_pct': round((used / book.capacity * 100), 1) if book.capacity else 0,
        })

    grand_total = sum(b['total_amount'] for b in books_data)
    grand_used = sum(b['used'] for b in books_data)
    grand_capacity = sum(b['book'].capacity for b in books_data)

    return render_template(
        'admin/books.html',
        books_data=books_data,
        grand_total=grand_total,
        grand_used=grand_used,
        grand_capacity=grand_capacity,
    )


@bp.route('/books/<int:book_number>')
@login_required
@admin_required
def book_detail(book_number):
    """Full detail page for a single book: pages, invoices, amounts, missing pages."""
    book = Book.query.filter_by(book_number=book_number).first_or_404()

    page = request.args.get('page', 1, type=int)
    base = Invoice.query.filter(Invoice.book_id == book.id)
    pagination = base.options(joinedload(Invoice.book_record)).order_by(
        Invoice.book_page.is_(None), Invoice.book_page.asc(), Invoice.serial_number.asc()
    ).paginate(page=max(1, page), per_page=12, error_out=False)
    invoices = pagination.items
    ids = [inv.id for inv in invoices]
    counts = dict(db.session.query(InvoiceMedia.invoice_id, func.count(InvoiceMedia.id)).filter(
        InvoiceMedia.invoice_id.in_(ids)).group_by(InvoiceMedia.invoice_id).all()) if ids else {}
    first_ids = [row[0] for row in db.session.query(func.min(InvoiceMedia.id)).filter(
        InvoiceMedia.invoice_id.in_(ids), InvoiceMedia.mime_type.like('image/%')
    ).group_by(InvoiceMedia.invoice_id).all()] if ids else []
    images = {m.invoice_id: m for m in InvoiceMedia.query.filter(InvoiceMedia.id.in_(first_ids)).all()} if first_ids else {}
    for inv in invoices:
        inv.media_count = counts.get(inv.id, 0)
        inv.first_image = images.get(inv.id)
    stats = db.session.query(func.count(Invoice.id), func.coalesce(func.sum(totals_amount_expr()), 0),
                             func.min(Invoice.date), func.max(Invoice.date)).filter(Invoice.book_id == book.id).one()
    used_pages, total_amount, first_date, last_date = stats
    total_amount = float(total_amount)
    average_amount = total_amount / used_pages if used_pages else 0
    used_numbers = {n for (n,) in db.session.query(Invoice.book_page).filter(Invoice.book_id == book.id).all()}
    missing_pages = [n for n in range(1, book.capacity + 1) if n not in used_numbers]

    # ---------- Users who entered invoices in this book ----------
    users_in_book = (db.session.query(User)
                     .join(Invoice, Invoice.created_by == User.id)
                     .filter(Invoice.book_id == book.id)
                     .distinct()
                     .order_by(User.username)
                     .all())

    # ---------- Per-user breakdown ----------
    per_user = (db.session.query(
                    User.username,
                    func.count(Invoice.id).label('count'),
                    func.sum(totals_amount_expr()).label('total'),
                )
                .join(Invoice, Invoice.created_by == User.id)
                .filter(Invoice.book_id == book.id)
                .group_by(User.username)
                .order_by(func.count(Invoice.id).desc())
                .all())
    per_user_rows = [
        {'username': r.username, 'count': int(r.count), 'total': float(r.total or 0)}
        for r in per_user
    ]

    context = {
        'book': book,
        'invoices': invoices,
        'pagination': pagination,
        'used_pages': used_pages,
        'missing_pages': missing_pages,
        'total_amount': total_amount,
        'average_amount': average_amount,
        'first_date': first_date,
        'last_date': last_date,
        'users_in_book': users_in_book,
        'per_user_rows': per_user_rows,
    }
    return render_template('admin/book_detail.html', **context)


# ============================================
# System Settings
# ============================================

@bp.route('/settings', methods=['GET', 'POST'])
@login_required
@admin_required
def settings():
    """System settings page. GET shows form, POST saves settings."""
    if request.method == 'GET':
        settings = {
            'media_required': SystemSetting.get_value('media_required', 'False') == 'True',
            'auto_backup_enabled': SystemSetting.get_value('auto_backup_enabled', 'True') == 'True',
            'backup_interval': int(SystemSetting.get_value('backup_interval', '2')),
            'backup_retention': int(SystemSetting.get_value('backup_retention', '20')),
            'pages_per_book': int(SystemSetting.get_value('pages_per_book', '50')),
            'number_of_books': int(SystemSetting.get_value('number_of_books', '10')),
            'date_format': get_date_format_label(),
        }

        today = date.today()
        pattern = DATE_FORMAT_PATTERNS.get(settings['date_format'], DATE_FORMAT_PATTERNS[DEFAULT_DATE_FORMAT])
        date_format_preview = today.strftime(pattern)

        backup_dir = current_app.config.get('BACKUP_DIR', 'backups')
        return render_template(
            'admin/settings.html',
            settings=settings,
            backup_dir=backup_dir,
            date_format_options=DATE_FORMAT_OPTIONS,
            date_format_preview=date_format_preview,
        )

    if request.is_json:
        data = request.get_json()
        if not isinstance(data, dict):
            return jsonify(success=False, error='Settings must be a JSON object.'), 400
    else:
        data = request.form.to_dict()

    try:
        media_required = data.get('media_required') in (True, 'true', 'on')
        auto_backup_enabled = data.get('auto_backup_enabled') in (True, 'true', 'on')
        backup_interval = int(data.get('backup_interval', 2))
        backup_retention = int(data.get('backup_retention', 20))
        pages_per_book = int(data.get('pages_per_book', 50))
        number_of_books = int(data.get('number_of_books', 10))
        date_format = data.get('date_format') or DEFAULT_DATE_FORMAT

        if date_format not in DATE_FORMAT_PATTERNS:
            raise ValueError(f'Invalid date format: {date_format}')

        if backup_interval < 1 or backup_interval > 60:
            raise ValueError('Backup interval must be between 1 and 60 minutes.')
        if backup_retention < 1 or backup_retention > 100:
            raise ValueError('Backup retention must be between 1 and 100 files.')
        if pages_per_book < 1 or pages_per_book > 1000:
            raise ValueError('Pages per book must be between 1 and 1000.')
        if number_of_books < 1 or number_of_books > 10000:
            raise ValueError('Number of books must be between 1 and 10000.')

        SystemSetting.set_value('media_required', str(media_required))
        SystemSetting.set_value('auto_backup_enabled', str(auto_backup_enabled))
        SystemSetting.set_value('backup_interval', str(backup_interval))
        SystemSetting.set_value('backup_retention', str(backup_retention))
        SystemSetting.set_value('pages_per_book', str(pages_per_book))
        SystemSetting.set_value('number_of_books', str(number_of_books))
        SystemSetting.set_value('date_format', date_format)

        db.session.commit()

        log_action(
            user_id=current_user.id,
            action='settings_update',
            details={
                'media_required': media_required,
                'auto_backup_enabled': auto_backup_enabled,
                'backup_interval': backup_interval,
                'backup_retention': backup_retention,
                'pages_per_book': pages_per_book,
                'number_of_books': number_of_books,
                'date_format': date_format,
            },
            ip_address=get_client_ip()
        )

        if request.is_json:
            return jsonify({'success': True, 'message': 'Settings updated successfully.'})
        else:
            flash('Settings updated successfully.', 'success')
            return redirect(url_for('admin.settings'))

    except ValueError as e:
        if request.is_json:
            return jsonify({'success': False, 'error': str(e)}), 400
        else:
            flash(f'Error: {str(e)}', 'danger')
            return redirect(url_for('admin.settings'))


# ============================================
# Audit Log
# ============================================

@bp.route('/audit-log')
@login_required
@admin_required
def audit_log():
    from app.services.audit_service import get_audit_logs, get_action_types

    user_id = request.args.get('user_id', type=int)
    action = request.args.get('action')
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')
    page = request.args.get('page', 1, type=int)
    per_page = 50

    if from_date:
        try:
            from_date = datetime.strptime(from_date, '%Y-%m-%d').date()
        except ValueError:
            from_date = None
    if to_date:
        try:
            to_date = datetime.strptime(to_date, '%Y-%m-%d').date()
        except ValueError:
            to_date = None

    from_dt = datetime.combine(from_date, datetime.min.time()) if from_date else None
    to_dt = datetime.combine(to_date, datetime.max.time()) if to_date else None

    pagination = get_audit_logs(
        user_id=user_id,
        action=action,
        from_date=from_dt,
        to_date=to_dt,
        page=page,
        per_page=per_page
    )

    users = User.query.order_by(User.username).all()
    action_types = get_action_types()

    return render_template(
        'admin/audit_log.html',
        pagination=pagination,
        users=users,
        action_types=action_types,
        current_date=date.today()
    )


@bp.route('/audit-log/export')
@login_required
@admin_required
def audit_log_export():
    user_id = request.args.get('user_id', type=int)
    action = request.args.get('action')
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')

    if from_date:
        try:
            from_date = datetime.strptime(from_date, '%Y-%m-%d').date()
        except ValueError:
            from_date = None
    if to_date:
        try:
            to_date = datetime.strptime(to_date, '%Y-%m-%d').date()
        except ValueError:
            to_date = None

    from_dt = datetime.combine(from_date, datetime.min.time()) if from_date else None
    to_dt = datetime.combine(to_date, datetime.max.time()) if to_date else None

    query = AuditLog.query
    if user_id:
        query = query.filter(AuditLog.user_id == user_id)
    if action:
        query = query.filter(AuditLog.action == action)
    if from_dt:
        query = query.filter(AuditLog.timestamp >= from_dt)
    if to_dt:
        query = query.filter(AuditLog.timestamp <= to_dt)

    logs = query.order_by(AuditLog.timestamp.desc()).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Timestamp', 'User', 'Action', 'IP Address', 'Details'])

    for log in logs:
        user = User.query.get(log.user_id)
        writer.writerow([
            log.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            user.username if user else 'System',
            log.action,
            log.ip_address or '',
            log.details or ''
        ])

    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8-sig')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=f'audit_log_{date.today().isoformat()}.csv'
    )


# ============================================
# Factory Reset / Clear Audit
# ============================================

@bp.route('/factory-reset', methods=['POST'])
@login_required
@admin_required
def factory_reset():
    backup_result = create_backup(manual=True)
    if not backup_result['success']:
        flash('Factory reset failed: Could not create backup before reset.', 'danger')
        return redirect(url_for('admin.settings'))

    upload_folder = current_app.config.get('UPLOAD_FOLDER', 'uploads')
    import shutil
    for media in InvoiceMedia.query.all():
        file_path = os.path.join(upload_folder, media.file_path)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except OSError:
                pass
        db.session.delete(media)

    from app.models import InvoiceNoteMedia
    for note_media in InvoiceNoteMedia.query.all():
        file_path = os.path.join(upload_folder, note_media.file_path)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except OSError:
                pass

    from app.detection import ReviewCase
    ReviewCase.query.delete()
    Invoice.query.execution_options(all_batches=True).delete()
    AuditLog.query.delete()
    db.session.commit()

    log_action(
        user_id=current_user.id,
        action='factory_reset',
        details={'backup_created': backup_result['filename']},
        ip_address=get_client_ip()
    )

    flash('Factory reset completed. All invoices, media, and audit logs deleted. Backup created.', 'success')
    return redirect(url_for('admin.settings'))


@bp.route('/clear-audit-logs', methods=['POST'])
@login_required
@admin_required
def clear_audit_logs():
    cutoff = datetime.now(timezone.utc) - timedelta(days=30)
    logs_to_delete = AuditLog.query.filter(AuditLog.timestamp < cutoff)
    count = logs_to_delete.count()
    if count == 0:
        flash('No audit logs older than 30 days found.', 'info')
        return redirect(url_for('admin.settings'))

    logs_to_delete.delete()
    db.session.commit()

    log_action(
        user_id=current_user.id,
        action='clear_audit_logs',
        details={'deleted_count': count},
        ip_address=get_client_ip()
    )

    flash(f'Cleared {count} audit logs older than 30 days.', 'success')
    return redirect(url_for('admin.settings'))


