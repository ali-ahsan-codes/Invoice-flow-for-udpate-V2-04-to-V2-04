# app/routes/auth.py

import io
import json
from urllib.parse import urlsplit
from datetime import datetime, timezone
from flask import (
    Blueprint, render_template, redirect, url_for, flash,
    request, current_app, send_file, session as flask_session,
)
from flask_login import login_user, logout_user, login_required, current_user
from app import db
from app.models import User, AuditLog
from app.forms import LoginForm, UserCreateForm, UserProfileForm, PasswordChangeForm
from app.utils.helpers import get_client_ip

bp = Blueprint('auth', __name__, url_prefix='/auth')


def safe_next_path(target):
    """Only allow local absolute paths; block browser-normalized redirects."""
    if not target or not target.startswith('/') or target.startswith('//'):
        return None
    if '\\' in target or any(ord(c) < 32 or ord(c) == 127 for c in target):
        return None
    try:
        parsed = urlsplit(target)
    except ValueError:
        return None
    return target if not parsed.scheme and not parsed.netloc else None


@bp.route('/login', methods=['GET', 'POST'])
def login():
    """User login with full session hygiene."""
    if current_user.is_authenticated and request.method == 'GET':
        return redirect(url_for('main.dashboard'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            # --- 1. Wipe everything from previous session ---
            flask_session.clear()
            logout_user()

            # --- 2. Fresh authenticated session ---
            user.last_login = datetime.now(timezone.utc)
            login_user(user, remember=form.remember.data)
            flask_session['_fresh'] = True
            flask_session.modified = True

            # --- 3. Audit log ---
            audit = AuditLog(
                user_id=user.id,
                action='login',
                details={'ip': get_client_ip()},
                ip_address=get_client_ip(),
            )
            db.session.add(audit)
            db.session.commit()

            # --- 4. Flash in the fresh session ---
            flash('Logged in successfully.', 'success')

            # --- 5. Redirect ---
            if user.is_data_entry():
                return redirect(url_for('invoices.start_session'))

            next_page = request.args.get('next')
            return redirect(safe_next_path(next_page) or url_for('main.dashboard'))
        else:
            flash('Invalid username or password.', 'danger')

    return render_template('auth/login.html', form=form)


@bp.route('/logout')
@login_required
def logout():
    """User logout with full session wipe and remember-cookie removal."""
    # Log BEFORE clearing (needs current_user)
    audit = AuditLog(
        user_id=current_user.id,
        action='logout',
        details={'ip': get_client_ip()},
        ip_address=get_client_ip(),
    )
    db.session.add(audit)
    db.session.commit()

    # Wipe login + full session (kills remember cookie too)
    flask_session.clear()
    logout_user()

    # Fresh flash for the login page
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))


@bp.route('/register', methods=['GET', 'POST'])
@login_required
def register():
    """Admin only: create new user accounts."""
    if not current_user.is_admin():
        flash('Access denied. Admins only.', 'danger')
        return redirect(url_for('main.dashboard'))

    form = UserCreateForm()
    if form.validate_on_submit():
        user = User(
            username=form.username.data,
            email=form.email.data,
            role=form.role.data,
            can_export=form.can_export.data,
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()

        audit = AuditLog(
            user_id=current_user.id,
            action='create_user',
            details={
                'new_user': user.username,
                'role': user.role,
                'can_export': user.can_export,
            },
            ip_address=get_client_ip(),
        )
        db.session.add(audit)
        db.session.commit()

        flash(f'User {user.username} created successfully.', 'success')
        return redirect(url_for('admin.users'))

    return render_template('auth/register.html', form=form)


@bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    """User profile update."""
    form = UserProfileForm(obj=current_user)
    if form.validate_on_submit():
        current_user.email = form.email.data
        current_user.preferred_start_serial = form.preferred_start_serial.data
        db.session.commit()

        audit = AuditLog(
            user_id=current_user.id,
            action='update_profile',
            details={
                'email': current_user.email,
                'preferred_start_serial': current_user.preferred_start_serial,
            },
            ip_address=get_client_ip(),
        )
        db.session.add(audit)
        db.session.commit()

        flash('Profile updated successfully.', 'success')
        return redirect(url_for('auth.profile'))

    return render_template('auth/profile.html', form=form)


@bp.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    """Change user's password."""
    form = PasswordChangeForm()
    if form.validate_on_submit():
        if current_user.check_password(form.current_password.data):
            current_user.set_password(form.new_password.data)
            db.session.commit()

            audit = AuditLog(
                user_id=current_user.id,
                action='change_password',
                details={'ip': get_client_ip()},
                ip_address=get_client_ip(),
            )
            db.session.add(audit)
            db.session.commit()

            flash('Password changed successfully.', 'success')
            return redirect(url_for('auth.profile'))
        else:
            flash('Current password is incorrect.', 'danger')

    return render_template('auth/change_password.html', form=form)


# ============================================================
# Mobile app connection QR
# ============================================================

@bp.route('/connect-qr.svg')
@login_required
def connect_qr():
    """SVG QR the mobile app scans to bind itself to this user."""
    if not current_user.api_key:
        current_user.regenerate_api_key()
        db.session.commit()

    base_url = request.url_root.rstrip('/')
    payload = json.dumps({
        'app': 'invoiceflow',
        'type': 'connect',
        'version': 1,
        'base_url': base_url,
        'api_key': current_user.api_key,
    })

    import qrcode
    import qrcode.image.svg
    factory = qrcode.image.svg.SvgPathImage
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10, border=2, image_factory=factory,
    )
    qr.add_data(payload)
    qr.make(fit=True)
    img = qr.make_image()
    buf = io.BytesIO()
    img.save(buf)
    buf.seek(0)
    return send_file(buf, mimetype='image/svg+xml')


@bp.route('/regenerate-api-key', methods=['POST'])
@login_required
def regenerate_api_key():
    """Invalidate the current API key and issue a new one."""
    current_user.regenerate_api_key()
    db.session.commit()

    audit = AuditLog(
        user_id=current_user.id,
        action='regenerate_api_key',
        details={'ip': get_client_ip()},
        ip_address=get_client_ip(),
    )
    db.session.add(audit)
    db.session.commit()

    flash('A new API key was generated. Any connected device must reconnect.', 'success')
    return redirect(url_for('auth.profile'))


