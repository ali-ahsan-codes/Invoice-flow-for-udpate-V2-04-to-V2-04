# app/routes/invoices.py

import csv
import os
import io
import json
from datetime import datetime, date, timedelta
from flask import (
    Blueprint, render_template, request, jsonify, flash, redirect,
    url_for, send_file, current_app, abort, session as flask_session,
)
from flask_login import login_required, current_user
from sqlalchemy import func, and_, or_
from sqlalchemy.orm import joinedload
from app import db
from app.models import Invoice, User, AuditLog, InvoiceMedia, Book, InvoiceNote, InvoiceNoteMedia, InvoiceLink, totals_included_clause
from app.forms import InvoiceForm, InvoiceSearchForm
from app.services.invoice_service import (
    create_invoice, update_invoice, delete_invoice, get_invoice_by_id,
    search_invoices, get_daily_totals, get_monthly_totals, get_work_days_summary,
    generate_next_serial, generate_next_serial_in_book,
    get_book_serial_range, get_book_usage,
    get_recent_invoices,
)
from app.services.audit_service import log_action
from app.services.invoice_history_service import (
    add_note, delete_note, create_link, delete_link, build_history, parse_bool,
    count_links, count_notes, can_access_invoice, note_attachment_path,
    get_invoice_any_batch,
)
from app.utils.decorators import data_entry_required, admin_required, owner_or_admin_required
from app.utils.helpers import (
    format_currency, get_client_ip, format_date, calculate_book_page,
    is_valid_serial, get_invoice_book_page, parse_date_string
)

from app.batches import current_batch_id

bp = Blueprint('invoices', __name__, url_prefix='/invoices')


def _is_ajax():
    return request.headers.get('X-Requested-With') == 'XMLHttpRequest'


def _ajax_error(message, status=400, errors=None, redirect_to=None):
    """Uniform JSON error response for AJAX requests."""
    payload = {'success': False, 'error': message}
    if errors:
        payload['errors'] = errors
    if redirect_to:
        payload['redirect'] = redirect_to
    return jsonify(payload), status


# ============================================================
# WORK SESSION HELPERS
# ============================================================

def get_work_session():
    from app.batches import current_batch_id
    ws = (flask_session.get('batch_work_sessions') or {}).get(str(current_batch_id())) or flask_session.get('work_session')
    if ws and ws.get('batch_id', 1) != current_batch_id():
        return None
    return ws


def _update_work_session(book_number=None, start_serial=None, session_date=None):
    """Persist the current working state into the session."""
    from app.batches import current_batch_id
    work_session = get_work_session() or {}
    work_session['batch_id'] = current_batch_id()
    if book_number is not None:
        work_session['book'] = book_number
    if start_serial is not None:
        work_session['start_serial'] = start_serial
    if session_date is not None:
        work_session['date'] = session_date
    if 'started_at' not in work_session:
        work_session['started_at'] = datetime.utcnow().isoformat() + 'Z'
    flask_session['work_session'] = work_session
    sessions = dict(flask_session.get('batch_work_sessions') or {})
    sessions[str(current_batch_id())] = work_session
    flask_session['batch_work_sessions'] = dict(list(sessions.items())[-8:])
    flask_session.modified = True
    return work_session


def _book_last_date(book):
    """Return the most recent invoice date for a book, or None."""
    inv = (Invoice.query
           .filter(Invoice.book_id == book.id)
           .order_by(Invoice.date.desc(), Invoice.serial_number.desc())
           .first())
    return inv.date if inv else None


def _pick_session_serial(work_session):
    """Decide which serial to prefill the create form with."""
    book_number = work_session.get('book')
    start_serial = work_session.get('start_serial')

    if not book_number:
        return generate_next_serial()

    book = Book.query.filter_by(book_number=book_number).first()
    if not book:
        return None

    start, end = get_book_serial_range(book)
    if start is None:
        return None

    if start_serial:
        try:
            serial_num = int(str(start_serial).lstrip('0') or '0')
            if start <= serial_num <= end:
                taken = Invoice.query.filter_by(serial_number=start_serial).first()
                if not taken:
                    return start_serial
        except (ValueError, TypeError):
            pass

    ns, _ = generate_next_serial_in_book(book_number)
    return ns


def _user_last_book(user_id):
    """The book the given user most recently entered an invoice in."""
    inv = (Invoice.query
           .filter(Invoice.created_by == user_id)
           .filter(Invoice.book_id.isnot(None))
           .order_by(Invoice.created_at.desc())
           .first())
    if inv:
        return inv.book_record
    return None


def _recent_active_books(limit=10, lookback_days=90):
    cutoff = datetime.utcnow() - timedelta(days=lookback_days)

    subq = (db.session.query(
                Invoice.book_id,
                func.max(Invoice.created_at).label('last_used'),
            )
            .filter(Invoice.book_id.isnot(None))
            .filter(Invoice.created_at >= cutoff)
            .group_by(Invoice.book_id)
            .subquery())

    rows = (db.session.query(Book, subq.c.last_used)
            .join(subq, Book.id == subq.c.book_id)
            .order_by(subq.c.last_used.desc())
            .all())

    result = []
    for book, last_used in rows:
        info = get_book_usage(book)
        if info['remaining'] > 0:
            ld = _book_last_date(book)
            info['last_date'] = ld.isoformat() if ld else None
            result.append({
                'book': book,
                'info': info,
                'last_used': last_used,
            })
    return result[:limit]


def _fallback_books(limit=10):
    books = Book.query.order_by(Book.book_number).all()
    result = []
    for book in books:
        info = get_book_usage(book)
        if info['remaining'] > 0:
            ld = _book_last_date(book)
            info['last_date'] = ld.isoformat() if ld else None
            result.append({
                'book': book,
                'info': info,
                'last_used': None,
            })
        if len(result) >= limit:
            break
    return result


# ============================================================
# START SESSION
# ============================================================

@bp.route('/start-session', methods=['GET', 'POST'])
@data_entry_required
def start_session():
    """Ask the user which book / serial / date they're starting with."""
    books_all = Book.query.order_by(Book.book_number).all()
    today_str = date.today().isoformat()

    if request.method == 'GET':
        prefill_book = request.args.get('book')
        prefill_serial = ''
        prefill_date = today_str

        recent = _recent_active_books(limit=10)
        if not recent:
            recent = _fallback_books(limit=10)

        user_last_book = _user_last_book(current_user.id)
        user_last_book_info = None
        if user_last_book:
            user_last_book_info = get_book_usage(user_last_book)
            if user_last_book_info['remaining'] == 0:
                user_last_book = None
                user_last_book_info = None
            else:
                ld = _book_last_date(user_last_book)
                user_last_book_info['last_date'] = ld.isoformat() if ld else None

        if prefill_book:
            try:
                bn = int(prefill_book)
                book = Book.query.filter_by(book_number=bn).first()
                if book:
                    info = get_book_usage(book)
                    if info['next_serial']:
                        prefill_serial = info['next_serial']
                    last_d = _book_last_date(book)
                    if last_d:
                        prefill_date = last_d.isoformat()
            except (ValueError, TypeError):
                pass

        if (not prefill_book
                and user_last_book_info
                and user_last_book_info['next_serial']):
            prefill_book = str(user_last_book.book_number)
            prefill_serial = user_last_book_info['next_serial']
            if user_last_book_info.get('last_date'):
                prefill_date = user_last_book_info['last_date']

        if not prefill_book and recent:
            first = recent[0]
            if first['info']['next_serial']:
                prefill_book = str(first['book'].book_number)
                prefill_serial = first['info']['next_serial']
                if first['info'].get('last_date'):
                    prefill_date = first['info']['last_date']

        return render_template(
            'invoices/start_session.html',
            books=books_all,
            recent_books=recent,
            user_last_book=user_last_book,
            user_last_book_info=user_last_book_info,
            today=today_str,
            prefill_book=prefill_book,
            prefill_serial=prefill_serial,
            prefill_date=prefill_date,
        )

    # ---------- POST ----------
    book_str = (request.form.get('book') or '').strip()
    serial_str = (request.form.get('serial') or '').strip()
    date_str = (request.form.get('date') or '').strip()

    errors = []
    book = None
    book_number = None
    invoice_date = None

    try:
        book_number = int(book_str)
    except (ValueError, TypeError):
        errors.append('Book number must be a number.')

    if book_number is not None:
        book = Book.query.filter_by(book_number=book_number).first()
        if not book:
            errors.append(f'Book #{book_number} is not configured.')

    if not date_str:
        errors.append('Date is required.')
    else:
        try:
            invoice_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            errors.append('Invalid date format.')

    if not serial_str:
        errors.append('Serial number is required.')

    if book and serial_str:
        start, end = get_book_serial_range(book)
        try:
            sn = int(serial_str.lstrip('0') or '0')
            if start is not None and (sn < start or sn > end):
                errors.append(
                    f'Serial {serial_str} is not in Book #{book_number} '
                    f'(range {str(start).zfill(4)}–{str(end).zfill(4)}).'
                )
        except (ValueError, TypeError):
            errors.append(f'Serial "{serial_str}" is not valid.')

    if book and not errors:
        info = get_book_usage(book)
        if info['remaining'] == 0:
            errors.append(
                f'Book #{book_number} is already full '
                f'({book.capacity}/{book.capacity}). Pick a different book.'
            )

    if serial_str and not errors:
        existing = Invoice.query.filter_by(serial_number=serial_str).first()
        if existing:
            next_serial, _ = (
                generate_next_serial_in_book(book_number)
                if book_number else (None, None)
            )
            if next_serial:
                errors.append(
                    f'Serial {serial_str} is already used. '
                    f'Next available in Book #{book_number} is {next_serial}.'
                )
            else:
                errors.append(f'Serial {serial_str} is already used.')

    if errors:
        for e in errors:
            flash(e, 'danger')

        recent = _recent_active_books(limit=10) or _fallback_books(limit=10)
        user_last_book = _user_last_book(current_user.id)
        user_last_book_info = (
            get_book_usage(user_last_book) if user_last_book else None
        )
        return render_template(
            'invoices/start_session.html',
            books=books_all,
            recent_books=recent,
            user_last_book=user_last_book,
            user_last_book_info=user_last_book_info,
            today=today_str,
            prefill_book=book_str,
            prefill_serial=serial_str,
            prefill_date=date_str,
        )

    from app.batches import current_batch_id
    flask_session['work_session'] = {
        'batch_id': current_batch_id(),
        'book': book_number,
        'start_serial': serial_str,
        'date': invoice_date.isoformat(),
        'started_at': datetime.utcnow().isoformat() + 'Z',
    }
    sessions = dict(flask_session.get('batch_work_sessions') or {})
    sessions[str(current_batch_id())] = flask_session['work_session']
    flask_session['batch_work_sessions'] = dict(list(sessions.items())[-8:])
    flask_session.modified = True

    log_action(
        user_id=current_user.id,
        action='start_work_session',
        details={
            'book': book_number,
            'start_serial': serial_str,
            'date': invoice_date.isoformat(),
        },
        ip_address=get_client_ip(),
    )

    flash(f'Session started — Book #{book_number}, serial {serial_str}.', 'success')
    return redirect(url_for('invoices.create', batch_id=current_batch_id()))


@bp.route('/end-session', methods=['POST'])
@data_entry_required
def end_session():
    from app.batches import current_batch_id
    sessions = dict(flask_session.get('batch_work_sessions') or {})
    sessions.pop(str(current_batch_id()),None)
    flask_session['batch_work_sessions'] = dict(list(sessions.items())[-8:])
    old = flask_session.pop('work_session', None)
    if old:
        log_action(
            user_id=current_user.id,
            action='end_work_session',
            details={'book': old.get('book'), 'start_serial': old.get('start_serial')},
            ip_address=get_client_ip(),
        )
    flash('Session ended. You can start a new one.', 'info')
    return redirect(url_for('invoices.start_session', batch_id=current_batch_id()))


# ============================================================
# UPDATE SESSION
# ============================================================

@bp.route('/update-session', methods=['POST'])
@data_entry_required
def update_session():
    if not _is_ajax():
        return jsonify({'error': 'AJAX only'}), 400

    work_session = get_work_session()
    if not work_session:
        return jsonify({'success': False, 'error': 'No active session'}), 400

    new_date = (request.form.get('date') or '').strip()
    new_serial = (request.form.get('serial') or '').strip()
    new_book = (request.form.get('book') or '').strip()

    book_number = None
    if new_book:
        try:
            book_number = int(new_book)
        except ValueError:
            pass

    session_date = None
    if new_date:
        try:
            parsed = datetime.strptime(new_date, '%Y-%m-%d').date()
            session_date = parsed.isoformat()
        except ValueError:
            return jsonify({'success': False, 'error': 'Invalid date'}), 400

    _update_work_session(
        book_number=book_number,
        start_serial=new_serial or None,
        session_date=session_date,
    )

    return jsonify({'success': True, 'session': get_work_session()})


# ============================================================
# INDEX
# ============================================================

@bp.route('/')
@data_entry_required
def index():
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('INVOICES_PER_PAGE', 50)
    search_type = request.args.get('search_type', 'serial')
    query = request.args.get('query', '')
    user_id = request.args.get('user_id', type=int) if current_user.is_admin() else None

    if current_user.is_admin():
        base_query = Invoice.query
        if user_id:
            base_query = base_query.filter(Invoice.created_by == user_id)
    else:
        base_query = Invoice.query.filter(Invoice.created_by == current_user.id)

    base_query = base_query.options(joinedload(Invoice.book_record))

    matched_date = None
    matched_book = None
    if query:
        if search_type == 'serial':
            base_query = base_query.filter(Invoice.serial_number.like(f'%{query}%'))
        elif search_type == 'book':
            try:
                book_number = int(str(query).strip().lstrip('#'))
                matched_book = Book.query.filter_by(book_number=book_number).first()
                if matched_book:
                    base_query = base_query.filter(Invoice.book_id == matched_book.id)
                else:
                    base_query = base_query.filter(Invoice.id == -1)
            except (ValueError, TypeError):
                base_query = base_query.filter(Invoice.id == -1)
        else:
            matched_date = parse_date_string(query, '%Y-%m-%d')
            if matched_date:
                base_query = base_query.filter(Invoice.date == matched_date)

    date_summary = None
    if matched_date is not None:
        stats = base_query.filter(totals_included_clause()).with_entities(
            func.count(Invoice.id).label('count'),
            func.sum(Invoice.total_amount).label('total'),
            func.min(Invoice.total_amount).label('min_amount'),
            func.max(Invoice.total_amount).label('max_amount'),
            func.min(Invoice.serial_number).label('min_serial'),
            func.max(Invoice.serial_number).label('max_serial'),
            func.min(Invoice.created_at).label('first_created'),
        ).first()
        if stats and stats.count:
            total = float(stats.total or 0)
            date_summary = {
                'date': matched_date,
                'count': int(stats.count),
                'total': total,
                'average': total / stats.count if stats.count else 0.0,
                'min_amount': float(stats.min_amount or 0),
                'max_amount': float(stats.max_amount or 0),
                'min_serial': stats.min_serial,
                'max_serial': stats.max_serial,
                'first_created': stats.first_created,
            }

    book_summary = None
    if matched_book is not None:
        stats = base_query.filter(totals_included_clause()).with_entities(
            func.count(Invoice.id).label('count'),
            func.sum(Invoice.total_amount).label('total'),
            func.min(Invoice.total_amount).label('min_amount'),
            func.max(Invoice.total_amount).label('max_amount'),
            func.min(Invoice.serial_number).label('min_serial'),
            func.max(Invoice.serial_number).label('max_serial'),
            func.min(Invoice.date).label('first_date'),
            func.max(Invoice.date).label('last_date'),
        ).first()
        if stats and stats.count:
            total = float(stats.total or 0)
            used = int(stats.count)
            book_summary = {
                'book': matched_book,
                'count': used,
                'total': total,
                'average': total / used if used else 0.0,
                'min_amount': float(stats.min_amount or 0),
                'max_amount': float(stats.max_amount or 0),
                'min_serial': stats.min_serial,
                'max_serial': stats.max_serial,
                'first_date': stats.first_date,
                'last_date': stats.last_date,
                'capacity': matched_book.capacity,
                'remaining': max(matched_book.capacity - used, 0),
                'missing': max(matched_book.capacity - used, 0),
            }

    invoice_query = base_query.order_by(Invoice.date.desc(), Invoice.serial_number.desc())
    pagination = invoice_query.paginate(page=page, per_page=per_page, error_out=False)
    invoices = pagination.items

    invoice_ids = [inv.id for inv in invoices]
    media_by_invoice = {}
    if invoice_ids:
        all_media = InvoiceMedia.query.filter(
            InvoiceMedia.invoice_id.in_(invoice_ids)
        ).order_by(InvoiceMedia.id).all()
        for m in all_media:
            media_by_invoice.setdefault(m.invoice_id, []).append(m)

    for inv in invoices:
        inv.book, inv.page = get_invoice_book_page(inv)
        media_list = media_by_invoice.get(inv.id, [])
        inv.media_count = len(media_list)
        inv.first_media = media_list[0] if media_list else None
        inv.first_image = next(
            (m for m in media_list if m.mime_type and m.mime_type.startswith('image/')),
            None,
        )

    form = InvoiceSearchForm()
    form.search_type.data = search_type
    form.query.data = query
    users = User.query.order_by(User.username).all() if current_user.is_admin() else []

    return render_template(
        'invoices/list.html',
        invoices=invoices,
        pagination=pagination,
        form=form,
        search_type=search_type,
        query=query,
        user_id=user_id,
        users=users,
        date_summary=date_summary,
        book_summary=book_summary,
    )


# ============================================================
# CREATE
# ============================================================

@bp.route('/create', methods=['GET', 'POST'])
@data_entry_required
def create():
    work_session = get_work_session()

    # ---------- GET: require session ----------
    if request.method == 'GET':
        if not work_session:
            if request.headers.get('X-Live-Sync') == '1':
                return jsonify(error='Entry session changed. Your unsaved draft is kept.'), 409
            flash('Tell us which book you are working on first.', 'info')
            return redirect(url_for('invoices.start_session', batch_id=current_batch_id()))

        session_book_number = work_session.get('book')
        if session_book_number:
            session_book = Book.query.filter_by(book_number=session_book_number).first()
            if session_book:
                session_info = get_book_usage(session_book)
                if session_info['remaining'] == 0:
                    if request.headers.get('X-Live-Sync') == '1':
                        return jsonify(error='This book is complete. Your unsaved draft is kept.'), 409
                    flask_session.pop('work_session', None)
                    flash(
                        f'Book #{session_book_number} is complete. '
                        f'Please start a new session.',
                        'info',
                    )
                    return redirect(url_for('invoices.start_session', batch_id=current_batch_id()))
            else:
                if request.headers.get('X-Live-Sync') == '1':
                    return jsonify(error='Entry book changed. Your unsaved draft is kept.'), 409
                flask_session.pop('work_session', None)
                flash('Your session book is no longer configured. Start a new session.', 'warning')
                return redirect(url_for('invoices.start_session', batch_id=current_batch_id()))

    form = InvoiceForm()

    if request.method == 'GET':
        try:
            prefill_date = datetime.strptime(work_session['date'], '%Y-%m-%d').date()
        except (ValueError, KeyError, TypeError):
            prefill_date = date.today()
        form.date.data = prefill_date

        form.book_number.data = work_session.get('book')
        form.serial_number.data = _pick_session_serial(work_session)

    # ---------- POST ----------
    if request.method == 'POST':

        # Session must exist to accept a POST
        if not work_session:
            if _is_ajax():
                return _ajax_error(
                    'No active work session. Please start a session first.',
                    redirect_to=url_for('invoices.start_session', batch_id=current_batch_id()),
                )
            flash('Tell us which book you are working on first.', 'info')
            return redirect(url_for('invoices.start_session', batch_id=current_batch_id()))

        session_book_number = work_session.get('book')
        if session_book_number:
            session_book = Book.query.filter_by(book_number=session_book_number).first()
            if session_book:
                session_info = get_book_usage(session_book)
                if session_info['remaining'] == 0:
                    flask_session.pop('work_session', None)
                    if _is_ajax():
                        return _ajax_error(
                            f'Book #{session_book_number} is complete.',
                            redirect_to=url_for('invoices.start_session', batch_id=current_batch_id()),
                        )
                    flash(
                        f'Book #{session_book_number} is complete. '
                        f'Please start a new session.',
                        'info',
                    )
                    return redirect(url_for('invoices.start_session', batch_id=current_batch_id()))

        if form.validate_on_submit():
            amounts = []
            for a in form.amounts.data:
                if a is None:
                    continue
                try:
                    val = float(a)
                except (TypeError, ValueError):
                    continue
                if val < 0:
                    continue
                amounts.append(val)

            if not amounts:
                if _is_ajax():
                    return _ajax_error('At least one amount is required.')
                flash('At least one amount is required.', 'danger')
                return _render_create_form(form)

            data = {
                'date': form.date.data,
                'serial_number': form.serial_number.data,
                'amounts': amounts,
                'media_required': form.media_required.data,
            }

            invoice, error = create_invoice(data, current_user.id, get_client_ip())
            if error:
                if _is_ajax():
                    return _ajax_error(error)
                flash(error, 'danger')
                return _render_create_form(form)

            book_number = None
            if form.book_number.data:
                try:
                    book_number = int(form.book_number.data)
                except (ValueError, TypeError):
                    pass
            if book_number is None and invoice.book_record:
                book_number = invoice.book_record.book_number
            if book_number is None and work_session:
                book_number = work_session.get('book')

            # ---- AJAX response ----
            if _is_ajax():
                next_serial = None
                next_page = None
                next_book_info = None
                book_full = False

                if book_number:
                    book = Book.query.filter_by(book_number=book_number).first()
                    # NOTE: DO NOT pass exclude_invoice_id here.
                    # The invoice we just created IS used; we want the NEXT free serial.
                    ns, err = generate_next_serial_in_book(book_number)
                    if ns:
                        next_serial = ns
                        if book:
                            start, end = get_book_serial_range(book)
                            next_page = int(ns) - (start - 1) if start else None
                            next_book_info = get_book_usage(book)
                            book_full = (next_book_info['remaining'] == 0)
                    else:
                        book_full = True
                        if book:
                            next_book_info = get_book_usage(book)

                # Update the work session so a refresh restores the exact state.
                if book_full:
                    flask_session.pop('work_session', None)
                    flask_session.modified = True
                else:
                    _update_work_session(
                        book_number=book_number,
                        start_serial=next_serial,
                        session_date=invoice.date.isoformat(),
                    )

                return jsonify({
                    'success': True,
                    'message': f'Invoice {invoice.serial_number} created.',
                    'next_serial': next_serial,
                    'next_date': invoice.date.isoformat(),
                    'next_book': book_number,
                    'next_page': next_page,
                    'book_info': next_book_info,
                    'book_full': book_full,
                    'invoice_id': invoice.id,
                })

            # ---- Non-AJAX response ----
            flash(f'Invoice {invoice.serial_number} created successfully.', 'success')

            if book_number:
                ns, _ = generate_next_serial_in_book(book_number)
                if ns is None:
                    flask_session.pop('work_session', None)
                    flash(
                        f'Book #{book_number} is now complete. '
                        f'Start a new session for the next book.',
                        'info',
                    )
                    return redirect(url_for('invoices.start_session', batch_id=current_batch_id()))

                _update_work_session(
                    book_number=book_number,
                    start_serial=ns,
                    session_date=invoice.date.isoformat(),
                )

            return redirect(url_for('invoices.view', id=invoice.id))

        # ---- Validation failed ----
        if _is_ajax():
            return _ajax_error(
                'Please correct the errors in the form.',
                errors=form.errors,
            )
        return _render_create_form(form)

    return _render_create_form(form)


def _render_create_form(form, mode='create', invoice=None):
    book_info = None
    try:
        bn = form.book_number.data
        if bn:
            book = Book.query.filter_by(book_number=int(bn)).first()
            if book:
                book_info = get_book_usage(book)
    except (ValueError, TypeError):
        pass

    return render_template(
        'invoices/form.html',
        form=form,
        mode=mode,
        invoice=invoice,
        book_info=book_info,
        page=(get_invoice_book_page(invoice)[1] if invoice else (book_info.get('next_page') if book_info else None)),
        work_session=get_work_session() if mode == 'create' else None,
    )


# ============================================================
# EDIT
# ============================================================

@bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@data_entry_required
@owner_or_admin_required(Invoice, 'id')
def edit(id):
    invoice = get_invoice_by_id(id)
    if not invoice:
        if _is_ajax():
            return _ajax_error('Invoice not found.', 404)
        flash('Invoice not found.', 'danger')
        return redirect(url_for('invoices.index', batch_id=current_batch_id()))

    form = InvoiceForm(obj=invoice)
    form.invoice_id.data = id

    if request.method == 'GET':
        amounts = invoice.get_amounts()
        form.amounts.process(None, data=amounts)
        current_book, _ = get_invoice_book_page(invoice)
        form.book_number.data = current_book

    if form.validate_on_submit():
        amounts = []
        for a in form.amounts.data:
            if a is None:
                continue
            try:
                val = float(a)
            except (TypeError, ValueError):
                continue
            if val < 0:
                continue
            amounts.append(val)

        if not amounts:
            if _is_ajax():
                return _ajax_error('At least one amount is required.')
            flash('At least one amount is required.', 'danger')
            return _render_create_form(form, mode='edit', invoice=invoice)

        data = {
            'date': form.date.data,
            'serial_number': form.serial_number.data,
            'amounts': amounts,
            'media_required': form.media_required.data,
            'source_version': request.form.get('source_version'),
        }

        updated_invoice, error = update_invoice(id, data, current_user.id, get_client_ip())
        if error:
            if _is_ajax():
                return _ajax_error(error)
            flash(error, 'danger')
            return _render_create_form(form, mode='edit', invoice=invoice)

        if _is_ajax():
            return jsonify({
                'success': True,
                'message': f'Invoice {updated_invoice.serial_number} updated.',
                'redirect': url_for('invoices.view', id=updated_invoice.id),
            })

        flash(f'Invoice {updated_invoice.serial_number} updated successfully.', 'success')
        return redirect(url_for('invoices.view', id=updated_invoice.id))

    # ---- Validation failed ----
    if request.method == 'POST' and _is_ajax():
        return _ajax_error(
            'Please correct the errors in the form.',
            errors=form.errors,
        )
    return _render_create_form(form, mode='edit', invoice=invoice)


# ============================================================
# DELETE
# ============================================================

@bp.route('/<int:id>/delete', methods=['POST'])
@data_entry_required
@owner_or_admin_required(Invoice, 'id')
def delete(id):
    invoice = get_invoice_by_id(id)
    if not invoice:
        if _is_ajax():
            return jsonify({'success': False, 'error': 'Invoice not found'}), 404
        flash('Invoice not found.', 'danger')
        return redirect(url_for('invoices.index', batch_id=current_batch_id()))

    serial_number = invoice.serial_number
    success, error = delete_invoice(id, current_user.id, get_client_ip())
    if not success:
        if _is_ajax():
            return jsonify({'success': False, 'error': error}), 400
        flash(error, 'danger')
        return redirect(request.referrer or url_for('invoices.index', batch_id=current_batch_id()))

    message = f'Invoice {serial_number} deleted.'
    if _is_ajax():
        return jsonify({'success': True, 'message': message})

    flash(message, 'success')
    return redirect(url_for('invoices.index', batch_id=current_batch_id()))


# ============================================================
# VIEW
# ============================================================

@bp.route('/<int:id>')
@data_entry_required
def view(id):
    invoice = get_invoice_by_id(id)
    if not invoice:
        if request.headers.get('X-Live-Sync') == '1':
            return jsonify(error='Invoice no longer exists'), 404
        flash('Invoice not found.', 'danger')
        return redirect(url_for('invoices.index', batch_id=current_batch_id()))

    if not current_user.is_admin() and invoice.created_by != current_user.id:
        if request.headers.get('X-Live-Sync') == '1':
            return jsonify(error='Access denied'), 403
        flash('You do not have permission to view this invoice.', 'danger')
        return redirect(url_for('invoices.index', batch_id=current_batch_id()))

    book, page = get_invoice_book_page(invoice)
    amounts = invoice.get_amounts()
    media_files = invoice.media.all()
    history = build_history(invoice, current_user)

    return render_template(
        'invoices/view.html',
        invoice=invoice,
        book=book,
        page=page,
        amounts=amounts,
        media_files=media_files,
        history=history,
        created_by=User.query.get(invoice.created_by),
        updated_by=User.query.get(invoice.updated_by),
    )


# ============================================================
# SEARCH
# ============================================================

@bp.route('/search', methods=['GET', 'POST'])
@data_entry_required
def search():
    if request.method == 'POST' or request.args.get('query'):
        search_type = request.form.get('search_type') or request.args.get('search_type', 'serial')
        query = request.form.get('query') or request.args.get('query', '')

        if _is_ajax():
            results = search_invoices(
                query, search_type,
                current_user.id if not current_user.is_admin() else None,
            )
            data = []
            for inv in results[:20]:
                book, page = get_invoice_book_page(inv)
                data.append({
                    'id': inv.id,
                    'date': inv.date.isoformat(),
                    'serial_number': inv.serial_number,
                    'book': book,
                    'page': page,
                    'total_amount': float(inv.total_amount),
                    'amounts': inv.get_amounts(),
                    'created_by': inv.creator.username if inv.creator else None,
                    'linked_count': count_links(inv.id),
                    'note_count': count_notes(inv.id),
                })
            return jsonify({'results': data, 'count': len(data)})

        return redirect(url_for('invoices.index', search_type=search_type, query=query))

    return redirect(url_for('invoices.index', batch_id=current_batch_id()))


# ============================================================
# NEXT-SERIAL
# ============================================================

@bp.route('/next-serial')
@data_entry_required
def next_serial():
    date_str = request.args.get('date')
    book_str = request.args.get('book')

    invoice_date = date.today()
    if date_str:
        try:
            invoice_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'Invalid date format'}), 400

    if book_str:
        try:
            book_number = int(book_str)
        except ValueError:
            return jsonify({'error': 'Invalid book number'}), 400

        book = Book.query.filter_by(book_number=book_number).first()
        if not book:
            return jsonify({'error': f'Book #{book_number} is not configured.'}), 404

        serial, error = generate_next_serial_in_book(book_number)
        if error:
            info = get_book_usage(book)
            ld = _book_last_date(book)
            info['last_date'] = ld.isoformat() if ld else None
            return jsonify({
                'error': error,
                'book': book_number,
                'book_info': info,
            }), 200

        start, end = get_book_serial_range(book)
        page = int(serial) - (start - 1) if start else None
        info = get_book_usage(book)
        ld = _book_last_date(book)
        info['last_date'] = ld.isoformat() if ld else None

        return jsonify({
            'serial': serial,
            'book': book_number,
            'page': page,
            'book_capacity': book.capacity,
            'book_start': start,
            'book_end': end,
            'book_info': info,
        })

    serial = generate_next_serial(invoice_date)
    return jsonify({'serial': serial})


# ============================================================
# BOOK-INFO
# ============================================================

@bp.route('/book-info')
@data_entry_required
def book_info_endpoint():
    book_str = request.args.get('book')
    if not book_str:
        return jsonify({'error': 'book parameter required'}), 400

    try:
        book_number = int(book_str)
    except ValueError:
        return jsonify({'error': 'Invalid book number'}), 400

    book = Book.query.filter_by(book_number=book_number).first()
    if not book:
        return jsonify({'error': f'Book #{book_number} is not configured.'}), 404

    info = get_book_usage(book)
    last_d = _book_last_date(book)
    info['last_date'] = last_d.isoformat() if last_d else None

    return jsonify(info)


# ============================================================
# GRID / CALENDAR / SUMMARY / EXPORT
# ============================================================

@bp.route('/grid')
@data_entry_required
def grid():
    today = date.today()
    from_date = today.replace(day=1).isoformat()
    to_date = today.isoformat()
    return render_template('invoices/grid.html', current_date=today, from_date=from_date, to_date=to_date)


@bp.route('/grid-data')
@data_entry_required
def grid_data():
    start_serial = request.args.get('start_serial', type=int, default=1)
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')

    if not from_date or not to_date:
        return jsonify({'error': 'Date range required'}), 400

    try:
        start_date = datetime.strptime(from_date, '%Y-%m-%d').date()
        end_date = datetime.strptime(to_date, '%Y-%m-%d').date()
    except ValueError:
        return jsonify({'error': 'Invalid date format'}), 400

    serial_count = 70
    serials = [str(start_serial + i).zfill(4) for i in range(serial_count)]

    dates = []
    current = start_date
    while current <= end_date:
        dates.append(current.isoformat())
        current += timedelta(days=1)

    query = Invoice.query.filter(
        Invoice.serial_number.in_(serials),
        Invoice.date.between(start_date, end_date),
    )

    if not current_user.is_admin():
        query = query.filter(Invoice.created_by == current_user.id)

    invoices = query.all()

    grid = {}
    for inv in invoices:
        key = f"{inv.serial_number}-{inv.date.isoformat()}"
        grid[key] = {'id': inv.id, 'total': float(inv.total_amount), 'amounts': inv.get_amounts()}

    return jsonify({'serials': serials, 'dates': dates, 'grid': grid})


@bp.route('/calendar')
@data_entry_required
def calendar():
    return render_template('invoices/calendar.html')


@bp.route('/calendar-data')
@data_entry_required
def calendar_data():
    year = request.args.get('year', type=int, default=date.today().year)
    month = request.args.get('month', type=int, default=date.today().month)

    start_date = date(year, month, 1)
    if month == 12:
        end_date = date(year + 1, 1, 1) - timedelta(days=1)
    else:
        end_date = date(year, month + 1, 1) - timedelta(days=1)

    query = Invoice.query.filter(Invoice.date.between(start_date, end_date))
    if not current_user.is_admin():
        query = query.filter(Invoice.created_by == current_user.id)

    invoices = query.all()
    dates_with_invoices = {inv.date.isoformat() for inv in invoices}

    all_dates = []
    current = start_date
    while current <= end_date:
        all_dates.append(current.isoformat())
        current += timedelta(days=1)

    return jsonify({
        'year': year,
        'month': month,
        'dates_with_invoices': list(dates_with_invoices),
        'all_dates': all_dates,
    })


@bp.route('/summary')
@data_entry_required
def summary():
    today = date.today()
    from_date = today.replace(day=1).isoformat()
    to_date = today.isoformat()
    return render_template('invoices/summary.html', current_date=today, from_date=from_date, to_date=to_date)


@bp.route('/summary-data')
@data_entry_required
def summary_data():
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')

    if not from_date or not to_date:
        today = date.today()
        from_date = today.replace(day=1).isoformat()
        to_date = today.isoformat()

    try:
        start_date = datetime.strptime(from_date, '%Y-%m-%d').date()
        end_date = datetime.strptime(to_date, '%Y-%m-%d').date()
    except ValueError:
        return jsonify({'error': 'Invalid date format'}), 400

    user_id = None if current_user.is_admin() else current_user.id

    summary = get_work_days_summary(start_date, end_date, user_id=user_id)
    daily = get_daily_totals(start_date, end_date, user_id=user_id)
    monthly = get_monthly_totals(start_date, end_date, user_id=user_id)

    return jsonify({
        'summary': {
            'total_amount': summary['total_amount'],
            'invoice_count': summary['invoice_count'],
            'working_days': summary['working_days'],
            'calendar_days': summary['calendar_days'],
        },
        'daily': daily,
        'monthly': monthly,
    })


@bp.route('/export')
@data_entry_required
def export():
    if not current_user.is_admin() and not current_user.can_export:
        flash('You do not have permission to export data.', 'danger')
        return redirect(url_for('invoices.index', batch_id=current_batch_id()))

    export_type = request.args.get('type', 'all')
    user_id = None if current_user.is_admin() else current_user.id

    if export_type == 'daily':
        from_date = request.args.get('from_date')
        to_date = request.args.get('to_date')
        if not from_date or not to_date:
            flash('Date range required.', 'danger')
            return redirect(url_for('invoices.summary'))

        try:
            start_date = datetime.strptime(from_date, '%Y-%m-%d').date()
            end_date = datetime.strptime(to_date, '%Y-%m-%d').date()
        except ValueError:
            flash('Invalid date format.', 'danger')
            return redirect(url_for('invoices.summary'))

        daily_totals = get_daily_totals(start_date, end_date, user_id=user_id)

        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Date', 'Total Amount'])
        for item in daily_totals:
            writer.writerow([item['date'], f"{item['total']:.3f}"])

        filename = f"daily_totals_{from_date}_to_{to_date}.csv"

    elif export_type == 'monthly':
        month = request.args.get('month')
        if not month:
            flash('Month required.', 'danger')
            return redirect(url_for('invoices.summary'))

        try:
            month_date = datetime.strptime(month, '%Y-%m').date()
        except ValueError:
            flash('Invalid month format.', 'danger')
            return redirect(url_for('invoices.summary'))

        from_date = month_date.replace(day=1)
        if month_date.month == 12:
            to_date = month_date.replace(year=month_date.year + 1, month=1, day=1) - timedelta(days=1)
        else:
            to_date = month_date.replace(month=month_date.month + 1, day=1) - timedelta(days=1)

        monthly_totals = get_monthly_totals(from_date, to_date, user_id=user_id)

        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Month', 'Total Amount'])
        for item in monthly_totals:
            writer.writerow([item['month'], f"{item['total']:.3f}"])

        filename = f"monthly_totals_{month}.csv"

    else:
        if current_user.is_admin():
            invoices = Invoice.query.order_by(Invoice.date.desc(), Invoice.serial_number.desc()).all()
        else:
            invoices = Invoice.query.filter(Invoice.created_by == current_user.id).order_by(
                Invoice.date.desc(), Invoice.serial_number.desc()
            ).all()

        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([
            'ID', 'Batch ID', 'Date', 'Serial Number', 'Book', 'Page',
            'Amounts', 'Total Amount', 'Created By', 'Created At', 'Updated At'
        ])

        for inv in invoices:
            book, page = get_invoice_book_page(inv)
            amounts_str = '|'.join([f"{a:.3f}" for a in inv.get_amounts()])
            creator = User.query.get(inv.created_by)
            writer.writerow([
                inv.id,
                inv.batch_id,
                inv.date.isoformat(),
                inv.serial_number,
                book if book is not None else '',
                page if page is not None else '',
                amounts_str,
                f"{inv.total_amount:.3f}",
                creator.username if creator else '',
                inv.created_at.isoformat() if inv.created_at else '',
                inv.updated_at.isoformat() if inv.updated_at else '',
            ])

        filename = f"all_invoices_{date.today().isoformat()}.csv"

    from app.batches import current_batch_id
    filename = f'batch_{current_batch_id()}_{filename}'
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=filename,
    )


# ============================================================
# NOTES, ATTACHMENTS & RELATIONS (complete invoice history)
# ============================================================

def _history_reply(invoice_id, ok, message, status=200):
    """Uniform reply for note/link actions: JSON for AJAX, flash + redirect for forms."""
    if _is_ajax():
        if ok:
            return jsonify(success=True, message=message), status
        return jsonify(success=False, error=message), status
    flash(message, 'success' if ok else 'danger')
    return redirect(url_for('invoices.view', id=invoice_id))


_INLINE_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}


@bp.route('/<int:id>/notes', methods=['POST'])
@data_entry_required
@owner_or_admin_required(Invoice, 'id')
def note_create(id):
    """Add a note (text and/or attachments) to an invoice. Form fields: body, files[]."""
    invoice = get_invoice_by_id(id)
    if not invoice:
        return _history_reply(id, False, 'Invoice not found.', 404)

    note, error = add_note(invoice, current_user, request.form.get('body'),
                           request.files.getlist('files'), get_client_ip())
    if error:
        return _history_reply(id, False, error, 400)
    return _history_reply(id, True, 'Note saved.')


@bp.route('/<int:id>/notes/<int:note_id>/delete', methods=['POST'])
@data_entry_required
@owner_or_admin_required(Invoice, 'id')
def note_delete(id, note_id):
    invoice = get_invoice_by_id(id)
    if not invoice:
        return _history_reply(id, False, 'Invoice not found.', 404)

    ok, error = delete_note(invoice, db.session.get(InvoiceNote, note_id), current_user, get_client_ip())
    if not ok:
        return _history_reply(id, False, error, 400)
    return _history_reply(id, True, 'Note deleted.')


@bp.route('/<int:id>/notes/attachments/<int:media_id>')
@data_entry_required
def note_attachment(id, media_id):
    """Download or preview a note attachment. Allowed when the user may see both invoices."""
    invoice = get_invoice_by_id(id)
    media = db.session.get(InvoiceNoteMedia, media_id)
    if not invoice or not media or not can_access_invoice(invoice, current_user):
        abort(404)

    note = db.session.get(InvoiceNote, media.note_id)
    owner = get_invoice_any_batch(note.invoice_id) if note else None
    if owner is None or not can_access_invoice(owner, current_user):
        abort(404)

    path = note_attachment_path(media)
    if not os.path.isfile(path):
        abort(404)

    extension = media.file_name.rsplit('.', 1)[-1].lower() if '.' in media.file_name else ''
    if extension in _INLINE_IMAGE_EXTENSIONS and (media.mime_type or '').startswith('image/'):
        return send_file(path, mimetype=media.mime_type)
    return send_file(path, as_attachment=True, download_name=media.file_name, mimetype=media.mime_type)


@bp.route('/<int:id>/links', methods=['POST'])
@data_entry_required
@owner_or_admin_required(Invoice, 'id')
def link_create(id):
    """Link this invoice to another invoice in the same batch.

    Form fields: linked_serial (required), link_type (related|duplicate|adjustment),
    amount_action (none|merge), link_note (optional).
    """
    invoice = get_invoice_by_id(id)
    if not invoice:
        return _history_reply(id, False, 'Invoice not found.', 404)

    link, error = create_link(
        invoice, current_user,
        linked_serial=request.form.get('linked_serial'),
        link_type=request.form.get('link_type', 'related'),
        amount_action=request.form.get('amount_action', 'none'),
        link_note=request.form.get('link_note'),
        ip_address=get_client_ip(),
        linked_batch_id=request.form.get('linked_batch_id'),
        exclude_from_totals=parse_bool(request.form.get('exclude_from_totals'), default=False),
    )
    if error:
        return _history_reply(id, False, error, 400)
    if link.amount_action == 'merge':
        return _history_reply(id, True, f'Invoice linked and amount {float(link.merged_amount):.3f} merged.')
    return _history_reply(id, True, 'Invoice linked.')


@bp.route('/<int:id>/links/<int:link_id>/delete', methods=['POST'])
@data_entry_required
@owner_or_admin_required(Invoice, 'id')
def link_delete(id, link_id):
    invoice = get_invoice_by_id(id)
    if not invoice:
        return _history_reply(id, False, 'Invoice not found.', 404)

    ok, error = delete_link(invoice, db.session.get(InvoiceLink, link_id), current_user, get_client_ip())
    if not ok:
        return _history_reply(id, False, error, 400)
    return _history_reply(id, True, 'Link removed.')


@bp.route('/<int:id>/history')
@data_entry_required
def history_json(id):
    """Complete history as JSON: relations, merged amounts, notes and attachments."""
    invoice = get_invoice_by_id(id)
    if not invoice or not can_access_invoice(invoice, current_user):
        return jsonify(success=False, error='Invoice not found.'), 404
    return jsonify(success=True, **build_history(invoice, current_user))

