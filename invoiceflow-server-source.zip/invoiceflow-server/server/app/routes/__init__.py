# app/routes/__init__.py

from .auth import bp as auth_bp
from .main import bp as main_bp
from .invoices import bp as invoices_bp
from .admin import bp as admin_bp
from .backup import bp as backup_bp
from .import_export import bp as import_export_bp
from .media import bp as media_bp
from .api import bp as api_bp
from .analytics import bp as analytics_bp

blueprints = [
    auth_bp,
    main_bp,
    invoices_bp,
    admin_bp,
    backup_bp,
    import_export_bp,
    media_bp,
    api_bp,
    analytics_bp,
]


