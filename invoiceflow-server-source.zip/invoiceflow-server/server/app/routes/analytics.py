# app/routes/analytics.py
"""
Admin-only business analytics & reports.
Read-only. No DB changes.
"""

import csv
import io
from datetime import datetime, date, timedelta

from flask import (
    Blueprint, render_template, request, jsonify, send_file,
)
from flask_login import login_required, current_user
from sqlalchemy import func

from app import db
from app.models import Invoice, InvoiceMedia, User, Book, totals_included_clause
from app.utils.decorators import admin_required
from app.utils.helpers import get_client_ip
from app.services.audit_service import log_action


bp = Blueprint('analytics', __name__, url_prefix='/admin/analytics')


def _parse_range():
    today = date.today()
    from_str = (request.args.get('from_date') or '').strip()
    to_str = (request.args.get('to_date') or '').strip()

    try:
        from_date = datetime.strptime(from_str, '%Y-%m-%d').date() if from_str else today - timedelta(days=29)
    except ValueError:
        from_date = today - timedelta(days=29)

    try:
        to_date = datetime.strptime(to_str, '%Y-%m-%d').date() if to_str else today
    except ValueError:
        to_date = today

    if from_date > to_date:
        from_date, to_date = to_date, from_date
    return from_date, to_date


def _compute_metrics(from_date, to_date):
    base = Invoice.query.filter(Invoice.date.between(from_date, to_date), totals_included_clause())

    totals = base.with_entities(
        func.count(Invoice.id).label('count'),
        func.sum(Invoice.total_amount).label('total'),
        func.min(Invoice.total_amount).label('min_amount'),
        func.max(Invoice.total_amount).label('max_amount'),
    ).first()

    total_invoices = int(totals.count or 0)
    total_revenue = float(totals.total or 0)
    avg_invoice = (total_revenue / total_invoices) if total_invoices else 0.0

    zero_count = base.filter(Invoice.total_amount == 0).count()
    working_days = base.with_entities(func.count(func.distinct(Invoice.date))).scalar() or 0
    calendar_days = (to_date - from_date).days + 1

    invoice_ids = [row[0] for row in base.with_entities(Invoice.id).all()]
    with_media = 0
    if invoice_ids:
        with_media = db.session.query(
            func.count(func.distinct(InvoiceMedia.invoice_id))
        ).filter(InvoiceMedia.invoice_id.in_(invoice_ids)).scalar() or 0
    media_pct = (with_media / total_invoices * 100.0) if total_invoices else 0.0

    unique_users = base.with_entities(func.count(func.distinct(Invoice.created_by))).scalar() or 0
    unique_books = base.with_entities(func.count(func.distinct(Invoice.book_id))).scalar() or 0

    summary = {
        'total_revenue': round(total_revenue, 3),
        'total_invoices': total_invoices,
        'avg_invoice_value': round(avg_invoice, 3),
        'min_invoice_value': round(float(totals.min_amount or 0), 3),
        'max_invoice_value': round(float(totals.max_amount or 0), 3),
        'working_days': int(working_days),
        'calendar_days': calendar_days,
        'revenue_per_working_day': round(total_revenue / working_days, 3) if working_days else 0.0,
        'revenue_per_calendar_day': round(total_revenue / calendar_days, 3) if calendar_days else 0.0,
        'invoices_per_working_day': round(total_invoices / working_days, 2) if working_days else 0.0,
        'zero_amount_count': int(zero_count),
        'zero_amount_pct': round(zero_count / total_invoices * 100.0, 2) if total_invoices else 0.0,
        'media_coverage_pct': round(media_pct, 2),
        'unique_users': int(unique_users),
        'unique_books': int(unique_books),
    }

    # ---- Daily (fill missing days) ----
    daily_rows = db.session.query(
        Invoice.date,
        func.count(Invoice.id),
        func.sum(Invoice.total_amount),
    ).filter(Invoice.date.between(from_date, to_date), totals_included_clause()) \
     .group_by(Invoice.date).order_by(Invoice.date).all()
    daily_map = {r[0].isoformat(): {'count': int(r[1]), 'total': float(r[2] or 0)} for r in daily_rows}
    daily = []
    cursor = from_date
    while cursor <= to_date:
        k = cursor.isoformat()
        e = daily_map.get(k, {'count': 0, 'total': 0.0})
        daily.append({'date': k, 'count': e['count'], 'total': round(e['total'], 3)})
        cursor += timedelta(days=1)

    # ---- Monthly ----
    month_expr = func.date_format(Invoice.date, '%Y-%m')
    monthly_rows = db.session.query(
        month_expr.label('month'),
        func.count(Invoice.id),
        func.sum(Invoice.total_amount),
    ).filter(Invoice.date.between(from_date, to_date), totals_included_clause()) \
     .group_by(month_expr).order_by(month_expr).all()
    monthly = [
        {'month': r[0], 'count': int(r[1]), 'total': round(float(r[2] or 0), 3)}
        for r in monthly_rows
    ]

    # ---- Weekday ----
    weekday_expr = func.dayname(Invoice.date)
    weekday_rows = db.session.query(
        weekday_expr, func.count(Invoice.id), func.sum(Invoice.total_amount),
    ).filter(Invoice.date.between(from_date, to_date), totals_included_clause()).group_by(weekday_expr).all()
    wd_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    wd_map = {r[0]: {'count': int(r[1]), 'total': float(r[2] or 0)} for r in weekday_rows}
    weekday = [
        {'day': d,
         'count': wd_map.get(d, {'count': 0})['count'],
         'total': round(wd_map.get(d, {'total': 0.0})['total'], 3)}
        for d in wd_order
    ]

    # ---- Hourly ----
    hour_expr = func.hour(Invoice.created_at)
    hourly_rows = db.session.query(
        hour_expr, func.count(Invoice.id),
    ).filter(Invoice.date.between(from_date, to_date), totals_included_clause()).group_by(hour_expr).all()
    hour_map = {int(r[0]): int(r[1]) for r in hourly_rows}
    hourly = [{'hour': h, 'count': hour_map.get(h, 0)} for h in range(24)]

    # ---- Top books ----
    book_rows = db.session.query(
        Book.book_number, Book.capacity,
        func.count(Invoice.id).label('cnt'),
        func.sum(Invoice.total_amount).label('ttl'),
    ).join(Invoice, Invoice.book_id == Book.id) \
     .filter(Invoice.date.between(from_date, to_date), totals_included_clause()) \
     .group_by(Book.id, Book.book_number, Book.capacity) \
     .order_by(func.sum(Invoice.total_amount).desc()).limit(15).all()
    top_books = [{
        'book_number': r.book_number,
        'capacity': r.capacity,
        'count': int(r.cnt),
        'total': round(float(r.ttl or 0), 3),
        'fill_pct': round((int(r.cnt) / r.capacity * 100.0), 1) if r.capacity else 0.0,
    } for r in book_rows]

    # ---- Users ----
    user_rows = db.session.query(
        User.username, User.role,
        func.count(Invoice.id).label('cnt'),
        func.sum(Invoice.total_amount).label('ttl'),
    ).join(Invoice, Invoice.created_by == User.id) \
     .filter(Invoice.date.between(from_date, to_date), totals_included_clause()) \
     .group_by(User.id, User.username, User.role) \
     .order_by(func.sum(Invoice.total_amount).desc()).all()
    users = [{
        'username': r.username,
        'role': r.role,
        'count': int(r.cnt),
        'total': round(float(r.ttl or 0), 3),
        'avg': round((float(r.ttl or 0) / int(r.cnt)), 3) if r.cnt else 0.0,
    } for r in user_rows]

    # ---- Amount distribution ----
    buckets = [
        ('Zero', 0, 0),
        ('0 – 10', 0.001, 10),
        ('10 – 25', 10, 25),
        ('25 – 50', 25, 50),
        ('50 – 100', 50, 100),
        ('100 – 250', 100, 250),
        ('250 – 500', 250, 500),
        ('500 – 1k', 500, 1000),
        ('1k+', 1000, None),
    ]
    amount_dist = []
    for label, lo, hi in buckets:
        if lo == 0 and hi == 0:
            q = base.filter(Invoice.total_amount == 0)
        elif hi is None:
            q = base.filter(Invoice.total_amount >= lo)
        else:
            q = base.filter(Invoice.total_amount > lo, Invoice.total_amount <= hi)
        amount_dist.append({'label': label, 'count': q.count()})

    return {
        'summary': summary, 'daily': daily, 'monthly': monthly,
        'weekday': weekday, 'hourly': hourly, 'top_books': top_books,
        'users': users, 'amount_distribution': amount_dist,
    }


@bp.route('/')
@login_required
@admin_required
def index():
    today = date.today()
    default_from = today - timedelta(days=29)
    return render_template(
        'admin/analytics.html',
        default_from=default_from.isoformat(),
        default_to=today.isoformat(),
    )


@bp.route('/data')
@login_required
@admin_required
def data():
    from_date, to_date = _parse_range()
    metrics = _compute_metrics(from_date, to_date)
    metrics['range'] = {'from': from_date.isoformat(), 'to': to_date.isoformat()}
    return jsonify(metrics)


@bp.route('/export')
@login_required
@admin_required
def export():
    from_date, to_date = _parse_range()
    section = (request.args.get('section') or 'all').lower()
    if section not in ('all', 'summary', 'daily', 'monthly', 'weekday',
                       'books', 'users', 'amounts'):
        section = 'all'

    m = _compute_metrics(from_date, to_date)

    buf = io.StringIO()
    w = csv.writer(buf)

    w.writerow(['InvoiceFlow - Analytics Report'])
    w.writerow(['Period', f'{from_date.isoformat()} to {to_date.isoformat()}'])
    w.writerow(['Generated', datetime.now().strftime('%Y-%m-%d %H:%M:%S')])
    w.writerow([])

    if section in ('all', 'summary'):
        s = m['summary']
        w.writerow(['== SUMMARY =='])
        w.writerow(['Metric', 'Value'])
        w.writerow(['Total Revenue (OMR)', f"{s['total_revenue']:.3f}"])
        w.writerow(['Total Invoices', s['total_invoices']])
        w.writerow(['Average Invoice Value (OMR)', f"{s['avg_invoice_value']:.3f}"])
        w.writerow(['Smallest Invoice (OMR)', f"{s['min_invoice_value']:.3f}"])
        w.writerow(['Largest Invoice (OMR)', f"{s['max_invoice_value']:.3f}"])
        w.writerow(['Working Days', s['working_days']])
        w.writerow(['Calendar Days', s['calendar_days']])
        w.writerow(['Revenue / Working Day (OMR)', f"{s['revenue_per_working_day']:.3f}"])
        w.writerow(['Revenue / Calendar Day (OMR)', f"{s['revenue_per_calendar_day']:.3f}"])
        w.writerow(['Invoices / Working Day', f"{s['invoices_per_working_day']:.2f}"])
        w.writerow(['Zero-Amount Invoices', s['zero_amount_count']])
        w.writerow(['Zero-Amount %', f"{s['zero_amount_pct']:.2f}%"])
        w.writerow(['Media Coverage %', f"{s['media_coverage_pct']:.2f}%"])
        w.writerow(['Unique Users', s['unique_users']])
        w.writerow(['Unique Books', s['unique_books']])
        w.writerow([])

    if section in ('all', 'daily'):
        w.writerow(['== DAILY BREAKDOWN =='])
        w.writerow(['Date', 'Invoices', 'Revenue (OMR)'])
        for d in m['daily']:
            w.writerow([d['date'], d['count'], f"{d['total']:.3f}"])
        w.writerow([])

    if section in ('all', 'monthly'):
        w.writerow(['== MONTHLY BREAKDOWN =='])
        w.writerow(['Month', 'Invoices', 'Revenue (OMR)'])
        for r in m['monthly']:
            w.writerow([r['month'], r['count'], f"{r['total']:.3f}"])
        w.writerow([])

    if section in ('all', 'weekday'):
        w.writerow(['== WEEKDAY BREAKDOWN =='])
        w.writerow(['Weekday', 'Invoices', 'Revenue (OMR)'])
        for r in m['weekday']:
            w.writerow([r['day'], r['count'], f"{r['total']:.3f}"])
        w.writerow([])

    if section in ('all', 'books'):
        w.writerow(['== TOP BOOKS =='])
        w.writerow(['Book #', 'Used Pages', 'Capacity', 'Fill %', 'Revenue (OMR)'])
        for b in m['top_books']:
            w.writerow([b['book_number'], b['count'], b['capacity'],
                        f"{b['fill_pct']:.1f}%", f"{b['total']:.3f}"])
        w.writerow([])

    if section in ('all', 'users'):
        w.writerow(['== USER PERFORMANCE =='])
        w.writerow(['Username', 'Role', 'Invoices', 'Revenue (OMR)', 'Avg (OMR)'])
        for u in m['users']:
            w.writerow([u['username'], u['role'], u['count'],
                        f"{u['total']:.3f}", f"{u['avg']:.3f}"])
        w.writerow([])

    if section in ('all', 'amounts'):
        w.writerow(['== AMOUNT DISTRIBUTION =='])
        w.writerow(['Bucket (OMR)', 'Invoices'])
        for a in m['amount_distribution']:
            w.writerow([a['label'], a['count']])

    log_action(
        user_id=current_user.id,
        action='export_analytics',
        details={'section': section,
                 'from': from_date.isoformat(),
                 'to': to_date.isoformat()},
        ip_address=get_client_ip(),
    )

    buf.seek(0)
    filename = f"analytics_{section}_{from_date.isoformat()}_to_{to_date.isoformat()}.csv"
    return send_file(
        io.BytesIO(buf.getvalue().encode('utf-8-sig')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=filename,
    )


