# app/routes/main.py

from flask import Blueprint, render_template, jsonify, request, current_app
from flask_login import login_required, current_user
from sqlalchemy import func as sqlfunc
from datetime import datetime, timedelta, date
from app import db
from app.models import Invoice, User, AuditLog, Book, InvoiceMedia
from app.utils.helpers import get_client_ip, format_currency
from app.services.invoice_service import get_recent_invoices

bp = Blueprint('main', __name__)


@bp.route('/')
@bp.route('/dashboard')
@login_required
def dashboard():
    """Main dashboard page with summary and recent invoices."""
    today = date.today()

    if current_user.is_admin():
        invoice_query = Invoice.query
    else:
        invoice_query = Invoice.query.filter(Invoice.created_by == current_user.id)

    total_invoices = invoice_query.count()
    total_revenue = invoice_query.with_entities(sqlfunc.sum(Invoice.total_amount)).scalar() or 0

    today_revenue = invoice_query.filter(Invoice.date == today).with_entities(
        sqlfunc.sum(Invoice.total_amount)
    ).scalar() or 0

    today_count = invoice_query.filter(Invoice.date == today).count()

    if current_user.is_admin():
        recent_invoices = get_recent_invoices(limit=10)
    else:
        recent_invoices = invoice_query.order_by(Invoice.created_at.desc()).limit(10).all()

    # Batch media counts for recent invoices
    if recent_invoices:
        ids = [inv.id for inv in recent_invoices]
        media_counts = dict(
            db.session.query(InvoiceMedia.invoice_id, sqlfunc.count(InvoiceMedia.id))
            .filter(InvoiceMedia.invoice_id.in_(ids))
            .group_by(InvoiceMedia.invoice_id)
            .all()
        )
        for inv in recent_invoices:
            inv.media_count = media_counts.get(inv.id, 0)

    is_admin = current_user.is_admin()
    if is_admin:
        user_count = User.query.count()
        recent_activity = AuditLog.query.order_by(AuditLog.timestamp.desc()).limit(5).all()

        # ---- 1 query: counts per book ----
        book_counts = dict(
            db.session.query(Invoice.book_id, sqlfunc.count(Invoice.id))
            .filter(Invoice.book_id.isnot(None))
            .group_by(Invoice.book_id)
            .all()
        )

        # ---- 1 query: latest invoice per book (for "last user") ----
        latest_subq = db.session.query(
            Invoice.book_id,
            sqlfunc.max(Invoice.created_at).label('max_created'),
        ).filter(Invoice.book_id.isnot(None)).group_by(Invoice.book_id).subquery()

        latest_invoices = db.session.query(Invoice).join(
            latest_subq,
            (Invoice.book_id == latest_subq.c.book_id) &
            (Invoice.created_at == latest_subq.c.max_created)
        ).all()
        latest_by_book = {}
        for inv in latest_invoices:
            latest_by_book.setdefault(inv.book_id, inv)

        # ---- 1 query: first & last invoice DATE per book ----
        date_range_rows = db.session.query(
            Invoice.book_id,
            sqlfunc.min(Invoice.date).label('first_date'),
            sqlfunc.max(Invoice.date).label('last_date'),
        ).filter(Invoice.book_id.isnot(None)) \
         .group_by(Invoice.book_id).all()
        date_range_by_book = {
            r.book_id: (r.first_date, r.last_date) for r in date_range_rows
        }

        book_overview = []
        for book in Book.query.order_by(Book.book_number).all():
            used = int(book_counts.get(book.id, 0))
            latest = latest_by_book.get(book.id)
            first_date, last_date = date_range_by_book.get(book.id, (None, None))
            book_overview.append({
                'book': book,
                'used': used,
                'remaining': max(book.capacity - used, 0),
                'last_user': latest.creator if latest else book.assigned_user,
                'first_date': first_date,
                'last_date': last_date,
            })
    else:
        user_count = None
        recent_activity = None
        book_overview = []

    yesterday = today - timedelta(days=1)
    yesterday_revenue = invoice_query.filter(Invoice.date == yesterday).with_entities(
        sqlfunc.sum(Invoice.total_amount)
    ).scalar() or 0

    today_revenue_f = float(today_revenue)
    yesterday_revenue_f = float(yesterday_revenue)
    revenue_change = (
        (today_revenue_f - yesterday_revenue_f) / (yesterday_revenue_f + 0.01) * 100
        if yesterday_revenue_f else 0
    )

    context = {
        'total_invoices': total_invoices,
        'total_revenue': format_currency(total_revenue),
        'today_revenue': format_currency(today_revenue),
        'today_count': today_count,
        'recent_invoices': recent_invoices,
        'is_admin': is_admin,
        'user_count': user_count,
        'recent_activity': recent_activity,
        'revenue_change': f"{revenue_change:.1f}",
        'revenue_change_positive': revenue_change >= 0,
        'book_overview': book_overview,
    }
    return render_template('main/dashboard.html', **context)


@bp.route('/recent-invoices')
@login_required
def recent_invoices():
    """AJAX endpoint to refresh recent invoices (for footer)."""
    limit = request.args.get('limit', default=10, type=int)
    if current_user.is_admin():
        recent = get_recent_invoices(limit=limit)
    else:
        recent = Invoice.query.filter(Invoice.created_by == current_user.id).order_by(
            Invoice.created_at.desc()
        ).limit(limit).all()

    data = []
    for inv in recent:
        data.append({
            'id': inv.id,
            'date': inv.date.isoformat(),
            'serial_number': inv.serial_number,
            'total_amount': float(inv.total_amount),
            'created_by': inv.creator.username if inv.creator else None,
        })
    return jsonify(data)


@bp.route('/quick-stats')
@login_required
def quick_stats():
    """AJAX endpoint to refresh quick stats on dashboard."""
    today = date.today()
    if current_user.is_admin():
        today_revenue = db.session.query(sqlfunc.sum(Invoice.total_amount)).filter(
            Invoice.date == today
        ).scalar() or 0
        today_count = Invoice.query.filter(Invoice.date == today).count()
    else:
        today_revenue = db.session.query(sqlfunc.sum(Invoice.total_amount)).filter(
            Invoice.date == today, Invoice.created_by == current_user.id
        ).scalar() or 0
        today_count = Invoice.query.filter(
            Invoice.date == today, Invoice.created_by == current_user.id
        ).count()

    return jsonify({
        'today_revenue': float(today_revenue),
        'today_count': today_count,
    })


