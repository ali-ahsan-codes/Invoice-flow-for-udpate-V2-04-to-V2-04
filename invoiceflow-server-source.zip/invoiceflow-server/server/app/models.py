from sqlalchemy import cast, Integer
# app/models.py

from datetime import datetime, timezone, timedelta
from flask_login import UserMixin
from app.extensions import db, bcrypt
from werkzeug.security import check_password_hash as check_werkzeug_hash
import json


class User(db.Model, UserMixin):
    """User model with roles."""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='data_entry')
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    last_login = db.Column(db.DateTime, nullable=True)
    preferred_start_serial = db.Column(db.Integer, default=1)
    can_export = db.Column(db.Boolean, default=True)
    api_key = db.Column(db.String(64), unique=True, nullable=True, index=True)

    invoices_created = db.relationship('Invoice', foreign_keys='Invoice.created_by', backref='creator', lazy='dynamic')
    invoices_updated = db.relationship('Invoice', foreign_keys='Invoice.updated_by', backref='updater', lazy='dynamic')
    audit_logs = db.relationship('AuditLog', backref='user', lazy='dynamic')
    media_uploads = db.relationship('InvoiceMedia', backref='uploader', lazy='dynamic')
    assigned_books = db.relationship('Book', back_populates='assigned_user', lazy='dynamic')

    def set_password(self, password):
        self.password_hash = bcrypt.generate_password_hash(password).decode('utf-8')

    def check_password(self, password):
        if not self.password_hash or not password:
            return False

        if isinstance(self.password_hash, str) and self.password_hash.startswith(('$2a$', '$2b$', '$2y$', '$2x$')):
            try:
                return bcrypt.check_password_hash(self.password_hash, password)
            except Exception:
                return False

        try:
            if check_werkzeug_hash(self.password_hash, password):
                try:
                    self.set_password(password)
                    db.session.commit()
                except Exception:
                    db.session.rollback()
                return True
        except Exception:
            pass

        try:
            return bcrypt.check_password_hash(self.password_hash, password)
        except Exception:
            return False

    def regenerate_api_key(self):
        """Generate a fresh API key. Invalidates any previously issued key."""
        import secrets
        self.api_key = secrets.token_urlsafe(48)
        return self.api_key

    def is_admin(self):
        return self.role == 'admin'

    def is_data_entry(self):
        return self.role == 'data_entry'

    def is_recently_active(self, days=7):
        if not self.last_login:
            return False
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        last = self.last_login
        if last.tzinfo is None:
            cutoff = cutoff.replace(tzinfo=None)
        return last > cutoff

    def __repr__(self):
        return f'<User {self.username}>'


class Batch(db.Model):
    __tablename__ = 'batches'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    numbering_mode = db.Column(db.String(20), nullable=False, default='repeat')
    start_book = db.Column(db.Integer, nullable=False, default=1)
    start_serial = db.Column(db.Integer, nullable=False, default=1)
    archived = db.Column(db.Boolean, nullable=False, default=False)
    locked = db.Column(db.Boolean, nullable=False, default=False, server_default=db.false())
    hidden = db.Column(db.Boolean, nullable=False, default=False, server_default=db.false())
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))


class Book(db.Model):
    """Configured invoice book and its capacity."""
    __tablename__ = 'books'

    id = db.Column(db.Integer, primary_key=True)
    __table_args__ = (db.UniqueConstraint('batch_id', 'book_number', name='uq_batch_book'),)
    batch_id = db.Column(db.Integer, db.ForeignKey('batches.id'), nullable=False, default=lambda: __import__('app.batches', fromlist=['current_batch_id']).current_batch_id())
    batch = db.relationship('Batch')
    book_number = db.Column(db.Integer, nullable=False)
    capacity = db.Column(db.Integer, nullable=False, default=50)
    assigned_user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    invoices = db.relationship('Invoice', backref='book_record', lazy='dynamic')
    assigned_user = db.relationship('User', back_populates='assigned_books', foreign_keys=[assigned_user_id])

    @property
    def used_count(self):
        return self.invoices.count()

    @property
    def remaining_count(self):
        return max(self.capacity - self.used_count, 0)

    def __repr__(self):
        return f'<Book {self.book_number}>'


class Invoice(db.Model):
    """Invoice model."""
    __tablename__ = 'invoices'

    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    serial_numeric = db.Column(db.BigInteger, db.Computed('CAST(serial_number AS UNSIGNED)', persisted=True))
    __table_args__ = (db.UniqueConstraint('batch_id', 'serial_number', name='uq_batch_serial'),
                      db.UniqueConstraint('date', 'serial_numeric', name='uq_date_serial_numeric'),
                      db.CheckConstraint("serial_number <> '' AND serial_number NOT REGEXP '[^0-9]' AND serial_numeric BETWEEN 1 AND 2147483647", name='ck_positive_serial'))
    batch_id = db.Column(db.Integer, db.ForeignKey('batches.id'), nullable=False, default=lambda: __import__('app.batches', fromlist=['current_batch_id']).current_batch_id())
    batch = db.relationship('Batch')
    serial_number = db.Column(db.String(20), nullable=False)
    amounts_json = db.Column(db.Text, nullable=False)
    total_amount = db.Column(db.Numeric(10, 3), nullable=False)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    updated_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    media_required = db.Column(db.Boolean, default=False)
    book_id = db.Column(db.Integer, db.ForeignKey('books.id'), nullable=True)
    book_page = db.Column(db.Integer, nullable=True)

    media = db.relationship('InvoiceMedia', backref='invoice', lazy='dynamic', cascade='all, delete-orphan')

    @property
    def total_on_date(self):
        return Invoice.query.filter(Invoice.date == self.date, Invoice.batch_id == self.batch_id).count()

    @property
    def rank_on_date(self):
        return (
            Invoice.query.filter(Invoice.date == self.date, Invoice.batch_id == self.batch_id)
            .filter(cast(Invoice.serial_number, Integer) < (int(self.serial_number) if self.serial_number.isdigit() else 0))
            .count() + 1
        )

    def set_amounts(self, amounts_list):
        self.amounts_json = json.dumps(amounts_list)

    def get_amounts(self):
        if self.amounts_json:
            return json.loads(self.amounts_json)
        return []

    def total(self):
        return sum(self.get_amounts())

    def __repr__(self):
        return f'<Invoice {self.serial_number}>'


class InvoiceMedia(db.Model):
    """Media attachments for invoices."""
    __tablename__ = 'invoice_media'

    id = db.Column(db.Integer, primary_key=True)
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoices.id'), nullable=False)
    file_name = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(500), nullable=False)
    file_size = db.Column(db.Integer, nullable=False)
    mime_type = db.Column(db.String(100), nullable=False)
    uploaded_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    uploaded_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))

    def __repr__(self):
        return f'<InvoiceMedia {self.file_name}>'


class AuditLog(db.Model):
    """Audit trail for all actions."""
    __tablename__ = 'audit_logs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    action = db.Column(db.String(50), nullable=False)
    details = db.Column(db.Text, nullable=True)
    ip_address = db.Column(db.String(45), nullable=True)
    timestamp = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))

    def __init__(self, **kwargs):
        if 'details' in kwargs and isinstance(kwargs['details'], (dict, list)):
            kwargs['details'] = json.dumps(kwargs['details'])
        super().__init__(**kwargs)

    def set_details(self, details_dict):
        self.details = json.dumps(details_dict)

    def get_details(self):
        if self.details:
            try:
                return json.loads(self.details)
            except Exception:
                return {}
        return {}

    def __repr__(self):
        return f'<AuditLog {self.action} by user {self.user_id}>'


class BackupRecord(db.Model):
    """Track generated backup files."""
    __tablename__ = 'backup_records'

    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    size = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))

    def __repr__(self):
        return f'<BackupRecord {self.filename}>'


class SystemSetting(db.Model):
    """System settings stored in key-value pairs."""
    __tablename__ = 'system_settings'

    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text, nullable=False)
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    def __repr__(self):
        return f'<SystemSetting {self.key}={self.value}>'

    @classmethod
    def get_value(cls, key, default=None):
        setting = cls.query.filter_by(key=key).first()
        if setting:
            return setting.value
        return default

    @classmethod
    def set_value(cls, key, value):
        setting = cls.query.filter_by(key=key).first()
        if setting:
            setting.value = value
        else:
            setting = cls(key=key, value=value)
            db.session.add(setting)
        db.session.commit()


class InvoiceIdentityReservation(db.Model):
    """Current and previous date/serial keys, released only by invoice deletion."""
    __tablename__ = 'invoice_identity_reservations'
    date = db.Column(db.Date, primary_key=True)
    serial_numeric = db.Column(db.BigInteger, primary_key=True)
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoices.id', ondelete='CASCADE'), nullable=False, index=True)


