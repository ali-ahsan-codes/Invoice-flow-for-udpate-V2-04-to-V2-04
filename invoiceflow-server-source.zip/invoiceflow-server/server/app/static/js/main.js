// static/js/main.js

/**
 * InvoiceFlow v2 - Main JavaScript
 * UPDATED: robust serial auto-update after save.
 */

// ============================================
// Global Configuration
// ============================================
const CONFIG = {
    csrfToken: document.querySelector('meta[name="csrf-token"]')?.content || '',
    endpoints: {
        createInvoice: '/invoices/create',
        updateInvoice: '/invoices/update',
        deleteInvoice: '/invoices/<id>/delete',
        searchInvoices: '/invoices/search',
        nextSerial: '/invoices/next-serial',
        bookInfo: '/invoices/book-info',
        updateSession: '/invoices/update-session',
        startSession: '/invoices/start-session',
        gridData: '/invoices/grid-data',
        calendarData: '/invoices/calendar-data',
        summaryData: '/invoices/summary-data',
        recentInvoices: '/recent-invoices',
        quickStats: '/quick-stats',
    },
    shortcuts: {
        saveInvoice: 'Enter',
        addAmount: 'a',
        nextInvoice: 'Enter',
        setDateAndSerial: 'F7',
        nextDate: 'F8',
    }
};

// ============================================
// Utility Functions
// ============================================

function formatCurrency(amount, currency = 'OMR', decimalPlaces = 3) {
    if (amount === null || amount === undefined) amount = 0;
    const formatted = Number(amount).toFixed(decimalPlaces).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return `${currency} ${formatted}`;
}

function formatDate(dateStr, format = 'YYYY-MM-DD') {
    if (!dateStr) return '';
    // ISO date-only values represent a local calendar day, not midnight UTC.
    const d = /^\d{4}-\d{2}-\d{2}$/.test(dateStr)
        ? new Date(Number(dateStr.slice(0,4)), Number(dateStr.slice(5,7))-1, Number(dateStr.slice(8,10)))
        : new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;

    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');

    if (format === 'MM/DD/YYYY') return `${month}/${day}/${year}`;
    if (format === 'DD/MM/YYYY') return `${day}/${month}/${year}`;
    if (format === 'MMM D, YYYY') {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return `${months[d.getMonth()]} ${d.getDate()}, ${year}`;
    }
    return `${year}-${month}-${day}`;
}

function showToast(message, type = 'info', duration = 3000) {
    const container = document.getElementById('toast-container') || (() => {
        const c = document.createElement('div');
        c.id = 'toast-container';
        c.className = 'position-fixed bottom-0 end-0 p-3';
        c.style.zIndex = '1050';
        document.body.appendChild(c);
        return c;
    })();

    const colors = {
        success: 'bg-success text-white',
        danger: 'bg-danger text-white',
        warning: 'bg-warning text-dark',
        info: 'bg-info text-white',
    };
    const icons = {
        success: 'fa-check-circle',
        danger: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle',
    };

    const toast = document.createElement('div');
    toast.className = `toast align-items-center ${colors[type] || colors.info} border-0 show`;
    toast.role = 'alert';
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                <i class="fas ${icons[type] || icons.info} me-2"></i>
                <span class="toast-message"></span>
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    toast.querySelector('.toast-message').textContent = String(message);
    toast.querySelector('.btn-close').setAttribute('aria-label', 'Close notification');
    toast.querySelector('.btn-close').addEventListener('click', () => toast.remove());
    container.appendChild(toast);
    setTimeout(() => toast.remove(), duration);
}

function getCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (meta && meta.content) return meta.content;
    if (CONFIG.csrfToken) return CONFIG.csrfToken;
    const input = document.querySelector('input[name="csrf_token"]');
    if (input && input.value) return input.value;
    return '';
}

async function ajaxRequest(url, method = 'GET', data = null) {
    const options = {
        method: method,
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRFToken': getCsrfToken(),
        },
        credentials: 'same-origin',
        redirect: 'manual',
    };

    if (data) {
        if (data instanceof FormData) options.body = data;
        else {
            options.headers['Content-Type'] = 'application/json';
            options.body = JSON.stringify(data);
        }
    }

    const response = await fetch(url, options);
    if(response.type==='opaqueredirect' || response.status===401)throw new Error('Your session ended. Your draft is kept. Copy the draft before signing in and reopening this form.');
    const text = await response.text();
    let responseData;
    try {
        responseData = JSON.parse(text);
    } catch (e) {
        console.error('Non-JSON response:', text.substring(0, 300));
        throw new Error(`Server returned ${response.status} (not JSON)`);
    }
    if (!response.ok) {
        throw new Error(responseData.error || `Request failed (${response.status})`);
    }
    return responseData;
}

// ============================================
// Invoice Form Handler
// ============================================

class InvoiceFormHandler {
    constructor(formId) {
        this.form = document.getElementById(formId);
        if (!this.form) return;

        this.amountFields = this.form.querySelector('.amount-fields');
        this.totalDisplay = this.form.querySelector('.total-display');
        this.serialInput = this.form.querySelector('[name="serial_number"]');
        this.dateInput = this.form.querySelector('[name="date"]');
        this.bookInput = this.form.querySelector('[name="book_number"]');
        this.pageInput = document.getElementById('page');
        this.submitBtn = this.form.querySelector('[type="submit"]');
        this.invoiceIdInput = this.form.querySelector('[name="invoice_id"]');
        this.infoBox = document.getElementById('book-info-box');
        this.mode = this.form.dataset.mode || 'create';

        this._sessionSyncTimer = null;

        this.init();
    }

    init() {
        const addBtn = this.form.querySelector('.btn-add-amount');
        if (addBtn) addBtn.addEventListener('click', () => this.addAmountField());

        const nextDayBtn = this.form.querySelector('#btn-date-next-day');
        if (nextDayBtn) nextDayBtn.addEventListener('click', () => this.advanceDateManual());

        this.form.addEventListener('input', (e) => {
            if (e.target.matches('.amount-field-input')) this.calculateTotal();
        });

        if (this.dateInput && this.mode !== 'edit') {
            this.dateInput.addEventListener('change', () => {
                this.syncDateToSerial();
                this.syncSessionToServer();
            });
        }

        if (this.serialInput && this.mode !== 'edit') {
            this.serialInput.addEventListener('input', () => this.scheduleSessionSync());
        }

        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.submitForm();
        });

        this.amountFields?.addEventListener('click', (e) => {
            const button = e.target.closest('.btn-remove-amount');
            if (!button || this.amountFields.querySelectorAll('.amount-field').length <= 1) return;
            button.closest('.amount-field').remove();
            this.reindexAmountFields();
            this.calculateTotal();
        });
        this.reindexAmountFields();
        this.setupShortcuts();
        this.calculateTotal();
    }

    reindexAmountFields() {
        const fields = this.amountFields?.querySelectorAll('.amount-field') || [];
        fields.forEach((field, i) => {
            const input = field.querySelector('input');
            if (input) { input.name = `amounts-${i}`; input.setAttribute('aria-label', `Amount ${i + 1} in OMR`); }
            const remove = field.querySelector('.btn-remove-amount');
            if (remove) { remove.disabled = fields.length <= 1; remove.setAttribute('aria-label', `Remove amount ${i + 1}`); }
        });
    }

    addAmountField() {
        if(this._saving)return;
        const fields = this.amountFields.querySelectorAll('.amount-field');
        const lastField = fields[fields.length - 1];
        if (!lastField) return;

        if (fields.length >= 20) { showToast('You can add up to 20 amounts per invoice.', 'warning'); return; }
        const newField = lastField.cloneNode(true);
        newField.querySelectorAll('input').forEach(input => { input.value = ''; input.removeAttribute('id'); });
        const removeBtn = newField.querySelector('.btn-remove-amount');
        if (removeBtn) removeBtn.disabled = false;

        this.amountFields.appendChild(newField);
        this.reindexAmountFields();
        const firstInput = newField.querySelector('input');
        if (firstInput) { firstInput.focus(); firstInput.select(); }
        this.calculateTotal();
    }

    calculateTotal() {
        if (!this.totalDisplay) return;
        let total = 0;
        this.amountFields.querySelectorAll('.amount-field-input').forEach(input => {
            const val = parseFloat(input.value);
            if (!isNaN(val) && val >= 0) total += val;
        });
        this.totalDisplay.textContent = formatCurrency(total);
    }

    async syncDateToSerial() {
        if (!this.dateInput || !this.serialInput || this.mode === 'edit') return;
        const bookVal = this.bookInput ? this.bookInput.value.trim() : '';
        if (!bookVal || !this.dateInput.value) return;

        if ([...this.amountFields.querySelectorAll('input')].some(i => i.value !== '' && i.value !== '0')) return;
        const serialBefore = this.serialInput.value, dateBefore = this.dateInput.value;
        const requestId = this._serialRequest = (this._serialRequest || 0) + 1;
        try {
            const params = new URLSearchParams({ book: bookVal, date: dateBefore });
            const response = await fetch(`${CONFIG.endpoints.nextSerial}?${params}`, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                credentials: 'same-origin',
            });
            const data = await response.json();
            if (this._serialRequest !== requestId || this.serialInput.value !== serialBefore || this.dateInput.value !== dateBefore || [...this.amountFields.querySelectorAll('input')].some(i => i.value !== '' && i.value !== '0')) return;
            if (data.serial) this.serialInput.value = data.serial;
            if (this.pageInput && data.page !== undefined) this.pageInput.value = data.page || '';
        } catch (err) {
            console.error('Failed to fetch next serial:', err);
        }
    }

    async syncSessionToServer() {
        if (this.mode === 'edit' || this._saving) return;
        if(this._sessionSyncRequest){this._sessionSyncQueued=true;return this._sessionSyncRequest;}
        const dateVal = this.dateInput?.value;
        const bookVal = this.bookInput?.value;
        if (!dateVal || !bookVal) return;

        try {
            const formData = new FormData();
            formData.append('date', dateVal);
            formData.append('book', bookVal);
            if (this.serialInput?.value) formData.append('serial', this.serialInput.value);
            formData.append('csrf_token', getCsrfToken());

            this._sessionSyncRequest = fetch(CONFIG.endpoints.updateSession, {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRFToken': getCsrfToken(),
                },
                body: formData,
                credentials: 'same-origin',
            });
            await this._sessionSyncRequest;
        } catch (err) {
            console.error('Failed to sync session:', err);
        } finally {
            this._sessionSyncRequest=null;
            if(this._sessionSyncQueued){this._sessionSyncQueued=false;if(!this._saving)this.syncSessionToServer();}
        }
    }

    scheduleSessionSync() {
        clearTimeout(this._sessionSyncTimer);
        this._sessionSyncTimer = setTimeout(() => this.syncSessionToServer(), 500);
    }

    setupShortcuts() {
        document.addEventListener('keydown', (e) => {
            if (document.querySelector('.modal.show')) return;
            const active = document.activeElement;
            if (e.key === 'a' && active?.tagName === 'INPUT' && active.closest('.amount-field')) {
                e.preventDefault();
                this.addAmountField();
            }
        });

        document.addEventListener('keydown', (e) => {
            if (document.querySelector('.modal.show')) return;
            if (e.key === 'F7') { e.preventDefault(); this.setDateAndSerial(); }
            if (e.key === 'F8') { e.preventDefault(); this.nextDate(); }
        });
    }

    formatDateInput(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    advanceDateManual() {
        if (this._saving || !this.dateInput) return;
        if (!this.dateInput.value) this.dateInput.value = this.formatDateInput(new Date());
        const current = new Date(`${this.dateInput.value}T00:00:00`);
        if (Number.isNaN(current.getTime())) return;
        current.setDate(current.getDate() + 1);
        this.dateInput.value = this.formatDateInput(current);
        this.syncDateToSerial();
        this.syncSessionToServer();
    }

    setDateAndSerial() {
        if(this._saving)return;
        const today = this.formatDateInput(new Date());
        if (this.dateInput) this.dateInput.value = today;
        this.syncDateToSerial();
        this.syncSessionToServer();
    }

    nextDate() { this.submitForm(true); }
    nextInvoice() { this.submitForm(false); }

    /**
     * Fallback: if the server didn't include next_serial in the response,
     * fetch it separately. This guarantees the serial always updates.
     */
    async fetchNextSerialFallback() {
        if (this.mode === 'edit') return;
        const bookVal = this.bookInput ? this.bookInput.value.trim() : '';
        if (!bookVal) return;

        try {
            const params = new URLSearchParams({ book: bookVal });
            const resp = await fetch(`${CONFIG.endpoints.nextSerial}?${params}`, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                credentials: 'same-origin',
            });
            const data = await resp.json();
            if (data.serial && this.serialInput) {
                this.serialInput.value = data.serial;
                console.log('[form] serial updated from fallback:', data.serial);
            }
            if (this.pageInput && data.page !== undefined) {
                this.pageInput.value = data.page || '';
            }
            return data;
        } catch (err) {
            console.error('[form] fallback serial fetch failed:', err);
            return null;
        }
    }

    async submitForm(advanceDate = false) {
        if (this._saving || document.querySelector('.modal.show')) return;
        if (!this.form.reportValidity()) return;
        this._saving = true;
        const formData = new FormData(this.form);
        const editables = [...this.form.querySelectorAll('input:not([type=hidden]),select,textarea,button')];
        const states = editables.map(el => [el,el.disabled,el.readOnly]);
        editables.forEach(el => { if(el.matches('button,select,input[type=checkbox]'))el.disabled=true;else el.readOnly=true; });
        this._serialRequest = (this._serialRequest || 0) + 1;

        const invoiceId = this.invoiceIdInput?.value;
        let url = this.form.action || CONFIG.endpoints.createInvoice;
        if (invoiceId && parseInt(invoiceId) > 0) url = `/invoices/${invoiceId}/edit`;

        try {
            this.submitBtn.disabled = true;
            this.submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

            clearTimeout(this._sessionSyncTimer);this._sessionSyncQueued=false;
            if(this._sessionSyncRequest)await this._sessionSyncRequest.catch(()=>{});
            const response = await ajaxRequest(url, 'POST', formData);
            console.log('[form] save response:', response);

            if (!response.success) {
                showToast(response.error || 'Failed to save invoice', 'danger');
                return;
            }

            showToast(response.message || 'Invoice saved successfully!', 'success');

            // Edit flow: redirect
            if (response.redirect) {
                window.location.href = response.redirect;
                return;
            }

            // Book full: send user back to session card
            if (response.book_full) {
                showToast('Book complete! Redirecting…', 'info');
                setTimeout(() => window.location.href = CONFIG.endpoints.startSession, 900);
                return;
            }

            // ---- Update form with next serial/date/book info ----
            if (response.next_serial && this.serialInput) {
                this.serialInput.value = response.next_serial;
                console.log('[form] serial set to', response.next_serial);
            } else if (this.mode !== 'edit') {
                // Fallback: server didn't send next_serial — fetch manually
                console.log('[form] no next_serial in response, using fallback');
                await this.fetchNextSerialFallback();
            }

            if (response.next_page !== undefined && this.pageInput) {
                this.pageInput.value = response.next_page || '';
            }

            if (response.next_date && this.dateInput) {
                if (advanceDate) {
                    const currentDate = new Date(`${response.next_date}T00:00:00`);
                    currentDate.setDate(currentDate.getDate() + 1);
                    this.dateInput.value = this.formatDateInput(currentDate);
                } else {
                    this.dateInput.value = response.next_date;
                }
            }

            // Refresh book info box
            if (response.book_info && this.infoBox) {
                const info = response.book_info;
                const isFull = (info.remaining === 0);
                this.infoBox.className = 'book-info-box show' + (isFull ? ' warn' : '');
                this.infoBox.innerHTML = `
                    <div class="bi-line"><span class="bi-label">Range</span><span class="bi-value">${info.start || '?'}–${info.end || '?'}</span></div>
                    <div class="bi-line"><span class="bi-label">Used</span><span class="bi-value">${info.used} / ${info.capacity}</span></div>
                    <div class="bi-line"><span class="bi-label">Next</span><span class="bi-value">${response.next_serial || '— (full)'}</span></div>
                `;
            }

            // Clear amount fields
            this.amountFields.querySelectorAll('.amount-field').forEach((field, index) => {
                const input = field.querySelector('input');
                if (input) input.value = '';
                if (index > 0) field.remove();
            });

            if (this.invoiceIdInput) this.invoiceIdInput.value = '';

            this.reindexAmountFields();
            this.calculateTotal();
            refreshRecentInvoices();

            // Persist explicit Save + Next Day after the save lock is released.
            this._syncAfterSave = true;

        } catch (error) {
            console.error('[form] save failed:', error);
            showToast(error.message || 'An error occurred', 'danger');
        } finally {
            states.forEach(([el,disabled,readOnly]) => { el.disabled=disabled; if('readOnly' in el)el.readOnly=readOnly; });
            this.reindexAmountFields();
            this._saving = false;
            if(this._syncAfterSave){this._syncAfterSave=false;this.syncSessionToServer();}
            this.submitBtn.disabled = false;
            this.submitBtn.innerHTML = 'Save Invoice';
        }
    }
}

// ============================================
// Search / Grid / Recent (unchanged)
// ============================================

class SearchHandler {
    constructor(inputId, resultsId) {
        this.input = document.getElementById(inputId);
        this.results = document.getElementById(resultsId);
        if (!this.input) return;
        this.debounceTimer = null;
        this.init();
    }
    init() {
        this.input.addEventListener('input', () => {
            clearTimeout(this.debounceTimer);
            const q = this.input.value.trim();
            if (q.length < 2) { this.results.innerHTML = ''; return; }
            this.debounceTimer = setTimeout(() => this.search(q), 300);
        });
    }
    async search(query) {
        try {
            const data = await ajaxRequest(`${CONFIG.endpoints.searchInvoices}?query=${encodeURIComponent(query)}&search_type=serial`);
            this.results.innerHTML = '';
            if (data.results && data.results.length > 0) {
                data.results.forEach(inv => {
                    const item = document.createElement('div');
                    item.className = 'search-result-item';
                    const label = document.createElement('span');
                    label.className = 'batch';
                    label.textContent = inv.batch_name ? `${inv.batch_name} #${inv.batch_id}` : '';
                    item.innerHTML = `<span class="serial">${inv.serial_number}</span><span class="date">${formatDate(inv.date, 'MM/DD/YYYY')}</span><span class="amount">${formatCurrency(inv.total_amount)}</span>`;
                    item.appendChild(label);
                    item.addEventListener('click', () => window.location.href = `/invoices/${inv.id}`);
                    this.results.appendChild(item);
                });
            } else {
                this.results.innerHTML = '<div class="search-result-empty">No results found</div>';
            }
        } catch (e) { console.error(e); }
    }
}

class InvoiceGridHandler {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        if (!this.container) return;
        this.init();
    }
    init() {
        this.loadGrid();
        const refreshBtn = this.container.querySelector('.btn-refresh-grid');
        if (refreshBtn) refreshBtn.addEventListener('click', () => this.loadGrid());
    }
    async loadGrid() {
        const params = {
            start_serial: this.container.querySelector('.start-serial')?.value || 1,
            from_date: this.container.querySelector('.from-date')?.value,
            to_date: this.container.querySelector('.to-date')?.value,
        };
        if (!params.from_date || !params.to_date) return;
        try {
            this.showLoading(true);
            const data = await ajaxRequest(`${CONFIG.endpoints.gridData}?${new URLSearchParams(params)}`);
            this.renderGrid(data);
        } catch (e) {
            showToast('Failed to load grid data', 'danger');
        } finally {
            this.showLoading(false);
        }
    }
    renderGrid(data) {
        const table = this.container.querySelector('.grid-table');
        if (!table) return;
        table.innerHTML = '';
        const thead = document.createElement('thead');
        const hdr = document.createElement('tr');
        hdr.innerHTML = `<th class="serial-column">Serial #</th>`;
        data.dates.forEach(d => hdr.innerHTML += `<th>${formatDate(d, 'MM/DD')}</th>`);
        thead.appendChild(hdr);
        table.appendChild(thead);
        const tbody = document.createElement('tbody');
        data.serials.forEach(serial => {
            const row = document.createElement('tr');
            row.innerHTML = `<td class="serial-column">${serial}</td>`;
            data.dates.forEach(date => {
                const cell = data.grid[`${serial}-${date}`] || null;
                const td = document.createElement('td');
                const div = document.createElement('div');
                div.className = 'grid-cell';
                if (cell) {
                    if (cell.total === 0) { div.className += ' cell-zero-amount'; div.textContent = '0'; }
                    else { div.className += ' cell-has-invoice'; div.textContent = cell.total.toFixed(3); }
                } else { div.className += ' cell-missing'; div.textContent = '✗'; }
                td.appendChild(div); row.appendChild(td);
            });
            tbody.appendChild(row);
        });
        table.appendChild(tbody);
    }
    showLoading(loading) {
        const loader = this.container.querySelector('.grid-loader');
        if (loader) loader.style.display = loading ? 'block' : 'none';
        const content = this.container.querySelector('.grid-content');
        if (content) content.style.display = loading ? 'none' : 'block';
    }
}

async function refreshRecentInvoices() {
    const container = document.querySelector('.recent-invoices-table tbody');
    if (!container) return;
    try {
        const data = await ajaxRequest(CONFIG.endpoints.recentInvoices);
        container.innerHTML = '';
        if (data.length === 0) {
            container.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No recent invoices</td></tr>';
            return;
        }
        data.forEach(inv => {
            const tr = document.createElement('tr');
            tr.innerHTML = `<td>${formatDate(inv.date, 'MM/DD/YYYY')}</td><td><strong>${inv.serial_number}</strong></td><td><span class="rank-badge">${inv.rank || 1}/${inv.total_on_date || 1}</span></td><td class="text-end">${formatCurrency(inv.total_amount)}</td>`;
            container.appendChild(tr);
        });
    } catch (e) { console.error(e); }
}

// ============================================
// Init
// ============================================

document.addEventListener('DOMContentLoaded', function () {
    const invoiceForm = document.querySelector('.invoice-form');
    if (invoiceForm) {
        const handler = new InvoiceFormHandler('invoice-form');
        invoiceForm.__handler = handler;
        window.invoiceFormHandler = handler;
    }

    const searchInput = document.getElementById('search-input');
    const searchResults = document.getElementById('search-results');
    if (searchInput && searchResults) new SearchHandler('search-input', 'search-results');

    const gridContainer = document.getElementById('invoice-grid');
    if (gridContainer) window.invoiceGridHandler = new InvoiceGridHandler('invoice-grid');



    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.dataset.confirmBound = '1';
        el.addEventListener('click', (e) => {
            if (!confirm(el.dataset.confirm)) { e.preventDefault(); return false; }
        });
    });

    document.querySelectorAll('.app-flash .alert').forEach(alert => {
        setTimeout(() => {
            try { new bootstrap.Alert(alert).close(); } catch (e) {}
        }, 5000);
    });

    document.getElementById('btn-next-invoice')?.addEventListener('click', function () {
        if (window.invoiceFormHandler) window.invoiceFormHandler.nextInvoice();
    });
    document.getElementById('btn-next-date')?.addEventListener('click', function () {
        if (window.invoiceFormHandler) window.invoiceFormHandler.nextDate();
    });
    document.getElementById('btn-set-date-serial')?.addEventListener('click', function () {
        if (window.invoiceFormHandler) window.invoiceFormHandler.setDateAndSerial();
    });
});

window.InvoiceFormHandler = InvoiceFormHandler;
window.InvoiceFlow = {
    formatCurrency, formatDate, showToast, ajaxRequest,
    refreshRecentInvoices, CONFIG,
};


