/* Worker-safe, auth-scoped live sync. No navigation or document reload. */
(() => {
    'use strict';
    const status = document.getElementById('live-status');
    if (!status) return; // Never sync or display workspace data on anonymous/auth screens.
    const originalFetch = window.fetch.bind(window);
    let revision = document.querySelector('meta[name="live-revision"]')?.content || null, running = false, timer, retry = 1500, requested = false;
    const channel = 'BroadcastChannel' in window ? new BroadcastChannel('invoiceflow-changes') : null;
    function label(text, state = '') {
        if (status && status.textContent !== text) status.textContent = text;
        if (status) status.dataset.state = state;
    }
    function changed() { requested = true; schedule(80); }
    window.fetch = async function(input, options = {}) {
        const response = await originalFetch(input, options);
        const method = (options.method || (input instanceof Request ? input.method : 'GET')).toUpperCase();
        if (!['GET','HEAD','OPTIONS'].includes(method) && response.ok && !String(input).includes('/invoices/update-session')) {
            changed(); channel?.postMessage('changed');
        }
        return response;
    };
    channel?.addEventListener('message', changed);
    document.addEventListener('input', event => {
        if (event.target.matches('input,select,textarea')) event.target.dataset.liveDirty = '1';
    }, true);
    document.addEventListener('change', event => {
        if (event.target.matches('input,select,textarea')) event.target.dataset.liveDirty = '1';
    }, true);
    function retain(oldNode, newNode) {
        if (oldNode.nodeType !== 1) return;
        if (oldNode.matches('.book-tile')) newNode.classList.toggle('selected', oldNode.classList.contains('selected'));
        if (oldNode.matches('button') && oldNode.disabled) return false;
        if (oldNode.matches('form') && oldNode.querySelector('[data-live-dirty]') && !oldNode.matches('#settings-form')) return false;
        if(oldNode.matches('[data-bs-toggle="tab"],[data-bs-toggle="pill"]')) {
            newNode.classList.toggle('active',oldNode.classList.contains('active'));
            newNode.setAttribute('aria-selected',oldNode.getAttribute('aria-selected') || 'false');
        }
        if (oldNode.matches('.tab-pane')) {
            ['active','show'].forEach(name => newNode.classList.toggle(name, oldNode.classList.contains(name)));
        }
        if (oldNode.matches('script,.modal,form,[name="csrf_token"],canvas,[data-live-preserve]')) return false;
        if (oldNode.matches('input,textarea') && (oldNode.type === 'file' || oldNode.dataset.liveDirty || oldNode === document.activeElement)) return false;
        if (oldNode.matches('select') && (oldNode.dataset.liveDirty || oldNode === document.activeElement)) return false;
    }
    async function refreshPage() {
        // Custom loaders keep chart instances, filters and calendar selection alive.
        if (window.invoiceLiveRefresh) {
            if (document.activeElement?.matches('main input,main select,main textarea')) return 'deferred';
            await window.invoiceLiveRefresh(); return null;
        }
        const response = await originalFetch(location.pathname + location.search, {
            credentials:'same-origin', cache:'no-store', redirect:'manual', headers:{'X-Live-Sync':'1'}, signal:AbortSignal.timeout(15000)
        });
        if (response.status === 401 || response.status === 403 || (response.redirected && new URL(response.url).pathname.includes('/login'))) {
            label('Session ended', 'offline'); throw new Error('session');
        }
        if(response.status===409){
            const detail=await response.json().catch(()=>({}));
            if(detail.code==='csrf_session')throw new Error('session');
            if(!document.getElementById('live-entry-state')){const hint=document.createElement('p');hint.id='live-entry-state';hint.dataset.livePreserve='1';hint.className='text-warning';hint.textContent='Entry session or book changed. Your draft is kept; confirm the book before saving.';document.querySelector('#invoice-form')?.prepend(hint);}
            throw new Error('entry');
        }
        if (response.status === 404) {
            label('Item removed', 'offline');
            if (!document.getElementById('live-removed')) {
                const banner = document.createElement('div'); banner.id = 'live-removed';
                banner.className = 'alert alert-warning';
                banner.textContent = 'This item was removed or its batch is no longer accessible. Unsaved inputs have been kept. Copy your draft before returning to the list.';
                document.querySelector('main.app-content')?.prepend(banner);
            }
            throw new Error('removed');
        }
        if (!response.ok || response.redirected) throw new Error('sync unavailable');
        const fresh = new DOMParser().parseFromString(await response.text(), 'text/html');
        const batchSelect = document.getElementById('batch-selector');
        const nextBatchSelect = fresh.getElementById('batch-selector');
        if (batchSelect && nextBatchSelect && document.activeElement !== batchSelect) {
            const selected = batchSelect.value;
            batchSelect.replaceChildren(...[...nextBatchSelect.options].map(option => option.cloneNode(true)));
            batchSelect.value = selected;
        }
        const count=document.getElementById('review-count'), freshCount=fresh.getElementById('review-count');
        if(count && freshCount)count.textContent=freshCount.textContent;
        const old = document.querySelector('main.app-content');
        const next = fresh.querySelector('main.app-content');
        // Dialogs were portaled to body once; never reintroduce duplicate IDs in main.
        next?.querySelectorAll('.modal').forEach(modal => modal.remove());
        if (!old || !next) throw new Error('invalid snapshot');
        [old, next].forEach(root => root.querySelectorAll('[data-live-key]').forEach(el => { el.id = 'live-' + el.dataset.liveKey; }));
        old.querySelectorAll('[data-bs-toggle="tab"],[data-bs-toggle="pill"]').forEach(tab=>{
            const target=tab.getAttribute('data-bs-target');
            const incoming=next.querySelector('[data-bs-target="'+target+'"]');
            if(incoming){incoming.className=tab.className;incoming.setAttribute('aria-selected',tab.getAttribute('aria-selected') || 'false');}
        });
        const scroll = [scrollX, scrollY];
        const scrollers = [...old.querySelectorAll('*')].filter(el => el.scrollTop || el.scrollLeft).map(el => [el, el.scrollTop, el.scrollLeft]);
        // Do not overwrite edit drafts; explicitly warn if persisted source changes.
        const form = old.querySelector('form.invoice-form[data-mode="edit"]');
        // Preserve server validation and its submitted form until the user retries.
        old.querySelectorAll('form').forEach(f => {
            if (f.querySelector('.is-invalid,.invalid-feedback')) f.dataset.livePreserve = 'validation';
        });
        const nextForm = next.querySelector('form.invoice-form[data-mode="edit"]');
        if (form && nextForm && form.dataset.sourceVersion !== nextForm.dataset.sourceVersion && !form.dataset.conflictNotified) {
            form.dataset.conflictNotified = '1';
            const hint=document.createElement('p');hint.className='text-warning mb-2';hint.dataset.livePreserve='conflict';
            hint.textContent='This invoice changed elsewhere. Your draft is kept; review the latest record before saving.';
            form.prepend(hint);
        }
        // Never morph a form's ancestor: morph libraries can replace wrappers and
        // detach the original form even when its own removal callback vetoes it.
        const hasEditor = [...old.querySelectorAll('form')].some(f =>
            !f.closest('.modal')) || !!old.querySelector('input[type="file"]');
        const draft = old.querySelector('[data-live-dirty]');
        const callbacks={beforeNodeMorphed:retain,beforeNodeRemoved(node){
            if(node.nodeType===1 && node.matches('.modal,[data-live-preserve]'))return false;
        }};
        old.querySelectorAll('form[data-batch-action],form[data-batch-archive]').forEach(f=>{
            const incoming=next.querySelector('#'+CSS.escape(f.id));
            if(!incoming || incoming.getAttribute('action')===f.getAttribute('action'))return;
            f.action=incoming.getAttribute('action');
            const button=f.querySelector('button'), nextButton=incoming.querySelector('button');
            button.textContent=nextButton.textContent;button.className=nextButton.className;
            const label=f.querySelector('label'), nextLabel=incoming.querySelector('label');
            if(label&&!nextLabel)label.remove();
            if(!label&&nextLabel)f.insertBefore(nextLabel.cloneNode(true),button);
        });
        const settings=old.querySelector('#settings-form'), incomingSettings=next.querySelector('#settings-form');
        if(settings && incomingSettings && !settings.querySelector('[data-live-dirty]') && !settings.contains(document.activeElement)){
            settings.querySelectorAll('input[id],select[id]').forEach(el=>{
                const incoming=incomingSettings.querySelector('#'+CSS.escape(el.id));
                if(!incoming)return;
                if(el.type==='checkbox')el.checked=incoming.checked;else el.value=incoming.value;
            });
            settings.querySelectorAll('.status-badge[id]').forEach(el=>{const incoming=incomingSettings.querySelector('#'+CSS.escape(el.id));if(incoming){el.textContent=incoming.textContent;el.className=incoming.className;}});
        }
        document.body.classList.add('invoiceflow-syncing');
        try {
            if (hasEditor || draft) {
                // Only explicitly designated read-only islands can update on editors.
                old.querySelectorAll('[data-live-region][id]').forEach(region => {
                    const replacement=next.querySelector('#'+CSS.escape(region.id));
                    if(replacement?.dataset.batchWritable)region.dataset.batchWritable=replacement.dataset.batchWritable;
                    // Regions with forms are updated only when explicitly opted in (data-live-allow-forms).
                    // retain() still keeps any form, input or select the user has typed in or focused.
                    const mayHoldForms = region.hasAttribute('data-live-allow-forms');
                    if(replacement && (mayHoldForms || !region.querySelector('form,input,textarea,select')) && region.innerHTML!==replacement.innerHTML)
                        Idiomorph.morph(region,replacement.innerHTML,{morphStyle:'innerHTML',callbacks});
                });
            } else if (old.innerHTML !== next.innerHTML) {
                Idiomorph.morph(old,next.innerHTML,{morphStyle:'innerHTML',ignoreActive:true,ignoreActiveValue:true,callbacks});
            }
        } finally { document.body.classList.remove('invoiceflow-syncing'); }
        scrollers.forEach(([el, top, left]) => { if (el.isConnected) { el.scrollTop = top; el.scrollLeft = left; } });
        window.scrollTo(...scroll);
        document.dispatchEvent(new CustomEvent('invoiceflow:updated'));
        return response.headers.get('X-Live-Revision');
    }
    async function tick(force = false) {
        if (running) { if (force) requested = true; return; }
        if (document.querySelector('.modal.show,.modal-backdrop')) { requested = true; schedule(300); return; }
        if (document.hidden && !force) { schedule(15000); return; }
        if (!navigator.onLine) { label('Offline · retrying', 'offline'); schedule(5000); return; }
        running = true;
        const doForce = force || requested; requested = false;
        try {
            const res = await originalFetch('/live/version', {credentials:'same-origin', cache:'no-store', headers:{'X-Live-Sync':'1'}, redirect:'manual', signal:AbortSignal.timeout(10000)});
            if (res.status === 401) throw new Error('session');
            if (!res.ok) throw new Error('version unavailable');
            const data = await res.json();
            const badge=document.getElementById('review-count');
            if(badge && Number.isInteger(data.review_open_count))badge.textContent=data.review_open_count;
            if (revision === null && !doForce) { revision=data.revision; }
            if (data.revision !== revision || doForce) {
                const snapshotVersion = await refreshPage();
                if(snapshotVersion !== 'deferred') revision = snapshotVersion || data.revision;
            }
            retry = 1500; label('Live', 'live');
        } catch (error) {
            retry = Math.min(retry * 2, 30000); label(error.message==='session' ? 'Session ended' : error.message==='removed' ? 'Item removed' : error.message==='entry' ? 'Check entry session' : 'Reconnecting…', 'offline');
        } finally {
            running = false; document.dispatchEvent(new Event('invoiceflow:sync-idle')); schedule(requested ? 80 : retry);
        }
    }
    function schedule(delay) { clearTimeout(timer); timer = setTimeout(() => tick(), delay); }
    window.InvoiceLive = {refresh:async () => {
        // Serialize with pending sync, then refresh from the canonical server state.
        requested = true;
        if (running) { await new Promise(resolve => document.addEventListener('invoiceflow:sync-idle', resolve, {once:true})); }
        await tick(true);
    }};
    document.addEventListener('visibilitychange', () => { if (!document.hidden) changed(); });
    window.addEventListener('online', changed);
    window.addEventListener('offline', () => label('Offline · retrying', 'offline'));
    window.addEventListener('pageshow', event => { if (event.persisted) changed(); });
    // Native actions are announced too; polling catches background jobs and other devices.
    async function hideDialog(modal) {
        if (!modal || !modal.classList.contains('show')) return;
        await new Promise(resolve => {
            modal.addEventListener('hidden.bs.modal', resolve, {once:true});
            bootstrap.Modal.getOrCreateInstance(modal).hide();
        });
    }
    document.addEventListener('hidden.bs.modal', changed);
    document.addEventListener('submit', async event => {
        channel?.postMessage('changed');
        const form = event.target;
        const invoiceDelete = form.id === 'delete-form' && /\/invoices\/\d+\/delete/.test(form.action);
        const userDelete = form.id === 'delete-form' && /\/admin\/users\/\d+\/delete/.test(form.action);
        if (form.id !== 'delete-media-form' && !invoiceDelete && !userDelete) return;
        event.preventDefault();
        if (form.dataset.submitting) return;
        form.dataset.submitting = '1';
        const btn = form.querySelector('[type=submit]');
        const labelText = invoiceDelete ? 'Delete Invoice' : userDelete ? 'Delete User' : 'Delete File';
        if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Deleting…'; }
        try {
            const response = await fetch(form.action, {method:'POST',body:new FormData(form),headers:{'X-Requested-With':'XMLHttpRequest'}});
            if (response.redirected) throw new Error('Your session or permissions changed. Sign in and try again.');
            const data = await response.json();
            if (!response.ok || !data.success) throw new Error(data.error || 'Delete failed');
            await hideDialog(form.closest('.modal'));
            if (invoiceDelete && /^\/invoices\/\d+$/.test(location.pathname)) {
                location.assign('/invoices/?batch_id='+encodeURIComponent(window.invoiceflowBatch || '')); return;
            }
            await window.InvoiceLive.refresh();
            showToast(data.message || (invoiceDelete ? 'Invoice deleted.' : userDelete ? 'User deleted.' : 'Attachment deleted.'), 'success');
        } catch(error) { showToast(error.message, 'danger'); }
        finally {
            delete form.dataset.submitting;
            if (btn) { btn.disabled = false; btn.textContent = labelText; }
        }
    });
    // Delegate confirmations so newly synchronized action links still work.
    document.addEventListener('click', event => {
        const el = event.target.closest('[data-confirm]');
        if (el && !el.dataset.confirmBound && !confirm(el.dataset.confirm)) event.preventDefault();
    });
    schedule(100);
})();


