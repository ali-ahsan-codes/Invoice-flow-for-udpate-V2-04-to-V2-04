# app/utils/validators.py

import re
from datetime import datetime
from wtforms.validators import ValidationError
from app.models import Invoice, User


def unique_serial_number(message=None):
    """Validator to ensure serial number is unique in the database."""
    if message is None:
        message = 'Serial number already exists. Please choose a unique one.'

    def _unique_serial_number(form, field):
        # Get invoice_id if present (for edit mode)
        invoice_id = form.invoice_id.data if hasattr(form, 'invoice_id') else None
        serial = field.data

        # Query for existing invoice with same serial
        query = Invoice.query.filter(Invoice.serial_number == serial)
        if invoice_id:
            query = query.filter(Invoice.id != invoice_id)

        if query.first():
            raise ValidationError(message)

    return _unique_serial_number


def valid_date_format(format='%Y-%m-%d', message=None):
    """Validator to ensure date string matches a specific format."""
    if message is None:
        message = f'Date must be in format {format}'

    def _valid_date_format(form, field):
        date_str = field.data
        if date_str:
            try:
                datetime.strptime(date_str, format)
            except ValueError:
                raise ValidationError(message)

    return _valid_date_format


def is_valid_serial_format(message=None):
    """Validator for serial number format: alphanumeric, hyphens, underscores only."""
    if message is None:
        message = 'Serial number can only contain letters, numbers, hyphens, and underscores.'

    def _is_valid_serial_format(form, field):
        serial = field.data
        if serial and not re.match(r'^[a-zA-Z0-9\-_]+$', serial):
            raise ValidationError(message)

    return _is_valid_serial_format


def unique_username(message=None):
    """Validator to ensure username is unique (excluding current user in edit mode)."""
    if message is None:
        message = 'Username already taken.'

    def _unique_username(form, field):
        username = field.data
        # If we have a user_id field, we are in edit mode
        user_id = form.user_id.data if hasattr(form, 'user_id') else None
        query = User.query.filter(User.username == username)
        if user_id:
            query = query.filter(User.id != user_id)
        if query.first():
            raise ValidationError(message)

    return _unique_username


def unique_email(message=None):
    """Validator to ensure email is unique (excluding current user in edit mode)."""
    if message is None:
        message = 'Email already registered.'

    def _unique_email(form, field):
        email = field.data
        user_id = form.user_id.data if hasattr(form, 'user_id') else None
        query = User.query.filter(User.email == email)
        if user_id:
            query = query.filter(User.id != user_id)
        if query.first():
            raise ValidationError(message)

    return _unique_email


def positive_number(message=None):
    """Validator to ensure a number is positive."""
    if message is None:
        message = 'Value must be a positive number.'

    def _positive_number(form, field):
        value = field.data
        if value is not None and value <= 0:
            raise ValidationError(message)

    return _positive_number


def max_amount_fields(max_fields=20, message=None):
    """Validator to ensure the amount field list does not exceed max entries."""
    if message is None:
        message = f'You can only add up to {max_fields} amount fields.'

    def _max_amount_fields(form, field):
        if len(field.data) > max_fields:
            raise ValidationError(message)

    return _max_amount_fields


