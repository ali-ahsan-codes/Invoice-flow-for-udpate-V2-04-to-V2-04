# app/utils/helpers.py

import os
import re
from datetime import datetime, date
from flask import request
from decimal import Decimal, ROUND_HALF_UP
from app.models import SystemSetting


# ============================================================
# Date format configuration
# ============================================================

DATE_FORMAT_PATTERNS = {
    'YYYY-MM-DD': '%Y-%m-%d',   # 2026-09-23  (ISO — default)
    'YYYY/MM/DD': '%Y/%m/%d',   # 2026/09/23
    'DD/MM/YYYY': '%d/%m/%Y',   # 23/09/2026  (European)
    'MM/DD/YYYY': '%m/%d/%Y',   # 09/23/2026  (US)
    'DD-MM-YYYY': '%d-%m-%Y',   # 23-09-2026
    'DD.MM.YYYY': '%d.%m.%Y',   # 23.09.2026
}

DATE_FORMAT_OPTIONS = [
    ('YYYY-MM-DD', '2026-09-23  (ISO 8601)'),
    ('YYYY/MM/DD', '2026/09/23'),
    ('DD/MM/YYYY', '23/09/2026  (European)'),
    ('MM/DD/YYYY', '09/23/2026  (US)'),
    ('DD-MM-YYYY', '23-09-2026'),
    ('DD.MM.YYYY', '23.09.2026'),
]

DEFAULT_DATE_FORMAT = 'YYYY-MM-DD'


def _get_date_pattern():
    """Return the configured strftime pattern, cached per request via flask.g."""
    try:
        from flask import g
        if hasattr(g, '_date_pattern'):
            return g._date_pattern
        value = SystemSetting.get_value('date_format', DEFAULT_DATE_FORMAT)
        pattern = DATE_FORMAT_PATTERNS.get(value, DATE_FORMAT_PATTERNS[DEFAULT_DATE_FORMAT])
        g._date_pattern = pattern
        return pattern
    except Exception:
        try:
            value = SystemSetting.get_value('date_format', DEFAULT_DATE_FORMAT)
            return DATE_FORMAT_PATTERNS.get(value, DATE_FORMAT_PATTERNS[DEFAULT_DATE_FORMAT])
        except Exception:
            return DATE_FORMAT_PATTERNS[DEFAULT_DATE_FORMAT]


def get_date_format_label():
    """Return the configured format token, e.g. 'DD/MM/YYYY'."""
    try:
        return SystemSetting.get_value('date_format', DEFAULT_DATE_FORMAT) or DEFAULT_DATE_FORMAT
    except Exception:
        return DEFAULT_DATE_FORMAT


def format_date_display(date_obj):
    """Format a date using the admin-configured format. Jinja: | localdate"""
    if not date_obj:
        return ''
    try:
        return date_obj.strftime(_get_date_pattern())
    except Exception:
        return str(date_obj)


def format_datetime_display(dt_obj, include_time=True):
    """Format a datetime using the configured format. Jinja: | localdatetime"""
    if not dt_obj:
        return ''
    try:
        pattern = _get_date_pattern()
        if include_time:
            return dt_obj.strftime(f'{pattern} %H:%M')
        return dt_obj.strftime(pattern)
    except Exception:
        return str(dt_obj)


# ============================================================
# Existing helpers (unchanged)
# ============================================================

def format_currency(amount, currency='OMR', decimal_places=3):
    if amount is None:
        amount = 0
    try:
        decimal_amount = Decimal(str(amount))
        rounded = decimal_amount.quantize(Decimal('0.001'), rounding=ROUND_HALF_UP)
        formatted = f"{rounded:,.3f}"
        return f"{currency} {formatted}"
    except Exception:
        return f"{currency} 0.000"


def get_client_ip():
    if request.headers.get('X-Forwarded-For'):
        ip = request.headers.get('X-Forwarded-For').split(',')[0].strip()
    else:
        ip = request.remote_addr
    return ip


def format_file_size(size_bytes):
    if size_bytes == 0:
        return "0 B"
    units = ['B', 'KB', 'MB', 'GB', 'TB']
    i = 0
    while size_bytes >= 1024 and i < len(units) - 1:
        size_bytes /= 1024.0
        i += 1
    return f"{size_bytes:.1f} {units[i]}"


def allowed_file(filename, allowed_extensions=None):
    if allowed_extensions is None:
        from flask import current_app
        allowed_extensions = current_app.config.get(
            'ALLOWED_EXTENSIONS',
            {'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx'}
        )
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions


def generate_unique_filename(original_filename):
    import time
    import random
    import string
    ext = original_filename.rsplit('.', 1)[1].lower() if '.' in original_filename else ''
    timestamp = int(time.time() * 1000)
    random_str = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
    new_filename = f"{timestamp}_{random_str}"
    if ext:
        new_filename += f".{ext}"
    return new_filename


def parse_date_string(date_str, format='%Y-%m-%d'):
    if not date_str:
        return None

    date_str = str(date_str).strip()

    try:
        return datetime.strptime(date_str, format).date()
    except (ValueError, TypeError):
        pass

    candidates = [
        '%Y-%m-%d', '%Y/%m/%d',
        '%m/%d/%Y', '%m/%d/%y',
        '%d/%m/%Y', '%d-%m-%Y', '%d.%m.%Y',
        '%d/%m/%y', '%m-%d-%Y', '%m.%d.%Y',
    ]

    for candidate in candidates:
        try:
            return datetime.strptime(date_str, candidate).date()
        except (ValueError, TypeError):
            continue

    return None


def format_date(date_obj, format='%Y-%m-%d'):
    if date_obj is None:
        return ''
    return date_obj.strftime(format)


def is_valid_serial(serial):
    return bool(re.match(r'^[a-zA-Z0-9\-_]+$', serial))


def safe_json_loads(json_str):
    import json
    try:
        return json.loads(json_str) if json_str else None
    except json.JSONDecodeError:
        return None


def get_pages_per_book():
    try:
        value = SystemSetting.get_value('pages_per_book', '50')
        return int(value)
    except (ValueError, TypeError):
        return 50


def calculate_book_page(serial_number, batch_id=None):
    from app.models import Book
    from app.batches import current_batch_id
    from app.services.invoice_service import get_book_serial_range
    try: serial = int(serial_number)
    except (ValueError, TypeError): return None, None
    bid = batch_id or current_batch_id()
    for book in Book.query.execution_options(all_batches=True).filter_by(batch_id=bid).order_by(Book.book_number).all():
        start, end = get_book_serial_range(book)
        if start <= serial <= end: return book.book_number, serial-start+1
    return None, None


def get_invoice_book_page(invoice):
    if invoice is None:
        return None, None
    book_record = getattr(invoice, 'book_record', None)
    stored_page = getattr(invoice, 'book_page', None)
    if book_record is not None and stored_page:
        return book_record.book_number, stored_page
    return calculate_book_page(getattr(invoice, 'serial_number', None), invoice.batch_id)


