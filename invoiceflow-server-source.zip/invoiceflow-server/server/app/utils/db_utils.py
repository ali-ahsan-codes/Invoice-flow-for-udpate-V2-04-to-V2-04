# app/utils/db_utils.py

import logging
from sqlalchemy import inspect, text, create_engine
from app.extensions import db

logger = logging.getLogger(__name__)


def ensure_database_exists(app):
    """Offline only; never guess credentials or swallow connection failures."""
    from sqlalchemy.engine import make_url
    url = make_url(app.config['SQLALCHEMY_DATABASE_URI'])
    name = url.database
    if not name: raise RuntimeError('A target database name is required.')
    engine = create_engine(url.set(database=None), isolation_level='AUTOCOMMIT')
    try:
        with engine.connect() as conn:
            exists = conn.execute(text('SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME=:name'), {'name':name}).first()
            if not exists:
                escaped=name.replace('`','``')
                conn.execute(text(f'CREATE DATABASE `{escaped}` CHARACTER SET utf8mb4'))
                logger.info('Configured database created during offline upgrade.')
    finally:
        engine.dispose()


def ensure_columns(app):
    """Add missing columns using simple ALTER TABLE statements."""
    with app.app_context():
        inspector = inspect(db.engine)
        table_columns = {
            'users': [
                ('email', 'VARCHAR(120) UNIQUE'),
                ('last_login', 'DATETIME'),
                ('preferred_start_serial', 'INT DEFAULT 1'),
                ('can_export', 'BOOLEAN DEFAULT 1'),
                ('api_key', 'VARCHAR(64) NULL'),
            ],
            'invoices': [
                ('book_id', 'INT NULL'),
                ('book_page', 'INT NULL'),
            ],
        }
        for table_name, columns in table_columns.items():
            if table_name not in inspector.get_table_names():
                continue
            existing = [col['name'] for col in inspector.get_columns(table_name)]
            for col_name, col_type in columns:
                if col_name not in existing:
                    logger.info(f"Adding column '{col_name}' to table '{table_name}'")
                    stmt = f"ALTER TABLE {table_name} ADD COLUMN {col_name} {col_type}"
                    try:
                        db.session.execute(text(stmt))
                        db.session.commit()
                        logger.info(f"Column '{col_name}' added successfully.")
                    except Exception as e:
                        logger.error(f"Failed to add column '{col_name}': {e}")
                        db.session.rollback()
                        raise RuntimeError(f"Legacy column upgrade failed: {table_name}.{col_name}. Keep offline and inspect database privileges/schema.") from e


def migrate_batches():
    """Idempotent MySQL/MariaDB upgrade. Run stopped/offline after a full backup.

    Columns and composite indexes are installed BEFORE global indexes are removed.
    Existing identity, timestamps, attachments and audit rows are never rewritten.
    DDL failures abort startup rather than silently running with partial scoping.
    """
    from app.models import Batch
    inspector = inspect(db.engine)
    if db.engine.dialect.name not in ('mysql', 'mariadb'):
        raise RuntimeError('Batch migration supports MySQL/MariaDB only.')
    with db.engine.connect() as conn:
        if conn.execute(text("SELECT GET_LOCK('invoiceflow_batch_migration', 60)")).scalar() != 1:
            raise RuntimeError('Could not acquire migration lock')
        try:
            invalid = conn.execute(text("SELECT id,serial_number FROM invoices WHERE serial_number = '' OR serial_number REGEXP '[^0-9]' OR CAST(serial_number AS UNSIGNED) NOT BETWEEN 1 AND 2147483647 LIMIT 20")).all()
            conflicts = conn.execute(text("SELECT date,CAST(serial_number AS UNSIGNED) AS serial,COUNT(*) AS copies,GROUP_CONCAT(id ORDER BY id) AS invoice_ids FROM invoices GROUP BY date,CAST(serial_number AS UNSIGNED) HAVING COUNT(*) > 1 LIMIT 20")).all()
            if invalid or conflicts:
                raise RuntimeError(f'Global date/serial upgrade blocked. No invoices changed. Invalid serials: {invalid}; duplicate date/serial (invoice IDs): {conflicts}. Resolve offline using the previous release after a backup, then retry.')
            columns = {c['name'] for c in inspect(db.engine).get_columns('batches')}
            for name in ('locked','hidden'):
                if name not in columns:
                    conn.execute(text(f'ALTER TABLE batches ADD COLUMN {name} BOOLEAN NOT NULL DEFAULT 0')); conn.commit()
            columns = {c['name'] for c in inspect(db.engine).get_columns('invoices')}
            if 'serial_numeric' not in columns:
                conn.execute(text('ALTER TABLE invoices ADD COLUMN serial_numeric BIGINT GENERATED ALWAYS AS (CAST(serial_number AS UNSIGNED)) STORED')); conn.commit()
            indexes = inspect(db.engine).get_indexes('invoices')
            if not any(i['unique'] and i['column_names']==['date','serial_numeric'] for i in indexes):
                conn.execute(text('ALTER TABLE invoices ADD UNIQUE INDEX uq_date_serial_numeric (date,serial_numeric)')); conn.commit()
            checks = inspect(db.engine).get_check_constraints('invoices')
            if not any(c['name']=='ck_positive_serial' for c in checks):
                conn.execute(text("ALTER TABLE invoices ADD CONSTRAINT ck_positive_serial CHECK (serial_number <> '' AND serial_number NOT REGEXP '[^0-9]' AND serial_numeric BETWEEN 1 AND 2147483647)")); conn.commit()
            conn.execute(text("INSERT IGNORE INTO batches (id,name,numbering_mode,start_book,start_serial,archived,created_at) VALUES (1,'Batch 1','repeat',1,1,0,UTC_TIMESTAMP())")); conn.commit()
            for table, number, index in [('books','book_number','uq_batch_book'),('invoices','serial_number','uq_batch_serial')]:
                columns = {c['name'] for c in inspect(db.engine).get_columns(table)}
                if 'batch_id' not in columns:
                    conn.execute(text(f'ALTER TABLE {table} ADD COLUMN batch_id INT NOT NULL DEFAULT 1')); conn.commit()
                indexes = inspect(db.engine).get_indexes(table)
                if not any(i['unique'] and i['column_names'] == ['batch_id',number] for i in indexes):
                    conn.execute(text(f'ALTER TABLE {table} ADD UNIQUE INDEX {index} (batch_id,{number})')); conn.commit()
                for i in indexes:
                    if i['unique'] and i['column_names'] == [number]:
                        name = i['name'].replace('`','``')
                        conn.execute(text(f'ALTER TABLE {table} DROP INDEX `{name}`')); conn.commit()
                fks = inspect(db.engine).get_foreign_keys(table)
                if not any(fk['constrained_columns'] == ['batch_id'] for fk in fks):
                    conn.execute(text(f'ALTER TABLE {table} ADD CONSTRAINT fk_{table}_batch FOREIGN KEY (batch_id) REFERENCES batches(id)')); conn.commit()
            for table in ('books','invoices'):
                column = next(c for c in inspect(db.engine).get_columns(table) if c['name']=='batch_id')
                if column.get('default') is not None:
                    conn.execute(text(f'ALTER TABLE {table} ALTER COLUMN batch_id DROP DEFAULT')); conn.commit()
            indexes = inspect(db.engine).get_indexes('books')
            if not any(i['unique'] and i['column_names']==['batch_id','id'] for i in indexes):
                conn.execute(text('ALTER TABLE books ADD UNIQUE INDEX uq_batch_book_id (batch_id,id)')); conn.commit()
            if not any(f['constrained_columns']==['batch_id','book_id'] for f in inspect(db.engine).get_foreign_keys('invoices')):
                conn.execute(text('ALTER TABLE invoices ADD CONSTRAINT fk_invoice_batch_book FOREIGN KEY (batch_id,book_id) REFERENCES books(batch_id,id)')); conn.commit()
            # Current keys are backfilled; historical edits before this upgrade cannot
            # be reconstructed from the legacy audit schema. Existing reservations persist.
            collisions = conn.execute(text("SELECT i.id,r.invoice_id,i.date,i.serial_numeric FROM invoices i JOIN invoice_identity_reservations r ON r.date=i.date AND r.serial_numeric=i.serial_numeric WHERE r.invoice_id<>i.id LIMIT 20")).all()
            if collisions: raise RuntimeError(f'Reserved identity migration conflict: {collisions}. Keep offline; no identities released.')
            conn.execute(text("INSERT IGNORE INTO invoice_identity_reservations (date,serial_numeric,invoice_id) SELECT date,serial_numeric,id FROM invoices")); conn.commit()
            # No generated-column NEW references: supported on both MySQL and MariaDB.
            # Duplicate-key no-op takes an exclusive key lock; check actual owner under it.
            for suffix, operation in [('ai','INSERT'),('au','UPDATE')]:
                name = 'invoices_reserve_' + suffix
                body = reservation_trigger_body()
                existing = conn.execute(text('SELECT ACTION_STATEMENT,ACTION_TIMING,EVENT_MANIPULATION,EVENT_OBJECT_TABLE FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE() AND TRIGGER_NAME=:name'), {'name':name}).first()
                if existing:
                    normalize = lambda value: ''.join(value.replace('`','').lower().split())
                    if (normalize(existing[0]) != normalize(body) or tuple(existing[1:]) != ('AFTER', operation, 'invoices')):
                        raise RuntimeError(f'Unexpected reservation trigger definition: {name}. Keep offline and have a DBA inspect it; it was not replaced.')
                    continue
                conn.execute(text(f'CREATE TRIGGER {name} AFTER {operation} ON invoices FOR EACH ROW {body}')); conn.commit()
            # Parameterless definer procedure: runtime EXECUTE, never runtime TRIGGER.
            # INFORMATION_SCHEMA filters views by invoker on MySQL; routines switch context.
            procedure_body = f"""SELECT TRIGGER_NAME,ACTION_STATEMENT,ACTION_TIMING,EVENT_MANIPULATION,EVENT_OBJECT_TABLE,TRIGGER_SCHEMA, 'invoiceflow-guards-v1' AS guard_version,DEFINER,SQL_MODE
                FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE()
                AND EVENT_OBJECT_TABLE='invoices'"""
            routine = conn.execute(text("SELECT ROUTINE_DEFINITION,SECURITY_TYPE FROM information_schema.ROUTINES WHERE ROUTINE_SCHEMA=DATABASE() AND ROUTINE_NAME='invoiceflow_verify_identity_guards' AND ROUTINE_TYPE='PROCEDURE'")).first()
            normalize = lambda value: ''.join(value.replace('`','').lower().split())
            if routine:
                if normalize(routine[0] or '')!=normalize(procedure_body) or routine[1]!='DEFINER':
                    raise RuntimeError('Unexpected verification procedure definition. Keep offline: DBA must inspect, drop the procedure, rerun upgrade and regrant EXECUTE.')
            else:
                conn.execute(text(f'CREATE PROCEDURE invoiceflow_verify_identity_guards() SQL SECURITY DEFINER READS SQL DATA {procedure_body}')); conn.commit()
            installed = set(conn.execute(text("SELECT TRIGGER_NAME FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE() AND TRIGGER_NAME IN ('invoices_reserve_ai','invoices_reserve_au')")).scalars())
            if len(installed)!=2: raise RuntimeError('Identity reservation triggers missing. Keep application offline.')
        finally:
            conn.execute(text("SELECT RELEASE_LOCK('invoiceflow_batch_migration')")); conn.commit()


def reservation_trigger_body():
    return """BEGIN
                      DECLARE owner_id INT;
                      INSERT INTO invoice_identity_reservations (date,serial_numeric,invoice_id)
                      VALUES (NEW.date,CAST(NEW.serial_number AS UNSIGNED),NEW.id)
                      ON DUPLICATE KEY UPDATE invoice_id=invoice_id;
                      SELECT invoice_id INTO owner_id FROM invoice_identity_reservations
                      WHERE date=NEW.date AND serial_numeric=CAST(NEW.serial_number AS UNSIGNED) FOR UPDATE;
                      IF owner_id IS NULL OR owner_id <> NEW.id THEN
                        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='INVOICE_IDENTITY_RESERVED';
                      END IF;
                    END"""


def verify_schema():
    """Read-only startup gate. No CREATE/ALTER/backfill is performed."""
    from sqlalchemy.exc import DBAPIError
    from pymysql.err import MySQLError
    required = {'users','batches','books','invoices','invoice_media','audit_logs',
                'system_settings','backup_records','live_revision','detection_policy',
                'review_cases','invoice_identity_reservations',
                'invoice_notes','invoice_note_media','invoice_links'}
    inspector = inspect(db.engine)
    missing = required - set(inspector.get_table_names())
    if missing: raise RuntimeError(f'Database schema not ready: missing {sorted(missing)}. Back up, stop all writers and run python upgrade_database.py with the migration account.')
    for table, columns in {'batches':{'locked','hidden','archived'}, 'invoices':{'serial_numeric','batch_id','book_id','book_page'},'books':{'batch_id'}, 'invoice_links':{'exclude_from_totals'}}.items():
        if not columns <= {c['name'] for c in inspector.get_columns(table)}:
            raise RuntimeError(f'Database schema behind: {table}. Run the offline upgrade_database.py before starting.')
    with db.engine.connect() as conn:
        try:
            # CALL includes a trailing result set. Drain it before returning the
            # DBAPI connection to the pool (avoids later packet-sync failures).
            raw = db.engine.raw_connection()
            try:
                with raw.cursor() as cursor:
                    cursor.execute('CALL invoiceflow_verify_identity_guards()')
                    guards = cursor.fetchall()
                    while cursor.nextset(): pass
            finally:
                raw.close()
        except (DBAPIError, MySQLError) as exc:
            raise RuntimeError('Identity verification procedure missing, inaccessible or its migration account no longer exists. Run upgrade_database.py offline with a durable migration account; grant runtime EXECUTE on PROCEDURE invoiceflow_verify_identity_guards.') from exc
        if len(guards)!=2 or any(g[6]!='invoiceflow-guards-v1' for g in guards):
            raise RuntimeError('Missing/unexpected invoice triggers or outdated verification procedure. Keep offline; have a DBA inspect and rerun upgrade_database.py.')
        normalize = lambda value: ''.join(value.replace('`','').lower().split())
        for suffix,event in [('ai','INSERT'),('au','UPDATE')]:
            matching = [g for g in guards if g[0]=='invoices_reserve_'+suffix]
            if len(matching)!=1 or normalize(matching[0][1])!=normalize(reservation_trigger_body()) or tuple(matching[0][2:5])!=('AFTER',event,'invoices') or matching[0][5]!=conn.execute(text('SELECT DATABASE()')).scalar():
                raise RuntimeError('Invoice identity trigger missing or incorrect. Keep entry offline; run upgrade_database.py and have a DBA inspect enforcement.')
        if conn.execute(text('SELECT COUNT(*) FROM invoices i LEFT JOIN invoice_identity_reservations r ON r.date=i.date AND r.serial_numeric=i.serial_numeric AND r.invoice_id=i.id WHERE r.invoice_id IS NULL')).scalar():
            raise RuntimeError('Invoice identity reservations incomplete. Keep offline and run upgrade_database.py.')
    if not any(i['unique'] and i['column_names']==['date','serial_numeric'] for i in inspector.get_indexes('invoices')):
        raise RuntimeError('Global identity index missing. Run the offline database upgrade.')
    if not any(c['name']=='ck_positive_serial' for c in inspector.get_check_constraints('invoices')):
        raise RuntimeError('Serial validation constraint missing. Run the offline database upgrade.')


