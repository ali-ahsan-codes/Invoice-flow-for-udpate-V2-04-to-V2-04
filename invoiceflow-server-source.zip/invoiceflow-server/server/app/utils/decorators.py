# app/utils/decorators.py

from functools import wraps
from flask import flash, redirect, url_for, abort, request, jsonify
from flask_login import current_user

from app.permissions import user_can, capability_label, DENIED_MESSAGE


def admin_required(f):
    """
    Decorator to restrict access to admin users only.
    If the user is not logged in, redirects to login.
    If the user is logged in but not admin, flashes a message and redirects to dashboard.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.headers.get('X-Live-Sync') == '1':
                return jsonify(success=False, error='Please sign in again.'), 401
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login'))
        if not current_user.is_admin():
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.headers.get('X-Live-Sync') == '1':
                return jsonify(success=False, error='Admin privileges required.'), 403
            flash('Access denied. Admin privileges required.', 'danger')
            return redirect(url_for('main.dashboard'))
        return f(*args, **kwargs)
    return decorated_function


def data_entry_required(f):
    """
    Decorator to restrict access to data entry users or admin.
    Both admin and data entry roles can access.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.headers.get('X-Live-Sync') == '1':
                return jsonify(success=False, error='Please sign in again.'), 401
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login'))
        if not (current_user.is_admin() or current_user.is_data_entry()):
            flash('Access denied. Data entry or admin privileges required.', 'danger')
            return redirect(url_for('main.dashboard'))
        return f(*args, **kwargs)
    return decorated_function


def owner_or_admin_required(model, id_field='id'):
    """
    Decorator to check if the current user is the owner of the resource or an admin.
    model: SQLAlchemy model class (e.g., Invoice)
    id_field: name of the primary key field (default 'id')
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.headers.get('X-Live-Sync') == '1':
                    return jsonify(success=False, error='Please sign in again.'), 401
                flash('Please log in to access this page.', 'warning')
                return redirect(url_for('auth.login'))
            
            # Get the resource ID from the URL parameters (assuming it's named 'id' or similar)
            resource_id = kwargs.get(id_field)
            if resource_id is None:
                # Try to find it in request args
                resource_id = request.args.get(id_field) or request.form.get(id_field)
            
            if resource_id is None:
                abort(400, description="Missing resource ID")
            
            # Query the resource
            resource = model.query.get(resource_id)
            if resource is None:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.accept_mimetypes.accept_json:
                    return jsonify({'success': False, 'error': 'Resource not found'}), 404
                flash('Resource not found.', 'danger')
                return redirect(request.referrer or url_for('invoices.index'))

            # Check if resource has a 'created_by' attribute (assumed to store user ID)
            if hasattr(resource, 'created_by'):
                if current_user.is_admin() or (resource.created_by == current_user.id):
                    return f(*args, **kwargs)
                else:
                    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.headers.get('X-Live-Sync') == '1':
                        return jsonify(success=False, error='Permission denied.'), 403
                    flash('You do not have permission to modify this resource.', 'danger')
                    return redirect(url_for('main.dashboard'))
            else:
                # If no ownership field, default to admin only
                if current_user.is_admin():
                    return f(*args, **kwargs)
                else:
                    flash('Access denied.', 'danger')
                    return redirect(url_for('main.dashboard'))
        return decorated_function
    return decorator




def capability_required(cap):
    """
    Allow the request only if the logged-in user has capability `cap`.
    Admins always pass. Data-entry users need an allow from the admin (see app/permissions.py).
    AJAX/JSON callers get a 403 JSON body; normal page requests get a flash and a redirect back.
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.headers.get('X-Live-Sync') == '1':
                    return jsonify(success=False, error='Please sign in again.'), 401
                flash('Please log in to access this page.', 'warning')
                return redirect(url_for('auth.login'))
            if not user_can(current_user, cap):
                message = DENIED_MESSAGE.format(label=capability_label(cap))
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.headers.get('X-Live-Sync') == '1' \
                        or request.accept_mimetypes.accept_json:
                    return jsonify(success=False, error=message, capability=cap), 403
                flash(message, 'danger')
                return redirect(request.referrer or url_for('main.dashboard'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator
