@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Run Setup InvoiceFlow.bat first.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" diagnose.py
set "RESULT=%ERRORLEVEL%"
echo Report: logs\diagnostic-report.html
pause
exit /b %RESULT%


