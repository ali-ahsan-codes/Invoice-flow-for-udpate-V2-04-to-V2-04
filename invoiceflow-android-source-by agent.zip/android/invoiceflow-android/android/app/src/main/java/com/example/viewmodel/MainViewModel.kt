package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ApiException
import com.example.data.Cap
import com.example.data.Me
import com.example.data.ApiService
import com.example.data.InvoiceHistory
import com.example.data.NoteAttachment
import com.example.data.PickedFile
import com.example.data.Connection
import com.example.data.ConnectionStore
import com.example.data.CropSettings
import com.example.data.Invoice
import com.example.data.QrParser
import com.example.data.ScannedQr
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

sealed class UploadStatus {
    object Idle : UploadStatus()
    object Uploading : UploadStatus()
    object Success : UploadStatus()
    data class Failed(val message: String) : UploadStatus()
}

/**
 * AUTO  — the original behaviour: scanning an invoice QR replaces whatever
 *         is currently loaded. Search + continuous scanning auto-advance.
 * FOCUS — locks onto the current invoice until the user advances or switches mode.
 */
enum class ScanMode { AUTO, FOCUS }

data class UiState(
    val connection: Connection? = null,
    val loading: Boolean = false,
    val error: String? = null,
    val currentInvoice: Invoice? = null,
    val nextInvoice: Invoice? = null,
    val uploadStatus: UploadStatus = UploadStatus.Idle,
    val searchResults: List<Invoice> = emptyList(),
    val scanMode: ScanMode = ScanMode.AUTO,
    val toastMessage: String? = null,
    val dateFormat: String = "YYYY-MM-DD",
    val cropSettings: CropSettings = CropSettings(),
    val pendingCropPhoto: File? = null,
    val showCropSettingsModal: Boolean = false,
    /** Notes, attachments and links of the current invoice. */
    val showHistory: Boolean = false,
    val history: InvoiceHistory? = null,
    val historyLoading: Boolean = false,
    val historyBusy: Boolean = false,
    val historyError: String? = null,
    /** Admin-set switches for this account (see Cap). Missing key = allowed. */
    val permissions: Map<String, Boolean> = emptyMap(),
) {
    fun allows(capability: String): Boolean = permissions[capability] ?: true
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ConnectionStore(app)
    private val api = ApiService()

    // Camera analysis can deliver the same code repeatedly, and network replies may
    // arrive out of order. Track the active target and ignore stale completions.
    private var invoiceLoadGeneration = 0L
    private var loadingSerial: String? = null
    private var loadingBatchId: Int? = null

    private val _state = MutableStateFlow(UiState(cropSettings = store.loadCropSettings()))
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        store.load()?.let { saved ->
            api.configure(saved)
            _state.value = _state.value.copy(
                connection = saved,
                cropSettings = store.loadCropSettings()
            )
            refreshPermissions()
        }
    }

    /** Re-reads the admin's switches. Quietly ignores network errors; actions still get server checks. */
    fun refreshPermissions() {
        val conn = _state.value.connection ?: return
        viewModelScope.launch {
            try {
                val me = api.ping(conn)
                _state.value = _state.value.copy(permissions = me.capabilities, dateFormat = me.dateFormat)
            } catch (_: Exception) {
                // Keep the last known switches; the server still enforces every action.
            }
        }
    }

    /** Refuses a connection when the admin has turned off mobile access for this account. */
    private fun requireMobileAccess(me: Me) {
        if (!me.allows(Cap.MOBILE_ACCESS)) throw IllegalStateException(Cap.deniedMessage(Cap.MOBILE_ACCESS))
    }

    // ----------------------------------------------------------------
    // Crop & Scanner Settings
    // ----------------------------------------------------------------

    fun openCropSettingsModal() {
        _state.value = _state.value.copy(showCropSettingsModal = true)
    }

    fun closeCropSettingsModal() {
        _state.value = _state.value.copy(showCropSettingsModal = false)
    }

    fun updateCropSettings(settings: CropSettings) {
        store.saveCropSettings(settings)
        _state.value = _state.value.copy(cropSettings = settings)
    }

    // ----------------------------------------------------------------
    // Pending Photo for Cropping
    // ----------------------------------------------------------------

    fun setPendingCropPhoto(file: File?) {
        _state.value = _state.value.copy(pendingCropPhoto = file)
    }

    fun cancelCrop() {
        _state.value.pendingCropPhoto?.let { f ->
            try { f.delete() } catch (_: Exception) {}
        }
        _state.value = _state.value.copy(pendingCropPhoto = null)
    }

    // ----------------------------------------------------------------
    // Connection — only accepts a Connection QR
    // ----------------------------------------------------------------

    fun connect(rawQr: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            try {
                val parsed = QrParser.parse(rawQr)
                val payload = when (parsed) {
                    is ScannedQr.Connection -> parsed.payload
                    is ScannedQr.Invoice -> throw IllegalArgumentException(
                        "This is an invoice QR. Please scan the connection QR from your Profile page."
                    )
                    ScannedQr.Unknown -> throw IllegalArgumentException(
                        "QR code not recognized. Scan the connection QR from your Profile page."
                    )
                }

                val tempConn = Connection(
                    baseUrl = payload.baseUrl,
                    apiKey = payload.apiKey,
                )
                val me = api.ping(tempConn)
                requireMobileAccess(me)
                val conn = tempConn.copy(
                    userId = me.id,
                    username = me.username,
                    role = me.role,
                )
                api.configure(conn)
                store.save(conn)
                _state.value = _state.value.copy(
                    connection = conn,
                    loading = false,
                    scanMode = ScanMode.AUTO,
                    dateFormat = me.dateFormat,
                    permissions = me.capabilities,
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    loading = false,
                    error = e.message ?: "Could not connect",
                )
            }
        }
    }

    fun connectDirect(baseUrl: String, apiKey: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            try {
                val tempConn = Connection(
                    baseUrl = baseUrl.trim(),
                    apiKey = apiKey.trim(),
                )
                val me = api.ping(tempConn)
                requireMobileAccess(me)
                val conn = tempConn.copy(
                    userId = me.id,
                    username = me.username,
                    role = me.role,
                )
                api.configure(conn)
                store.save(conn)
                _state.value = _state.value.copy(
                    connection = conn,
                    loading = false,
                    scanMode = ScanMode.AUTO,
                    dateFormat = me.dateFormat,
                    permissions = me.capabilities,
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    loading = false,
                    error = e.message ?: "Could not connect",
                )
            }
        }
    }

    fun disconnect() {
        invoiceLoadGeneration++
        loadingSerial = null
        loadingBatchId = null
        store.clear()
        api.clear()
        _state.value = UiState(cropSettings = store.loadCropSettings())
    }

    // ----------------------------------------------------------------
    // Scan mode
    // ----------------------------------------------------------------

    fun setScanMode(mode: ScanMode) {
        if (_state.value.scanMode == mode) return
        _state.value = _state.value.copy(
            scanMode = mode,
            toastMessage = when (mode) {
                ScanMode.FOCUS -> "Focus mode — locked to current invoice."
                ScanMode.AUTO  -> "Auto mode — captures advance to next invoice."
            },
        )
    }

    fun toggleScanMode() {
        val newMode =
            if (_state.value.scanMode == ScanMode.AUTO) ScanMode.FOCUS else ScanMode.AUTO
        setScanMode(newMode)
    }

    /**
     * Handle a scan from a server QR or a legacy barcode. V2 server QRs carry
     * batch_id because serials may be repeated in different batches. A focus QR
     * is authoritative: it must switch the UI into FOCUS even when its invoice
     * is already displayed.
     */
    fun handleQrScan(serial: String, scanHint: String = "auto", batchId: Int? = null) {
        val cleanSerial = serial.trim().trimStart('#').trim()
        if (cleanSerial.isEmpty()) return
        val safeBatchId = batchId?.takeIf { it > 0 }
        val s = _state.value

        if (scanHint.trim().equals("focus", ignoreCase = true)) {
            val changedMode = s.scanMode != ScanMode.FOCUS
            _state.value = s.copy(
                scanMode = ScanMode.FOCUS,
                toastMessage = if (changedMode) "Focus mode — locked to #$cleanSerial." else s.toastMessage,
            )
            if (!sameInvoiceTarget(s.currentInvoice, cleanSerial, safeBatchId) &&
                !sameLoadingTarget(cleanSerial, safeBatchId)
            ) {
                loadInvoice(cleanSerial, safeBatchId)
            }
            return
        }

        when (s.scanMode) {
            ScanMode.AUTO -> {
                if (!sameInvoiceTarget(s.currentInvoice, cleanSerial, safeBatchId) &&
                    !sameLoadingTarget(cleanSerial, safeBatchId)
                ) {
                    loadInvoice(cleanSerial, safeBatchId)
                }
            }
            ScanMode.FOCUS -> {
                when {
                    s.currentInvoice == null -> {
                        if (!sameLoadingTarget(cleanSerial, safeBatchId)) {
                            loadInvoice(cleanSerial, safeBatchId)
                        }
                    }
                    sameInvoiceTarget(s.currentInvoice, cleanSerial, safeBatchId) -> { /* stay focused */ }
                    else -> _state.value = s.copy(
                        toastMessage =
                            "Locked to #${s.currentInvoice.serialNumber}. " +
                            "Tap Next Invoice or scan a Focus QR to switch.",
                    )
                }
            }
        }
    }

    private fun sameInvoiceTarget(invoice: Invoice?, serial: String, batchId: Int?): Boolean {
        if (invoice == null || invoice.serialNumber.trim() != serial) return false
        return batchId == null || invoice.batchId == batchId
    }

    private fun sameLoadingTarget(serial: String, batchId: Int?): Boolean =
        _state.value.loading && loadingSerial == serial && loadingBatchId == batchId

    // ----------------------------------------------------------------
    // Load
    // ----------------------------------------------------------------

    fun loadInvoice(serial: String, batchId: Int? = null) {
        val cleanSerial = serial.trim().trimStart('#').trim()
        if (cleanSerial.isEmpty()) return
        val cleanBatchId = batchId?.takeIf { it > 0 }

        if (sameLoadingTarget(cleanSerial, cleanBatchId)) return
        val requestGeneration = ++invoiceLoadGeneration
        loadingSerial = cleanSerial
        loadingBatchId = cleanBatchId

        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            try {
                val invoice = api.getInvoice(cleanSerial, cleanBatchId)
                val resolvedBatchId = invoice.batchId ?: cleanBatchId
                val next = api.getNextInvoice(invoice.serialNumber, resolvedBatchId)
                if (requestGeneration != invoiceLoadGeneration) return@launch
                loadingSerial = null
                loadingBatchId = null
                _state.value = _state.value.copy(
                    loading = false,
                    currentInvoice = invoice,
                    nextInvoice = next,
                    uploadStatus = UploadStatus.Idle,
                )
            } catch (e: ApiException) {
                if (requestGeneration != invoiceLoadGeneration) return@launch
                loadingSerial = null
                loadingBatchId = null
                _state.value = _state.value.copy(
                    loading = false,
                    error = e.message,
                    currentInvoice = null,
                    nextInvoice = null,
                )
            } catch (e: Exception) {
                if (requestGeneration != invoiceLoadGeneration) return@launch
                loadingSerial = null
                loadingBatchId = null
                _state.value = _state.value.copy(
                    loading = false,
                    error = e.message ?: "Failed to load invoice",
                    currentInvoice = null,
                    nextInvoice = null,
                )
            }
        }
    }

    fun advanceToNextInvoice() {
        val next = _state.value.nextInvoice
        if (next != null) {
            loadInvoice(next.serialNumber, next.batchId)
        } else {
            _state.value = _state.value.copy(
                toastMessage = "No next invoice available.",
            )
        }
    }

    // ----------------------------------------------------------------
    // Search
    // ----------------------------------------------------------------

    fun search(query: String, date: String? = null) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            try {
                val results = api.listInvoices(query = query, date = date)
                _state.value = _state.value.copy(loading = false, searchResults = results)
                if (results.size == 1) {
                    loadInvoice(results.first().serialNumber, results.first().batchId)
                }
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    loading = false,
                    error = e.message ?: "Search failed",
                )
            }
        }
    }

    // ----------------------------------------------------------------
    // Media upload
    // ----------------------------------------------------------------

    fun uploadMedia(
        serial: String,
        batchId: Int?,
        file: File,
        autoAdvance: Boolean = true,
    ) {
        val cleanSerial = serial.trim().trimStart('#').trim()
        val cleanBatchId = batchId?.takeIf { it > 0 }
        if (!_state.value.allows(Cap.MEDIA_UPLOAD)) {
            _state.value = _state.value.copy(
                uploadStatus = UploadStatus.Failed(Cap.deniedMessage(Cap.MEDIA_UPLOAD)),
                pendingCropPhoto = null,
            )
            return
        }
        viewModelScope.launch {
            _state.value = _state.value.copy(
                uploadStatus = UploadStatus.Uploading,
                pendingCropPhoto = null,
            )
            try {
                val resp = api.uploadMedia(cleanSerial, cleanBatchId, file)
                val previousInvoice = _state.value.currentInvoice
                val updated = resp.invoice ?: previousInvoice?.copy(
                    mediaCount = resp.mediaCount,
                    hasMedia = true,
                )
                _state.value = _state.value.copy(
                    uploadStatus = UploadStatus.Success,
                    currentInvoice = updated,
                )

                val resolvedBatchId = updated?.batchId ?: cleanBatchId
                val next = api.getNextInvoice(cleanSerial, resolvedBatchId)
                _state.value = _state.value.copy(nextInvoice = next)

                val shouldAdvance = autoAdvance &&
                    _state.value.scanMode == ScanMode.AUTO &&
                    next != null

                if (shouldAdvance) {
                    delay(550)
                    loadInvoice(next!!.serialNumber, next.batchId ?: resolvedBatchId)
                }
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    uploadStatus = UploadStatus.Failed(e.message ?: "Upload failed"),
                )
            }
        }
    }

    // ----------------------------------------------------------------
    // Notes, attachments & links for the CURRENT (focused) invoice
    // ----------------------------------------------------------------

    fun openHistory() {
        _state.value = _state.value.copy(showHistory = true, historyError = null)
    }

    fun closeHistory() {
        _state.value = _state.value.copy(showHistory = false, historyError = null)
    }

    /** Loads history for the invoice currently on screen. Replies for an older invoice are dropped. */
    fun refreshHistory() {
        val inv = _state.value.currentInvoice ?: return
        viewModelScope.launch {
            _state.value = _state.value.copy(historyLoading = true, historyError = null)
            try {
                val history = api.getHistory(inv.serialNumber, inv.batchId)
                if (_state.value.currentInvoice?.id != inv.id) return@launch
                _state.value = _state.value.copy(history = history, historyLoading = false)
            } catch (e: Exception) {
                if (_state.value.currentInvoice?.id != inv.id) return@launch
                _state.value = _state.value.copy(
                    historyLoading = false,
                    historyError = e.message ?: "Could not load notes and links",
                )
            }
        }
    }

    private fun runHistoryAction(
        successMessage: String,
        onSuccess: () -> Unit = {},
        action: suspend (Invoice) -> InvoiceHistory,
    ) {
        val inv = _state.value.currentInvoice ?: return
        viewModelScope.launch {
            _state.value = _state.value.copy(historyBusy = true, historyError = null)
            try {
                val history = action(inv)
                if (_state.value.currentInvoice?.id == inv.id) {
                    _state.value = _state.value.copy(
                        history = history,
                        historyBusy = false,
                        toastMessage = successMessage,
                    )
                    onSuccess()
                } else {
                    _state.value = _state.value.copy(historyBusy = false)
                }
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    historyBusy = false,
                    historyError = e.message ?: "Action failed",
                )
            }
        }
    }

    fun addNote(body: String, files: List<PickedFile>, onSaved: () -> Unit = {}) {
        if (!_state.value.allows(Cap.NOTES_CREATE)) {
            _state.value = _state.value.copy(historyError = Cap.deniedMessage(Cap.NOTES_CREATE))
            return
        }
        if (body.isBlank() && files.isEmpty()) {
            _state.value = _state.value.copy(historyError = "Write a note or attach at least one file.")
            return
        }
        runHistoryAction("Note saved.", onSaved) { inv ->
            api.addNote(inv.serialNumber, inv.batchId, body.trim(), files)
        }
    }

    fun deleteNote(noteId: Int) {
        if (!_state.value.allows(Cap.NOTES_DELETE)) {
            _state.value = _state.value.copy(historyError = Cap.deniedMessage(Cap.NOTES_DELETE))
            return
        }
        runHistoryAction("Note deleted.") { inv -> api.deleteNote(inv.serialNumber, inv.batchId, noteId) }
    }

    fun addLink(
        linkedSerial: String,
        linkedBatchId: Int?,
        linkType: String,
        amountAction: String,
        excludeFromTotals: Boolean,
        linkNote: String,
        onSaved: () -> Unit = {},
    ) {
        if (!_state.value.allows(Cap.LINKS_CREATE)) {
            _state.value = _state.value.copy(historyError = Cap.deniedMessage(Cap.LINKS_CREATE))
            return
        }
        if (linkedSerial.isBlank()) {
            _state.value = _state.value.copy(historyError = "Enter the serial number of the other invoice.")
            return
        }
        runHistoryAction("Invoice linked.", onSaved) { inv ->
            api.addLink(
                serial = inv.serialNumber,
                batchId = inv.batchId,
                linkedSerial = linkedSerial,
                linkedBatchId = linkedBatchId,
                linkType = linkType,
                amountAction = amountAction,
                excludeFromTotals = excludeFromTotals,
                linkNote = linkNote,
            )
        }
    }

    fun deleteLink(linkId: Int) {
        if (!_state.value.allows(Cap.LINKS_DELETE)) {
            _state.value = _state.value.copy(historyError = Cap.deniedMessage(Cap.LINKS_DELETE))
            return
        }
        runHistoryAction("Link removed.") { inv -> api.deleteLink(inv.serialNumber, inv.batchId, linkId) }
    }

    /** Uploads any document type to the focused invoice (no camera crop). */
    fun uploadDocument(doc: PickedFile) {
        val inv = _state.value.currentInvoice ?: return
        if (!_state.value.allows(Cap.MEDIA_UPLOAD)) {
            _state.value = _state.value.copy(uploadStatus = UploadStatus.Failed(Cap.deniedMessage(Cap.MEDIA_UPLOAD)))
            return
        }
        viewModelScope.launch {
            _state.value = _state.value.copy(uploadStatus = UploadStatus.Uploading)
            try {
                val resp = api.uploadMedia(inv.serialNumber, inv.batchId, doc.file, doc.mimeType)
                if (_state.value.currentInvoice?.id != inv.id) return@launch
                _state.value = _state.value.copy(
                    uploadStatus = UploadStatus.Success,
                    currentInvoice = resp.invoice ?: inv.copy(mediaCount = resp.mediaCount, hasMedia = true),
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    uploadStatus = UploadStatus.Failed(e.message ?: "Upload failed"),
                )
            }
        }
    }

    /** Downloads an attachment into the app cache so it can be opened with another app. */
    fun downloadAttachment(attachment: NoteAttachment, onReady: (File) -> Unit) {
        val inv = _state.value.currentInvoice ?: return
        val dir = File(getApplication<Application>().cacheDir, "attachments")
        val safeName = attachment.fileName.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(120).ifBlank { "document" }
        viewModelScope.launch {
            _state.value = _state.value.copy(historyBusy = true, historyError = null)
            try {
                val file = api.downloadAttachment(
                    inv.serialNumber, inv.batchId, attachment.id, File(dir, "${attachment.id}_$safeName"),
                )
                _state.value = _state.value.copy(historyBusy = false)
                onReady(file)
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    historyBusy = false,
                    historyError = e.message ?: "Download failed",
                )
            }
        }
    }

    // ----------------------------------------------------------------
    // Small helpers
    // ----------------------------------------------------------------

    fun clearUploadStatus() {
        _state.value = _state.value.copy(uploadStatus = UploadStatus.Idle)
    }

    fun clearError() {
        _state.value = _state.value.copy(error = null)
    }

    fun clearHistoryError() {
        _state.value = _state.value.copy(historyError = null)
    }

    fun clearSearchResults() {
        _state.value = _state.value.copy(searchResults = emptyList())
    }

    fun clearToast() {
        _state.value = _state.value.copy(toastMessage = null)
    }
}


