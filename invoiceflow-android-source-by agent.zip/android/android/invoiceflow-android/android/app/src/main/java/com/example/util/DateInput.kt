package com.example.util

import java.util.GregorianCalendar

/**
 * Reads a date typed by the user in the server's configured format (for example "MM/DD/YYYY")
 * and converts it to the ISO form (yyyy-MM-dd) that the server's search endpoint expects.
 *
 * ISO input is always accepted, so older habits keep working. Uses only regex and GregorianCalendar
 * so it runs on minSdk 24 without java.time desugaring.
 */
object DateInput {

    /** Format used when the server has not reported one. */
    const val DEFAULT_FORMAT = "YYYY-MM-DD"

    private val isoRegex = Regex("""\d{4}-\d{2}-\d{2}""")
    private val tokenRegex = Regex("YYYY|MM|DD")

    /** Hint text for the search box, e.g. "MM/DD/YYYY". */
    fun example(format: String): String = format.ifBlank { DEFAULT_FORMAT }

    /**
     * Returns the ISO date (yyyy-MM-dd) for [text] typed in [format], or null when [text] is not a
     * valid date in that format (or in ISO form). Impossible dates such as 02/30/2026 return null.
     */
    fun toIso(text: String, format: String): String? {
        val input = text.trim()
        if (isoRegex.matches(input)) return validIso(input.substring(0, 4).toInt(), input.substring(5, 7).toInt(), input.substring(8, 10).toInt())

        val pattern = format.ifBlank { DEFAULT_FORMAT }
        val tokens = tokenRegex.findAll(pattern).map { it.value }.toList()
        if (tokens.isEmpty() || tokens.size != 3 || tokens.toSet() != setOf("YYYY", "MM", "DD")) return null

        val regexBody = StringBuilder()
        var last = 0
        for (m in tokenRegex.findAll(pattern)) {
            regexBody.append(Regex.escape(pattern.substring(last, m.range.first)))
            regexBody.append(if (m.value == "YYYY") """(\d{4})""" else """(\d{2})""")
            last = m.range.last + 1
        }
        regexBody.append(Regex.escape(pattern.substring(last)))

        val match = Regex(regexBody.toString()).matchEntire(input) ?: return null
        var year = 0
        var month = 0
        var day = 0
        tokens.forEachIndexed { i, token ->
            val value = match.groupValues[i + 1].toInt()
            when (token) {
                "YYYY" -> year = value
                "MM" -> month = value
                "DD" -> day = value
            }
        }
        return validIso(year, month, day)
    }

    private fun validIso(year: Int, month: Int, day: Int): String? {
        if (year < 1 || month !in 1..12 || day < 1) return null
        val cal = GregorianCalendar(year, month - 1, 1)
        if (day > cal.getActualMaximum(GregorianCalendar.DAY_OF_MONTH)) return null
        return "%04d-%02d-%02d".format(year, month, day)
    }
}
