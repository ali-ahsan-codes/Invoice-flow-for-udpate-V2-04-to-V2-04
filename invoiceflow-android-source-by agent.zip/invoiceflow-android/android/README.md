# InvoiceFlow Android app

Native Android client for the InvoiceFlow Flask server. The app scans a profile connection QR, scans invoice QR codes, looks up invoices through `/api/v1`, captures/crops invoice images, and uploads media.

## Requirements

- Android Studio with JDK 17 or newer
- Android SDK platform 36.1 (the project compiles against API 36, minor API 1)
- A server instance with the InvoiceFlow API enabled and an API key generated from the authenticated Profile screen

No Firebase, Gemini, or private signing keys are needed by this client. Debug signing uses Gradle's local default key; configure release signing outside this source tree.

## Open and run

1. Open the `android/` project directory in Android Studio.
2. Sync Gradle and install the Android SDK components it requests.
3. Run the `app` configuration on Android 7.0/API 24 or newer.
4. Grant camera permission, then scan the server's Profile connection QR. The manual URL/API-key form is also available.
5. For invoice-specific Focus QRs, use server QR mode **App** and scan behaviour **Focus**. The app uses the QR's `batch_id` for invoice lookups, next-invoice navigation, and media uploads. Legacy serial-only QRs remain supported when their serial is unambiguous.

## Tests

Run from Android Studio or a machine with the Android/Gradle toolchain:

```bash
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
./gradlew :app:connectedDebugAndroidTest
```

Unit tests cover connection/invoice QR parsing, v2 batch/focus QR payloads, web-fallback QR URLs, API URL batch scoping, crop selection, and persisted crop defaults. Device/emulator tests require an Android runtime; camera scanning still needs acceptance testing on a physical device with the target server.

## Server compatibility

The app authenticates with `X-API-Key`. Invoice-specific requests carry `?batch_id=...` when the scanned server QR supplies it. Responses' `batch_id` values are retained for subsequent `next` and media endpoints so repeated serials in separate batches do not cross-resolve.
