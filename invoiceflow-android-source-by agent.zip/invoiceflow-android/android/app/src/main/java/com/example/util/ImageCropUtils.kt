package com.example.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import androidx.compose.ui.geometry.Rect
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

data class CropSelection(
    val left: Float = 0f,
    val top: Float = 0f,
    val right: Float = 1f,
    val bottom: Float = 1f
) {
    val isFull: Boolean
        get() = left <= 0.005f && top <= 0.005f && right >= 0.995f && bottom >= 0.995f

    fun toRect(width: Float, height: Float): Rect {
        return Rect(
            left = left.coerceIn(0f, 1f) * width,
            top = top.coerceIn(0f, 1f) * height,
            right = right.coerceIn(0f, 1f) * width,
            bottom = bottom.coerceIn(0f, 1f) * height
        )
    }

    fun clamped(): CropSelection {
        val minSize = 0.05f
        val l = left.coerceIn(0f, 0.95f)
        val t = top.coerceIn(0f, 0.95f)
        val r = max(l + minSize, right.coerceIn(0.05f, 1f))
        val b = max(t + minSize, bottom.coerceIn(0.05f, 1f))
        return CropSelection(left = l, top = t, right = r, bottom = b)
    }

    val width: Float get() = max(0.01f, right - left)
    val height: Float get() = max(0.01f, bottom - top)
}

object ImageCropUtils {

    /**
     * Fixes EXIF orientation so the image on disk is physically upright,
     * matching exactly what was visible in the camera viewfinder.
     */
    fun fixImageOrientation(file: File): File {
        if (!file.exists()) return file
        try {
            val exif = ExifInterface(file.absolutePath)
            val orientation = exif.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
            val rotationDegrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }

            if (rotationDegrees != 0) {
                val original = BitmapFactory.decodeFile(file.absolutePath) ?: return file
                val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
                val rotated = Bitmap.createBitmap(original, 0, 0, original.width, original.height, matrix, true)
                FileOutputStream(file).use { out ->
                    rotated.compress(Bitmap.CompressFormat.JPEG, 92, out)
                }
                if (rotated != original) original.recycle()
                rotated.recycle()

                // Reset EXIF orientation to normal so viewers don't rotate again
                try {
                    val newExif = ExifInterface(file.absolutePath)
                    newExif.setAttribute(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL.toString())
                    newExif.saveAttributes()
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            // ignore
        }
        return file
    }

    /**
     * Crops and optionally rotates the source image file and saves to [destFile].
     * If [crop.isFull] and rotation is 0, copies [sourceFile] directly so no invoice
     * details are touched or recompressed.
     */
    fun cropAndSave(
        sourceFile: File,
        destFile: File,
        crop: CropSelection,
        rotationDegrees: Int = 0
    ): Boolean {
        if (!sourceFile.exists()) return false

        // Fast path: Full image, no rotation -> copy raw file directly
        if (crop.isFull && rotationDegrees % 360 == 0) {
            return try {
                destFile.parentFile?.mkdirs()
                sourceFile.copyTo(destFile, overwrite = true)
                true
            } catch (e: Exception) {
                false
            }
        }

        val original = BitmapFactory.decodeFile(sourceFile.absolutePath) ?: return false

        // 1. Rotate if user requested
        val rotated = if (rotationDegrees % 360 != 0) {
            val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
            val rot = Bitmap.createBitmap(original, 0, 0, original.width, original.height, matrix, true)
            if (rot != original) original.recycle()
            rot
        } else {
            original
        }

        val w = rotated.width
        val h = rotated.height

        // 2. Compute crop pixel coordinates
        val finalCropBitmap = if (crop.isFull) {
            rotated
        } else {
            val cl = (crop.left.coerceIn(0f, 1f) * w).roundToInt().coerceIn(0, w - 10)
            val ct = (crop.top.coerceIn(0f, 1f) * h).roundToInt().coerceIn(0, h - 10)
            val cr = (crop.right.coerceIn(0f, 1f) * w).roundToInt().coerceIn(cl + 10, w)
            val cb = (crop.bottom.coerceIn(0f, 1f) * h).roundToInt().coerceIn(ct + 10, h)

            val cropW = cr - cl
            val cropH = cb - ct

            val cropped = Bitmap.createBitmap(rotated, cl, ct, cropW, cropH)
            if (cropped != rotated) rotated.recycle()
            cropped
        }

        // 3. Save to destination
        return try {
            destFile.parentFile?.mkdirs()
            FileOutputStream(destFile).use { out ->
                finalCropBitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
            }
            finalCropBitmap.recycle()
            true
        } catch (e: Exception) {
            false
        }
    }
}


