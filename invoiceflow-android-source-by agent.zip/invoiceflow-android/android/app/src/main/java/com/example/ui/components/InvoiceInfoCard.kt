package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Invoice
import com.example.ui.theme.DangerBg
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FocusText
import com.example.ui.theme.SuccessBg
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningBg
import com.example.ui.theme.WarningText
import com.example.viewmodel.UploadStatus

@Composable
fun InvoiceInfoCard(
    invoice: Invoice,
    uploadStatus: UploadStatus,
    onDismissUpload: () -> Unit,
    modifier: Modifier = Modifier,
    focused: Boolean = false,
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = if (focused) BorderStroke(1.5.dp, FocusText) else null,
        modifier = modifier
            .fillMaxWidth()
            .testTag("invoice_info_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Serial + Status badge row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "#${invoice.serialNumber}",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.testTag("invoice_serial_text")
                )
                Spacer(modifier = Modifier.weight(1f))
                MediaBadge(invoice = invoice)
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Date + Book / Page
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = invoice.dateDisplay.ifBlank { invoice.date }.ifEmpty { "Date unavailable" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                if (invoice.book != null && invoice.page != null) {
                    Text(
                        text = "  ·  ",
                        color = TextMuted
                    )
                    Text(
                        text = "B${invoice.book} / P${invoice.page}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Amount row
            Row(
                verticalAlignment = Alignment.Bottom,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "OMR",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMuted,
                    modifier = Modifier.padding(bottom = 3.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "%.3f".format(invoice.totalAmount),
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp
                    ),
                    modifier = Modifier.testTag("invoice_amount_text")
                )
            }

            // Upload Status Row
            if (uploadStatus !is UploadStatus.Idle) {
                Spacer(modifier = Modifier.height(12.dp))
                UploadStatusRow(status = uploadStatus, onDismiss = onDismissUpload)
            }
        }
    }
}

@Composable
private fun MediaBadge(invoice: Invoice) {
    val bg: Color
    val fg: Color
    val label: String
    val icon: ImageVector

    when {
        invoice.hasMedia -> {
            bg = SuccessBg
            fg = SuccessGreen
            label = "${invoice.mediaCount} attached"
            icon = Icons.Default.CheckCircle
        }
        invoice.mediaRequired -> {
            bg = DangerBg
            fg = DangerRed
            label = "Media required"
            icon = Icons.Default.Warning
        }
        else -> {
            bg = WarningBg
            fg = WarningText
            label = "No media yet"
            icon = Icons.Default.PendingActions
        }
    }

    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .padding(horizontal = 10.dp, vertical = 5.dp)
            .testTag("media_badge"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = fg,
            modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = label,
            color = fg,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun UploadStatusRow(status: UploadStatus, onDismiss: () -> Unit) {
    when (status) {
        is UploadStatus.Uploading -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .testTag("uploading_row")
            ) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Uploading…",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
        is UploadStatus.Success -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SuccessBg)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .testTag("upload_success_row")
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = SuccessGreen,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Photo attached",
                    color = SuccessGreen,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.weight(1f))
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("dismiss_upload_button")
                ) {
                    Text("OK", color = SuccessGreen)
                }
            }
        }
        is UploadStatus.Failed -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DangerBg)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .testTag("upload_failed_row")
            ) {
                Icon(
                    imageVector = Icons.Default.Error,
                    contentDescription = null,
                    tint = DangerRed,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = status.message,
                    color = DangerRed,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.weight(1f),
                    maxLines = 2
                )
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("dismiss_upload_error_button")
                ) {
                    Text("Dismiss", color = DangerRed)
                }
            }
        }
        else -> {}
    }
}


