package com.example.ui

import android.content.Context
import android.widget.Toast
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.QrParser
import com.example.data.ScannedQr
import com.example.ui.components.CropSettingsModal
import com.example.ui.components.DocumentCropScreen
import com.example.ui.components.InvoiceInfoCard
import com.example.ui.components.QrScannerView
import com.example.ui.components.SearchResultsSheet
import com.example.ui.theme.*
import com.example.util.CropSelection
import com.example.util.ImageCropUtils
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.ScanMode
import com.example.viewmodel.UiState
import com.example.viewmodel.UploadStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScanScreen(
    vm: MainViewModel,
    modifier: Modifier = Modifier,
) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var isCapturing by remember { mutableStateOf(false) }

    LaunchedEffect(state.toastMessage) {
        state.toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            vm.clearToast()
        }
    }

    // Notes, documents and links for the focused invoice (full-screen, like the crop review).
    if (state.showHistory && state.currentInvoice != null) {
        InvoiceHistoryScreen(
            vm = vm,
            onBack = { vm.closeHistory() },
            modifier = Modifier.fillMaxSize(),
        )
        return
    }

    // If an image was captured and is awaiting review / manual crop:
    if (state.pendingCropPhoto != null && state.currentInvoice != null) {
        DocumentCropScreen(
            imageFile = state.pendingCropPhoto!!,
            cropSettings = state.cropSettings,
            onConfirmCrop = { croppedFile ->
                val inv = state.currentInvoice
                if (inv != null) {
                    vm.uploadMedia(inv.serialNumber, inv.batchId, croppedFile, autoAdvance = true)
                }
            },
            onCancel = {
                vm.cancelCrop()
            },
            onOpenSettings = {
                vm.openCropSettingsModal()
            },
            modifier = Modifier.fillMaxSize()
        )

        // Show Crop Settings Modal on top if opened from review screen
        if (state.showCropSettingsModal) {
            CropSettingsModal(
                settings = state.cropSettings,
                onSettingsChanged = { vm.updateCropSettings(it) },
                onDismiss = { vm.closeCropSettingsModal() }
            )
        }
        return
    }

    Scaffold(
        modifier = modifier.background(Brush.radialGradient(listOf(Color(0xFFEAE3FF), SurfaceBg))),
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Scan Invoices", fontWeight = FontWeight.Bold)
                        state.connection?.let { c ->
                            Text(
                                "@${c.username}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted,
                            )
                        }
                    }
                },
                actions = {
                    // Auto / Focus Mode Switcher
                    ModeChip(mode = state.scanMode, onClick = { vm.toggleScanMode() })

                    // Settings Button
                    IconButton(
                        onClick = { vm.openCropSettingsModal() },
                        modifier = Modifier.testTag("settings_button")
                    ) {
                        Icon(Icons.Default.Tune, contentDescription = "Settings", tint = BluePrimary)
                    }

                    // Logout / Disconnect Button
                    IconButton(
                        onClick = { vm.disconnect() },
                        modifier = Modifier.testTag("disconnect_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Disconnect")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = Navy,
                ),
            )
        },
        bottomBar = {
            CaptureBar(
                state = state,
                isCapturing = isCapturing,
                onCapture = {
                    val capture = imageCapture
                    val inv = state.currentInvoice
                    if (capture == null || inv == null) return@CaptureBar

                    isCapturing = true
                    val f = createImageFile(context)
                    val opts = ImageCapture.OutputFileOptions.Builder(f).build()

                    capture.takePicture(
                        opts,
                        ContextCompat.getMainExecutor(context),
                        object : ImageCapture.OnImageSavedCallback {
                            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                                coroutineScope.launch(Dispatchers.IO) {
                                    // Ensure image is physically upright matching the camera screen exactly
                                    ImageCropUtils.fixImageOrientation(f)
                                    withContext(Dispatchers.Main) {
                                        isCapturing = false
                                        vm.setPendingCropPhoto(f)
                                    }
                                }
                            }

                            override fun onError(exc: ImageCaptureException) {
                                isCapturing = false
                                Toast.makeText(
                                    context,
                                    "Capture failed: ${exc.message}",
                                    Toast.LENGTH_SHORT,
                                ).show()
                            }
                        },
                    )
                },
                onNext = { vm.advanceToNextInvoice() },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
        ) {
            if (state.scanMode == ScanMode.FOCUS) {
                FocusModeBanner(onExit = { vm.setScanMode(ScanMode.AUTO) })
                Spacer(Modifier.height(10.dp))
            }

            var query by remember { mutableStateOf("") }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("invoice_search_input"),
                placeholder = { Text("Serial number or date (YYYY-MM-DD)") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (query.isNotEmpty()) {
                            IconButton(
                                onClick = {
                                    val isDate = Regex("""\d{4}-\d{2}-\d{2}""").matches(query.trim())
                                    if (isDate) vm.search("", query.trim()) else vm.search(query.trim())
                                },
                                modifier = Modifier.testTag("execute_search_button")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Search")
                            }
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Default.Clear, null)
                            }
                        }
                    }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(
                    onSearch = {
                        val isDate = Regex("""\d{4}-\d{2}-\d{2}""").matches(query.trim())
                        if (isDate) vm.search("", query.trim()) else vm.search(query.trim())
                    },
                ),
            )

            Spacer(Modifier.height(12.dp))

            val current = state.currentInvoice
            when {
                current != null -> {
                    InvoiceInfoCard(
                        invoice = current,
                        uploadStatus = state.uploadStatus,
                        onDismissUpload = { vm.clearUploadStatus() },
                        focused = state.scanMode == ScanMode.FOCUS,
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { vm.openHistory() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("notes_links_button"),
                        shape = RoundedCornerShape(12.dp),
                    ) {
                        Icon(Icons.Default.Link, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        val count = state.history?.takeIf { it.invoice?.id == current.id }
                            ?.let { it.notes.size + it.relations.size }
                        Text(if (count != null && count > 0) "Notes & links ($count)" else "Notes & links")
                    }
                    Spacer(Modifier.height(12.dp))
                }
                state.loading -> {
                    Card {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            CircularProgressIndicator(
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(20.dp),
                            )
                            Spacer(Modifier.width(12.dp))
                            Text("Loading invoice…")
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                else -> {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        ),
                    ) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Icon(
                                Icons.Default.QrCodeScanner, null,
                                modifier = Modifier.size(28.dp), tint = TextMuted,
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                if (state.scanMode == ScanMode.FOCUS)
                                    "Scan an invoice QR to lock onto it"
                                else
                                    "Scan or search to load an invoice",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextMuted,
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }

            // Camera preview
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black),
            ) {
                QrScannerView(
                    modifier = Modifier.fillMaxSize(),
                    onQrDetected = { raw ->
                        when (val parsed = QrParser.parse(raw)) {
                            is ScannedQr.Invoice -> vm.handleQrScan(
                                serial = parsed.payload.serial,
                                scanHint = parsed.payload.scan,
                                batchId = parsed.payload.batchId,
                            )
                            is ScannedQr.Connection -> { /* wrong screen */ }
                            ScannedQr.Unknown -> { /* ignore */ }
                        }
                    },
                    onImageCaptureReady = { imageCapture = it },
                )

                Surface(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(12.dp),
                    color = Color.Black.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(20.dp),
                ) {
                    Text(
                        if (state.scanMode == ScanMode.FOCUS)
                            "Locked — capture & crop multiple photos of this invoice"
                        else
                            "Point at invoice, tap Capture to crop & attach",
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }

                if (isCapturing) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.White.copy(alpha = 0.35f)),
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
        }
    }

    if (state.searchResults.size > 1) {
        SearchResultsSheet(
            results = state.searchResults,
            onPick = { inv ->
                vm.loadInvoice(inv.serialNumber, inv.batchId)
                vm.clearSearchResults()
            },
            onDismiss = { vm.clearSearchResults() },
        )
    }

    // Modal Sheet for Crop Settings
    if (state.showCropSettingsModal) {
        CropSettingsModal(
            settings = state.cropSettings,
            onSettingsChanged = { vm.updateCropSettings(it) },
            onDismiss = { vm.closeCropSettingsModal() }
        )
    }
}

@Composable
private fun CaptureBar(
    state: UiState,
    isCapturing: Boolean,
    onCapture: () -> Unit,
    onNext: () -> Unit,
) {
    Surface(
        shadowElevation = 8.dp,
        color = SurfaceCard,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .navigationBarsPadding(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val enabled = state.currentInvoice != null &&
                    !isCapturing &&
                    state.uploadStatus !is UploadStatus.Uploading

            Button(
                onClick = onCapture,
                modifier = Modifier
                    .weight(1.4f)
                    .height(52.dp)
                    .testTag("capture_photo_button"),
                enabled = enabled,
                colors = ButtonDefaults.buttonColors(
                    containerColor = BluePrimary,
                    contentColor = Color.White,
                ),
                shape = RoundedCornerShape(12.dp),
            ) {
                if (isCapturing) {
                    CircularProgressIndicator(
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(18.dp),
                        color = Color.White,
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Capturing…", fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.PhotoCamera, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Capture Photo", fontWeight = FontWeight.Bold)
                }
            }

            if (state.scanMode == ScanMode.FOCUS) {
                OutlinedButton(
                    onClick = onNext,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("next_invoice_button"),
                    enabled = enabled && state.nextInvoice != null,
                    shape = RoundedCornerShape(12.dp),
                ) {
                    Icon(Icons.Default.SkipNext, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Next", fontWeight = FontWeight.Bold)
                }
            } else {
                Surface(
                    color = SurfaceSubtle,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                    ) {
                        Icon(
                            Icons.Default.Autorenew,
                            contentDescription = null,
                            tint = SuccessGreen,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "Auto Next",
                            color = SuccessGreen,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeChip(mode: ScanMode, onClick: () -> Unit) {
    val isFocus = mode == ScanMode.FOCUS
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = if (isFocus) FocusBg else SurfaceSubtle,
        modifier = Modifier
            .padding(end = 4.dp)
            .testTag("mode_toggle_chip"),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
        ) {
            Icon(
                imageVector = if (isFocus) Icons.Default.Lock else Icons.Default.Autorenew,
                contentDescription = null,
                tint = if (isFocus) FocusText else TextSecondary,
                modifier = Modifier.size(14.dp),
            )
            Spacer(Modifier.width(4.dp))
            Text(
                text = if (isFocus) "FOCUS" else "AUTO",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = if (isFocus) FocusText else TextSecondary,
            )
        }
    }
}

@Composable
private fun FocusModeBanner(onExit: () -> Unit) {
    Surface(
        color = FocusBg,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            Icon(Icons.Default.Lock, null, tint = FocusText, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "Focus Mode",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = FocusText,
                )
                Text(
                    "Locked on one invoice. Capture as many photos as needed, then tap Next.",
                    style = MaterialTheme.typography.bodySmall,
                    color = FocusText,
                )
            }
            TextButton(
                onClick = onExit,
                modifier = Modifier.testTag("exit_focus_mode_button")
            ) {
                Text("Exit", color = FocusText, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun createImageFile(context: Context): File {
    val dir = File(context.cacheDir, "camera").apply { mkdirs() }
    return File(dir, "scan_${System.currentTimeMillis()}.jpg")
}


