package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = BluePrimary,
    onPrimary = Color.White,
    primaryContainer = SurfaceContainer,
    onPrimaryContainer = BlueDark,
    secondary = Teal,
    onSecondary = Color.White,
    background = SurfaceBg,
    onBackground = TextPrimary,
    surface = SurfaceCard,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceSubtle,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    error = DangerRed,
    onError = Color.White,
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB69CFF),
    onPrimary = Color(0xFF24164E),
    primaryContainer = Color(0xFF43306E),
    onPrimaryContainer = Color(0xFFE5D9FF),
    secondary = Color(0xFF94D6C6),
    background = Color(0xFF171426),
    onBackground = Color(0xFFF3EFFA),
    surface = Color(0xFF211B34),
    onSurface = Color(0xFFF3EFFA),
    surfaceVariant = Color(0xFF302842),
    onSurfaceVariant = Color(0xFFD0C8DE),
    outline = Color(0xFF574C6A),
    error = Color(0xFFFFA9BF),
    onError = Color(0xFF3B1020),
)

/** Server-inspired light theme is the default; dark mode is available to callers explicitly. */
@Composable
fun InvoiceFlowTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography,
        content = content,
    )
}

// Backward-compatible wrapper retained for existing UI tests/callers.
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit,
) {
    InvoiceFlowTheme(darkTheme = darkTheme, content = content)
}
