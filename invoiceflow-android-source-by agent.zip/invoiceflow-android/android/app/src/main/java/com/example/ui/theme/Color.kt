package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// InvoiceFlow server design tokens (luxe.css), mirrored for the native app.
val Navy = Color(0xFF302445)
val Teal = Color(0xFF5BA59B)
val BluePrimary = Color(0xFF7048DF) // Kept for source compatibility; now the server violet.
val BlueDark = Color(0xFF5130B0)
val SurfaceBg = Color(0xFFF6F5FA)
val SurfaceCard = Color(0xF2FFFFFF)
val SurfaceSubtle = Color(0xFFF2F0FA)
val SurfaceContainer = Color(0xFFEDE8FF)
val BorderSubtle = Color(0xFFE7E4F0)
val TextPrimary = Color(0xFF25213D)
val TextSecondary = Color(0xFF625B79)
val TextMuted = Color(0xFF79718D)
val SuccessGreen = Color(0xFF368E74)
val SuccessBg = Color(0xFFE9F7F2)
val DangerRed = Color(0xFFB65474)
val DangerBg = Color(0xFFFBEAF0)
val WarningBg = Color(0xFFFCF2E6)
val WarningText = Color(0xFF9A6D3D)
val FocusBg = Color(0xFFF1EBFD)
val FocusText = Color(0xFF6241B4)
