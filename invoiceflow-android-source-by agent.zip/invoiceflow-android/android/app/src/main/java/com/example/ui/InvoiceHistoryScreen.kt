package com.example.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.InvoiceHistory
import com.example.data.InvoiceNote
import com.example.data.InvoiceRelation
import com.example.data.NoteAttachment
import com.example.data.PickedFile
import com.example.ui.theme.*
import com.example.util.copyPickedDocument
import com.example.util.openDocumentWith
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.UploadStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val MAX_NOTE_CHARS = 2000

/**
 * Notes, documents and links for the FOCUSED invoice.
 *
 * Works for any document type: notes can carry any number of files, and "Attach document" uploads
 * a file straight to this invoice. Everything goes to the invoice on screen, so after a Focus QR
 * scan, uploads and notes land on that invoice only.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvoiceHistoryScreen(
    vm: MainViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val invoice = state.currentInvoice

    // Reload whenever the focused invoice changes (new Focus QR, Next, search pick).
    LaunchedEffect(invoice?.id) { vm.refreshHistory() }

    var noteText by remember { mutableStateOf("") }
    var pendingFiles by remember { mutableStateOf<List<PickedFile>>(emptyList()) }
    var preparingFiles by remember { mutableStateOf(false) }
    var pendingDeleteNote by remember { mutableStateOf<InvoiceNote?>(null) }

    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        preparingFiles = true
        scope.launch {
            val picked = withContext(Dispatchers.IO) { uris.mapNotNull { copyPickedDocument(context, it) } }
            pendingFiles = pendingFiles + picked
            preparingFiles = false
            if (picked.size < uris.size) {
                Toast.makeText(context, "Some files could not be read.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val pickDocument = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val doc = withContext(Dispatchers.IO) { copyPickedDocument(context, uri) }
            if (doc == null) {
                Toast.makeText(context, "That file could not be read.", Toast.LENGTH_SHORT).show()
            } else {
                vm.uploadDocument(doc)
            }
        }
    }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Notes & links", fontWeight = FontWeight.Bold)
                        invoice?.let {
                            Text(
                                "#${it.serialNumber}" + (it.batchId?.let { id -> " · batch $id" } ?: ""),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted,
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("history_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        if (invoice == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Scan an invoice QR first.", color = TextMuted)
            }
            return@Scaffold
        }

        val history: InvoiceHistory? = state.history?.takeIf { it.invoice?.id == invoice.id }
        val busy = state.historyBusy || preparingFiles

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
        ) {
            state.historyError?.let { message ->
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = DangerBg)) {
                        Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                message,
                                color = DangerRed,
                                modifier = Modifier.weight(1f).testTag("history_error"),
                            )
                            TextButton(onClick = { vm.clearHistoryError() }) { Text("Dismiss") }
                        }
                    }
                }
            }

            if (state.historyLoading && history == null) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("Loading…", color = TextMuted)
                    }
                }
            }

            // ------------------------------------------------ Documents & note composer
            item {
                SectionCard(title = "Add a note or document") {
                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { if (it.length <= MAX_NOTE_CHARS) noteText = it },
                        modifier = Modifier.fillMaxWidth().testTag("note_input"),
                        placeholder = { Text("Write a note (optional if you attach files)") },
                        minLines = 2,
                        supportingText = { Text("${noteText.length}/$MAX_NOTE_CHARS") },
                    )
                    Spacer(Modifier.height(8.dp))

                    if (pendingFiles.isNotEmpty()) {
                        Text("Attached to this note:", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                        pendingFiles.forEachIndexed { index, file ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Icon(Icons.Default.AttachFile, null, modifier = Modifier.size(16.dp), tint = TextMuted)
                                Spacer(Modifier.width(6.dp))
                                Text(file.displayName, modifier = Modifier.weight(1f), maxLines = 1)
                                TextButton(onClick = {
                                    pendingFiles = pendingFiles.toMutableList().also { it.removeAt(index) }
                                }) { Text("Remove") }
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { pickFiles.launch(arrayOf("*/*")) },
                            enabled = !busy,
                            modifier = Modifier.weight(1f).testTag("attach_files_button"),
                        ) {
                            Icon(Icons.Default.AttachFile, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Attach files")
                        }
                        Button(
                            onClick = {
                                vm.addNote(noteText, pendingFiles) {
                                    noteText = ""
                                    pendingFiles = emptyList()
                                }
                            },
                            enabled = !busy && (noteText.isNotBlank() || pendingFiles.isNotEmpty()),
                            modifier = Modifier.weight(1f).testTag("save_note_button"),
                        ) {
                            Text("Save note")
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { pickDocument.launch(arrayOf("*/*")) },
                        enabled = !busy && state.uploadStatus !is UploadStatus.Uploading,
                        modifier = Modifier.fillMaxWidth().testTag("attach_document_button"),
                    ) {
                        Icon(Icons.Default.UploadFile, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            if (state.uploadStatus is UploadStatus.Uploading) "Uploading…"
                            else "Upload document to this invoice",
                        )
                    }
                    if (state.uploadStatus is UploadStatus.Failed) {
                        Text(
                            (state.uploadStatus as UploadStatus.Failed).message,
                            color = DangerRed,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }

            // ------------------------------------------------ Notes list
            item {
                Text(
                    "Notes & attachments",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                )
            }
            val notes = history?.notes.orEmpty()
            if (history != null && notes.isEmpty()) {
                item { Text("No notes yet.", color = TextMuted) }
            }
            items(notes, key = { "note-${it.id}" }) { note ->
                NoteCard(
                    note = note,
                    enabled = !busy,
                    onDelete = { pendingDeleteNote = note },
                    onOpen = { attachment ->
                        vm.downloadAttachment(attachment) { file ->
                            openDocumentWith(context, file, attachment.mimeType)
                        }
                    },
                )
            }

            // ------------------------------------------------ Links
            item {
                Text(
                    "Linked invoices",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
            val relations = history?.relations.orEmpty()
            if (history != null && relations.isEmpty()) {
                item { Text("No linked invoices.", color = TextMuted) }
            }
            items(relations, key = { "rel-${it.id}" }) { relation ->
                RelationCard(
                    relation = relation,
                    enabled = !busy,
                    onUnlink = { vm.deleteLink(relation.id) },
                )
            }
            history?.takeIf { it.hiddenLinkCount > 0 }?.let { h ->
                item {
                    Text(
                        "${h.hiddenLinkCount} linked invoice(s) not visible to you.",
                        color = TextMuted,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }

            item {
                LinkForm(
                    enabled = !busy,
                    currentBatchId = invoice.batchId,
                    onSubmit = { serial, batchId, type, action, exclude, note, reset ->
                        vm.addLink(serial, batchId, type, action, exclude, note, onSaved = reset)
                    },
                )
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    pendingDeleteNote?.let { note ->
        AlertDialog(
            onDismissRequest = { pendingDeleteNote = null },
            title = { Text("Delete this note?") },
            text = {
                Text(
                    "The note" +
                        (if (note.attachments.isNotEmpty()) " and its ${note.attachments.size} attachment(s)" else "") +
                        " will be removed.",
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        vm.deleteNote(note.id)
                        pendingDeleteNote = null
                    },
                    modifier = Modifier.testTag("confirm_delete_note"),
                ) { Text("Delete", color = DangerRed) }
            },
            dismissButton = { TextButton(onClick = { pendingDeleteNote = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun NoteCard(
    note: InvoiceNote,
    enabled: Boolean,
    onDelete: () -> Unit,
    onOpen: (NoteAttachment) -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        (note.author ?: "Unknown") +
                            (note.invoiceSerial?.takeIf { !note.isOwn }?.let { " · on #$it" } ?: ""),
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    note.createdAt?.let {
                        Text(it.replace('T', ' ').take(16), style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    }
                }
                if (note.canDelete) {
                    IconButton(
                        onClick = onDelete,
                        enabled = enabled,
                        modifier = Modifier.testTag("delete_note_${note.id}"),
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete note", tint = DangerRed)
                    }
                }
            }
            if (note.body.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(note.body, style = MaterialTheme.typography.bodyMedium)
            }
            note.attachments.forEach { att ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.AttachFile, null, modifier = Modifier.size(16.dp), tint = TextMuted)
                    Spacer(Modifier.width(6.dp))
                    Column(Modifier.weight(1f)) {
                        Text(att.fileName, maxLines = 1, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            formatBytes(att.fileSize),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted,
                        )
                    }
                    TextButton(onClick = { onOpen(att) }, enabled = enabled) { Text("Open") }
                }
            }
        }
    }
}

@Composable
private fun RelationCard(
    relation: InvoiceRelation,
    enabled: Boolean,
    onUnlink: () -> Unit,
) {
    val other = relation.other
    val batchLabel = other?.batch.orEmpty().takeIf { it.isNotBlank() }?.let { " · $it" } ?: ""
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "${relation.relation} #${other?.serialNumber ?: "?"}" + batchLabel,
                        fontWeight = FontWeight.SemiBold,
                    )
                    other?.let {
                        Text(
                            "${it.date} · ${"%.3f".format(it.totalAmount)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted,
                        )
                    }
                }
                if (relation.canUnlink) {
                    IconButton(
                        onClick = onUnlink,
                        enabled = enabled,
                        modifier = Modifier.testTag("unlink_${relation.id}"),
                    ) {
                        Icon(Icons.Default.LinkOff, contentDescription = "Remove link", tint = DangerRed)
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            if (relation.merged) {
                val amount = relation.mergedAmount?.let { "%.3f".format(it) } ?: ""
                val side = if (relation.receiverSide) "Merged +$amount into this invoice" else "Amount merged into the other invoice"
                StatusChip(side, SuccessGreen)
                Spacer(Modifier.height(4.dp))
                if (relation.excludeFromTotals) {
                    StatusChip("Excluded from totals (counted once)", FocusText)
                } else {
                    StatusChip("Counted in totals (both invoices)", TextSecondary)
                }
            } else if (relation.linkType == "duplicate" || relation.linkType == "adjustment") {
                StatusChip("Link only · no amount change", TextSecondary)
            }
            if (relation.note.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(relation.note, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun StatusChip(text: String, color: androidx.compose.ui.graphics.Color) {
    Text(
        text,
        color = color,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.SemiBold,
    )
}

/**
 * Link another invoice. Merge is only offered for Duplicate / Adjusted relations (server rule).
 * The include/exclude choice is shown only when merging and defaults to exclude; the user decides.
 */
@Composable
private fun LinkForm(
    enabled: Boolean,
    currentBatchId: Int?,
    onSubmit: (serial: String, batchId: Int?, type: String, action: String, exclude: Boolean, note: String, reset: () -> Unit) -> Unit,
) {
    var serial by remember { mutableStateOf("") }
    var batchText by remember { mutableStateOf("") }
    var linkType by remember { mutableStateOf("related") }
    var amountAction by remember { mutableStateOf("none") }
    var excludeFromTotals by remember { mutableStateOf(true) }
    var linkNote by remember { mutableStateOf("") }

    SectionCard(title = "Link another invoice") {
        OutlinedTextField(
            value = serial,
            onValueChange = { serial = it.filter { c -> c.isDigit() || c.isLetter() }.take(20) },
            modifier = Modifier.fillMaxWidth().testTag("link_serial_input"),
            placeholder = { Text("Serial of the other invoice, e.g. 0042") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = batchText,
            onValueChange = { batchText = it.filter { c -> c.isDigit() }.take(6) },
            modifier = Modifier.fillMaxWidth(),
            placeholder = {
                Text(
                    "Batch ID of the other invoice" +
                        (currentBatchId?.let { " (blank = batch $it)" } ?: " (blank = this batch)"),
                )
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        )

        Spacer(Modifier.height(10.dp))
        Text("Relation", style = MaterialTheme.typography.labelMedium, color = TextMuted)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("related" to "Related", "duplicate" to "Duplicate", "adjustment" to "Adjusted").forEach { (value, label) ->
                FilterChip(
                    selected = linkType == value,
                    onClick = {
                        linkType = value
                        if (value == "related") amountAction = "none"
                    },
                    label = { Text(label) },
                    enabled = enabled,
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        Text("Amount", style = MaterialTheme.typography.labelMedium, color = TextMuted)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(
                selected = amountAction == "none",
                onClick = { amountAction = "none" },
                label = { Text("Link only") },
                enabled = enabled,
            )
            FilterChip(
                selected = amountAction == "merge",
                onClick = { amountAction = "merge" },
                label = { Text("Merge total") },
                enabled = enabled && linkType != "related",
            )
        }

        if (amountAction == "merge") {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("Exclude the other invoice from totals", fontWeight = FontWeight.SemiBold)
                    Text(
                        if (excludeFromTotals)
                            "On: its amount is counted only on this invoice (no double count)."
                        else
                            "Off: both invoices stay in totals, so the amount is counted twice.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted,
                    )
                }
                Switch(
                    checked = excludeFromTotals,
                    onCheckedChange = { excludeFromTotals = it },
                    enabled = enabled,
                    modifier = Modifier.testTag("exclude_totals_switch"),
                )
            }
        }

        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = linkNote,
            onValueChange = { if (it.length <= 2000) linkNote = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Reason (optional)") },
        )
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                onSubmit(
                    serial.trim(),
                    batchText.toIntOrNull(),
                    linkType,
                    amountAction,
                    excludeFromTotals,
                    linkNote.trim(),
                ) {
                    serial = ""
                    batchText = ""
                    linkNote = ""
                }
            },
            enabled = enabled && serial.isNotBlank(),
            modifier = Modifier.fillMaxWidth().testTag("link_invoice_button"),
        ) {
            Icon(Icons.Default.Link, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Link invoice")
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = listOf("B", "KB", "MB", "GB")
    var size = bytes.toDouble()
    var i = 0
    while (size >= 1024 && i < units.lastIndex) {
        size /= 1024
        i++
    }
    return "%.1f %s".format(size, units[i])
}
