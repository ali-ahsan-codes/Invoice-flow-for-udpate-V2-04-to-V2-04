package com.example.data

import android.content.Context
import org.json.JSONObject

class ConnectionStore(context: Context) {
    private val prefs = context.getSharedPreferences("invoiceflow_prefs", Context.MODE_PRIVATE)

    fun save(c: Connection) {
        val json = JSONObject().apply {
            put("baseUrl", c.baseUrl)
            put("apiKey", c.apiKey)
            put("userId", c.userId)
            put("username", c.username)
            put("role", c.role)
        }
        prefs.edit().putString("connection_data", json.toString()).apply()
    }

    fun load(): Connection? {
        val raw = prefs.getString("connection_data", null) ?: return null
        return try {
            val json = JSONObject(raw)
            Connection(
                baseUrl = json.optString("baseUrl", ""),
                apiKey = json.optString("apiKey", ""),
                userId = json.optInt("userId", 0),
                username = json.optString("username", ""),
                role = json.optString("role", "")
            )
        } catch (e: Exception) {
            null
        }
    }

    fun clear() {
        prefs.edit().remove("connection_data").apply()
    }

    // ----------------------------------------------------------------
    // Crop settings persistence
    // ----------------------------------------------------------------

    fun saveCropSettings(settings: CropSettings) {
        prefs.edit()
            .putBoolean("crop_manual_enabled", settings.manualCropEnabled)
            .putBoolean("crop_auto_open_handles", settings.autoOpenHandles)
            .putBoolean("crop_show_grid", settings.showGrid)
            .apply()
    }

    fun loadCropSettings(): CropSettings {
        return CropSettings(
            manualCropEnabled = prefs.getBoolean("crop_manual_enabled", true),
            autoOpenHandles = prefs.getBoolean("crop_auto_open_handles", false),
            showGrid = prefs.getBoolean("crop_show_grid", true),
        )
    }
}


