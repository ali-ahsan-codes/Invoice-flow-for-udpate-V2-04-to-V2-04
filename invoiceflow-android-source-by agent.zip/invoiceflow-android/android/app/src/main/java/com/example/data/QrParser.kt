package com.example.data

import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.Locale

/**
 * Result of parsing a scanned QR string.
 *
 * The two QR types are mutually exclusive. The Connect screen accepts only
 * [ScannedQr.Connection], the Scan screen accepts only [ScannedQr.Invoice].
 * Anything else falls into [ScannedQr.Unknown].
 */
sealed class ScannedQr {
    data class Connection(val payload: ConnectionQrPayload) : ScannedQr()
    data class Invoice(val payload: InvoiceQrPayload) : ScannedQr()
    object Unknown : ScannedQr()
}

/** Central parser for every QR format emitted by the InvoiceFlow server. */
object QrParser {

    fun parse(raw: String): ScannedQr {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return ScannedQr.Unknown

        if (trimmed.startsWith("{")) return parseJson(trimmed)

        // Older deployments sometimes used a URI-style connection QR.
        if (trimmed.contains("api_key=") && (trimmed.contains("base_url=") || trimmed.contains("baseUrl="))) {
            val uri = parseUri(trimmed)
            val params = uri?.rawQuery?.let(::parseQuery).orEmpty()
            val baseUrl = params["base_url"] ?: params["baseUrl"]
            val apiKey = params["api_key"] ?: params["apiKey"]
            if (!baseUrl.isNullOrBlank() && !apiKey.isNullOrBlank()) {
                return ScannedQr.Connection(
                    ConnectionQrPayload(
                        app = "invoiceflow",
                        type = "connect",
                        version = 1,
                        baseUrl = baseUrl,
                        apiKey = apiKey,
                    )
                )
            }
        }

        // Web/fallback QR URLs have the invoice serial in the final path segment
        // and now also carry batch_id in the query string.
        val uri = parseUri(trimmed)
        if (uri != null && (uri.scheme.equals("http", true) || uri.scheme.equals("https", true))) {
            val params = uri.rawQuery?.let(::parseQuery).orEmpty()
            val pathSerial = uri.rawPath
                ?.trimEnd('/')
                ?.substringAfterLast('/')
                ?.takeIf { it.isNotBlank() }
                ?.let(::decodeComponent)
            val serial = (pathSerial ?: params["serial"] ?: params["serial_number"])
                ?.trim()
                ?.trimStart('#')
                ?.trim()
            if (!serial.isNullOrBlank() && serial.length <= 20) {
                return ScannedQr.Invoice(
                    InvoiceQrPayload(
                        serial = serial,
                        batchId = parsePositiveInt(params["batch_id"] ?: params["batchId"]),
                    )
                )
            }
            return ScannedQr.Unknown
        }

        // Bare serials are retained for older printed labels / barcode workflows.
        val candidate = trimmed.trimStart('#').trim()
        return if (candidate.isNotEmpty() && candidate.length <= 20) {
            ScannedQr.Invoice(InvoiceQrPayload(serial = candidate))
        } else {
            ScannedQr.Unknown
        }
    }

    private fun parseJson(raw: String): ScannedQr {
        val obj = try {
            JSONObject(raw)
        } catch (_: Exception) {
            return ScannedQr.Unknown
        }

        return when (readString(obj, "type")?.lowercase(Locale.ROOT)) {
            "connect" -> {
                val baseUrl = readString(obj, "base_url", "baseUrl")
                val apiKey = readString(obj, "api_key", "apiKey")
                if (baseUrl.isNullOrBlank() || apiKey.isNullOrBlank()) {
                    ScannedQr.Unknown
                } else {
                    ScannedQr.Connection(
                        ConnectionQrPayload(
                            app = readString(obj, "app").orEmpty(),
                            type = "connect",
                            version = readInt(obj, "version") ?: 1,
                            baseUrl = baseUrl,
                            apiKey = apiKey,
                        )
                    )
                }
            }

            "invoice" -> {
                val serial = readString(obj, "serial", "serial_number", "serialNumber")
                    ?.trim()
                    ?.trimStart('#')
                    ?.trim()
                if (serial.isNullOrBlank() || serial.length > 20) {
                    ScannedQr.Unknown
                } else {
                    val requestedScan = readString(obj, "scan")?.lowercase(Locale.ROOT)
                    val scan = requestedScan?.takeIf { it == "focus" || it == "auto" } ?: "auto"
                    ScannedQr.Invoice(
                        InvoiceQrPayload(
                            type = "invoice",
                            version = readInt(obj, "version") ?: 1,
                            serial = serial,
                            baseUrl = readString(obj, "base_url", "baseUrl").orEmpty(),
                            scan = scan,
                            batchId = readPositiveInt(obj, "batch_id", "batchId"),
                            invoiceId = readPositiveInt(obj, "invoice_id", "invoiceId"),
                        )
                    )
                }
            }

            else -> ScannedQr.Unknown
        }
    }

    private fun readString(obj: JSONObject, vararg keys: String): String? {
        for (key in keys) {
            if (!obj.has(key) || obj.isNull(key)) continue
            val value = obj.optString(key, "").trim()
            if (value.isNotEmpty() && !value.equals("null", ignoreCase = true)) return value
        }
        return null
    }

    private fun readInt(obj: JSONObject, vararg keys: String): Int? {
        for (key in keys) {
            if (!obj.has(key) || obj.isNull(key)) continue
            val value = obj.optString(key, "").trim().toIntOrNull()
            if (value != null) return value
        }
        return null
    }

    private fun readPositiveInt(obj: JSONObject, vararg keys: String): Int? =
        readInt(obj, *keys)?.takeIf { it > 0 }

    private fun parsePositiveInt(value: String?): Int? = value?.trim()?.toIntOrNull()?.takeIf { it > 0 }

    private fun parseUri(raw: String): URI? = try {
        URI(raw)
    } catch (_: Exception) {
        null
    }

    private fun parseQuery(query: String): Map<String, String> = query
        .split('&')
        .mapNotNull { part ->
            if (part.isEmpty()) return@mapNotNull null
            val pair = part.split('=', limit = 2)
            val key = decodeComponent(pair[0])
            val value = decodeComponent(pair.getOrElse(1) { "" })
            key to value
        }
        .toMap()

    private fun decodeComponent(value: String): String = try {
        URLDecoder.decode(value, StandardCharsets.UTF_8.name())
    } catch (_: Exception) {
        value
    }
}
