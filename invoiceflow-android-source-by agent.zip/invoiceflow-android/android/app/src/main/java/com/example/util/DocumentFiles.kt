package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import com.example.data.PickedFile
import java.io.File

/**
 * Copies a document chosen with the system picker into the app cache. Works for any file type
 * (PDF, Word, Excel, CSV, images, archives...). The server decides which types it accepts.
 * Returns null when the document cannot be read or is empty.
 */
fun copyPickedDocument(context: Context, uri: Uri): PickedFile? {
    val resolver = context.contentResolver
    val displayName = queryDisplayName(context, uri) ?: "document-${System.currentTimeMillis()}"
    val safeName = displayName.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(120).ifBlank { "document" }
    val mime = resolver.getType(uri)?.takeIf { it.isNotBlank() } ?: "application/octet-stream"
    val dir = File(context.cacheDir, "picked").apply { mkdirs() }
    val dest = File(dir, "${System.currentTimeMillis()}_$safeName")
    val copied = resolver.openInputStream(uri)?.use { input ->
        dest.outputStream().use { output -> input.copyTo(output) }
        true
    } ?: false
    if (!copied || dest.length() == 0L) {
        dest.delete()
        return null
    }
    return PickedFile(file = dest, displayName = displayName, mimeType = mime)
}

private fun queryDisplayName(context: Context, uri: Uri): String? =
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else null
    }

/** Opens a downloaded document with whatever app the user has for its type. */
fun openDocumentWith(context: Context, file: File, mimeType: String) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, mimeType.ifBlank { "*/*" })
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    // Direct intent (not a chooser) so the read grant reaches the receiving app.
    runCatching { context.startActivity(intent) }
}
