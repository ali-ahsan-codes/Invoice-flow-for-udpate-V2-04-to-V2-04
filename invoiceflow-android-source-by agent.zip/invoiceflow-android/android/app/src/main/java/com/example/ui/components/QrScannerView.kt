package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Size
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.CameraState
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Live camera preview that does two jobs at once:
 *   1. Continuously scans for QR codes and calls [onQrDetected] on each new one.
 *   2. Exposes an [ImageCapture] use case via [onImageCaptureReady] so the
 *      parent screen can trigger an in-app photo capture from the same
 *      camera session — no system camera app, no switching activities.
 */
@OptIn(ExperimentalGetImage::class)
@Composable
fun QrScannerView(
    modifier: Modifier = Modifier,
    onQrDetected: (String) -> Unit,
    onImageCaptureReady: (ImageCapture) -> Unit = {},
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    var cameraError by remember { mutableStateOf<String?>(null) }
    var scanStatusMessage by remember { mutableStateOf<String?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasPermission = isGranted
        if (!isGranted) {
            cameraError = "Camera permission is required to scan QR codes"
        } else {
            cameraError = null
        }
    }

    val currentOnQr by rememberUpdatedState(onQrDetected)
    val currentOnCaptureReady by rememberUpdatedState(onImageCaptureReady)

    // Image Picker for scanning QR from photo or screenshot
    val imageQrPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            decodeQrFromUri(context, uri) { code ->
                if (code != null) {
                    scanStatusMessage = null
                    currentOnQr(code)
                } else {
                    scanStatusMessage = "No QR code found in selected image"
                }
            }
        }
    }

    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    val lastDetected = remember { AtomicReference("") }
    val lastDetectedAt = remember { AtomicLong(0L) }

    if (hasPermission && cameraError == null) {
        DisposableEffect(lifecycleOwner, hasPermission) {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
            val executor = Executors.newSingleThreadExecutor()
            val barcodeOptions = BarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                    Barcode.FORMAT_QR_CODE,
                    Barcode.FORMAT_DATA_MATRIX,
                    Barcode.FORMAT_AZTEC,
                    Barcode.FORMAT_PDF417,
                    Barcode.FORMAT_CODE_128,
                    Barcode.FORMAT_CODE_39
                )
                .build()
            val scanner = BarcodeScanning.getClient(barcodeOptions)
            var providerRef: ProcessCameraProvider? = null

            cameraProviderFuture.addListener({
                try {
                    val cameraProvider = cameraProviderFuture.get()
                    providerRef = cameraProvider

                    val hasBack = try {
                        cameraProvider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)
                    } catch (e: Exception) {
                        false
                    }
                    val hasFront = try {
                        cameraProvider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)
                    } catch (e: Exception) {
                        false
                    }

                    val cameraSelector = when {
                        hasBack -> CameraSelector.DEFAULT_BACK_CAMERA
                        hasFront -> CameraSelector.DEFAULT_FRONT_CAMERA
                        else -> null
                    }

                    if (cameraSelector == null) {
                        cameraError = "No camera hardware detected on this device or emulator."
                        return@addListener
                    }

                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }

                    val imageAnalysis = ImageAnalysis.Builder()
                        .setTargetResolution(Size(1280, 720))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()

                    val rotation = previewView.display?.rotation ?: android.view.Surface.ROTATION_0
                    val imageCapture = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .setTargetRotation(rotation)
                        .setJpegQuality(92)
                        .build()

                    imageAnalysis.setAnalyzer(executor) { imageProxy ->
                        val mediaImage = imageProxy.image
                        if (mediaImage != null) {
                            val inputImage = InputImage.fromMediaImage(
                                mediaImage,
                                imageProxy.imageInfo.rotationDegrees
                            )
                            scanner.process(inputImage)
                                .addOnSuccessListener { barcodes ->
                                    val raw = barcodes.firstOrNull()?.rawValue
                                    if (!raw.isNullOrBlank()) {
                                        val now = System.currentTimeMillis()
                                        val last = lastDetected.get()
                                        val lastAt = lastDetectedAt.get()
                                        if (raw != last || now - lastAt > 1500L) {
                                            lastDetected.set(raw)
                                            lastDetectedAt.set(now)
                                            currentOnQr(raw)
                                        }
                                    }
                                }
                                .addOnCompleteListener {
                                    imageProxy.close()
                                }
                        } else {
                            imageProxy.close()
                        }
                    }

                    cameraProvider.unbindAll()
                    val camera = cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        preview,
                        imageAnalysis,
                        imageCapture,
                    )
                    currentOnCaptureReady(imageCapture)

                    camera.cameraInfo.cameraState.observe(lifecycleOwner) { state ->
                        if (state.type == CameraState.Type.CLOSED && state.error != null) {
                            val errorType = state.error?.code
                            if (errorType == CameraState.ERROR_CAMERA_FATAL_ERROR ||
                                errorType == CameraState.ERROR_CAMERA_DISABLED
                            ) {
                                cameraError = "Camera device unavailable in this environment"
                                try {
                                    cameraProvider.unbindAll()
                                } catch (e: Exception) {
                                    // ignore
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    cameraError = "Camera unavailable (${e.localizedMessage ?: "device error"})"
                }
            }, ContextCompat.getMainExecutor(context))

            onDispose {
                try {
                    providerRef?.unbindAll()
                } catch (e: Exception) {
                    // ignore
                }
                try {
                    scanner.close()
                } catch (e: Exception) {
                    // ignore
                }
                executor.shutdown()
            }
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        if (hasPermission && cameraError == null) {
            AndroidView(
                factory = { previewView },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Friendly fallback view when camera is not permitted or unavailable in emulator
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF181426))
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (!hasPermission) Icons.Default.CameraAlt else Icons.Default.VideocamOff,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.size(42.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = cameraError ?: "Camera access required",
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                if (!hasPermission) {
                    Button(
                        onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                        modifier = Modifier.testTag("grant_camera_permission_button")
                    ) {
                        Text("Grant Camera Permission")
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                OutlinedButton(
                    onClick = { imageQrPicker.launch("image/*") },
                    modifier = Modifier.testTag("scan_from_image_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("Scan QR from Photo / File", color = Color.White)
                }

                if (scanStatusMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = scanStatusMessage ?: "",
                        color = Color(0xFFFDA4BF),
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

private fun decodeQrFromUri(
    context: Context,
    uri: Uri,
    onResult: (String?) -> Unit
) {
    try {
        val inputImage = InputImage.fromFilePath(context, uri)
        val scanner = BarcodeScanning.getClient()
        scanner.process(inputImage)
            .addOnSuccessListener { barcodes ->
                val code = barcodes.firstOrNull()?.rawValue
                onResult(code)
            }
            .addOnFailureListener {
                onResult(null)
            }
    } catch (e: Exception) {
        onResult(null)
    }
}


