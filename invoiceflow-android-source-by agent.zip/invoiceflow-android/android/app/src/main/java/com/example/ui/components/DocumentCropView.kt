package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CropSettings
import com.example.ui.theme.BluePrimary
import com.example.util.CropSelection
import com.example.util.ImageCropUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

enum class DragHandle {
    NONE,
    TOP_LEFT,
    TOP_RIGHT,
    BOTTOM_RIGHT,
    BOTTOM_LEFT,
    EDGE_TOP,
    EDGE_BOTTOM,
    EDGE_LEFT,
    EDGE_RIGHT,
    CENTER_BODY
}

@Composable
fun DocumentCropScreen(
    imageFile: File,
    cropSettings: CropSettings,
    onConfirmCrop: (File) -> Unit,
    onCancel: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var rotationDegrees by remember { mutableIntStateOf(0) }
    var cropSelection by remember { mutableStateOf(CropSelection(0f, 0f, 1f, 1f)) }
    var isCropActive by remember { mutableStateOf(cropSettings.autoOpenHandles) }
    var isProcessing by remember { mutableStateOf(false) }

    // Efficiently load preview bitmap (orientation corrected)
    LaunchedEffect(imageFile) {
        withContext(Dispatchers.IO) {
            try {
                ImageCropUtils.fixImageOrientation(imageFile)

                // Decode with reasonable bounds for display so dragging is ultra-smooth 60fps
                val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(imageFile.absolutePath, boundsOpts)

                val sampleSize = max(1, min(boundsOpts.outWidth / 1440, boundsOpts.outHeight / 1440))
                val decodeOpts = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                val bmp = BitmapFactory.decodeFile(imageFile.absolutePath, decodeOpts)
                previewBitmap = bmp
                cropSelection = CropSelection(0f, 0f, 1f, 1f)
                isCropActive = cropSettings.autoOpenHandles
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF181426))
            .testTag("document_crop_screen")
    ) {
        val bmp = previewBitmap
        if (bmp == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color.White)
            }
            return
        }

        // Cache ImageBitmap once so DrawScope doesn't re-allocate textures every frame
        val cachedImageBitmap = remember(bmp) { bmp.asImageBitmap() }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // ---------------- Top App Bar ----------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onCancel,
                        modifier = Modifier.testTag("crop_cancel_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Cancel", tint = Color.White)
                    }
                    Spacer(Modifier.width(4.dp))
                    Column {
                        Text(
                            text = if (isCropActive) "Adjust Crop Area" else "Review Captured Photo",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isCropActive) "Freely drag corner handles to frame invoice" else "Full photo as captured. Tap Crop to trim.",
                            color = Color.White.copy(alpha = 0.75f),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Rotate 90° Button
                    IconButton(
                        onClick = { rotationDegrees = (rotationDegrees + 90) % 360 },
                        modifier = Modifier.testTag("crop_rotate_button")
                    ) {
                        Icon(Icons.Default.RotateRight, contentDescription = "Rotate", tint = Color.White)
                    }

                    // Open Settings Modal
                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier.testTag("crop_open_settings_button")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                    }
                }
            }

            // ---------------- Photo Display / Interactive Canvas ----------------
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                InteractiveCropCanvas(
                    imageBitmap = cachedImageBitmap,
                    rotationDegrees = rotationDegrees,
                    cropSelection = cropSelection,
                    isCroppingActive = isCropActive,
                    onCropChange = { newCrop ->
                        cropSelection = newCrop
                    },
                    showGrid = cropSettings.showGrid && isCropActive,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // ---------------- Bottom Action Panel ----------------
            Surface(
                color = Color(0xFF211B34),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    // Secondary action bar: Crop Toggle or Reset
                    if (!isCropActive) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            FilledTonalButton(
                                onClick = {
                                    isCropActive = true
                                    // Start with a spacious frame with handles so user can easily adjust freely
                                    cropSelection = CropSelection(0.04f, 0.04f, 0.96f, 0.96f)
                                    Toast.makeText(
                                        context,
                                        "Crop handles active. Freely drag any corner.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp)
                                    .testTag("enable_manual_crop_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color(0xFF302842),
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(Icons.Default.Crop, null, modifier = Modifier.size(17.dp), tint = Color(0xFFB69CFF))
                                Spacer(Modifier.width(8.dp))
                                Text("Crop Manually with Handles", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilledTonalButton(
                                onClick = {
                                    // Expand selection to almost full image
                                    cropSelection = CropSelection(0.01f, 0.01f, 0.99f, 0.99f)
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("crop_reset_handles_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color(0xFF302842),
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(Icons.Default.CropFree, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Full Frame", maxLines = 1, fontSize = 12.sp)
                            }

                            FilledTonalButton(
                                onClick = {
                                    isCropActive = false
                                    cropSelection = CropSelection(0f, 0f, 1f, 1f)
                                    Toast.makeText(context, "Cancelled crop. Full image will be attached.", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("crop_cancel_active_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color(0xFF46385F),
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(Icons.Default.Close, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Cancel Crop", maxLines = 1, fontSize = 12.sp)
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    // Primary Actions: Retake vs Attach
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = onCancel,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("crop_retake_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Retake", color = Color.White)
                        }

                        Button(
                            onClick = {
                                if (isProcessing) return@Button
                                isProcessing = true

                                scope.launch(Dispatchers.IO) {
                                    // If user didn't crop or kept full selection, attach the untouched raw photo directly
                                    if (!isCropActive || cropSelection.isFull) {
                                        if (rotationDegrees % 360 == 0) {
                                            withContext(Dispatchers.Main) {
                                                isProcessing = false
                                                onConfirmCrop(imageFile)
                                            }
                                            return@launch
                                        }
                                    }

                                    // Otherwise crop according to user's manual selection
                                    val destinationFile = File(
                                        imageFile.parentFile,
                                        "attached_${System.currentTimeMillis()}.jpg"
                                    )

                                    val finalCrop = if (!isCropActive) {
                                        CropSelection(0f, 0f, 1f, 1f)
                                    } else {
                                        cropSelection
                                    }

                                    val success = ImageCropUtils.cropAndSave(
                                        sourceFile = imageFile,
                                        destFile = destinationFile,
                                        crop = finalCrop,
                                        rotationDegrees = rotationDegrees
                                    )

                                    withContext(Dispatchers.Main) {
                                        isProcessing = false
                                        if (success && destinationFile.exists()) {
                                            onConfirmCrop(destinationFile)
                                        } else {
                                            onConfirmCrop(imageFile)
                                        }
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1.8f)
                                .height(50.dp)
                                .testTag("crop_confirm_button"),
                            enabled = !isProcessing,
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isProcessing) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text("Attaching…", fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.Check, null)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = if (isCropActive) "Attach Cropped Photo" else "Attach Full Photo",
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Ultra-smooth 60fps Interactive Crop Canvas.
 * Pointer input does NOT restart mid-drag, allowing corners to be dragged completely freely.
 */
@Composable
fun InteractiveCropCanvas(
    imageBitmap: ImageBitmap,
    rotationDegrees: Int,
    cropSelection: CropSelection,
    isCroppingActive: Boolean,
    onCropChange: (CropSelection) -> Unit,
    showGrid: Boolean,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val cornerGrabRadiusPx = with(density) { 56.dp.toPx() } // Generous 56dp grab radius
    val edgeGrabRadiusPx = with(density) { 36.dp.toPx() }

    var activeHandle by remember { mutableStateOf(DragHandle.NONE) }

    // Use updated states so pointerInput lambda does NOT re-launch on every coordinate change!
    val currentCropSelection by rememberUpdatedState(cropSelection)
    val currentOnCropChange by rememberUpdatedState(onCropChange)

    BoxWithConstraints(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        val containerWidth = constraints.maxWidth.toFloat()
        val containerHeight = constraints.maxHeight.toFloat()

        // Calculate aspect-fit geometry for image based on rotation
        val isSideways = rotationDegrees % 180 != 0
        val imageW = if (isSideways) imageBitmap.height.toFloat() else imageBitmap.width.toFloat()
        val imageH = if (isSideways) imageBitmap.width.toFloat() else imageBitmap.height.toFloat()

        val scale = min(containerWidth / imageW, containerHeight / imageH)
        val fitWidth = imageW * scale
        val fitHeight = imageH * scale
        val offsetX = (containerWidth - fitWidth) / 2f
        val offsetY = (containerHeight - fitHeight) / 2f

        val imageRect = Rect(offsetX, offsetY, offsetX + fitWidth, offsetY + fitHeight)
        val currentImageRect by rememberUpdatedState(imageRect)

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(isCroppingActive) {
                    if (!isCroppingActive) return@pointerInput

                    detectDragGestures(
                        onDragStart = { startPos ->
                            val r = currentImageRect
                            val sel = currentCropSelection

                            val leftPx = r.left + sel.left * r.width
                            val topPx = r.top + sel.top * r.height
                            val rightPx = r.left + sel.right * r.width
                            val bottomPx = r.top + sel.bottom * r.height
                            val midXPx = (leftPx + rightPx) / 2f
                            val midYPx = (topPx + bottomPx) / 2f

                            fun dist(x: Float, y: Float) =
                                sqrt(((startPos.x - x) * (startPos.x - x) + (startPos.y - y) * (startPos.y - y)).toDouble()).toFloat()

                            val dTL = dist(leftPx, topPx)
                            val dTR = dist(rightPx, topPx)
                            val dBR = dist(rightPx, bottomPx)
                            val dBL = dist(leftPx, bottomPx)

                            // 1. Priority to 4 Corners (find closest corner within 56dp grab radius)
                            val minCornerDist = minOf(dTL, dTR, dBR, dBL)
                            if (minCornerDist <= cornerGrabRadiusPx) {
                                activeHandle = when (minCornerDist) {
                                    dTL -> DragHandle.TOP_LEFT
                                    dTR -> DragHandle.TOP_RIGHT
                                    dBR -> DragHandle.BOTTOM_RIGHT
                                    else -> DragHandle.BOTTOM_LEFT
                                }
                                return@detectDragGestures
                            }

                            // 2. Check 4 Edges
                            val dTop = dist(midXPx, topPx)
                            val dBottom = dist(midXPx, bottomPx)
                            val dLeft = dist(leftPx, midYPx)
                            val dRight = dist(rightPx, midYPx)
                            val minEdgeDist = minOf(dTop, dBottom, dLeft, dRight)

                            if (minEdgeDist <= edgeGrabRadiusPx) {
                                activeHandle = when (minEdgeDist) {
                                    dTop -> DragHandle.EDGE_TOP
                                    dBottom -> DragHandle.EDGE_BOTTOM
                                    dLeft -> DragHandle.EDGE_LEFT
                                    else -> DragHandle.EDGE_RIGHT
                                }
                                return@detectDragGestures
                            }

                            // 3. Check Center Body
                            if (startPos.x in leftPx..rightPx && startPos.y in topPx..bottomPx) {
                                activeHandle = DragHandle.CENTER_BODY
                            } else {
                                activeHandle = DragHandle.NONE
                            }
                        },
                        onDragEnd = { activeHandle = DragHandle.NONE },
                        onDragCancel = { activeHandle = DragHandle.NONE },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val r = currentImageRect
                            if (activeHandle == DragHandle.NONE || r.width <= 0f || r.height <= 0f) return@detectDragGestures

                            val dxNorm = dragAmount.x / r.width
                            val dyNorm = dragAmount.y / r.height

                            val current = currentCropSelection
                            val updated = when (activeHandle) {
                                DragHandle.TOP_LEFT -> current.copy(
                                    left = (current.left + dxNorm).coerceIn(0f, current.right - 0.02f),
                                    top = (current.top + dyNorm).coerceIn(0f, current.bottom - 0.02f)
                                )
                                DragHandle.TOP_RIGHT -> current.copy(
                                    right = (current.right + dxNorm).coerceIn(current.left + 0.02f, 1f),
                                    top = (current.top + dyNorm).coerceIn(0f, current.bottom - 0.02f)
                                )
                                DragHandle.BOTTOM_RIGHT -> current.copy(
                                    right = (current.right + dxNorm).coerceIn(current.left + 0.02f, 1f),
                                    bottom = (current.bottom + dyNorm).coerceIn(current.top + 0.02f, 1f)
                                )
                                DragHandle.BOTTOM_LEFT -> current.copy(
                                    left = (current.left + dxNorm).coerceIn(0f, current.right - 0.02f),
                                    bottom = (current.bottom + dyNorm).coerceIn(current.top + 0.02f, 1f)
                                )
                                DragHandle.EDGE_TOP -> current.copy(
                                    top = (current.top + dyNorm).coerceIn(0f, current.bottom - 0.02f)
                                )
                                DragHandle.EDGE_BOTTOM -> current.copy(
                                    bottom = (current.bottom + dyNorm).coerceIn(current.top + 0.02f, 1f)
                                )
                                DragHandle.EDGE_LEFT -> current.copy(
                                    left = (current.left + dxNorm).coerceIn(0f, current.right - 0.02f)
                                )
                                DragHandle.EDGE_RIGHT -> current.copy(
                                    right = (current.right + dxNorm).coerceIn(current.left + 0.02f, 1f)
                                )
                                DragHandle.CENTER_BODY -> {
                                    val w = current.right - current.left
                                    val h = current.bottom - current.top
                                    var newL = current.left + dxNorm
                                    var newT = current.top + dyNorm
                                    if (newL < 0f) newL = 0f
                                    if (newT < 0f) newT = 0f
                                    if (newL + w > 1f) newL = 1f - w
                                    if (newT + h > 1f) newT = 1f - h
                                    current.copy(left = newL, top = newT, right = newL + w, bottom = newT + h)
                                }
                                DragHandle.NONE -> current
                            }
                            currentOnCropChange(updated)
                        }
                    )
                }
        ) {
            // 1. Draw Image with cached ImageBitmap (Zero GC allocations!)
            drawImageFitCached(
                imageBitmap = imageBitmap,
                rotationDegrees = rotationDegrees,
                targetRect = imageRect
            )

            // When crop is NOT active: Show raw image completely with no scrim or handles
            if (!isCroppingActive) {
                drawRect(
                    color = Color.White.copy(alpha = 0.25f),
                    topLeft = imageRect.topLeft,
                    size = imageRect.size,
                    style = Stroke(width = 1.dp.toPx())
                )
                return@Canvas
            }

            // 2. Crop Geometry on Canvas
            val cropRectPx = Rect(
                left = imageRect.left + cropSelection.left * imageRect.width,
                top = imageRect.top + cropSelection.top * imageRect.height,
                right = imageRect.left + cropSelection.right * imageRect.width,
                bottom = imageRect.top + cropSelection.bottom * imageRect.height
            )

            // 3. Draw Dark Dimmed Mask Outside Crop Selection
            val cropPath = Path().apply {
                addRect(cropRectPx)
            }

            clipPath(cropPath, clipOp = ClipOp.Difference) {
                drawRect(
                    color = Color.Black.copy(alpha = 0.65f),
                    topLeft = imageRect.topLeft,
                    size = imageRect.size
                )
            }

            // 4. Draw Crop Rectangle Border
            drawRect(
                color = Color.White,
                topLeft = cropRectPx.topLeft,
                size = cropRectPx.size,
                style = Stroke(width = 2.dp.toPx())
            )

            // 5. Draw 3x3 Rule-Of-Thirds Grid
            if (showGrid) {
                val thirdW = cropRectPx.width / 3f
                val thirdH = cropRectPx.height / 3f
                val gridColor = Color.White.copy(alpha = 0.35f)

                drawLine(
                    color = gridColor,
                    start = Offset(cropRectPx.left + thirdW, cropRectPx.top),
                    end = Offset(cropRectPx.left + thirdW, cropRectPx.bottom),
                    strokeWidth = 1.dp.toPx()
                )
                drawLine(
                    color = gridColor,
                    start = Offset(cropRectPx.left + 2 * thirdW, cropRectPx.top),
                    end = Offset(cropRectPx.left + 2 * thirdW, cropRectPx.bottom),
                    strokeWidth = 1.dp.toPx()
                )
                drawLine(
                    color = gridColor,
                    start = Offset(cropRectPx.left, cropRectPx.top + thirdH),
                    end = Offset(cropRectPx.right, cropRectPx.top + thirdH),
                    strokeWidth = 1.dp.toPx()
                )
                drawLine(
                    color = gridColor,
                    start = Offset(cropRectPx.left, cropRectPx.top + 2 * thirdH),
                    end = Offset(cropRectPx.right, cropRectPx.top + 2 * thirdH),
                    strokeWidth = 1.dp.toPx()
                )
            }

            // 6. Draw Corner L-Brackets and Knobs
            val handleRadius = 15.dp.toPx()
            val bracketLength = 22.dp.toPx()
            val bracketStroke = 4.dp.toPx()
            val bracketColor = Color(0xFFC8B2FF) // Bright Cyan/Blue

            // Top-Left Bracket
            drawLine(bracketColor, cropRectPx.topLeft, Offset(cropRectPx.topLeft.x + bracketLength, cropRectPx.topLeft.y), bracketStroke)
            drawLine(bracketColor, cropRectPx.topLeft, Offset(cropRectPx.topLeft.x, cropRectPx.topLeft.y + bracketLength), bracketStroke)

            // Top-Right Bracket
            drawLine(bracketColor, cropRectPx.topRight, Offset(cropRectPx.topRight.x - bracketLength, cropRectPx.topRight.y), bracketStroke)
            drawLine(bracketColor, cropRectPx.topRight, Offset(cropRectPx.topRight.x, cropRectPx.topRight.y + bracketLength), bracketStroke)

            // Bottom-Right Bracket
            drawLine(bracketColor, cropRectPx.bottomRight, Offset(cropRectPx.bottomRight.x - bracketLength, cropRectPx.bottomRight.y), bracketStroke)
            drawLine(bracketColor, cropRectPx.bottomRight, Offset(cropRectPx.bottomRight.x, cropRectPx.bottomRight.y - bracketLength), bracketStroke)

            // Bottom-Left Bracket
            drawLine(bracketColor, cropRectPx.bottomLeft, Offset(cropRectPx.bottomLeft.x + bracketLength, cropRectPx.bottomLeft.y), bracketStroke)
            drawLine(bracketColor, cropRectPx.bottomLeft, Offset(cropRectPx.bottomLeft.x, cropRectPx.bottomLeft.y - bracketLength), bracketStroke)

            // 4 Circular Corner Knobs
            val corners = listOf(
                Pair(cropRectPx.topLeft, DragHandle.TOP_LEFT),
                Pair(cropRectPx.topRight, DragHandle.TOP_RIGHT),
                Pair(cropRectPx.bottomRight, DragHandle.BOTTOM_RIGHT),
                Pair(cropRectPx.bottomLeft, DragHandle.BOTTOM_LEFT)
            )

            corners.forEach { (pt, handleType) ->
                val isActive = activeHandle == handleType
                // Dark outer glow
                drawCircle(
                    color = Color.Black.copy(alpha = 0.5f),
                    radius = handleRadius + 3.dp.toPx(),
                    center = pt
                )
                // White ring
                drawCircle(
                    color = Color.White,
                    radius = handleRadius,
                    center = pt
                )
                // Vibrant Blue center
                drawCircle(
                    color = if (isActive) Color(0xFFC8B2FF) else Color(0xFF8055DF),
                    radius = handleRadius - 3.5.dp.toPx(),
                    center = pt
                )
            }

            // 7. Edge Center Grips (pill-shaped markers)
            val edgeRadius = 5.dp.toPx()
            val edgeColor = Color.White.copy(alpha = 0.95f)
            val midTop = Offset((cropRectPx.left + cropRectPx.right) / 2f, cropRectPx.top)
            val midBottom = Offset((cropRectPx.left + cropRectPx.right) / 2f, cropRectPx.bottom)
            val midLeft = Offset(cropRectPx.left, (cropRectPx.top + cropRectPx.bottom) / 2f)
            val midRight = Offset(cropRectPx.right, (cropRectPx.top + cropRectPx.bottom) / 2f)

            drawRoundRect(
                color = edgeColor,
                topLeft = Offset(midTop.x - 14.dp.toPx(), midTop.y - 3.dp.toPx()),
                size = Size(28.dp.toPx(), 6.dp.toPx()),
                cornerRadius = CornerRadius(edgeRadius, edgeRadius)
            )
            drawRoundRect(
                color = edgeColor,
                topLeft = Offset(midBottom.x - 14.dp.toPx(), midBottom.y - 3.dp.toPx()),
                size = Size(28.dp.toPx(), 6.dp.toPx()),
                cornerRadius = CornerRadius(edgeRadius, edgeRadius)
            )
            drawRoundRect(
                color = edgeColor,
                topLeft = Offset(midLeft.x - 3.dp.toPx(), midLeft.y - 14.dp.toPx()),
                size = Size(6.dp.toPx(), 28.dp.toPx()),
                cornerRadius = CornerRadius(edgeRadius, edgeRadius)
            )
            drawRoundRect(
                color = edgeColor,
                topLeft = Offset(midRight.x - 3.dp.toPx(), midRight.y - 14.dp.toPx()),
                size = Size(6.dp.toPx(), 28.dp.toPx()),
                cornerRadius = CornerRadius(edgeRadius, edgeRadius)
            )
        }
    }
}

/**
 * Renders the pre-cached ImageBitmap onto the canvas within [targetRect].
 */
private fun DrawScope.drawImageFitCached(
    imageBitmap: ImageBitmap,
    rotationDegrees: Int,
    targetRect: Rect
) {
    drawContext.canvas.save()
    if (rotationDegrees % 360 != 0) {
        drawContext.canvas.translate(targetRect.center.x, targetRect.center.y)
        drawContext.canvas.rotate(rotationDegrees.toFloat())
        val isSideways = rotationDegrees % 180 != 0
        val drawW = if (isSideways) targetRect.height else targetRect.width
        val drawH = if (isSideways) targetRect.width else targetRect.height
        drawImage(
            image = imageBitmap,
            dstOffset = IntOffset((-drawW / 2f).roundToInt(), (-drawH / 2f).roundToInt()),
            dstSize = IntSize(drawW.roundToInt(), drawH.roundToInt())
        )
    } else {
        drawImage(
            image = imageBitmap,
            dstOffset = IntOffset(targetRect.left.roundToInt(), targetRect.top.roundToInt()),
            dstSize = IntSize(targetRect.width.roundToInt(), targetRect.height.roundToInt())
        )
    }
    drawContext.canvas.restore()
}


