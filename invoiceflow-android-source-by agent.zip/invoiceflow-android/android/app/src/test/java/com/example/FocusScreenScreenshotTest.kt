package com.example

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Looper
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.test.core.app.ApplicationProvider
import com.example.data.Connection
import com.example.data.ConnectionStore
import com.example.ui.ScanScreen
import com.example.ui.theme.InvoiceFlowTheme
import com.example.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.Shadows.shadowOf
import java.io.File
import java.net.InetSocketAddress
import java.nio.charset.StandardCharsets
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import com.sun.net.httpserver.HttpServer

/** Renders the real Compose Focus screen under Robolectric and saves a PNG artifact. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w393dp-h852dp")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class FocusScreenScreenshotTest {
    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun capturesFocusedInvoiceScreen() {
        Dispatchers.setMain(UnconfinedTestDispatcher())
        val app = ApplicationProvider.getApplicationContext<Application>()
        val requests = CountDownLatch(2)
        val httpServer = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        httpServer.createContext("/") { exchange ->
            val path = exchange.requestURI.path
            val body = if (path.endsWith("/next")) """{"error":"No next invoice"}""" else
                """{"id":184,"serial_number":"0001","batch_id":2,"date":"2026-10-10","date_display":"10 Oct 2026","book":1,"page":1,"total_amount":74.250,"amounts":[74.250],"media_count":1,"has_media":true,"media_required":false}"""
            val status = if (path.endsWith("/next")) 404 else 200
            val bytes = body.toByteArray(StandardCharsets.UTF_8)
            exchange.responseHeaders.add("Content-Type", "application/json")
            exchange.sendResponseHeaders(status, bytes.size.toLong())
            exchange.responseBody.use { it.write(bytes) }
            requests.countDown()
        }
        httpServer.start()
        val store = ConnectionStore(app)
        store.save(Connection("http://127.0.0.1:${httpServer.address.port}", "screenshot-key", 8, "qa"))
        val viewModel = MainViewModel(app)
        val activityController = Robolectric.buildActivity(ComponentActivity::class.java).setup()
        val activity = activityController.get()

        try {
            viewModel.handleQrScan("0001", "focus", 2)
            shadowOf(Looper.getMainLooper()).idle()
            assertTrue("mock InvoiceFlow API should answer", requests.await(5, TimeUnit.SECONDS))
            awaitMainLooperState(viewModel)
            assertTrue(viewModel.state.value.currentInvoice?.serialNumber == "0001")
            assertTrue(viewModel.state.value.scanMode.name == "FOCUS")

            activity.runOnUiThread {
                activity.setContent {
                    InvoiceFlowTheme(darkTheme = false) {
                        ScanScreen(vm = viewModel, modifier = Modifier.fillMaxSize())
                    }
                }
            }
            shadowOf(Looper.getMainLooper()).idle()
            val root = activity.window.decorView
            val metrics = activity.resources.displayMetrics
            val width = metrics.widthPixels.coerceAtLeast(393)
            val height = metrics.heightPixels.coerceAtLeast(852)
            root.measure(
                View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY),
            )
            root.layout(0, 0, width, height)
            shadowOf(Looper.getMainLooper()).idle()

            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            root.draw(Canvas(bitmap))
            val outputDirectory = System.getenv("INVOICEFLOW_SCREENSHOT_DIR")
                ?.takeIf { it.isNotBlank() }
                ?.let(::File)
                ?: File("build/test-screenshots").absoluteFile
            outputDirectory.mkdirs()
            val output = File(outputDirectory, "android-focus-screen.png")
            output.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
            assertTrue("Focus screen screenshot should be written", output.isFile && output.length() > 0)
            activityController.pause().stop().destroy()
        } finally {
            store.clear()
            httpServer.stop(0)
            Dispatchers.resetMain()
        }
    }

    private fun awaitMainLooperState(viewModel: MainViewModel) {
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(5)
        while (System.nanoTime() < deadline) {
            shadowOf(Looper.getMainLooper()).idle()
            if (!viewModel.state.value.loading && viewModel.state.value.currentInvoice != null) return
            Thread.sleep(10)
        }
    }
}
