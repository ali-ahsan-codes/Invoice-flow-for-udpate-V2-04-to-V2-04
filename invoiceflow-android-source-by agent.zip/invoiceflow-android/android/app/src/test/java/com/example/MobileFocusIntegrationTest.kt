package com.example

import android.app.Application
import com.example.data.Connection
import com.example.data.ConnectionStore
import com.example.data.QrParser
import com.example.data.ScannedQr
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.ScanMode
import com.example.viewmodel.UploadStatus
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import kotlinx.coroutines.withContext
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.net.InetSocketAddress
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import com.sun.net.httpserver.HttpServer

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MobileFocusIntegrationTest {
    private var server: HttpServer? = null

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun focusQrLoadsTheRightBatchAndKeepsItForUpload() = runTest {
        Dispatchers.setMain(UnconfinedTestDispatcher(testScheduler))
        val app = ApplicationProvider.getApplicationContext<Application>()
        val received = ConcurrentLinkedQueue<String>()
        val invoiceAndNextRequests = CountDownLatch(2)
        val uploadRequests = CountDownLatch(1)

        val httpServer = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server = httpServer
        httpServer.createContext("/") { exchange ->
            val request = "${exchange.requestMethod} ${exchange.requestURI}"
            received.add(request)
            val path = exchange.requestURI.path
            val (status, body) = when {
                path == "/api/v1/invoices/0001" -> 200 to invoiceJson(mediaCount = 0)
                path == "/api/v1/invoices/0001/next" -> 404 to """{"error":"No next invoice"}"""
                path == "/api/v1/invoices/0001/media" -> 201 to
                    """{"success":true,"media_id":501,"filename":"capture.jpg","media_count":1,"invoice":${invoiceJson(mediaCount = 1)}}"""
                else -> 404 to """{"error":"Not found"}"""
            }
            exchange.responseHeaders.add("Content-Type", "application/json")
            val bytes = body.toByteArray(StandardCharsets.UTF_8)
            exchange.sendResponseHeaders(status, bytes.size.toLong())
            exchange.responseBody.use { it.write(bytes) }
            when (path) {
                "/api/v1/invoices/0001", "/api/v1/invoices/0001/next" -> invoiceAndNextRequests.countDown()
                "/api/v1/invoices/0001/media" -> uploadRequests.countDown()
            }
        }
        httpServer.start()

        val baseUrl = "http://127.0.0.1:${httpServer.address.port}"
        val store = ConnectionStore(app)
        store.save(Connection(baseUrl = baseUrl, apiKey = "test-key", userId = 8, username = "qa"))
        val viewModel = MainViewModel(app)
        val rawFocusQr = """{"type":"invoice","version":2,"batch_id":2,"invoice_id":184,"serial":"0001","base_url":"$baseUrl","scan":"focus"}"""
        val parsed = QrParser.parse(rawFocusQr)
        assertTrue(parsed is ScannedQr.Invoice)
        val payload = (parsed as ScannedQr.Invoice).payload

        try {
            viewModel.handleQrScan(payload.serial, payload.scan, payload.batchId)
            assertTrue("invoice and next requests should complete", invoiceAndNextRequests.await(5, TimeUnit.SECONDS))
            awaitState { !viewModel.state.value.loading && viewModel.state.value.currentInvoice != null }

            assertEquals(ScanMode.FOCUS, viewModel.state.value.scanMode)
            assertEquals("0001", viewModel.state.value.currentInvoice?.serialNumber)
            assertEquals(2, viewModel.state.value.currentInvoice?.batchId)
            assertTrue(received.contains("GET /api/v1/invoices/0001?batch_id=2"))
            assertTrue(received.contains("GET /api/v1/invoices/0001/next?batch_id=2"))

            // Re-scanning a Focus QR for the already displayed invoice must still
            // enter Focus, without starting an unnecessary second lookup.
            viewModel.setScanMode(ScanMode.AUTO)
            viewModel.handleQrScan(payload.serial, payload.scan, payload.batchId)
            assertEquals(ScanMode.FOCUS, viewModel.state.value.scanMode)
            assertEquals(1, received.count { it.startsWith("GET /api/v1/invoices/0001?") })

            val photo = File.createTempFile("invoiceflow-test-", ".jpg")
            try {
                photo.writeBytes(byteArrayOf(0x01, 0x02, 0x03))
                viewModel.uploadMedia("0001", 2, photo, autoAdvance = false)
                assertTrue("batch-scoped media upload should complete", uploadRequests.await(5, TimeUnit.SECONDS))
                awaitState { viewModel.state.value.uploadStatus == UploadStatus.Success }
                assertTrue(received.contains("POST /api/v1/invoices/0001/media?batch_id=2"))
                assertEquals(1, viewModel.state.value.currentInvoice?.mediaCount)
                assertFalse(viewModel.state.value.loading)
            } finally {
                photo.delete()
            }
        } finally {
            store.clear()
            httpServer.stop(0)
            Dispatchers.resetMain()
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private suspend fun awaitState(predicate: () -> Boolean) {
        val complete = withContext(Dispatchers.IO) {
            val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(5)
            while (!predicate() && System.nanoTime() < deadline) Thread.sleep(10)
            predicate()
        }
        assertTrue("view-model state did not settle in time", complete)
    }

    private fun invoiceJson(mediaCount: Int): String =
        """{"id":184,"serial_number":"0001","batch_id":2,"date":"2026-10-10","date_display":"10 Oct 2026","book":1,"page":1,"total_amount":74.25,"amounts":[74.25],"media_count":$mediaCount,"has_media":${mediaCount > 0},"media_required":false}"""

    @After
    fun stopServer() {
        server?.stop(0)
        server = null
    }
}
