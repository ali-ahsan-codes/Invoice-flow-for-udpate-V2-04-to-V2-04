package com.example

import com.example.data.ApiException
import com.example.data.ApiService
import com.example.data.Connection
import com.example.data.PickedFile
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.net.InetSocketAddress
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentLinkedQueue
import com.sun.net.httpserver.HttpServer

/**
 * Exercises the notes / links / history calls against a local stub of the server's mobile API.
 * Checks request shape (batch scoping, JSON exclude flag, multipart documents) and reply parsing.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
@OptIn(ExperimentalCoroutinesApi::class)
class NotesLinksApiTest {
    private var server: HttpServer? = null
    private val requests = ConcurrentLinkedQueue<String>()

    private val historyJson = """
        {"invoice":{"id":184,"batch_id":2,"batch":"Batch 2","serial_number":"0001","date":"2026-10-10","total_amount":74.25,"created_by":"qa"},
         "relations":[{"id":7,"link_type":"duplicate","relation":"Duplicate of","amount_action":"merge","merged":true,
            "receiver_side":true,"merged_amount":30.0,"exclude_from_totals":true,"note":"re-issued","created_by":"qa",
            "can_unlink":true,"other":{"id":185,"batch_id":2,"batch":"Batch 2","serial_number":"0002","date":"2026-10-02","total_amount":30.0,"created_by":"qa"}}],
         "hidden_link_count":1,
         "notes":[{"id":5,"invoice_id":184,"invoice_serial":"0001","is_own":true,"body":"Customer called","author":"qa",
            "created_at":"2026-10-10T09:30:00","can_delete":true,
            "attachments":[{"id":9,"file_name":"scan.pdf","file_size":2048,"mime_type":"application/pdf","uploaded_by":"qa"}]}]}
    """.trimIndent()

    @After
    fun stopServer() {
        server?.stop(0)
        server = null
    }

    private fun startStub(): String {
        val httpServer = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server = httpServer
        httpServer.createContext("/") { exchange ->
            val path = exchange.requestURI.path
            val query = exchange.requestURI.query ?: ""
            val requestBody = exchange.requestBody.readBytes().toString(StandardCharsets.ISO_8859_1)
            val contentType = exchange.requestHeaders.getFirst("Content-Type") ?: ""
            requests.add("${exchange.requestMethod} $path?$query|$contentType|$requestBody")

            val (status, body, type) = when {
                path == "/api/v1/invoices/0001/history" ->
                    Triple(200, """{"success":true,"history":$historyJson}""", "application/json")
                path == "/api/v1/invoices/0001/links" && exchange.requestMethod == "POST" ->
                    Triple(201, """{"success":true,"link_id":7,"history":$historyJson}""", "application/json")
                path == "/api/v1/invoices/0001/notes" && exchange.requestMethod == "POST" ->
                    Triple(201, """{"success":true,"note_id":5,"history":$historyJson}""", "application/json")
                path == "/api/v1/invoices/0001/notes/attachments/9" ->
                    Triple(200, "%PDF-1.4 stub", "application/pdf")
                path == "/api/v1/invoices/0002/links" ->
                    Triple(400, """{"error":"Choose a valid relation type."}""", "application/json")
                else -> Triple(404, """{"error":"Not found"}""", "application/json")
            }
            exchange.responseHeaders.add("Content-Type", type)
            val bytes = body.toByteArray(StandardCharsets.UTF_8)
            exchange.sendResponseHeaders(status, bytes.size.toLong())
            exchange.responseBody.use { it.write(bytes) }
        }
        httpServer.start()
        return "http://127.0.0.1:${httpServer.address.port}"
    }

    private fun connectedApi(baseUrl: String): ApiService {
        val api = ApiService()
        api.configure(Connection(baseUrl = baseUrl, apiKey = "test-key"))
        return api
    }

    @Test
    fun historyIsParsedIncludingExclusionChoiceAndAttachments() = runTest {
        val api = connectedApi(startStub())
        val history = api.getHistory("0001", 2)

        assertEquals("0001", history.invoice?.serialNumber)
        assertEquals(1, history.relations.size)
        val relation = history.relations.first()
        assertTrue(relation.merged)
        assertTrue("exclude choice must survive parsing", relation.excludeFromTotals)
        assertEquals(30.0, relation.mergedAmount ?: 0.0, 0.0001)
        assertEquals("0002", relation.other?.serialNumber)
        assertEquals(1, history.hiddenLinkCount)

        val note = history.notes.single()
        assertEquals("Customer called", note.body)
        assertTrue(note.canDelete)
        assertEquals("scan.pdf", note.attachments.single().fileName)
        assertEquals("application/pdf", note.attachments.single().mimeType)
        assertTrue(requests.any { it.startsWith("GET /api/v1/invoices/0001/history?batch_id=2|") })
    }

    @Test
    fun linkRequestCarriesBatchAndTheIncludeExcludeChoice() = runTest {
        val api = connectedApi(startStub())
        api.addLink(
            serial = "0001",
            batchId = 2,
            linkedSerial = "0002",
            linkedBatchId = null,
            linkType = "duplicate",
            amountAction = "merge",
            excludeFromTotals = true,
            linkNote = "re-issued",
        )
        val post = requests.single { it.startsWith("POST /api/v1/invoices/0001/links?batch_id=2|") }
        assertTrue(post.contains("application/json"))
        assertTrue(post.contains("\"exclude_from_totals\":true"))
        assertTrue(post.contains("\"amount_action\":\"merge\""))
        assertTrue(post.contains("\"linked_serial\":\"0002\""))
    }

    @Test
    fun noteSendsTextAndAnyDocumentTypeAsMultipart() = runTest {
        val api = connectedApi(startStub())
        val tmp = File.createTempFile("ledger-", ".xlsx")
        try {
            tmp.writeBytes(byteArrayOf(0x50, 0x4B, 0x03, 0x04))
            api.addNote(
                serial = "0001",
                batchId = 2,
                body = "Ledger attached",
                files = listOf(
                    PickedFile(
                        file = tmp,
                        displayName = "ledger.xlsx",
                        mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    ),
                ),
            )
        } finally {
            tmp.delete()
        }
        val post = requests.single { it.startsWith("POST /api/v1/invoices/0001/notes?batch_id=2|") }
        assertTrue(post.contains("multipart/form-data"))
        assertTrue(post.contains("name=\"body\""))
        assertTrue(post.contains("Ledger attached"))
        assertTrue(post.contains("name=\"files\"; filename=\"ledger.xlsx\""))
    }

    @Test
    fun attachmentDownloadWritesTheFile() = runTest {
        val api = connectedApi(startStub())
        val dest = File.createTempFile("attachment-", ".pdf")
        try {
            api.downloadAttachment("0001", 2, 9, dest)
            assertEquals("%PDF-1.4 stub", dest.readText(StandardCharsets.UTF_8))
        } finally {
            dest.delete()
        }
    }

    @Test
    fun serverErrorMessageIsShownToTheUser() = runTest {
        val api = connectedApi(startStub())
        try {
            api.addLink("0002", 2, "0009", null, "bogus", "none", false, "")
            fail("expected ApiException")
        } catch (e: ApiException) {
            assertEquals(400, e.statusCode)
            assertEquals("Choose a valid relation type.", e.message)
        }
    }

    @Test
    fun relationOnlyLinkSendsExcludeFalse() = runTest {
        val api = connectedApi(startStub())
        api.addLink("0001", 2, "0002", null, "related", "none", false, "")
        val post = requests.single { it.startsWith("POST /api/v1/invoices/0001/links?batch_id=2|") }
        assertFalse(post.contains("\"exclude_from_totals\":true"))
        assertTrue(post.contains("\"exclude_from_totals\":false"))
    }
}
