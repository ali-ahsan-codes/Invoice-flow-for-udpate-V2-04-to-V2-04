package com.example

import com.example.data.CropSettings
import com.example.data.QrParser
import com.example.data.ScannedQr
import com.example.util.CropSelection
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun qrParser_connectionJson() {
    val raw = """{"app":"invoiceflow","type":"connect","version":1,"base_url":"http://server:5000","api_key":"test_key_123"}"""
    val result = QrParser.parse(raw)
    assertTrue(result is ScannedQr.Connection)
    val payload = (result as ScannedQr.Connection).payload
    assertEquals("http://server:5000", payload.baseUrl)
    assertEquals("test_key_123", payload.apiKey)
  }

  @Test
  fun qrParser_invoiceJson() {
    val raw = """{"type":"invoice","version":1,"serial":"1518","base_url":"http://server:5000"}"""
    val result = QrParser.parse(raw)
    assertTrue(result is ScannedQr.Invoice)
    val payload = (result as ScannedQr.Invoice).payload
    assertEquals("1518", payload.serial)
    assertEquals("http://server:5000", payload.baseUrl)
    assertEquals("auto", payload.scan)
  }

  @Test
  fun qrParser_invoiceJson_withScanFocus() {
    val raw = """{"type":"invoice","version":1,"serial":"1518","base_url":"http://server:5000","scan":"focus"}"""
    val result = QrParser.parse(raw)
    assertTrue(result is ScannedQr.Invoice)
    val payload = (result as ScannedQr.Invoice).payload
    assertEquals("1518", payload.serial)
    assertEquals("focus", payload.scan)
  }

  @Test
  fun qrParser_serverV2FocusQrKeepsBatchAndInvoiceIdentity() {
    val raw = """{"type":"invoice","version":2,"batch_id":2,"invoice_id":184,"serial":"0001","base_url":"https://invoice.example","scan":"focus"}"""
    val result = QrParser.parse(raw)
    assertTrue(result is ScannedQr.Invoice)
    val payload = (result as ScannedQr.Invoice).payload
    assertEquals(2, payload.version)
    assertEquals(2, payload.batchId)
    assertEquals(184, payload.invoiceId)
    assertEquals("0001", payload.serial)
    assertEquals("focus", payload.scan)
    assertEquals("https://invoice.example", payload.baseUrl)
  }

  @Test
  fun qrParser_acceptsStringBatchIdAndNormalizesScanHint() {
    val raw = """{"type":"invoice","batchId":"3","serial":"59","scan":"FOCUS"}"""
    val payload = (QrParser.parse(raw) as ScannedQr.Invoice).payload
    assertEquals(3, payload.batchId)
    assertEquals("focus", payload.scan)
  }

  @Test
  fun qrParser_webFallbackKeepsBatchIdFromQuery() {
    val result = QrParser.parse("https://invoice.example/media/m/0007?batch_id=4")
    assertTrue(result is ScannedQr.Invoice)
    val payload = (result as ScannedQr.Invoice).payload
    assertEquals("0007", payload.serial)
    assertEquals(4, payload.batchId)
  }

  @Test
  fun apiUrlBuilderCarriesBatchContextAndEncodesSerialSegment() {
    val url = com.example.data.buildApiUrl(
      "https://invoice.example/",
      listOf("api", "v1", "invoices", "A B#2"),
      batchId = 7,
    )
    assertEquals("/api/v1/invoices/A%20B%232", url.encodedPath)
    assertEquals("7", url.queryParameter("batch_id"))
  }

  @Test
  fun qrParser_oldInvoiceUrl() {
    val raw = "http://server:5000/media/m/1518"
    val result = QrParser.parse(raw)
    assertTrue(result is ScannedQr.Invoice)
    val payload = (result as ScannedQr.Invoice).payload
    assertEquals("1518", payload.serial)
  }

  @Test
  fun qrParser_bareSerial() {
    val result1 = QrParser.parse("1518")
    assertTrue(result1 is ScannedQr.Invoice)
    assertEquals("1518", (result1 as ScannedQr.Invoice).payload.serial)

    val result2 = QrParser.parse("#1518")
    assertTrue(result2 is ScannedQr.Invoice)
    assertEquals("1518", (result2 as ScannedQr.Invoice).payload.serial)
  }

  @Test
  fun qrParser_unknownPayload() {
    val result1 = QrParser.parse("""{"type":"other","foo":"bar"}""")
    assertTrue(result1 is ScannedQr.Unknown)

    val result2 = QrParser.parse("")
    assertTrue(result2 is ScannedQr.Unknown)
  }

  @Test
  fun cropSettings_clampedSelection() {
    val defaultSel = CropSelection()
    assertTrue(defaultSel.isFull)
    assertEquals(0f, defaultSel.left, 0.001f)
    assertEquals(0f, defaultSel.top, 0.001f)
    assertEquals(1f, defaultSel.right, 0.001f)
    assertEquals(1f, defaultSel.bottom, 0.001f)

    val sel = CropSelection(left = -0.1f, top = -0.2f, right = 1.5f, bottom = 1.3f)
    val clamped = sel.clamped()
    assertTrue(clamped.left >= 0f)
    assertTrue(clamped.top >= 0f)
    assertTrue(clamped.right <= 1f)
    assertTrue(clamped.bottom <= 1f)
    assertTrue(clamped.width > 0f)
    assertTrue(clamped.height > 0f)
  }

  @Test
  fun cropSettings_defaultValues() {
    val settings = CropSettings()
    assertTrue(settings.manualCropEnabled)
    assertFalse(settings.autoOpenHandles)
    assertTrue(settings.showGrid)
  }
}


