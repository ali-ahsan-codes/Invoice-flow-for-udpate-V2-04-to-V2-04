# InvoiceFlow release build currently disables minification; keep this file ready for explicit rules.
