package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ApiException
import com.example.data.ApiService
import com.example.data.Connection
import com.example.data.ConnectionStore
import com.example.data.CropSettings
import com.example.data.Invoice
import com.example.data.QrParser
import com.example.data.ScannedQr
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

sealed class UploadStatus {
    object Idle : UploadStatus()
    object Uploading : UploadStatus()
    object Success : UploadStatus()
    data class Failed(val message: String) : UploadStatus()
}

/**
 * AUTO  — the original behaviour: scanning an invoice QR replaces whatever
 *         is currently loaded. Search + continuous scanning auto-advance.
 * FOCUS — locks onto the current invoice until the user advances or switches mode.
 */
enum class ScanMode { AUTO, FOCUS }

data class UiState(
    val connection: Connection? = null,
    val loading: Boolean = false,
    val error: String? = null,
    val currentInvoice: Invoice? = null,
    val nextInvoice: Invoice? = null,
    val uploadStatus: UploadStatus = UploadStatus.Idle,
    val searchResults: List<Invoice> = emptyList(),
    val scanMode: ScanMode = ScanMode.AUTO,
    val toastMessage: String? = null,
    val dateFormat: String = "YYYY-MM-DD",
    val cropSettings: CropSettings = CropSettings(),
    val pendingCropPhoto: File? = null,
    val showCropSettingsModal: Boolean = false,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ConnectionStore(app)
    private val api = ApiService()

    // Camera analysis can deliver the same code repeatedly, and network replies may
    // arrive out of order. Track the active target and ignore stale completions.
    private var invoiceLoadGeneration = 0L
    private var loadingSerial: String? = null
    private var loadingBatchId: Int? = null

    private val _state = MutableStateFlow(UiState(cropSettings = store.loadCropSettings()))
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        store.load()?.let { saved ->
            api.configure(saved)
            _state.value = _state.value.copy(
                connection = saved,
                cropSettings = store.loadCropSettings()
            )
        }
    }

    // ----------------------------------------------------------------
    // Crop & Scanner Settings
    // ----------------------------------------------------------------

    fun openCropSettingsModal() {
        _state.value = _state.value.copy(showCropSettingsModal = true)
    }

    fun closeCropSettingsModal() {
        _state.value = _state.value.copy(showCropSettingsModal = false)
    }

    fun updateCropSettings(settings: CropSettings) {
        store.saveCropSettings(settings)
        _state.value = _state.value.copy(cropSettings = settings)
    }

    fun toggleManualCropEnabled() {
        val updated = _state.value.cropSettings.copy(
            manualCropEnabled = !_state.value.cropSettings.manualCropEnabled
        )
        updateCropSettings(updated)
    }

    fun toggleAutoOpenHandles() {
        val updated = _state.value.cropSettings.copy(
            autoOpenHandles = !_state.value.cropSettings.autoOpenHandles
        )
        updateCropSettings(updated)
    }

    // ----------------------------------------------------------------
    // Pending Photo for Cropping
    // ----------------------------------------------------------------

    fun setPendingCropPhoto(file: File?) {
        _state.value = _state.value.copy(pendingCropPhoto = file)
    }

    fun cancelCrop() {
        _state.value.pendingCropPhoto?.let { f ->
            try { f.delete() } catch (_: Exception) {}
        }
        _state.value = _state.value.copy(pendingCropPhoto = null)
    }

    // ----------------------------------------------------------------
    // Connection — only accepts a Connection QR
    // ----------------------------------------------------------------

    fun connect(rawQr: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            try {
                val parsed = QrParser.parse(rawQr)
                val payload = when (parsed) {
                    is ScannedQr.Connection -> parsed.payload
                    is ScannedQr.Invoice -> throw IllegalArgumentException(
                        "This is an invoice QR. Please scan the connection QR from your Profile page."
                    )
                    ScannedQr.Unknown -> throw IllegalArgumentException(
                        "QR code not recognized. Scan the connection QR from your Profile page."
                    )
                }

                val tempConn = Connection(
                    baseUrl = payload.baseUrl,
                    apiKey = payload.apiKey,
                )
                val me = api.ping(tempConn)
                val conn = tempConn.copy(
                    userId = me.id,
                    username = me.username,
                    role = me.role,
                )
                api.configure(conn)
                store.save(conn)
                _state.value = _state.value.copy(
                    connection = conn,
                    loading = false,
                    scanMode = ScanMode.AUTO,
                    dateFormat = me.dateFormat,
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    loading = false,
                    error = e.message ?: "Could not connect",
                )
            }
        }
    }

    fun connectDirect(baseUrl: String, apiKey: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            try {
                val tempConn = Connection(
                    baseUrl = baseUrl.trim(),
                    apiKey = apiKey.trim(),
                )
                val me = api.ping(tempConn)
                val conn = tempConn.copy(
                    userId = me.id,
                    username = me.username,
                    role = me.role,
                )
                api.configure(conn)
                store.save(conn)
                _state.value = _state.value.copy(
                    connection = conn,
                    loading = false,
                    scanMode = ScanMode.AUTO,
                    dateFormat = me.dateFormat,
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    loading = false,
                    error = e.message ?: "Could not connect",
                )
            }
        }
    }

    fun disconnect() {
        invoiceLoadGeneration++
        loadingSerial = null
        loadingBatchId = null
        store.clear()
        api.clear()
        _state.value = UiState(cropSettings = store.loadCropSettings())
    }

    // ----------------------------------------------------------------
    // Scan mode
    // ----------------------------------------------------------------

    fun setScanMode(mode: ScanMode) {
        if (_state.value.scanMode == mode) return
        _state.value = _state.value.copy(
            scanMode = mode,
            toastMessage = when (mode) {
                ScanMode.FOCUS -> "Focus mode — locked to current invoice."
                ScanMode.AUTO  -> "Auto mode — captures advance to next invoice."
            },
        )
    }

    fun toggleScanMode() {
        val newMode =
            if (_state.value.scanMode == ScanMode.AUTO) ScanMode.FOCUS else ScanMode.AUTO
        setScanMode(newMode)
    }

    /**
     * Handle a scan from a server QR or a legacy barcode. V2 server QRs carry
     * batch_id because serials may be repeated in different batches. A focus QR
     * is authoritative: it must switch the UI into FOCUS even when its invoice
     * is already displayed.
     */
    fun handleQrScan(serial: String, scanHint: String = "auto", batchId: Int? = null) {
        val cleanSerial = serial.trim().trimStart('#').trim()
        if (cleanSerial.isEmpty()) return
        val safeBatchId = batchId?.takeIf { it > 0 }
        val s = _state.value

        if (scanHint.trim().equals("focus", ignoreCase = true)) {
            val changedMode = s.scanMode != ScanMode.FOCUS
            _state.value = s.copy(
                scanMode = ScanMode.FOCUS,
                toastMessage = if (changedMode) "Focus mode — locked to #$cleanSerial." else s.toastMessage,
            )
            if (!sameInvoiceTarget(s.currentInvoice, cleanSerial, safeBatchId) &&
                !sameLoadingTarget(cleanSerial, safeBatchId)
            ) {
                loadInvoice(cleanSerial, safeBatchId)
            }
            return
        }

        when (s.scanMode) {
            ScanMode.AUTO -> {
                if (!sameInvoiceTarget(s.currentInvoice, cleanSerial, safeBatchId) &&
                    !sameLoadingTarget(cleanSerial, safeBatchId)
                ) {
                    loadInvoice(cleanSerial, safeBatchId)
                }
            }
            ScanMode.FOCUS -> {
                when {
                    s.currentInvoice == null -> {
                        if (!sameLoadingTarget(cleanSerial, safeBatchId)) {
                            loadInvoice(cleanSerial, safeBatchId)
                        }
                    }
                    sameInvoiceTarget(s.currentInvoice, cleanSerial, safeBatchId) -> { /* stay focused */ }
                    else -> _state.value = s.copy(
                        toastMessage =
                            "Locked to #${s.currentInvoice.serialNumber}. " +
                            "Tap Next Invoice or scan a Focus QR to switch.",
                    )
                }
            }
        }
    }

    private fun sameInvoiceTarget(invoice: Invoice?, serial: String, batchId: Int?): Boolean {
        if (invoice == null || invoice.serialNumber.trim() != serial) return false
        return batchId == null || invoice.batchId == batchId
    }

    private fun sameLoadingTarget(serial: String, batchId: Int?): Boolean =
        _state.value.loading && loadingSerial == serial && loadingBatchId == batchId

    // ----------------------------------------------------------------
    // Load
    // ----------------------------------------------------------------

    fun loadInvoice(serial: String, batchId: Int? = null) {
        val cleanSerial = serial.trim().trimStart('#').trim()
        if (cleanSerial.isEmpty()) return
        val cleanBatchId = batchId?.takeIf { it > 0 }

        if (sameLoadingTarget(cleanSerial, cleanBatchId)) return
        val requestGeneration = ++invoiceLoadGeneration
        loadingSerial = cleanSerial
        loadingBatchId = cleanBatchId

        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            try {
                val invoice = api.getInvoice(cleanSerial, cleanBatchId)
                val resolvedBatchId = invoice.batchId ?: cleanBatchId
                val next = api.getNextInvoice(invoice.serialNumber, resolvedBatchId)
                if (requestGeneration != invoiceLoadGeneration) return@launch
                loadingSerial = null
                loadingBatchId = null
                _state.value = _state.value.copy(
                    loading = false,
                    currentInvoice = invoice,
                    nextInvoice = next,
                    uploadStatus = UploadStatus.Idle,
                )
            } catch (e: ApiException) {
                if (requestGeneration != invoiceLoadGeneration) return@launch
                loadingSerial = null
                loadingBatchId = null
                _state.value = _state.value.copy(
                    loading = false,
                    error = e.message,
                    currentInvoice = null,
                    nextInvoice = null,
                )
            } catch (e: Exception) {
                if (requestGeneration != invoiceLoadGeneration) return@launch
                loadingSerial = null
                loadingBatchId = null
                _state.value = _state.value.copy(
                    loading = false,
                    error = e.message ?: "Failed to load invoice",
                    currentInvoice = null,
                    nextInvoice = null,
                )
            }
        }
    }

    fun advanceToNextInvoice() {
        val next = _state.value.nextInvoice
        if (next != null) {
            loadInvoice(next.serialNumber, next.batchId)
        } else {
            _state.value = _state.value.copy(
                toastMessage = "No next invoice available.",
            )
        }
    }

    // ----------------------------------------------------------------
    // Search
    // ----------------------------------------------------------------

    fun search(query: String, date: String? = null) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            try {
                val results = api.listInvoices(query = query, date = date)
                _state.value = _state.value.copy(loading = false, searchResults = results)
                if (results.size == 1) {
                    loadInvoice(results.first().serialNumber, results.first().batchId)
                }
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    loading = false,
                    error = e.message ?: "Search failed",
                )
            }
        }
    }

    // ----------------------------------------------------------------
    // Media upload
    // ----------------------------------------------------------------

    fun uploadMedia(
        serial: String,
        batchId: Int?,
        file: File,
        autoAdvance: Boolean = true,
    ) {
        val cleanSerial = serial.trim().trimStart('#').trim()
        val cleanBatchId = batchId?.takeIf { it > 0 }
        viewModelScope.launch {
            _state.value = _state.value.copy(
                uploadStatus = UploadStatus.Uploading,
                pendingCropPhoto = null,
            )
            try {
                val resp = api.uploadMedia(cleanSerial, cleanBatchId, file)
                val previousInvoice = _state.value.currentInvoice
                val updated = resp.invoice ?: previousInvoice?.copy(
                    mediaCount = resp.mediaCount,
                    hasMedia = true,
                )
                _state.value = _state.value.copy(
                    uploadStatus = UploadStatus.Success,
                    currentInvoice = updated,
                )

                val resolvedBatchId = updated?.batchId ?: cleanBatchId
                val next = api.getNextInvoice(cleanSerial, resolvedBatchId)
                _state.value = _state.value.copy(nextInvoice = next)

                val shouldAdvance = autoAdvance &&
                    _state.value.scanMode == ScanMode.AUTO &&
                    next != null

                if (shouldAdvance) {
                    delay(550)
                    loadInvoice(next!!.serialNumber, next.batchId ?: resolvedBatchId)
                }
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    uploadStatus = UploadStatus.Failed(e.message ?: "Upload failed"),
                )
            }
        }
    }

    // ----------------------------------------------------------------
    // Small helpers
    // ----------------------------------------------------------------

    fun clearUploadStatus() {
        _state.value = _state.value.copy(uploadStatus = UploadStatus.Idle)
    }

    fun clearError() {
        _state.value = _state.value.copy(error = null)
    }

    fun clearSearchResults() {
        _state.value = _state.value.copy(searchResults = emptyList())
    }

    fun clearToast() {
        _state.value = _state.value.copy(toastMessage = null)
    }
}
