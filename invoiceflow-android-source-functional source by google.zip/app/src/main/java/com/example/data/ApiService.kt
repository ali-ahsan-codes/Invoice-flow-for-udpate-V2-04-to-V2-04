package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

class ApiException(message: String, val statusCode: Int = 0) : Exception(message)

/** Shared URL builder; all invoice-specific API calls retain batch context. */
internal fun buildApiUrl(
    rawBaseUrl: String,
    pathSegments: List<String>,
    batchId: Int? = null,
    queryParameters: Map<String, String> = emptyMap(),
): HttpUrl {
    val builder = rawBaseUrl.trim().trimEnd('/').toHttpUrlOrNull()?.newBuilder()
        ?: throw ApiException("Invalid server URL. Include http:// or https://.")

    pathSegments.forEach { segment -> builder.addPathSegment(segment) }
    batchId?.takeIf { it > 0 }?.let { builder.addQueryParameter("batch_id", it.toString()) }
    queryParameters.forEach { (key, value) -> builder.addQueryParameter(key, value) }
    return builder.build()
}

class ApiService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private var connection: Connection? = null

    fun configure(c: Connection) {
        connection = c
    }

    fun clear() {
        connection = null
    }

    fun isConnected(): Boolean = connection != null

    private fun baseUrl(): String {
        return connection?.baseUrl?.trim()
            ?: throw ApiException("Not connected")
    }

    private fun authedRequest(
        pathSegments: List<String>,
        batchId: Int? = null,
        queryParameters: Map<String, String> = emptyMap(),
    ): Request.Builder {
        val url = buildApiUrl(baseUrl(), pathSegments, batchId, queryParameters)
        return Request.Builder()
            .url(url)
            .addHeader("X-API-Key", connection?.apiKey?.trim() ?: "")
            .addHeader("Accept", "application/json")
    }

    suspend fun ping(c: Connection): Me = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url(buildApiUrl(c.baseUrl, listOf("api", "v1", "me")))
            .addHeader("X-API-Key", c.apiKey.trim())
            .addHeader("Accept", "application/json")
            .build()
        val resp = client.newCall(req).execute()
        val body = resp.body?.string() ?: ""
        when (resp.code) {
            200 -> {
                val json = JSONObject(body)
                Me(
                    id = json.optInt("id", 0),
                    username = json.optString("username", ""),
                    email = json.optString("email", ""),
                    role = json.optString("role", ""),
                    canExport = json.optBoolean("can_export", json.optBoolean("canExport", false)),
                    dateFormat = json.optString("date_format", json.optString("dateFormat", "YYYY-MM-DD")),
                )
            }
            401 -> throw ApiException("Invalid API key", 401)
            else -> throw ApiException("Server error (${resp.code})", resp.code)
        }
    }

    suspend fun getInvoice(serial: String, batchId: Int? = null): Invoice = withContext(Dispatchers.IO) {
        val cleanSerial = cleanSerial(serial)
        val req = authedRequest(listOf("api", "v1", "invoices", cleanSerial), batchId).build()
        val resp = client.newCall(req).execute()
        val body = resp.body?.string() ?: ""
        when (resp.code) {
            200 -> parseInvoice(JSONObject(body))
            404 -> throw ApiException("Invoice #$cleanSerial not found", 404)
            401 -> throw ApiException("Invalid API key", 401)
            409 -> throw ApiException(
                "The server found more than one invoice #$cleanSerial. Scan its batch-aware QR code again or reconnect to the correct server.",
                409,
            )
            else -> throw ApiException("Error (${resp.code}): $body", resp.code)
        }
    }

    suspend fun getNextInvoice(serial: String, batchId: Int? = null): Invoice? = withContext(Dispatchers.IO) {
        try {
            val cleanSerial = cleanSerial(serial)
            val req = authedRequest(
                listOf("api", "v1", "invoices", cleanSerial, "next"),
                batchId,
            ).build()
            val resp = client.newCall(req).execute()
            if (resp.code != 200) return@withContext null
            val body = resp.body?.string() ?: ""
            parseInvoice(JSONObject(body))
        } catch (_: Exception) {
            null
        }
    }

    suspend fun listInvoices(
        query: String? = null,
        date: String? = null,
        batchId: Int? = null,
    ): List<Invoice> = withContext(Dispatchers.IO) {
        val params = linkedMapOf<String, String>()
        if (!query.isNullOrBlank()) params["q"] = query.trim()
        if (!date.isNullOrBlank()) params["date"] = date.trim()
        val req = authedRequest(
            pathSegments = listOf("api", "v1", "invoices"),
            batchId = batchId,
            queryParameters = params,
        ).build()
        val resp = client.newCall(req).execute()
        val body = resp.body?.string() ?: ""
        if (resp.code >= 400) {
            throw ApiException("Error (${resp.code}): $body", resp.code)
        }

        val resultList = mutableListOf<Invoice>()
        val trimmed = body.trim()
        if (trimmed.startsWith("[")) {
            val array = JSONArray(trimmed)
            for (i in 0 until array.length()) resultList.add(parseInvoice(array.getJSONObject(i)))
        } else if (trimmed.startsWith("{")) {
            val obj = JSONObject(trimmed)
            val array = obj.optJSONArray("invoices") ?: JSONArray()
            for (i in 0 until array.length()) resultList.add(parseInvoice(array.getJSONObject(i)))
        }
        resultList
    }

    suspend fun uploadMedia(
        serial: String,
        batchId: Int?,
        file: File,
        mimeType: String = "image/jpeg",
    ): UploadResponse = withContext(Dispatchers.IO) {
        val cleanSerial = cleanSerial(serial)
        val body = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", file.name, file.asRequestBody(mimeType.toMediaType()))
            .build()
        val req = authedRequest(
            pathSegments = listOf("api", "v1", "invoices", cleanSerial, "media"),
            batchId = batchId,
        )
            .post(body)
            .build()
        val resp = client.newCall(req).execute()
        val respBody = resp.body?.string() ?: ""
        when (resp.code) {
            200, 201 -> {
                val json = JSONObject(respBody)
                val invObj = json.optJSONObject("invoice")
                val parsedInv = if (invObj != null) parseInvoice(invObj) else null
                UploadResponse(
                    success = json.optBoolean("success", true),
                    mediaId = json.optInt("media_id", json.optInt("mediaId", 0)),
                    filename = json.optString("filename", file.name),
                    mediaCount = json.optInt("media_count", json.optInt("mediaCount", 0)),
                    invoice = parsedInv,
                )
            }
            404 -> throw ApiException("Invoice #$cleanSerial not found", 404)
            401 -> throw ApiException("Invalid API key", 401)
            409 -> throw ApiException(
                "Invoice #$cleanSerial is ambiguous on the server. Rescan its batch-aware QR code before uploading.",
                409,
            )
            else -> throw ApiException("Upload failed (${resp.code}): $respBody", resp.code)
        }
    }

    private fun parseInvoice(obj: JSONObject): Invoice {
        val amountsList = mutableListOf<Double>()
        val arr = obj.optJSONArray("amounts")
        if (arr != null) {
            for (i in 0 until arr.length()) amountsList.add(arr.optDouble(i, 0.0))
        }

        val bookVal = if (obj.has("book") && !obj.isNull("book")) obj.optInt("book") else null
        val pageVal = if (obj.has("page") && !obj.isNull("page")) obj.optInt("page") else null
        val mediaCount = obj.optInt("media_count", obj.optInt("mediaCount", 0))
        val hasMedia = obj.optBoolean("has_media", obj.optBoolean("hasMedia", mediaCount > 0))
        val mediaRequired = obj.optBoolean("media_required", obj.optBoolean("mediaRequired", false))
        val dateDisplay = obj.optString("date_display", obj.optString("dateDisplay", ""))
        val dateFormat = obj.optString("date_format", obj.optString("dateFormat", ""))
        val batchId = obj.optInt("batch_id", obj.optInt("batchId", 0)).takeIf { it > 0 }

        return Invoice(
            id = obj.optInt("id", 0),
            serialNumber = obj.optString("serial_number", obj.optString("serialNumber", "")),
            date = obj.optString("date", ""),
            dateDisplay = dateDisplay,
            dateFormat = dateFormat,
            book = bookVal,
            page = pageVal,
            totalAmount = obj.optDouble("total_amount", obj.optDouble("totalAmount", 0.0)),
            amounts = amountsList,
            mediaCount = mediaCount,
            hasMedia = hasMedia,
            mediaRequired = mediaRequired,
            batchId = batchId,
        )
    }

    private fun cleanSerial(serial: String): String = serial.trim().trimStart('#').trim()
}
