package com.example.data

import java.io.File

data class Connection(
    val baseUrl: String,
    val apiKey: String,
    val userId: Int = 0,
    val username: String = "",
    val role: String = "",
)

/**
 * Payload of the connection QR (shown on the web Profile page).
 * Example:
 *   {"app":"invoiceflow","type":"connect","version":1,
 *    "base_url":"http://server:5000","api_key":"..."}
 */
data class ConnectionQrPayload(
    val app: String = "",
    val type: String = "",
    val version: Int = 1,
    val baseUrl: String,
    val apiKey: String,
)

/**
 * Payload of a per-invoice QR.
 *
 * scan = "auto"  → app loads the invoice and stays in AUTO mode (auto-advance)
 * scan = "focus" → app loads the invoice and locks onto it (FOCUS mode)
 */
data class InvoiceQrPayload(
    val type: String = "invoice",
    val version: Int = 1,
    val serial: String,
    val baseUrl: String = "",
    val scan: String = "auto",
    /** The server includes this in v2 QR payloads so repeated serials in different batches resolve safely. */
    val batchId: Int? = null,
    /** Kept for diagnostics/future ID-addressed routes; the current API resolves by serial + batch. */
    val invoiceId: Int? = null,
    /**
     * "invoice" (default) → normal document upload for this invoice.
     * "note"              → open this invoice's Notes sheet and save the picked files as a note attachment.
     */
    val target: String = "invoice",
)

data class Me(
    val id: Int,
    val username: String,
    val email: String = "",
    val role: String = "",
    val canExport: Boolean = false,
    val dateFormat: String = "YYYY-MM-DD",
    /** Per-function switches set by the admin (server key -> allowed). Missing key = allowed. */
    val capabilities: Map<String, Boolean> = emptyMap(),
) {
    fun allows(capability: String): Boolean = capabilities[capability] ?: true
}

/** Capability keys. Must match app/permissions.py on the server. */
object Cap {
    const val MOBILE_ACCESS = "mobile.access"
    const val MEDIA_UPLOAD = "media.upload"
    const val MEDIA_DELETE = "media.delete"
    const val NOTES_CREATE = "notes.create"
    const val NOTES_DELETE = "notes.delete"
    const val LINKS_CREATE = "links.create"
    const val LINKS_DELETE = "links.delete"

    /** Readable name used in messages shown to the clerk. */
    fun label(capability: String): String = when (capability) {
        MOBILE_ACCESS -> "use the mobile app"
        MEDIA_UPLOAD -> "upload documents"
        MEDIA_DELETE -> "delete documents"
        NOTES_CREATE -> "add notes"
        NOTES_DELETE -> "delete notes"
        LINKS_CREATE -> "link invoices"
        LINKS_DELETE -> "remove links"
        else -> capability
    }

    fun deniedMessage(capability: String): String =
        "Your admin has not allowed you to ${label(capability)}."
}

data class Invoice(
    val id: Int,
    val serialNumber: String,
    val date: String,
    val dateDisplay: String = "",
    val dateFormat: String = "",
    val book: Int? = null,
    val page: Int? = null,
    val totalAmount: Double,
    val amounts: List<Double> = emptyList(),
    val mediaCount: Int = 0,
    val hasMedia: Boolean = false,
    val mediaRequired: Boolean = false,
    /** Batch identity is required for unambiguous lookups and uploads on multi-batch servers. */
    val batchId: Int? = null,
)

data class InvoiceListResponse(
    val invoices: List<Invoice> = emptyList(),
    val dateFormat: String = "YYYY-MM-DD",
)

data class UploadResponse(
    val success: Boolean,
    val mediaId: Int = 0,
    val filename: String = "",
    val mediaCount: Int = 0,
    val invoice: Invoice? = null,
)

/**
 * Settings for cropping and photo review
 */
data class CropSettings(
    val manualCropEnabled: Boolean = true,
    val autoOpenHandles: Boolean = false,
    val showGrid: Boolean = true,
)

// ---------------------------------------------------------------
// Invoice history: notes, attachments and relations (mobile API v1)
// ---------------------------------------------------------------

/** Compact invoice reference used inside relations. */
data class InvoiceSummary(
    val id: Int,
    val batchId: Int? = null,
    val batch: String = "",
    val serialNumber: String,
    val date: String = "",
    val totalAmount: Double = 0.0,
    val createdBy: String = "",
)

/**
 * One relation of the current invoice to another invoice.
 * [excludeFromTotals] is only meaningful for merged relations: true means the other invoice's
 * amount is counted only once (on the receiving invoice) in reports.
 */
data class InvoiceRelation(
    val id: Int,
    val linkType: String,
    val relation: String,
    val amountAction: String,
    val merged: Boolean,
    val receiverSide: Boolean,
    val mergedAmount: Double? = null,
    val excludeFromTotals: Boolean = false,
    val note: String = "",
    val createdBy: String? = null,
    val canUnlink: Boolean = false,
    val other: InvoiceSummary? = null,
)

data class NoteAttachment(
    val id: Int,
    val fileName: String,
    val fileSize: Long = 0L,
    val mimeType: String = "application/octet-stream",
    val uploadedBy: String? = null,
    val uploadedAt: String? = null,
)

data class InvoiceNote(
    val id: Int,
    val invoiceId: Int,
    val invoiceSerial: String? = null,
    val isOwn: Boolean = true,
    val body: String = "",
    val author: String? = null,
    val createdAt: String? = null,
    val canDelete: Boolean = false,
    val attachments: List<NoteAttachment> = emptyList(),
)

data class InvoiceHistory(
    val invoice: InvoiceSummary? = null,
    val relations: List<InvoiceRelation> = emptyList(),
    val hiddenLinkCount: Int = 0,
    val notes: List<InvoiceNote> = emptyList(),
)

/** A document chosen by the user (any file type), copied into the app cache and ready to upload. */
data class PickedFile(
    val file: File,
    val displayName: String,
    val mimeType: String,
)
