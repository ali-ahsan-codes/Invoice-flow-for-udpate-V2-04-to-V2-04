package com.example.data

data class Connection(
    val baseUrl: String,
    val apiKey: String,
    val userId: Int = 0,
    val username: String = "",
    val role: String = "",
)

/**
 * Payload of the connection QR (shown on the web Profile page).
 * Example:
 *   {"app":"invoiceflow","type":"connect","version":1,
 *    "base_url":"http://server:5000","api_key":"..."}
 */
data class ConnectionQrPayload(
    val app: String = "",
    val type: String = "",
    val version: Int = 1,
    val baseUrl: String,
    val apiKey: String,
)

/**
 * Payload of a per-invoice QR.
 *
 * scan = "auto"  → app loads the invoice and stays in AUTO mode (auto-advance)
 * scan = "focus" → app loads the invoice and locks onto it (FOCUS mode)
 */
data class InvoiceQrPayload(
    val type: String = "invoice",
    val version: Int = 1,
    val serial: String,
    val baseUrl: String = "",
    val scan: String = "auto",
    /** The server includes this in v2 QR payloads so repeated serials in different batches resolve safely. */
    val batchId: Int? = null,
    /** Kept for diagnostics/future ID-addressed routes; the current API resolves by serial + batch. */
    val invoiceId: Int? = null,
)

data class Me(
    val id: Int,
    val username: String,
    val email: String = "",
    val role: String = "",
    val canExport: Boolean = false,
    val dateFormat: String = "YYYY-MM-DD",
)

data class Invoice(
    val id: Int,
    val serialNumber: String,
    val date: String,
    val dateDisplay: String = "",
    val dateFormat: String = "",
    val book: Int? = null,
    val page: Int? = null,
    val totalAmount: Double,
    val amounts: List<Double> = emptyList(),
    val mediaCount: Int = 0,
    val hasMedia: Boolean = false,
    val mediaRequired: Boolean = false,
    /** Batch identity is required for unambiguous lookups and uploads on multi-batch servers. */
    val batchId: Int? = null,
)

data class InvoiceListResponse(
    val invoices: List<Invoice> = emptyList(),
    val dateFormat: String = "YYYY-MM-DD",
)

data class UploadResponse(
    val success: Boolean,
    val mediaId: Int = 0,
    val filename: String = "",
    val mediaCount: Int = 0,
    val invoice: Invoice? = null,
)

/**
 * Settings for cropping and photo review
 */
data class CropSettings(
    val manualCropEnabled: Boolean = true,
    val autoCropEnabled: Boolean = false,
    val autoDetectSensitivity: Float = 0.5f,
    val autoOpenHandles: Boolean = false,
    val showGrid: Boolean = true,
)
