package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.Invoice
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchResultsSheet(
    results: List<Invoice>,
    onPick: (Invoice) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("search_results_sheet")
    ) {
        Text(
            text = "${results.size} result(s)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
        )
        LazyColumn(
            contentPadding = PaddingValues(bottom = 32.dp),
            modifier = Modifier.testTag("search_results_list")
        ) {
            items(results, key = { it.id }) { inv ->
                ListItem(
                    modifier = Modifier
                        .clickable { onPick(inv) }
                        .testTag("search_result_item_${inv.serialNumber}"),
                    headlineContent = {
                        Text(
                            text = "#${inv.serialNumber}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    supportingContent = {
                        val displayDate = inv.dateDisplay.ifBlank { inv.date }
                        Text("$displayDate  ·  OMR %.3f".format(inv.totalAmount))
                    },
                    trailingContent = {
                        Text(
                            text = if (inv.hasMedia) "✓ attached" else "— no media",
                            color = if (inv.hasMedia) SuccessGreen else TextMuted,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                )
                HorizontalDivider()
            }
        }
    }
}
