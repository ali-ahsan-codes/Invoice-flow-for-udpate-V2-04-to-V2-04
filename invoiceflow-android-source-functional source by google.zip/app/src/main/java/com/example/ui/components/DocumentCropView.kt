package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CropSettings
import com.example.ui.theme.BluePrimary
import com.example.util.CropSelection
import com.example.util.ImageCropUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

enum class DragHandle {
    NONE,
    TOP_LEFT,
    TOP_RIGHT,
    BOTTOM_RIGHT,
    BOTTOM_LEFT,
    EDGE_TOP,
    EDGE_BOTTOM,
    EDGE_LEFT,
    EDGE_RIGHT,
    CENTER_BODY
}

@Composable
fun DocumentCropScreen(
    imageFile: File,
    cropSettings: CropSettings,
    onConfirmCrop: (File) -> Unit,
    onCancel: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var rotationDegrees by remember { mutableIntStateOf(0) }
    var cropSelection by remember { mutableStateOf(CropSelection(0f, 0f, 1f, 1f)) }
    var isCropActive by remember { mutableStateOf(cropSettings.autoOpenHandles) }
    var isProcessing by remember { mutableStateOf(false) }

    // Decode preview bitmap once without duplicate orientation fixes
    LaunchedEffect(imageFile) {
        withContext(Dispatchers.IO) {
            try {
                val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(imageFile.absolutePath, boundsOpts)

                val sampleSize = max(1, min(boundsOpts.outWidth / 1280, boundsOpts.outHeight / 1280))
                val decodeOpts = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                val bmp = BitmapFactory.decodeFile(imageFile.absolutePath, decodeOpts)
                previewBitmap = bmp
                cropSelection = CropSelection(0f, 0f, 1f, 1f)
                isCropActive = cropSettings.autoOpenHandles
            } catch (_: Exception) {}
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF14111E))
            .testTag("document_crop_screen")
    ) {
        val bmp = previewBitmap
        if (bmp == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color.White)
            }
            return
        }

        val cachedImageBitmap = remember(bmp) { bmp.asImageBitmap() }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // ---------------- Top Bar ----------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onCancel,
                        modifier = Modifier.testTag("crop_cancel_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Cancel", tint = Color.White)
                    }
                    Spacer(Modifier.width(4.dp))
                    Column {
                        Text(
                            text = if (isCropActive) "Adjust Crop Area" else "Review Captured Photo",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isCropActive) "Freely drag corner handles to frame invoice" else "Complete raw photo as captured. No crop applied.",
                            color = Color.White.copy(alpha = 0.75f),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Rotate 90°
                    IconButton(
                        onClick = { rotationDegrees = (rotationDegrees + 90) % 360 },
                        modifier = Modifier.testTag("crop_rotate_button")
                    ) {
                        Icon(Icons.Default.RotateRight, contentDescription = "Rotate", tint = Color.White)
                    }

                    // Open Settings Modal
                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier.testTag("crop_open_settings_button")
                    ) {
                        Icon(Icons.Default.Tune, contentDescription = "Settings", tint = Color.White)
                    }
                }
            }

            // ---------------- Photo Display with Overlay ----------------
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                InteractiveCropCanvas(
                    imageBitmap = cachedImageBitmap,
                    rotationDegrees = rotationDegrees,
                    cropSelection = cropSelection,
                    isCroppingActive = isCropActive,
                    onCropChange = { newCrop -> cropSelection = newCrop },
                    showGrid = cropSettings.showGrid && isCropActive,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // ---------------- Bottom Action Bar ----------------
            Surface(
                color = Color(0xFF1E182D),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    // Secondary action bar
                    if (!isCropActive) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Crop Manually button
                            FilledTonalButton(
                                onClick = {
                                    isCropActive = true
                                    // Start with a comfortable frame that gives ample room to grab corners
                                    cropSelection = CropSelection(0.06f, 0.06f, 0.94f, 0.94f)
                                    Toast.makeText(context, "Crop handles active. Freely drag any corner.", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                                    .testTag("enable_manual_crop_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color(0xFF33274E),
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(Icons.Default.Crop, null, modifier = Modifier.size(17.dp), tint = Color(0xFFC0A4FF))
                                Spacer(Modifier.width(6.dp))
                                Text("Crop Manually", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            }

                            // Auto-Detect Document button (if auto crop enabled)
                            if (cropSettings.autoCropEnabled) {
                                FilledTonalButton(
                                    onClick = {
                                        val detected = ImageCropUtils.detectDocumentEdges(bmp, cropSettings.autoDetectSensitivity)
                                        cropSelection = detected
                                        isCropActive = true
                                        Toast.makeText(context, "Detected edges. Adjust handles freely.", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(46.dp)
                                        .testTag("crop_auto_detect_button"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = Color(0xFF263A50),
                                        contentColor = Color.White
                                    )
                                ) {
                                    Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(16.dp), tint = Color(0xFF7DD3FC))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Auto-Detect", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                }
                            }
                        }
                    } else {
                        // When Crop is active: Full Frame, Auto-detect (optional), and Cancel Crop buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilledTonalButton(
                                onClick = {
                                    cropSelection = CropSelection(0f, 0f, 1f, 1f)
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("crop_reset_handles_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color(0xFF33274E),
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(Icons.Default.CropFree, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Full Frame", maxLines = 1, fontSize = 12.sp)
                            }

                            if (cropSettings.autoCropEnabled) {
                                FilledTonalButton(
                                    onClick = {
                                        val detected = ImageCropUtils.detectDocumentEdges(bmp, cropSettings.autoDetectSensitivity)
                                        cropSelection = detected
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(42.dp)
                                        .testTag("crop_auto_redetect_button"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = Color(0xFF263A50),
                                        contentColor = Color.White
                                    )
                                ) {
                                    Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(15.dp), tint = Color(0xFF7DD3FC))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Auto Edge", maxLines = 1, fontSize = 12.sp)
                                }
                            }

                            FilledTonalButton(
                                onClick = {
                                    isCropActive = false
                                    cropSelection = CropSelection(0f, 0f, 1f, 1f)
                                    Toast.makeText(context, "Crop cancelled. Raw full image will be attached.", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("crop_cancel_active_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color(0xFF4C3A66),
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(Icons.Default.Close, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Cancel", maxLines = 1, fontSize = 12.sp)
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    // Primary Actions: Retake vs Attach
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = onCancel,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("crop_retake_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Retake", color = Color.White)
                        }

                        Button(
                            onClick = {
                                if (isProcessing) return@Button
                                isProcessing = true

                                scope.launch(Dispatchers.IO) {
                                    // If user didn't activate crop or left full selection with no rotation:
                                    // Attach the untouched original raw image file directly!
                                    if (!isCropActive || cropSelection.isFull) {
                                        if (rotationDegrees % 360 == 0) {
                                            withContext(Dispatchers.Main) {
                                                isProcessing = false
                                                onConfirmCrop(imageFile)
                                            }
                                            return@launch
                                        }
                                    }

                                    // Otherwise crop according to user's manual selection
                                    val destinationFile = File(
                                        imageFile.parentFile,
                                        "attached_${System.currentTimeMillis()}.jpg"
                                    )

                                    val finalCrop = if (!isCropActive) CropSelection(0f, 0f, 1f, 1f) else cropSelection
                                    val success = ImageCropUtils.cropAndSave(
                                        sourceFile = imageFile,
                                        destFile = destinationFile,
                                        crop = finalCrop,
                                        rotationDegrees = rotationDegrees
                                    )

                                    withContext(Dispatchers.Main) {
                                        isProcessing = false
                                        if (success && destinationFile.exists()) {
                                            onConfirmCrop(destinationFile)
                                        } else {
                                            onConfirmCrop(imageFile)
                                        }
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1.8f)
                                .height(50.dp)
                                .testTag("crop_confirm_button"),
                            enabled = !isProcessing,
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isProcessing) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text("Attaching…", fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.Check, null)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = if (isCropActive && !cropSelection.isFull) "Attach Cropped Photo" else "Attach Full Photo",
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * High-performance 60fps Interactive Crop View.
 *
 * The image is rendered as a clean Compose Image layer underneath.
 * The interactive Canvas on top ONLY renders the crop rectangle, handles, and dark mask,
 * ensuring zero texture reallocations and ultra-smooth, unconstrained corner dragging.
 */
@Composable
fun InteractiveCropCanvas(
    imageBitmap: ImageBitmap,
    rotationDegrees: Int,
    cropSelection: CropSelection,
    isCroppingActive: Boolean,
    onCropChange: (CropSelection) -> Unit,
    showGrid: Boolean,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val cornerGrabRadiusPx = with(density) { 64.dp.toPx() } // Generous 64dp corner grab radius
    val edgeGrabRadiusPx = with(density) { 44.dp.toPx() }

    var activeHandle by remember { mutableStateOf(DragHandle.NONE) }

    val currentCropSelection by rememberUpdatedState(cropSelection)
    val currentOnCropChange by rememberUpdatedState(onCropChange)

    BoxWithConstraints(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        val containerWidth = constraints.maxWidth.toFloat()
        val containerHeight = constraints.maxHeight.toFloat()

        // Calculate aspect-fit geometry
        val isSideways = rotationDegrees % 180 != 0
        val imageW = if (isSideways) imageBitmap.height.toFloat() else imageBitmap.width.toFloat()
        val imageH = if (isSideways) imageBitmap.width.toFloat() else imageBitmap.height.toFloat()

        val scale = min(containerWidth / imageW, containerHeight / imageH)
        val fitWidth = imageW * scale
        val fitHeight = imageH * scale
        val offsetX = (containerWidth - fitWidth) / 2f
        val offsetY = (containerHeight - fitHeight) / 2f

        val imageRect = Rect(offsetX, offsetY, offsetX + fitWidth, offsetY + fitHeight)
        val currentImageRect by rememberUpdatedState(imageRect)

        val fitWidthDp = with(density) { fitWidth.toDp() }
        val fitHeightDp = with(density) { fitHeight.toDp() }

        // Layer 1: Background Image (Rendered cleanly, does NOT repaint on drag events)
        Box(
            modifier = Modifier
                .size(fitWidthDp, fitHeightDp)
                .align(Alignment.Center)
        ) {
            Image(
                bitmap = imageBitmap,
                contentDescription = "Captured Invoice",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .rotate(rotationDegrees.toFloat())
            )
        }

        // Layer 2: Interactive Crop Canvas (Runs on top with instant gesture tracking)
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(isCroppingActive) {
                    if (!isCroppingActive) return@pointerInput

                    detectDragGestures(
                        onDragStart = { startPos ->
                            val r = currentImageRect
                            val sel = currentCropSelection

                            val leftPx = r.left + sel.left * r.width
                            val topPx = r.top + sel.top * r.height
                            val rightPx = r.left + sel.right * r.width
                            val bottomPx = r.top + sel.bottom * r.height
                            val midXPx = (leftPx + rightPx) / 2f
                            val midYPx = (topPx + bottomPx) / 2f

                            fun dist(x: Float, y: Float) =
                                sqrt(((startPos.x - x) * (startPos.x - x) + (startPos.y - y) * (startPos.y - y)).toDouble()).toFloat()

                            val dTL = dist(leftPx, topPx)
                            val dTR = dist(rightPx, topPx)
                            val dBR = dist(rightPx, bottomPx)
                            val dBL = dist(leftPx, bottomPx)

                            // 1. Highest Priority: 4 Corners
                            val minCornerDist = minOf(dTL, dTR, dBR, dBL)
                            if (minCornerDist <= cornerGrabRadiusPx) {
                                activeHandle = when (minCornerDist) {
                                    dTL -> DragHandle.TOP_LEFT
                                    dTR -> DragHandle.TOP_RIGHT
                                    dBR -> DragHandle.BOTTOM_RIGHT
                                    else -> DragHandle.BOTTOM_LEFT
                                }
                                return@detectDragGestures
                            }

                            // 2. 4 Edges
                            val dTop = dist(midXPx, topPx)
                            val dBottom = dist(midXPx, bottomPx)
                            val dLeft = dist(leftPx, midYPx)
                            val dRight = dist(rightPx, midYPx)
                            val minEdgeDist = minOf(dTop, dBottom, dLeft, dRight)
                            if (minEdgeDist <= edgeGrabRadiusPx) {
                                activeHandle = when (minEdgeDist) {
                                    dTop -> DragHandle.EDGE_TOP
                                    dBottom -> DragHandle.EDGE_BOTTOM
                                    dLeft -> DragHandle.EDGE_LEFT
                                    else -> DragHandle.EDGE_RIGHT
                                }
                                return@detectDragGestures
                            }

                            // 3. Center Body (Only if crop is not full frame, else grab closest corner)
                            val isFullOrNearFull = sel.width >= 0.90f && sel.height >= 0.90f
                            if (!isFullOrNearFull && startPos.x in leftPx..rightPx && startPos.y in topPx..bottomPx) {
                                activeHandle = DragHandle.CENTER_BODY
                            } else {
                                // Default to closest corner so touch is never ignored
                                activeHandle = when (minCornerDist) {
                                    dTL -> DragHandle.TOP_LEFT
                                    dTR -> DragHandle.TOP_RIGHT
                                    dBR -> DragHandle.BOTTOM_RIGHT
                                    else -> DragHandle.BOTTOM_LEFT
                                }
                            }
                        },
                        onDragEnd = { activeHandle = DragHandle.NONE },
                        onDragCancel = { activeHandle = DragHandle.NONE },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val r = currentImageRect
                            if (activeHandle == DragHandle.NONE || r.width <= 0f || r.height <= 0f) return@detectDragGestures

                            // Direct absolute touch tracking: corner follows finger directly with zero lag/drift
                            val touchX = change.position.x
                            val touchY = change.position.y
                            val normTouchX = ((touchX - r.left) / r.width).coerceIn(0f, 1f)
                            val normTouchY = ((touchY - r.top) / r.height).coerceIn(0f, 1f)

                            val minSpan = 0.04f
                            val current = currentCropSelection

                            val updated = when (activeHandle) {
                                DragHandle.TOP_LEFT -> current.copy(
                                    left = normTouchX.coerceAtMost(current.right - minSpan),
                                    top = normTouchY.coerceAtMost(current.bottom - minSpan)
                                )
                                DragHandle.TOP_RIGHT -> current.copy(
                                    right = normTouchX.coerceAtLeast(current.left + minSpan),
                                    top = normTouchY.coerceAtMost(current.bottom - minSpan)
                                )
                                DragHandle.BOTTOM_RIGHT -> current.copy(
                                    right = normTouchX.coerceAtLeast(current.left + minSpan),
                                    bottom = normTouchY.coerceAtLeast(current.top + minSpan)
                                )
                                DragHandle.BOTTOM_LEFT -> current.copy(
                                    left = normTouchX.coerceAtMost(current.right - minSpan),
                                    bottom = normTouchY.coerceAtLeast(current.top + minSpan)
                                )
                                DragHandle.EDGE_TOP -> current.copy(
                                    top = normTouchY.coerceAtMost(current.bottom - minSpan)
                                )
                                DragHandle.EDGE_BOTTOM -> current.copy(
                                    bottom = normTouchY.coerceAtLeast(current.top + minSpan)
                                )
                                DragHandle.EDGE_LEFT -> current.copy(
                                    left = normTouchX.coerceAtMost(current.right - minSpan)
                                )
                                DragHandle.EDGE_RIGHT -> current.copy(
                                    right = normTouchX.coerceAtLeast(current.left + minSpan)
                                )
                                DragHandle.CENTER_BODY -> {
                                    val dxNorm = dragAmount.x / r.width
                                    val dyNorm = dragAmount.y / r.height
                                    val w = current.right - current.left
                                    val h = current.bottom - current.top
                                    var newL = current.left + dxNorm
                                    var newT = current.top + dyNorm
                                    if (newL < 0f) newL = 0f
                                    if (newT < 0f) newT = 0f
                                    if (newL + w > 1f) newL = 1f - w
                                    if (newT + h > 1f) newT = 1f - h
                                    current.copy(left = newL, top = newT, right = newL + w, bottom = newT + h)
                                }
                                DragHandle.NONE -> current
                            }
                            currentOnCropChange(updated)
                        }
                    )
                }
        ) {
            // When crop is NOT active: Show subtle border indicating complete raw photo
            if (!isCroppingActive) {
                drawRect(
                    color = Color.White.copy(alpha = 0.25f),
                    topLeft = imageRect.topLeft,
                    size = imageRect.size,
                    style = Stroke(width = 1.dp.toPx())
                )
                return@Canvas
            }

            // 1. Crop Geometry
            val cropRectPx = Rect(
                left = imageRect.left + cropSelection.left * imageRect.width,
                top = imageRect.top + cropSelection.top * imageRect.height,
                right = imageRect.left + cropSelection.right * imageRect.width,
                bottom = imageRect.top + cropSelection.bottom * imageRect.height
            )

            // 2. Dimmed Mask Outside Crop Selection
            val cropPath = Path().apply {
                addRect(cropRectPx)
            }

            clipPath(cropPath, clipOp = ClipOp.Difference) {
                drawRect(
                    color = Color.Black.copy(alpha = 0.65f),
                    topLeft = imageRect.topLeft,
                    size = imageRect.size
                )
            }

            // 3. Crop Rectangle Border
            drawRect(
                color = Color.White,
                topLeft = cropRectPx.topLeft,
                size = cropRectPx.size,
                style = Stroke(width = 2.dp.toPx())
            )

            // 4. Rule-of-Thirds Grid
            if (showGrid) {
                val thirdW = cropRectPx.width / 3f
                val thirdH = cropRectPx.height / 3f
                val gridColor = Color.White.copy(alpha = 0.35f)

                drawLine(
                    color = gridColor,
                    start = Offset(cropRectPx.left + thirdW, cropRectPx.top),
                    end = Offset(cropRectPx.left + thirdW, cropRectPx.bottom),
                    strokeWidth = 1.dp.toPx()
                )
                drawLine(
                    color = gridColor,
                    start = Offset(cropRectPx.left + 2 * thirdW, cropRectPx.top),
                    end = Offset(cropRectPx.left + 2 * thirdW, cropRectPx.bottom),
                    strokeWidth = 1.dp.toPx()
                )
                drawLine(
                    color = gridColor,
                    start = Offset(cropRectPx.left, cropRectPx.top + thirdH),
                    end = Offset(cropRectPx.right, cropRectPx.top + thirdH),
                    strokeWidth = 1.dp.toPx()
                )
                drawLine(
                    color = gridColor,
                    start = Offset(cropRectPx.left, cropRectPx.top + 2 * thirdH),
                    end = Offset(cropRectPx.right, cropRectPx.top + 2 * thirdH),
                    strokeWidth = 1.dp.toPx()
                )
            }

            // 5. Corner L-Brackets
            val bracketLength = 22.dp.toPx()
            val bracketStroke = 4.dp.toPx()
            val bracketColor = Color(0xFFC4B5FD) // Bright Lilac/Violet Accent

            drawLine(bracketColor, cropRectPx.topLeft, Offset(cropRectPx.topLeft.x + bracketLength, cropRectPx.topLeft.y), bracketStroke)
            drawLine(bracketColor, cropRectPx.topLeft, Offset(cropRectPx.topLeft.x, cropRectPx.topLeft.y + bracketLength), bracketStroke)

            drawLine(bracketColor, cropRectPx.topRight, Offset(cropRectPx.topRight.x - bracketLength, cropRectPx.topRight.y), bracketStroke)
            drawLine(bracketColor, cropRectPx.topRight, Offset(cropRectPx.topRight.x, cropRectPx.topRight.y + bracketLength), bracketStroke)

            drawLine(bracketColor, cropRectPx.bottomRight, Offset(cropRectPx.bottomRight.x - bracketLength, cropRectPx.bottomRight.y), bracketStroke)
            drawLine(bracketColor, cropRectPx.bottomRight, Offset(cropRectPx.bottomRight.x, cropRectPx.bottomRight.y - bracketLength), bracketStroke)

            drawLine(bracketColor, cropRectPx.bottomLeft, Offset(cropRectPx.bottomLeft.x + bracketLength, cropRectPx.bottomLeft.y), bracketStroke)
            drawLine(bracketColor, cropRectPx.bottomLeft, Offset(cropRectPx.bottomLeft.x, cropRectPx.bottomLeft.y + bracketLength), bracketStroke)

            // 6. Circular Corner Knobs (with dynamic highlight when touched)
            val baseRadius = 15.dp.toPx()
            val corners = listOf(
                Pair(cropRectPx.topLeft, DragHandle.TOP_LEFT),
                Pair(cropRectPx.topRight, DragHandle.TOP_RIGHT),
                Pair(cropRectPx.bottomRight, DragHandle.BOTTOM_RIGHT),
                Pair(cropRectPx.bottomLeft, DragHandle.BOTTOM_LEFT)
            )

            corners.forEach { (pt, handleType) ->
                val isActive = activeHandle == handleType
                val handleRadius = if (isActive) baseRadius + 3.dp.toPx() else baseRadius

                // Dark drop shadow
                drawCircle(
                    color = Color.Black.copy(alpha = 0.5f),
                    radius = handleRadius + 3.dp.toPx(),
                    center = pt
                )
                // White outer ring
                drawCircle(
                    color = Color.White,
                    radius = handleRadius,
                    center = pt
                )
                // Center core
                drawCircle(
                    color = if (isActive) Color(0xFFC4B5FD) else Color(0xFF7C3AED),
                    radius = handleRadius - 3.5.dp.toPx(),
                    center = pt
                )
            }

            // 7. Edge Pill Grips
            val edgeRadius = 4.dp.toPx()
            val edgeColor = Color.White.copy(alpha = 0.95f)
            val midTop = Offset((cropRectPx.left + cropRectPx.right) / 2f, cropRectPx.top)
            val midBottom = Offset((cropRectPx.left + cropRectPx.right) / 2f, cropRectPx.bottom)
            val midLeft = Offset(cropRectPx.left, (cropRectPx.top + cropRectPx.bottom) / 2f)
            val midRight = Offset(cropRectPx.right, (cropRectPx.top + cropRectPx.bottom) / 2f)

            drawRoundRect(
                color = edgeColor,
                topLeft = Offset(midTop.x - 14.dp.toPx(), midTop.y - 3.dp.toPx()),
                size = Size(28.dp.toPx(), 6.dp.toPx()),
                cornerRadius = CornerRadius(edgeRadius, edgeRadius)
            )
            drawRoundRect(
                color = edgeColor,
                topLeft = Offset(midBottom.x - 14.dp.toPx(), midBottom.y - 3.dp.toPx()),
                size = Size(28.dp.toPx(), 6.dp.toPx()),
                cornerRadius = CornerRadius(edgeRadius, edgeRadius)
            )
            drawRoundRect(
                color = edgeColor,
                topLeft = Offset(midLeft.x - 3.dp.toPx(), midLeft.y - 14.dp.toPx()),
                size = Size(6.dp.toPx(), 28.dp.toPx()),
                cornerRadius = CornerRadius(edgeRadius, edgeRadius)
            )
            drawRoundRect(
                color = edgeColor,
                topLeft = Offset(midRight.x - 3.dp.toPx(), midRight.y - 14.dp.toPx()),
                size = Size(6.dp.toPx(), 28.dp.toPx()),
                cornerRadius = CornerRadius(edgeRadius, edgeRadius)
            )
        }
    }
}
