package com.example

import com.example.util.DateInput
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** Date typed in the search box must follow the server's configured format. */
class DateInputTest {

    @Test
    fun usFormatIsConvertedToIso() {
        assertEquals("2026-10-17", DateInput.toIso("10/17/2026", "MM/DD/YYYY"))
    }

    @Test
    fun europeanFormatIsConvertedToIso() {
        assertEquals("2026-10-17", DateInput.toIso("17/10/2026", "DD/MM/YYYY"))
    }

    @Test
    fun dottedAndDashedFormatsAreConverted() {
        assertEquals("2026-03-05", DateInput.toIso("05.03.2026", "DD.MM.YYYY"))
        assertEquals("2026-03-05", DateInput.toIso("05-03-2026", "DD-MM-YYYY"))
        assertEquals("2026-03-05", DateInput.toIso("2026/03/05", "YYYY/MM/DD"))
    }

    @Test
    fun isoIsAlwaysAccepted() {
        assertEquals("2026-10-17", DateInput.toIso("2026-10-17", "MM/DD/YYYY"))
    }

    @Test
    fun serialIsNotADate() {
        assertNull(DateInput.toIso("0001", "MM/DD/YYYY"))
        assertNull(DateInput.toIso("0042", "YYYY-MM-DD"))
    }

    @Test
    fun impossibleDatesAreRejected() {
        assertNull(DateInput.toIso("02/30/2026", "MM/DD/YYYY"))
        assertNull(DateInput.toIso("13/01/2026", "MM/DD/YYYY"))
        assertNull(DateInput.toIso("2025-02-29", "YYYY-MM-DD"))
        assertEquals("2028-02-29", DateInput.toIso("02/29/2028", "MM/DD/YYYY"))
    }

    @Test
    fun wrongSeparatorIsRejected() {
        assertNull(DateInput.toIso("10-17-2026", "MM/DD/YYYY"))
    }

    @Test
    fun blankFormatFallsBackToIso() {
        assertEquals("YYYY-MM-DD", DateInput.example(""))
        assertEquals("MM/DD/YYYY", DateInput.example("MM/DD/YYYY"))
        assertEquals("2026-10-17", DateInput.toIso("2026-10-17", ""))
    }
}
