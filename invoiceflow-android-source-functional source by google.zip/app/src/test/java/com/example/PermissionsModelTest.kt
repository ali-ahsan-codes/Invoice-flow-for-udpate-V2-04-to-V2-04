package com.example

import com.example.data.Cap
import com.example.data.Me
import com.example.viewmodel.UiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pure JVM checks for the admin-controlled permission switches (no Android runtime needed). */
class PermissionsModelTest {

    @Test
    fun missingSwitchMeansAllowed() {
        // Older servers do not send `capabilities`; everything stays available.
        val me = Me(id = 1, username = "sarah")
        assertTrue(me.allows(Cap.LINKS_CREATE))
        assertTrue(me.allows(Cap.MEDIA_UPLOAD))
    }

    @Test
    fun explicitDenyIsHonouredAndOthersStayOn() {
        val me = Me(
            id = 1,
            username = "sarah",
            capabilities = mapOf(Cap.LINKS_CREATE to false, Cap.NOTES_CREATE to true),
        )
        assertFalse(me.allows(Cap.LINKS_CREATE))
        assertTrue(me.allows(Cap.NOTES_CREATE))
        assertTrue(me.allows(Cap.MEDIA_UPLOAD))
    }

    @Test
    fun screenStateUsesTheSameRule() {
        assertTrue(UiState().allows(Cap.NOTES_DELETE))
        assertFalse(UiState(permissions = mapOf(Cap.NOTES_DELETE to false)).allows(Cap.NOTES_DELETE))
    }

    @Test
    fun deniedMessageNamesTheFunction() {
        assertEquals(
            "Your admin has not allowed you to link invoices.",
            Cap.deniedMessage(Cap.LINKS_CREATE),
        )
    }

    @Test
    fun clientKeysExistOnServerCatalogue() {
        // Must match CAPABILITY_KEYS in server app/permissions.py.
        val serverKeys = setOf(
            "mobile.access", "invoice.create", "invoice.edit", "invoice.delete",
            "media.upload", "media.delete", "notes.create", "notes.delete",
            "links.create", "links.delete", "data.export", "data.import",
        )
        val clientKeys = setOf(
            Cap.MOBILE_ACCESS, Cap.MEDIA_UPLOAD, Cap.MEDIA_DELETE, Cap.NOTES_CREATE,
            Cap.NOTES_DELETE, Cap.LINKS_CREATE, Cap.LINKS_DELETE,
        )
        assertTrue(serverKeys.containsAll(clientKeys))
    }
}
