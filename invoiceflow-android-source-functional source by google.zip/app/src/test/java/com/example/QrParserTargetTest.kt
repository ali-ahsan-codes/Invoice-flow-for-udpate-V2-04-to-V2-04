package com.example

import com.example.data.QrParser
import com.example.data.ScannedQr
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

/** The server's invoice QR now says whether a scan is for a document upload or a note attachment. */
@RunWith(RobolectricTestRunner::class)
class QrParserTargetTest {

    private fun invoice(raw: String): ScannedQr.Invoice {
        val parsed = QrParser.parse(raw)
        assertTrue("expected an invoice QR", parsed is ScannedQr.Invoice)
        return parsed as ScannedQr.Invoice
    }

    @Test
    fun noteTargetIsParsed() {
        val payload = invoice(
            """{"type":"invoice","version":2,"batch_id":2,"invoice_id":18,"serial":"0001",""" +
                """"base_url":"https://example.test","scan":"focus","target":"note"}"""
        ).payload
        assertEquals("note", payload.target)
        assertEquals("focus", payload.scan)
        assertEquals(2, payload.batchId)
    }

    @Test
    fun missingTargetMeansInvoiceUpload() {
        // QR printed before this release has no target field.
        val payload = invoice(
            """{"type":"invoice","version":2,"batch_id":2,"serial":"0007","scan":"auto"}"""
        ).payload
        assertEquals("invoice", payload.target)
    }

    @Test
    fun unknownTargetFallsBackToInvoice() {
        val payload = invoice(
            """{"type":"invoice","version":2,"batch_id":2,"serial":"0007","target":"something-else"}"""
        ).payload
        assertEquals("invoice", payload.target)
    }
}
